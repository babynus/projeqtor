Subdir testing
==============

This is a file in the ``subdir`` directory

Back to the :doc:`/index` ?

This is the :doc:`testing_sub` page

Testing include:

.. include:: testinclude.rst
