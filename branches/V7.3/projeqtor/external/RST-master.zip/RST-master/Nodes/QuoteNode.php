<?php

namespace Gregwar\RST\Nodes;

abstract class QuoteNode extends CodeNode
{
}
