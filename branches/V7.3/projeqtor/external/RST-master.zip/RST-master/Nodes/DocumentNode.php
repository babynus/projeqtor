<?php

namespace Gregwar\RST\Nodes;

use Gregwar\RST\Nodes\Node as Base;

class DocumentNode extends Base
{
    public function render()
    {
        return '';
    }
}
