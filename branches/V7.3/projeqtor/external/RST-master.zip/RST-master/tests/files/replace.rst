
Hello |name|

.. |name| replace:: world!

