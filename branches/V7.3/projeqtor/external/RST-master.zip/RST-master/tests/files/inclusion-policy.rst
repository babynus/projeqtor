Test the inclusion policy:

.. include:: subdir/test.rst

.. include:: inclusion-scope-include.rst

.. include:: ../html/include-external.rst
