
Inclusion test
==============

.. include:: include.rst
