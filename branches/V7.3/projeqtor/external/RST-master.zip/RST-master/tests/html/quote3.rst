
.. image:: /test.jpg

    This should be a quote, right?
