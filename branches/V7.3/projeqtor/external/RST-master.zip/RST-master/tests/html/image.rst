
.. image:: test.jpg
.. image:: try.jpg
    :width: 123

.. image:: other.jpg
    :title: Other

