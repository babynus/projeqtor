
This is a direct link to `Google <http://www.google.com/>`_, This is a link to `xkcd`_ spacy

This is another link to something_

This is an `anonymous link`__

__ http://anonymous.com/

I love GitHub__

.. __: http://www.github.com/

This is a under_score that is not supposed to be used

.. _`xkcd`: http://xkcd.com/
.. _something: http://something.com/
