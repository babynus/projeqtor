
.. figure:: foo.jpg
    :width: 100

    This is a foo!
