
Testing an ordered list:

1. First item
2. Second item
3. Third item

