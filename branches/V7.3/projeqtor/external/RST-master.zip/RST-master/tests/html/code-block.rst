
.. code-block:: c++

    #include <iostream>

    using namespace std;

    int main(void)
    {
        cout << "Hello world!" << endl;
    }
