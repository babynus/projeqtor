
This is an |inline| image!

.. |inline| image:: test.jpg

