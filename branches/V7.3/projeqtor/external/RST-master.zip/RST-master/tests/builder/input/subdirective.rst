Sub directives
==============

Testing sub directives

.. note::
    This is a simple note!

    There is a title here
    ---------------------

.. note::
    * This is a list
    * With two points
