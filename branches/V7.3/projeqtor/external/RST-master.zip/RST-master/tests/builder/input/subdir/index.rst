.. url:: test

Subdirectory
============

Relative `link </to/resource>`_

Absolute `test <http://absolute/>`_

You can click `here <http://google.com>`__ or `here <http://yahoo.com>`__

This is `something`_, and this is again `something`_

.. _something: http://something.com/

Reference to the :doc:`/index`
