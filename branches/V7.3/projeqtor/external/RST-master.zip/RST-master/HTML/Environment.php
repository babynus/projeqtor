<?php

namespace Gregwar\RST\HTML;

use Gregwar\RST\Environment as Base;

class Environment extends Base
{
}
