-- *** COPYRIGHT NOTICE *********************************************************
-- *
-- * Copyright 2016 ProjeQtOr - Pascal BERNARD - support@projeqtor.org
-- *
-- ******************************************************************************
-- *** WARNING *** T H I S    F I L E    I S    N O T    O P E N    S O U R C E *
-- ******************************************************************************
-- *
-- * This file is an add-on to ProjeQtOr, packaged as a plug-in module.
-- * It is NOT distributed under an open source license. 
-- * It is distributed in a proprietary mode, only to the customer who bought
-- * corresponding licence. 
-- * The company ProjeQtOr remains owner of all add-ons it delivers.
-- * Any change to an add-ons without the explicit agreement of the company 
-- * ProjeQtOr is prohibited.
-- * The diffusion (or any kind if distribution) of an add-on is prohibited.
-- * Violators will be prosecuted.
-- *    
-- *** DO NOT REMOVE THIS NOTICE ************************************************/

-- ///////////////////////////////////////////////////////////////////////////////
-- // PROJECTOR PERSONALIZED TRANSLATION PLUGIN                                 //
-- // Allows definition of new field names and change all translated texts.     //
-- ///////////////////////////////////////////////////////////////////////////////

INSERT INTO `${prefix}menu` (`id`, `name`, `idMenu`, `type`, `sortOrder`, `level`, `idle`, `menuClass`) VALUES
(100006001, 'menuKanban', 0, 'item', 35, NULL, 0, 'Work Risk RequirementTest Financial Meeting ');        

CREATE TABLE `${prefix}kanban` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `idUser` int(12),
  `isShared` int(1),
  `name`  varchar(64),
  `type`  varchar(64),
  `param` varchar(10000),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;