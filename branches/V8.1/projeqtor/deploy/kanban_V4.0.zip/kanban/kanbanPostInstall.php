<?php 
/*** COPYRIGHT NOTICE *********************************************************
 *
******************************************************************************
*** WARNING *** T H I S    F I L E    I S    N O T    O P E N    S O U R C E *
******************************************************************************
*
* Copyright 2015 ProjeQtOr - Pascal BERNARD - support@projeqtor.org
*
* This file is an add-on to ProjeQtOr, packaged as a plug-in module.
* It is NOT distributed under an open source license.
* It is distributed in a proprietary mode, only to the customer who bought
* corresponding licence.
* The company ProjeQtOr remains owner of all add-ons it delivers.
* Any change to an add-ons without the explicit agreement of the company
* ProjeQtOr is prohibited.
* The diffusion (or any kind if distribution) of an add-on is prohibited.
* Violators will be prosecuted.
*
*** DO NOT REMOVE THIS NOTICE ************************************************/

$getList=SqlList::getListWithCrit("Plugin", array("uniqueCode"=>100006));
$alreadyExist=count($getList)!=0;

if(!$alreadyExist){
  $hab=SqlElement::getSingleSqlElementFromCriteria('Habilitation',array('idMenu'=>'100006001','idProfile'=>getSessionUser()->idProfile));
  $hab->idProfile=getSessionUser()->idProfile;
  $hab->idMenu='100006001';
  $hab->allowAccess=1;
  $hab->save();
  Habilitation::correctUpdates();
  
  if (SqlElement::class_exists('HabilitationSuperAdmin')) {
    $hab=SqlElement::getSingleSqlElementFromCriteria('HabilitationSuperAdmin',array('idMenu'=>'100006001'));
    $hab->idMenu='100006001';
    $hab->save();
  }
  
  $objStatus = new Status();
  $listStatus=$objStatus->getSqlElementsFromCriteria(null,false);
  $listStatusWithOrder=array();
  foreach ($listStatus as $line){
    $listStatusWithOrder[$line->sortOrder.'-'.$line->id]=$line;
  }
  ksort($listStatusWithOrder);
  $kanban=new Kanban();
  $listColumn=array();
  $stat=0;
  foreach ($listStatusWithOrder as $line){
    if($stat==0 && !$line->setHandledStatus && !$line->setDoneStatus && !$line->setIdleStatus){
      $listColumn['column'][$stat]['from']=$line->id;
      $listColumn['column'][$stat]['name']=ucfirst ("backlog");
      $listColumn['column'][$stat]['cantDelete']=true;
      $stat++;
    }else
    if($stat==1 && $line->setHandledStatus){
      $listColumn['column'][$stat]['from']=$line->id;
      $listColumn['column'][$stat]['name']=ucfirst (i18n("colHandled"));
      $stat++;
    }else
    if($stat==2 && $line->setDoneStatus){
      $listColumn['column'][$stat]['from']=$line->id;
      $listColumn['column'][$stat]['name']=ucfirst (i18n("colDone"));
      $stat++;
    }else
    if($stat==3 && $line->setIdleStatus){
      $listColumn['column'][$stat]['from']=$line->id;
      $listColumn['column'][$stat]['name']=ucfirst (i18n("colIdle"));
      $stat++;
    }
  }
  $listColumn["typeData"]="Ticket";
  $kanban->idUser=getSessionUser()->id;
  $kanban->param=json_encode($listColumn);
  $kanban->name="Kanban";
  $kanban->type="Status";
  $kanban->isShared=0;
  $kanban->save();
}