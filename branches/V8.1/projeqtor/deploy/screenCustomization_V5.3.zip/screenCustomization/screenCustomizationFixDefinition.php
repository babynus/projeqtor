<?php
/*** COPYRIGHT NOTICE *********************************************************
 *
 ******************************************************************************
 *** WARNING *** T H I S    F I L E    I S    N O T    O P E N    S O U R C E *
 ******************************************************************************
 *
 * Copyright 2015 ProjeQtOr - Pascal BERNARD - support@projeqtor.org
 * 
 * This file is an add-on to ProjeQtOr, packaged as a plug-in module.
 * It is NOT distributed under an open source license. 
 * It is distributed in a proprietary mode, only to the customer who bought
 * corresponding licence. 
 * The company ProjeQtOr remains owner of all add-ons it delivers.
 * Any change to an add-ons without the explicit agreement of the company 
 * ProjeQtOr is prohibited.
 * The diffusion (or any kind if distribution) of an add-on is prohibited.
 * Violators will be prosecuted.
 *    
 *** DO NOT REMOVE THIS NOTICE ************************************************/
require_once "../tool/projeqtor.php";
require_once "../plugin/screenCustomization/screenCustomizationFunctions.php";
require_once "../db/maintenanceFunctions.php";
function screenCustomizationFixDefinition($fixclass) {
  global $availableAttributes; // for calling SaveField script
  $included=true;
  $fixclassMain=$fixclass.'Main';
  $fixobj=new $fixclass();
  $fixobjMain=new $fixclassMain();
  $fixlast=false;
  $fixresult="KO";
  foreach ($fixobj as $fixfld=>$fixval) {
    if ($fixfld=='_Note' or $fixfld=='_Link' or $fixfld=='_Attachment' or $fixfld=='_sec_Link') {
      $fixlast=true;
    } else if (substr($fixfld, 0,1)=='_') {
      continue; // specific field
    } else if ($fixlast and !$fixobj->isAttributeSetToField($fixfld,'hidden')) { // not a specific field, after $last (notes, attachment, link)
      $fixprec=null;
      foreach ($fixobjMain as $fixmainFld=>$fixmainVal) {
        if ($fixmainFld==$fixfld) break;
        $fixprec=$fixmainFld;
      }
      if ($fixprec) {
        $_REQUEST['screenCustomizationEditFieldObjectClass']=$fixclass;
        $_REQUEST['screenCustomizationEditFieldField']=$fixfld;
        $_REQUEST['screenCustomizationEditFieldNew']='false';
        $_REQUEST['screenCustomizationEditFieldDataType']='';
        $_REQUEST['screenCustomizationEditFieldDataLength']='';
        $_REQUEST['screenCustomizationEditFieldPosition']=$fixprec;
        $_REQUEST['screenCustomizationEditFieldName']='';
        $_REQUEST['screenCustomizationEditFieldDefaultValue']='';
        ob_start();
        include "screenCustomizationSaveField.php";
        ob_clean();
        $fixresult='OK';
      } else {
        $fixresult='KO';
      }
    }
  }
  return $fixresult;
}