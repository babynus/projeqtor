-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 24 Octobre 2016 à 07:41
-- Version du serveur :  5.7.11
-- Version de PHP :  7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projeqtor_v55`
--

-- --------------------------------------------------------

--
-- Structure de la table `accessprofile`
--

CREATE TABLE `accessprofile` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idAccessScopeRead` int(12) DEFAULT NULL,
  `idAccessScopeCreate` int(12) DEFAULT NULL,
  `idAccessScopeUpdate` int(12) DEFAULT NULL,
  `idAccessScopeDelete` int(12) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `accessprofile`
--

INSERT INTO `accessprofile` (`id`, `name`, `description`, `idAccessScopeRead`, `idAccessScopeCreate`, `idAccessScopeUpdate`, `idAccessScopeDelete`, `sortOrder`, `idle`) VALUES
(1, 'accessProfileRestrictedReader', 'Read only his projects', 3, 1, 1, 1, 100, 0),
(2, 'accessProfileGlobalReader', 'Read all projects', 4, 1, 1, 1, 150, 0),
(3, 'accessProfileRestrictedUpdater', 'Read and Update only his projects', 3, 1, 3, 1, 200, 0),
(4, 'accessProfileGlobalUpdater', 'Read and Update all projects', 4, 1, 4, 1, 250, 0),
(5, 'accessProfileRestrictedCreator', 'Read only his projects\nCan create\nUpdate and delete his own elements', 3, 3, 2, 2, 300, 0),
(6, 'accessProfileGlobalCreator', 'Read all projects\nCan create\nUpdate and delete his own elements', 4, 4, 2, 2, 350, 0),
(7, 'accessProfileRestrictedManager', 'Read only his projects\nCan create\nUpdate and delete his projects', 3, 3, 3, 3, 400, 0),
(8, 'accessProfileGlobalManager', 'Read all projects\nCan create\nUpdate and delete his projects', 4, 4, 4, 4, 450, 0),
(9, 'accessProfileNoAccess', 'no access allowed', 1, 1, 1, 1, 999, 0),
(10, 'accessReadOwnOnly', NULL, 2, 1, 1, 1, 900, 0);

-- --------------------------------------------------------

--
-- Structure de la table `accessright`
--

CREATE TABLE `accessright` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProfile` int(12) UNSIGNED DEFAULT NULL,
  `idMenu` int(12) UNSIGNED DEFAULT NULL,
  `idAccessProfile` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `accessright`
--

INSERT INTO `accessright` (`id`, `idProfile`, `idMenu`, `idAccessProfile`) VALUES
(1, 1, 3, 8),
(2, 2, 3, 2),
(3, 3, 3, 7),
(4, 4, 3, 1),
(5, 6, 3, 1),
(6, 7, 3, 1),
(7, 5, 3, 1),
(8, 1, 4, 8),
(9, 2, 4, 4),
(10, 3, 4, 7),
(11, 4, 4, 3),
(12, 6, 4, 3),
(13, 7, 4, 1),
(14, 5, 4, 1),
(15, 1, 5, 8),
(16, 2, 5, 2),
(17, 3, 5, 7),
(18, 4, 5, 1),
(19, 6, 5, 1),
(20, 7, 5, 1),
(21, 5, 5, 1),
(22, 1, 50, 8),
(23, 2, 50, 2),
(24, 3, 50, 7),
(25, 4, 50, 1),
(26, 6, 50, 9),
(27, 7, 50, 9),
(28, 5, 50, 9),
(29, 1, 22, 8),
(30, 2, 22, 2),
(31, 3, 22, 7),
(32, 4, 22, 7),
(33, 6, 22, 7),
(34, 7, 22, 5),
(35, 5, 22, 1),
(36, 1, 51, 8),
(37, 2, 51, 9),
(38, 3, 51, 7),
(39, 4, 51, 9),
(40, 6, 51, 9),
(41, 7, 51, 9),
(42, 5, 51, 9),
(43, 1, 25, 8),
(44, 2, 25, 2),
(45, 3, 25, 7),
(46, 4, 25, 3),
(47, 6, 25, 1),
(48, 7, 25, 1),
(49, 5, 25, 1),
(50, 1, 26, 8),
(51, 2, 26, 2),
(52, 3, 26, 7),
(53, 4, 26, 3),
(54, 6, 26, 1),
(55, 7, 26, 1),
(56, 5, 26, 1),
(57, 1, 16, 8),
(58, 2, 16, 2),
(59, 3, 16, 7),
(60, 4, 16, 9),
(61, 6, 16, 9),
(62, 7, 16, 9),
(63, 5, 16, 9),
(64, 1, 62, 8),
(65, 2, 62, 2),
(66, 3, 62, 7),
(67, 4, 62, 1),
(68, 6, 62, 1),
(69, 7, 62, 1),
(70, 5, 62, 1),
(71, 1, 63, 8),
(72, 2, 63, 2),
(73, 3, 63, 7),
(74, 4, 63, 1),
(75, 6, 63, 1),
(76, 7, 63, 1),
(77, 5, 63, 1),
(78, 1, 64, 8),
(79, 2, 64, 2),
(80, 3, 64, 7),
(81, 4, 64, 1),
(82, 6, 64, 1),
(83, 7, 64, 1),
(84, 5, 64, 1),
(85, 1, 69, 2),
(86, 2, 69, 9),
(87, 3, 69, 1),
(88, 4, 69, 1),
(89, 6, 69, 9),
(90, 7, 69, 9),
(91, 5, 69, 9),
(92, 1, 75, 8),
(93, 2, 75, 2),
(94, 3, 75, 7),
(95, 4, 75, 5),
(96, 6, 75, 9),
(97, 7, 75, 9),
(98, 5, 75, 9),
(99, 1, 76, 8),
(100, 2, 76, 2),
(101, 3, 76, 7),
(102, 4, 76, 9),
(103, 6, 76, 9),
(104, 7, 76, 9),
(105, 5, 76, 9),
(106, 1, 77, 8),
(107, 2, 77, 2),
(108, 3, 77, 7),
(109, 4, 77, 9),
(110, 6, 77, 9),
(111, 7, 77, 9),
(112, 5, 77, 9),
(113, 1, 78, 8),
(114, 2, 78, 2),
(115, 3, 78, 7),
(116, 4, 78, 9),
(117, 6, 78, 9),
(118, 7, 78, 9),
(119, 5, 78, 9),
(120, 1, 91, 2),
(121, 2, 91, 1),
(122, 3, 91, 1),
(123, 4, 91, 10),
(124, 6, 91, 10),
(125, 7, 91, 10),
(126, 5, 91, 10),
(127, 1, 94, 8),
(128, 1, 95, 8),
(129, 1, 96, 8),
(130, 1, 97, 8),
(131, 1, 98, 8),
(132, 1, 99, 8),
(133, 1, 100, 8),
(134, 1, 102, 8),
(135, 2, 102, 2),
(136, 3, 102, 7),
(137, 4, 102, 7),
(138, 6, 102, 1),
(139, 7, 102, 1),
(140, 5, 102, 9),
(141, 1, 111, 8),
(142, 2, 111, 2),
(143, 3, 111, 7),
(144, 4, 111, 7),
(145, 6, 111, 1),
(146, 7, 111, 1),
(147, 5, 111, 9),
(148, 1, 112, 8),
(149, 2, 112, 2),
(150, 3, 112, 7),
(151, 4, 112, 7),
(152, 6, 112, 1),
(153, 7, 112, 1),
(154, 5, 112, 9),
(155, 1, 113, 8),
(156, 2, 113, 2),
(157, 3, 113, 7),
(158, 4, 113, 7),
(159, 6, 113, 1),
(160, 7, 113, 1),
(161, 5, 113, 9),
(162, 1, 118, 8),
(163, 2, 118, 2),
(164, 3, 118, 7),
(165, 4, 118, 7),
(166, 6, 118, 7),
(167, 7, 118, 5),
(168, 5, 118, 1),
(169, 1, 119, 8),
(170, 2, 119, 2),
(171, 3, 119, 7),
(172, 4, 119, 1),
(173, 6, 119, 1),
(174, 7, 119, 1),
(175, 5, 119, 1),
(176, 1, 124, 8),
(177, 2, 124, 2),
(178, 3, 124, 7),
(179, 4, 124, 1),
(180, 6, 124, 1),
(181, 7, 124, 1),
(182, 5, 124, 1),
(183, 1, 125, 8),
(184, 1, 126, 8),
(185, 1, 131, 8),
(186, 1, 132, 8),
(187, 1, 153, 8),
(188, 1, 154, 8);

-- --------------------------------------------------------

--
-- Structure de la table `accessscope`
--

CREATE TABLE `accessscope` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `accessCode` varchar(3) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `accessscope`
--

INSERT INTO `accessscope` (`id`, `name`, `accessCode`, `sortOrder`, `idle`) VALUES
(1, 'accessScopeNo', 'NO', 100, 0),
(2, 'accessScopeOwn', 'OWN', 200, 0),
(3, 'accessScopeProject', 'PRO', 300, 0),
(4, 'accessScopeAll', 'ALL', 400, 0),
(5, 'accessScopeResp', 'RES', 250, 0);

-- --------------------------------------------------------

--
-- Structure de la table `action`
--

CREATE TABLE `action` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `initialDueDate` date DEFAULT NULL,
  `actualDueDate` date DEFAULT NULL,
  `idleDate` date DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `idActionType` int(12) UNSIGNED DEFAULT NULL,
  `idPriority` int(12) UNSIGNED DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idEfficiency` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `isPrivate` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `action`
--

INSERT INTO `action` (`id`, `idProject`, `name`, `description`, `creationDate`, `idUser`, `idStatus`, `idResource`, `initialDueDate`, `actualDueDate`, `idleDate`, `result`, `comment`, `idle`, `done`, `doneDate`, `idActionType`, `idPriority`, `handled`, `handledDate`, `reference`, `externalReference`, `idEfficiency`, `cancelled`, `isPrivate`) VALUES
(1, 1, 'Build a new environment for testing purpose', NULL, '2012-03-14', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 27, 3, 0, NULL, '001-001-PRO-1', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `activity`
--

CREATE TABLE `activity` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idActivityType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `idVersion` int(12) UNSIGNED DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idComponent` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `isPlanningActivity` int(1) UNSIGNED DEFAULT '0',
  `lastUpdateDateTime` datetime DEFAULT NULL,
  `idComponentVersion` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `activity`
--

INSERT INTO `activity` (`id`, `idProject`, `idActivityType`, `name`, `description`, `creationDate`, `idUser`, `idStatus`, `idResource`, `result`, `comment`, `idle`, `idActivity`, `done`, `idleDate`, `doneDate`, `handled`, `handledDate`, `idVersion`, `reference`, `externalReference`, `idContact`, `cancelled`, `idComponent`, `idProduct`, `isPlanningActivity`, `lastUpdateDateTime`, `idComponentVersion`) VALUES
(1, 2, 26, 'bug fixing', 'Main activity to follow-up work spent of bug fixing tickets', '2011-09-01', 1, 3, 3, NULL, NULL, 0, NULL, 0, NULL, NULL, 1, '2011-09-01', NULL, '001-001-1-TAS-1', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL),
(2, 3, 20, 'Evolution X', NULL, '2011-09-02', 1, 3, 8, NULL, NULL, 0, NULL, 0, NULL, NULL, 1, '2011-09-03', 2, '001-001-2-EVO-1', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL),
(3, 3, 26, 'Evolutoin X - Analysis', NULL, '2011-09-02', 1, 1, NULL, NULL, NULL, 0, 2, 0, NULL, NULL, 0, NULL, NULL, '001-001-2-TAS-1', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL),
(4, 3, 26, 'Evolution X - Development', NULL, '2011-09-02', 1, 1, NULL, NULL, NULL, 0, 2, 0, NULL, NULL, 0, NULL, NULL, '001-001-2-TAS-2', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL),
(5, 3, 26, 'Evolution X - Tests', NULL, '2011-09-02', 1, 1, NULL, NULL, NULL, 0, 2, 0, NULL, NULL, 0, NULL, NULL, '001-001-2-TAS-3', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL),
(6, 3, 20, 'Evolution Y', NULL, '2011-09-02', 1, 1, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, '001-001-2-EVO-2', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL),
(7, 4, 21, 'Management', NULL, '2012-03-15', 1, 1, 3, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, '001-001-TAS-1', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `activityprice`
--

CREATE TABLE `activityprice` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idActivityType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `priceCost` decimal(10,2) DEFAULT '0.00',
  `subcontractor` int(1) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) DEFAULT '0',
  `subcontractorCost` decimal(10,2) DEFAULT NULL,
  `idTeam` int(12) UNSIGNED DEFAULT NULL,
  `commissionCost` decimal(10,2) DEFAULT NULL,
  `isRef` int(1) NOT NULL DEFAULT '0',
  `pct` int(3) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `activityprice`
--

INSERT INTO `activityprice` (`id`, `idProject`, `idActivityType`, `name`, `priceCost`, `subcontractor`, `sortOrder`, `idle`, `subcontractorCost`, `idTeam`, `commissionCost`, `isRef`, `pct`, `idUser`, `creationDate`) VALUES
(1, 4, 21, 'Management (not included in fixed price)', '900.00', NULL, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `affectation`
--

CREATE TABLE `affectation` (
  `id` int(12) UNSIGNED NOT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `rate` int(3) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idRole` int(12) UNSIGNED DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idResourceSelect` int(12) UNSIGNED DEFAULT NULL,
  `idProfile` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `affectation`
--

INSERT INTO `affectation` (`id`, `idResource`, `idProject`, `rate`, `description`, `idle`, `idRole`, `startDate`, `endDate`, `idContact`, `idUser`, `idResourceSelect`, `idProfile`) VALUES
(1, 3, 1, 80, NULL, 0, NULL, NULL, NULL, NULL, 3, 3, 3),
(2, 3, 4, 20, NULL, 0, NULL, NULL, NULL, NULL, 3, 3, 3),
(3, 3, 6, 0, NULL, 0, NULL, NULL, NULL, NULL, 3, 3, 3),
(4, 4, 2, 100, NULL, 0, NULL, NULL, NULL, NULL, 4, 4, 4),
(5, 8, 3, 100, NULL, 0, NULL, NULL, NULL, NULL, 8, 8, 4),
(6, 9, 4, 100, NULL, 0, NULL, NULL, NULL, NULL, 9, 9, 4),
(7, 4, 6, 0, NULL, 0, NULL, NULL, NULL, NULL, 4, 4, 4),
(8, 8, 6, 0, NULL, 0, NULL, NULL, NULL, NULL, 8, 8, 4),
(9, 9, 6, 0, NULL, 0, NULL, NULL, NULL, NULL, 9, 9, 4),
(10, 10, 1, 100, NULL, 0, NULL, NULL, NULL, NULL, NULL, 10, 4),
(11, 11, 4, 100, NULL, 0, NULL, NULL, NULL, NULL, NULL, 11, 4),
(12, 12, 1, 80, NULL, 0, NULL, NULL, NULL, NULL, NULL, 12, 4),
(13, 12, 4, 20, NULL, 0, NULL, NULL, NULL, NULL, NULL, 12, 4),
(14, 7, 1, 100, NULL, 0, NULL, NULL, NULL, 7, NULL, NULL, 5),
(15, 5, 1, 100, NULL, 0, NULL, NULL, NULL, 5, 5, NULL, 6),
(16, 6, 4, 100, NULL, 0, NULL, NULL, NULL, 6, 6, NULL, 6),
(19, 1, 1, 100, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1),
(20, 1, 4, 100, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `alert`
--

CREATE TABLE `alert` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED DEFAULT NULL,
  `idIndicatorValue` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `alertType` varchar(10) DEFAULT NULL,
  `alertInitialDateTime` datetime DEFAULT NULL,
  `alertDateTime` datetime DEFAULT NULL,
  `alertReadDateTime` datetime DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `message` varchar(4000) DEFAULT NULL,
  `readFlag` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `alert`
--

INSERT INTO `alert` (`id`, `idProject`, `refType`, `refId`, `idIndicatorValue`, `idUser`, `alertType`, `alertInitialDateTime`, `alertDateTime`, `alertReadDateTime`, `title`, `message`, `readFlag`, `idle`) VALUES
(1, 1, 'Ticket', 1, NULL, 1, 'WARNING', '2011-10-13 17:24:39', '2011-10-13 17:24:00', '2011-10-13 17:30:15', 'WARNING - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="30%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="30%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="30%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 17:30</td></table>', 1, 0),
(2, 1, 'Ticket', 1, NULL, 3, 'WARNING', '2011-10-13 17:24:39', '2011-10-13 17:24:00', NULL, 'WARNING - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="30%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="30%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="30%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 17:30</td></table>', 0, 0),
(3, 1, 'Ticket', 1, NULL, 1, 'ALERT', '2011-10-13 17:24:39', '2011-10-13 17:24:00', '2011-10-13 17:30:19', 'ALERT - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="30%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="30%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="30%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td></table>', 1, 0),
(4, 1, 'Ticket', 1, NULL, 3, 'ALERT', '2011-10-13 17:24:39', '2011-10-13 17:24:00', NULL, 'ALERT - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="30%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="30%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="30%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td></table>', 0, 0),
(5, 1, 'Ticket', 1, NULL, 1, 'WARNING', '2011-10-13 17:24:39', '2011-10-13 17:24:00', '2011-10-13 17:30:22', 'WARNING - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="30%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of initial due date/time</td><tr><td width="30%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>02/09/2011 18:00</td><tr><td width="30%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>02/09/2011 18:00</td></table>', 1, 0),
(6, 1, 'Ticket', 1, NULL, 1, 'WARNING', '2011-10-13 17:31:53', '2011-10-13 17:31:00', '2011-10-13 17:33:13', 'WARNING - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 17:30</td></table>', 1, 0),
(7, 1, 'Ticket', 1, NULL, 3, 'WARNING', '2011-10-13 17:31:53', '2011-10-13 17:31:00', NULL, 'WARNING - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 17:30</td></table>', 0, 0),
(8, 1, 'Ticket', 1, NULL, 1, 'ALERT', '2011-10-13 17:31:53', '2011-10-13 17:31:00', '2011-10-13 17:33:33', 'ALERT - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td></table>', 1, 0),
(9, 1, 'Ticket', 1, NULL, 3, 'ALERT', '2011-10-13 17:31:53', '2011-10-13 17:31:00', NULL, 'ALERT - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of actual due date/time</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>09/09/2011 18:30</td></table>', 0, 0),
(10, 1, 'Ticket', 1, NULL, 1, 'WARNING', '2011-10-13 17:31:53', '2011-10-13 17:31:00', '2011-10-13 17:33:36', 'WARNING - Ticket #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug: it does not work</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of initial due date/time</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>02/09/2011 18:00</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>02/09/2011 18:00</td></table>', 1, 0),
(11, NULL, NULL, NULL, NULL, 1, 'INFO', '2011-10-13 17:33:00', '2011-10-13 17:33:00', '2011-10-14 14:08:43', 'Information from Admin', 'Access will be shut down tomorrow from 22:00 to 23:00', 1, 0),
(12, 2, 'Activity', 1, NULL, 1, 'WARNING', '2012-03-14 21:30:23', '2012-03-14 21:30:00', '2012-03-14 21:31:42', 'Warning - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>31/12/2011</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>30/12/2011</td></table>', 1, 0),
(13, 2, 'Activity', 1, NULL, 3, 'WARNING', '2012-03-14 21:30:23', '2012-03-14 21:30:00', NULL, 'Warning - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>31/12/2011</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>30/12/2011</td></table>', 0, 0),
(14, 2, 'Activity', 1, NULL, 1, 'ALERT', '2012-03-14 21:30:23', '2012-03-14 21:30:00', '2012-03-14 21:31:54', 'Alert - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>31/12/2011</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>31/12/2011</td></table>', 1, 0),
(15, 2, 'Activity', 1, NULL, 3, 'ALERT', '2012-03-14 21:30:23', '2012-03-14 21:30:00', NULL, 'Alert - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>31/12/2011</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>31/12/2011</td></table>', 0, 0),
(16, 2, 'Activity', 1, NULL, 3, 'WARNING', '2012-03-14 21:30:23', '2012-03-14 21:30:00', NULL, 'Warning - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">planned work compared to validated work</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>0 d</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>0 d</td></table>', 0, 0),
(17, 2, 'Activity', 1, NULL, 3, 'ALERT', '2012-03-14 21:30:23', '2012-03-14 21:30:00', NULL, 'Alert - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">planned work compared to validated work</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>0 d</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>0 d</td></table>', 0, 0),
(18, NULL, NULL, NULL, NULL, 1, 'INFO', '2012-07-26 17:38:12', '2012-07-26 17:38:12', '2012-07-26 17:38:29', 'V2.4.0', 'New version V2.4.0 is available at Project\'Or RIA website<br/><a href="http://projectorria.toolware.fr" target="#">http://projectorria.toolware.fr</a>', 1, 0),
(19, 4, 'Activity', 7, 7, 3, 'WARNING', '2014-01-05 16:51:12', '2014-01-05 16:51:00', NULL, 'Warning - Activity #7', '<table><tr><td colspan="3" style="border:1px solid grey">Management</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">planned work compared to validated work</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>0 d</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>0 d</td></table>', 0, 0),
(20, 4, 'Activity', 7, 7, 3, 'ALERT', '2014-01-05 16:51:12', '2014-01-05 16:51:00', NULL, 'Alert - Activity #7', '<table><tr><td colspan="3" style="border:1px solid grey">Management</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">planned work compared to validated work</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>0 d</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>0 d</td></table>', 0, 0),
(21, 3, 'Activity', 3, NULL, 1, 'WARNING', '2015-10-26 18:50:48', '2015-10-26 18:50:00', '2015-10-26 18:55:38', 'Warning - Activity #3', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',3);">Evolutoin X - Analysis</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>08/07/2015</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>07/07/2015</td></table>', 1, 0),
(22, 3, 'Activity', 3, NULL, 1, 'ALERT', '2015-10-26 18:50:48', '2015-10-26 18:50:00', '2015-10-26 18:55:53', 'Alert - Activity #3', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',3);">Evolutoin X - Analysis</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>08/07/2015</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>08/07/2015</td></table>', 1, 0),
(23, 2, 'Activity', 1, 5, 1, 'WARNING', '2015-10-26 18:52:36', '2015-10-26 18:52:00', '2015-10-26 18:59:06', 'Warning - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',1);">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>19/08/2015</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>18/08/2015</td></table>', 1, 0),
(24, 2, 'Activity', 1, 5, 3, 'WARNING', '2015-10-26 18:52:36', '2015-10-26 18:52:00', NULL, 'Warning - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',1);">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>19/08/2015</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>18/08/2015</td></table>', 0, 0),
(25, 2, 'Activity', 1, 5, 1, 'ALERT', '2015-10-26 18:52:36', '2015-10-26 18:52:00', '2015-10-26 18:59:31', 'Alert - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',1);">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>19/08/2015</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>19/08/2015</td></table>', 1, 0),
(26, 2, 'Activity', 1, 5, 3, 'ALERT', '2015-10-26 18:52:36', '2015-10-26 18:52:00', NULL, 'Alert - Activity #1', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',1);">bug fixing</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>19/08/2015</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>19/08/2015</td></table>', 0, 0),
(27, 4, 'Activity', 7, 9, 1, 'WARNING', '2015-10-26 18:53:16', '2015-10-26 18:53:00', '2015-10-26 18:59:39', 'Warning - Activity #7', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',7);">Management</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>24/08/2015</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>21/08/2015</td></table>', 1, 0),
(28, 4, 'Activity', 7, 9, 3, 'WARNING', '2015-10-26 18:53:16', '2015-10-26 18:53:00', NULL, 'Warning - Activity #7', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',7);">Management</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>24/08/2015</td><tr><td width="35%" align="right">warning value</td><td>&nbsp;:&nbsp;</td><td>21/08/2015</td></table>', 0, 0),
(29, 4, 'Activity', 7, 9, 1, 'ALERT', '2015-10-26 18:53:16', '2015-10-26 18:53:00', '2015-10-26 19:01:06', 'Alert - Activity #7', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',7);">Management</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>24/08/2015</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>24/08/2015</td></table>', 1, 0),
(30, 4, 'Activity', 7, 9, 3, 'ALERT', '2015-10-26 18:53:16', '2015-10-26 18:53:00', NULL, 'Alert - Activity #7', '<table><tr><td colspan="3" style="border:1px solid grey; cursor:pointer;" onClick="gotoElement(\'Activity\',7);">Management</td></tr><tr><td width="35%" align="right" valign="top">indicator</td><td valign="top">&nbsp;:&nbsp;</td><td valign="top">respect of validated end date</td><tr><td width="35%" align="right">target value</td><td>&nbsp;:&nbsp;</td><td>24/08/2015</td><tr><td width="35%" align="right">alert value</td><td>&nbsp;:&nbsp;</td><td>24/08/2015</td></table>', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `approver`
--

CREATE TABLE `approver` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED DEFAULT NULL,
  `idAffectable` int(12) UNSIGNED DEFAULT NULL,
  `approved` int(1) UNSIGNED DEFAULT '0',
  `approvedDate` datetime DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `approver`
--

INSERT INTO `approver` (`id`, `refType`, `refId`, `idAffectable`, `approved`, `approvedDate`, `idle`) VALUES
(1, 'Document', 1, 1, 0, NULL, 0),
(2, 'DocumentVersion', 4, 1, 1, '2012-05-03 18:42:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `assignment`
--

CREATE TABLE `assignment` (
  `id` int(12) UNSIGNED NOT NULL,
  `idResource` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `rate` int(3) UNSIGNED DEFAULT '100',
  `assignedWork` decimal(12,5) UNSIGNED DEFAULT NULL,
  `realWork` decimal(12,5) UNSIGNED DEFAULT NULL,
  `leftWork` decimal(12,5) UNSIGNED DEFAULT NULL,
  `plannedWork` decimal(12,5) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `realStartDate` date DEFAULT NULL,
  `realEndDate` date DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `plannedStartDate` date DEFAULT NULL,
  `plannedEndDate` date DEFAULT NULL,
  `idRole` int(12) UNSIGNED DEFAULT NULL,
  `dailyCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `newDailyCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `assignedCost` decimal(11,2) DEFAULT NULL,
  `realCost` decimal(11,2) DEFAULT NULL,
  `leftCost` decimal(11,2) DEFAULT NULL,
  `plannedCost` decimal(11,2) DEFAULT NULL,
  `billedWork` decimal(10,2) NOT NULL DEFAULT '0.00',
  `notPlannedWork` decimal(12,5) UNSIGNED DEFAULT '0.00000',
  `plannedStartFraction` decimal(6,5) DEFAULT '0.00000',
  `plannedEndFraction` decimal(6,5) DEFAULT '1.00000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `assignment`
--

INSERT INTO `assignment` (`id`, `idResource`, `idProject`, `refType`, `refId`, `rate`, `assignedWork`, `realWork`, `leftWork`, `plannedWork`, `idle`, `realStartDate`, `realEndDate`, `comment`, `plannedStartDate`, `plannedEndDate`, `idRole`, `dailyCost`, `newDailyCost`, `assignedCost`, `realCost`, `leftCost`, `plannedCost`, `billedWork`, `notPlannedWork`, `plannedStartFraction`, `plannedEndFraction`) VALUES
(1, 3, 2, 'Activity', 1, 20, '10.00000', '0.00000', '10.00000', '10.00000', 0, NULL, NULL, NULL, '2015-11-05', '2016-02-09', 1, '500.00', '500.00', '5000.00', '0.00', '5000.00', '5000.00', '0.00', '0.00000', '0.00000', '0.10000'),
(2, 10, 2, 'Activity', 1, 50, '75.20000', '0.00000', '75.20000', '75.20000', 0, NULL, NULL, NULL, '2015-11-02', '2016-02-29', 3, '220.00', '220.00', '16544.00', '0.00', '16544.00', '16544.00', '0.00', '0.00000', '0.00000', '0.14000'),
(3, 8, 3, 'Activity', 3, 100, '5.00000', '0.00000', '15.70000', '15.70000', 0, NULL, NULL, NULL, '2015-11-02', '2015-11-23', 2, '300.00', '300.00', '1500.00', '0.00', '4710.00', '4710.00', '0.00', '0.00000', '0.00000', '0.70000'),
(4, 10, 3, 'Activity', 4, 100, '10.00000', '0.00000', '10.00000', '10.00000', 0, NULL, NULL, NULL, '2015-11-24', '2015-11-26', 3, '220.00', '220.00', '2200.00', '0.00', '2200.00', '2200.00', '0.00', '0.00000', '0.10000', '0.30000'),
(5, 8, 3, 'Activity', 5, 100, '3.00000', '0.00000', '3.00000', '3.00000', 0, NULL, NULL, 'Work could be anticipated to prepare tests', '2015-11-27', '2015-12-01', 2, '300.00', '300.00', '900.00', '0.00', '900.00', '900.00', '0.00', '0.00000', '0.00000', '1.00000'),
(6, 3, 4, 'Activity', 7, 100, '0.00000', '0.00000', '9.00000', '9.00000', 0, NULL, NULL, NULL, '2015-11-06', '2016-02-29', 1, '500.00', '500.00', '0.00', '0.00', '4500.00', '4500.00', '5.00', '0.00000', '0.00000', '0.50000'),
(7, 10, 1, 'TestSession', 1, 100, '2.00000', '0.00000', '2.00000', '2.00000', 0, NULL, NULL, NULL, '2015-11-27', '2015-12-01', 3, '220.00', '220.00', '440.00', '0.00', '440.00', '440.00', '0.00', '0.00000', '0.10000', '0.24000');

-- --------------------------------------------------------

--
-- Structure de la table `attachment`
--

CREATE TABLE `attachment` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) NOT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `fileName` varchar(1024) DEFAULT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `subDirectory` varchar(100) DEFAULT NULL,
  `mimeType` varchar(100) DEFAULT NULL,
  `fileSize` int(12) UNSIGNED DEFAULT NULL,
  `link` varchar(1024) DEFAULT NULL,
  `type` varchar(10) DEFAULT 'file',
  `idPrivacy` int(12) UNSIGNED DEFAULT '1',
  `idTeam` int(12) UNSIGNED DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `attachment`
--

INSERT INTO `attachment` (`id`, `refType`, `refId`, `idUser`, `creationDate`, `fileName`, `description`, `subDirectory`, `mimeType`, `fileSize`, `link`, `type`, `idPrivacy`, `idTeam`) VALUES
(1, 'Anomaly', 3, 1, '2009-09-08 17:26:45', 'vlc.exe.manifest', 'Test fichier', 'D:\\TEMP\\attachment_1\\', 'application/octet-stream', 606, NULL, 'file', 1, NULL),
(2, 'Ticket', 1, 1, '2011-10-13 18:28:19', 'readme.txt', 'readme file', '../files/attach//attachment_2/', 'text/plain', 1183, NULL, 'file', 1, NULL),
(3, 'Project', 1, 1, '2012-05-03 16:10:57', 'projectorria.toolware.fr', 'Project\'Or RIA', NULL, NULL, NULL, 'projectorria.toolware.fr', 'link', 1, NULL),
(4, 'Project', 1, 1, '2012-05-03 16:11:22', 'Google', 'www.google.com', NULL, NULL, NULL, 'Google', 'link', 1, NULL),
(5, 'Project', 4, 1, '2012-05-03 16:23:48', 'dojotoolkit.org', 'Dojo Toolkit', NULL, NULL, NULL, 'http://dojotoolkit.org/', 'link', 1, NULL),
(6, 'Ticket', 2, 1, '2014-01-05 16:21:04', 'license.txt', NULL, '${attachmentDirectory}\\attachment_6\\', 'text/plain', 35147, NULL, 'file', 1, NULL),
(7, 'Ticket', 2, 1, '2014-01-05 16:22:01', 'Tel.doc', NULL, '${attachmentDirectory}\\attachment_7\\', 'application/msword', 208384, NULL, 'file', 1, NULL),
(8, 'Ticket', 2, 1, '2014-01-05 16:22:58', 'recent', 'Forum : Recent topics', NULL, NULL, NULL, 'http://www.projeqtor.org/index.php/forum/recent', 'link', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `audit`
--

CREATE TABLE `audit` (
  `id` int(12) UNSIGNED NOT NULL,
  `sessionId` varchar(100) DEFAULT NULL,
  `auditDay` varchar(8) DEFAULT NULL,
  `connectionDateTime` datetime DEFAULT NULL,
  `disconnectionDateTime` datetime DEFAULT NULL,
  `lastAccessDateTime` datetime DEFAULT NULL,
  `duration` time DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `userName` varchar(100) DEFAULT NULL,
  `userAgent` varchar(400) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `browserVersion` varchar(100) DEFAULT NULL,
  `requestRefreshParam` int(1) DEFAULT '0',
  `requestDisconnection` int(1) DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `requestRefreshProject` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `audit`
--

INSERT INTO `audit` (`id`, `sessionId`, `auditDay`, `connectionDateTime`, `disconnectionDateTime`, `lastAccessDateTime`, `duration`, `idUser`, `userName`, `userAgent`, `platform`, `browser`, `browserVersion`, `requestRefreshParam`, `requestDisconnection`, `idle`, `requestRefreshProject`) VALUES
(1, 'durcvufq4v2aj8o2gnqau8deh0', '20140104', '2014-01-04 18:26:52', '2014-01-04 18:34:51', '2014-01-04 18:34:51', '00:07:59', 1, 'admin', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36', 'Windows', 'Google Chrome', '31.0.1650.63', 0, 0, 1, 0),
(2, 'p7ki3gkilk164h4rluk4nujjs1', '20140104', '2014-01-04 18:34:55', '2014-01-04 18:35:46', '2014-01-04 18:35:46', '00:00:51', 1, 'admin', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36', 'Windows', 'Google Chrome', '31.0.1650.63', 0, 0, 1, 0),
(3, 'jgrsenc9taef3usd4e6k3vvcj4', '20140105', '2014-01-04 18:35:50', '2014-01-05 18:07:49', '2014-01-05 18:07:49', '23:31:59', 1, 'admin', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36', 'Windows', 'Google Chrome', '31.0.1650.63', 0, 0, 1, 0),
(4, 'cnih6hq1j8qmhn92tik6klusg6', '20140105', '2014-01-05 16:18:34', '2014-01-05 18:07:54', '2014-01-05 18:07:54', '01:49:20', 2, 'guest', 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko', 'Windows', 'Internet Explorer', '11.0', 0, 0, 1, 0),
(5, 'fdgll59v7usg007gsitbv4mrq3', '20150625', '2015-06-25 22:42:43', '2015-06-25 22:54:25', '2015-06-25 22:54:25', '00:11:42', 1, 'admin', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36', 'Windows', 'Google Chrome', '43.0.2357.130', 0, 0, 1, 0),
(6, 'aeekbkrpk8prk3f63j5lke41t1', '20150625', '2015-06-25 23:56:19', '2015-06-25 23:58:27', '2015-06-25 23:58:27', '00:02:08', 1, 'admin', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36', 'Windows', 'Google Chrome', '43.0.2357.130', 0, 0, 1, 0),
(7, 'n276nmt6kvke54auh39lp2hp24', '20151026', '2015-10-26 18:47:15', '2015-10-26 18:47:15', '2015-10-26 18:47:15', '00:00:00', 1, 'admin', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36', 'Windows', 'Google Chrome', '46.0.2490.80', 0, 0, 1, 0),
(8, 'cj12rl190b0c87ilfqnean2gq7', '20151026', '2015-10-26 18:47:22', '2015-10-26 19:01:08', '2015-10-26 19:01:08', '00:13:46', 1, 'admin', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36', 'Windows', 'Google Chrome', '46.0.2490.80', 1, 0, 1, 0),
(9, 'i3o0qu4ed9l3hgffrsqoqvqlb5', '20151026', '2015-10-26 18:47:58', '2015-10-26 18:50:58', '2015-10-26 18:50:58', '00:03:00', 1, 'admin', 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; ASJB; rv:11.0) like Gecko', 'Windows', 'Internet Explorer', '11.0', 1, 0, 1, 0),
(10, 'jkon8uhnsd6nuivcqrnlvsjmt0', '20151026', '2015-10-26 18:47:58', '2015-10-26 18:50:59', '2015-10-26 18:50:59', '00:03:01', 1, 'admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240', 'Windows', 'Google Chrome', '42.0.2311.135', 1, 0, 1, 0),
(11, '2klc8orc5teo5gqbinq5rgasv7', '20161024', '2016-10-24 09:33:16', '2016-10-24 09:34:27', '2016-10-24 09:34:27', '00:01:11', 1, 'admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36', 'Windows', 'Google Chrome', '53.0.2785.143', 0, 0, 1, 0),
(12, 'fmh6nrkcf3iqqdh8fatio0g851', '20161024', '2016-10-24 09:34:29', '2016-10-24 09:39:25', '2016-10-24 09:39:25', '00:04:56', 1, 'admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36', 'Windows', 'Google Chrome', '53.0.2785.143', 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `auditsummary`
--

CREATE TABLE `auditsummary` (
  `id` int(12) UNSIGNED NOT NULL,
  `auditDay` varchar(8) DEFAULT NULL,
  `firstConnection` datetime DEFAULT NULL,
  `lastConnection` datetime DEFAULT NULL,
  `numberSessions` int(10) DEFAULT NULL,
  `minDuration` time DEFAULT NULL,
  `maxDuration` time DEFAULT NULL,
  `meanDuration` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `auditsummary`
--

INSERT INTO `auditsummary` (`id`, `auditDay`, `firstConnection`, `lastConnection`, `numberSessions`, `minDuration`, `maxDuration`, `meanDuration`) VALUES
(1, '20140104', '2014-01-04 18:26:52', '2014-01-04 18:35:46', 2, '00:00:51', '00:07:59', '00:04:25'),
(2, '20150625', '2015-06-25 22:42:43', '2015-06-25 22:54:25', 1, '00:11:42', '00:11:42', '00:11:42'),
(3, '20151026', '2015-10-26 18:47:15', '2015-10-26 18:47:15', 1, '00:00:00', '00:00:00', '00:00:00'),
(4, '20161024', '2016-10-24 09:33:16', '2016-10-24 09:39:25', 2, '00:01:11', '00:04:56', '00:03:04');

-- --------------------------------------------------------

--
-- Structure de la table `bill`
--

CREATE TABLE `bill` (
  `id` int(12) UNSIGNED NOT NULL,
  `idBillType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idClient` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `idRecipient` int(12) UNSIGNED DEFAULT NULL,
  `billingType` varchar(10) DEFAULT NULL,
  `description` mediumtext,
  `date` date DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `billId` int(12) UNSIGNED DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT NULL,
  `untaxedAmount` decimal(12,2) DEFAULT NULL,
  `fullAmount` decimal(12,2) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idActivityType` int(12) UNSIGNED DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `paymentDone` int(1) UNSIGNED DEFAULT '0',
  `paymentDate` date DEFAULT NULL,
  `paymentAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `idPaymentDelay` int(12) UNSIGNED DEFAULT NULL,
  `paymentDueDate` date DEFAULT NULL,
  `idDeliveryMode` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `paymentsCount` int(3) DEFAULT '0',
  `commandAmountPct` int(3) UNSIGNED DEFAULT '100',
  `sendDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bill`
--

INSERT INTO `bill` (`id`, `idBillType`, `name`, `idProject`, `idClient`, `idContact`, `idRecipient`, `billingType`, `description`, `date`, `idStatus`, `done`, `idle`, `billId`, `tax`, `untaxedAmount`, `fullAmount`, `cancelled`, `idActivityType`, `reference`, `paymentDone`, `paymentDate`, `paymentAmount`, `idPaymentDelay`, `paymentDueDate`, `idDeliveryMode`, `idResource`, `idUser`, `creationDate`, `paymentsCount`, `commandAmountPct`, `sendDate`) VALUES
(1, 72, 'Bill March 2012', 1, 1, 7, 1, 'E', NULL, '2012-03-31', 4, 1, 0, 10000, '19.60', '2400.00', '2870.40', 0, NULL, 'BILL10000_FR', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 100, NULL),
(2, 72, 'Bill for tests', 4, 1, NULL, NULL, 'R', NULL, NULL, 1, 0, 0, NULL, NULL, '13500.00', '13500.00', 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 100, NULL),
(3, 72, 'test', 1, 1, 7, 1, 'E', NULL, '2012-03-15', 3, 0, 0, NULL, NULL, '0.00', '0.00', 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 100, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `billline`
--

CREATE TABLE `billline` (
  `id` int(12) UNSIGNED NOT NULL,
  `line` int(3) UNSIGNED DEFAULT NULL,
  `quantity` decimal(9,2) UNSIGNED DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `detail` varchar(4000) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `refType` varchar(100) NOT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `idTerm` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idActivityPrice` int(12) UNSIGNED DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `idMeasureUnit` int(12) UNSIGNED DEFAULT NULL,
  `extra` int(1) UNSIGNED DEFAULT '0',
  `billingType` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `billline`
--

INSERT INTO `billline` (`id`, `line`, `quantity`, `description`, `detail`, `price`, `amount`, `refType`, `refId`, `idTerm`, `idResource`, `idActivityPrice`, `startDate`, `endDate`, `idMeasureUnit`, `extra`, `billingType`) VALUES
(1, 1, '1.00', 'March 2012 - 50%', 'Evolution X', '2400.00', '2400.00', 'Bill', 1, 1, NULL, NULL, '1970-01-01', '1970-01-01', NULL, 0, NULL),
(2, 1, '10.00', 'Billing for not followed work', '10 days of Architect', '900.00', '9000.00', 'Bill', 2, NULL, NULL, NULL, '1970-01-01', '1970-01-01', NULL, 0, NULL),
(4, 2, '5.00', 'project manager\nManagement (not included in fixed price)\n01/03/2012 - 31/03/2012', 'Management : 5 days', '900.00', '4500.00', 'Bill', 2, NULL, 3, 1, '2012-03-01', '2012-03-31', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `calendar`
--

CREATE TABLE `calendar` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `isOffDay` int(1) UNSIGNED DEFAULT '0',
  `calendarDate` date DEFAULT NULL,
  `day` varchar(8) DEFAULT NULL,
  `week` varchar(6) DEFAULT NULL,
  `month` varchar(6) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idCalendarDefinition` int(12) UNSIGNED DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `calendar`
--

INSERT INTO `calendar` (`id`, `name`, `isOffDay`, `calendarDate`, `day`, `week`, `month`, `year`, `idle`, `idCalendarDefinition`) VALUES
(1, 'New year day', 1, '2011-01-01', '20110101', '201152', '201101', '2011', 0, 1),
(2, 'Christmas', 1, '2011-12-25', '20111225', '201151', '201112', '2011', 0, 1),
(3, 'Worked week-end', 0, '2011-10-22', '20111022', '201142', '201110', '2011', 0, 1),
(5, NULL, 1, '2012-05-01', '20120501', '201218', '201205', '2012', 0, 1),
(6, NULL, 1, '2012-05-08', '20120508', '201219', '201205', '2012', 0, 1),
(7, NULL, 1, '2012-05-17', '20120517', '201220', '201205', '2012', 0, 1),
(8, NULL, 1, '2012-05-28', '20120528', '201222', '201205', '2012', 0, 1),
(9, NULL, 1, '2012-08-15', '20120815', '201233', '201208', '2012', 0, 1),
(10, NULL, 1, '2012-11-01', '20121101', '201244', '201211', '2012', 0, 1),
(11, NULL, 1, '2012-12-25', '20121225', '201252', '201212', '2012', 0, 1),
(13, NULL, 1, '2012-08-14', '20120814', '201233', '201208', '2012', 0, 1),
(14, NULL, 0, '2012-06-09', '20120609', '201223', '201206', '2012', 0, 1),
(16, NULL, 1, '2014-01-01', '20140101', '201401', '201401', '2014', 0, 2),
(17, NULL, 1, '2014-01-08', '20140108', '201402', '201401', '2014', 0, 2),
(18, NULL, 1, '2014-01-15', '20140115', '201403', '201401', '2014', 0, 2),
(19, NULL, 1, '2014-01-22', '20140122', '201404', '201401', '2014', 0, 2),
(20, NULL, 1, '2014-01-29', '20140129', '201405', '201401', '2014', 0, 2),
(22, NULL, 1, '2014-02-05', '20140205', '201406', '201402', '2014', 0, 2),
(23, NULL, 1, '2014-02-12', '20140212', '201407', '201402', '2014', 0, 2),
(24, NULL, 1, '2014-02-19', '20140219', '201408', '201402', '2014', 0, 2),
(25, NULL, 1, '2014-02-26', '20140226', '201409', '201402', '2014', 0, 2),
(26, NULL, 1, '2014-03-05', '20140305', '201410', '201403', '2014', 0, 2),
(27, NULL, 1, '2014-03-12', '20140312', '201411', '201403', '2014', 0, 2),
(29, NULL, 1, '2014-03-19', '20140319', '201412', '201403', '2014', 0, 2),
(30, NULL, 1, '2014-03-26', '20140326', '201413', '201403', '2014', 0, 2),
(31, NULL, 1, '2014-04-02', '20140402', '201414', '201404', '2014', 0, 2),
(32, NULL, 1, '2014-04-09', '20140409', '201415', '201404', '2014', 0, 2),
(33, NULL, 1, '2014-04-16', '20140416', '201416', '201404', '2014', 0, 2),
(34, NULL, 1, '2014-04-23', '20140423', '201417', '201404', '2014', 0, 2),
(35, NULL, 1, '2014-04-30', '20140430', '201418', '201404', '2014', 0, 2),
(36, NULL, 1, '2014-05-07', '20140507', '201419', '201405', '2014', 0, 2),
(37, NULL, 1, '2014-05-14', '20140514', '201420', '201405', '2014', 0, 2),
(38, NULL, 1, '2014-05-21', '20140521', '201421', '201405', '2014', 0, 2),
(39, NULL, 1, '2014-05-28', '20140528', '201422', '201405', '2014', 0, 2),
(40, NULL, 1, '2014-06-04', '20140604', '201423', '201406', '2014', 0, 2),
(41, NULL, 1, '2014-06-11', '20140611', '201424', '201406', '2014', 0, 2),
(42, NULL, 1, '2014-06-18', '20140618', '201425', '201406', '2014', 0, 2),
(43, NULL, 1, '2014-06-25', '20140625', '201426', '201406', '2014', 0, 2),
(44, NULL, 1, '2014-07-02', '20140702', '201427', '201407', '2014', 0, 2),
(45, NULL, 1, '2014-07-09', '20140709', '201428', '201407', '2014', 0, 2),
(46, NULL, 1, '2014-07-16', '20140716', '201429', '201407', '2014', 0, 2),
(47, NULL, 1, '2014-07-23', '20140723', '201430', '201407', '2014', 0, 2),
(48, NULL, 1, '2014-07-30', '20140730', '201431', '201407', '2014', 0, 2),
(49, NULL, 1, '2014-08-06', '20140806', '201432', '201408', '2014', 0, 2),
(50, NULL, 1, '2014-08-13', '20140813', '201433', '201408', '2014', 0, 2),
(51, NULL, 1, '2014-08-20', '20140820', '201434', '201408', '2014', 0, 2),
(52, NULL, 1, '2014-08-27', '20140827', '201435', '201408', '2014', 0, 2),
(53, NULL, 1, '2014-09-03', '20140903', '201436', '201409', '2014', 0, 2),
(54, NULL, 1, '2014-09-10', '20140910', '201437', '201409', '2014', 0, 2),
(55, NULL, 1, '2014-09-17', '20140917', '201438', '201409', '2014', 0, 2),
(56, NULL, 1, '2014-09-24', '20140924', '201439', '201409', '2014', 0, 2),
(57, NULL, 1, '2014-10-01', '20141001', '201440', '201410', '2014', 0, 2),
(58, NULL, 1, '2014-10-08', '20141008', '201441', '201410', '2014', 0, 2),
(59, NULL, 1, '2014-10-15', '20141015', '201442', '201410', '2014', 0, 2),
(60, NULL, 1, '2014-10-22', '20141022', '201443', '201410', '2014', 0, 2),
(61, NULL, 1, '2014-10-29', '20141029', '201444', '201410', '2014', 0, 2),
(62, NULL, 1, '2014-11-05', '20141105', '201445', '201411', '2014', 0, 2),
(63, NULL, 1, '2014-11-12', '20141112', '201446', '201411', '2014', 0, 2),
(64, NULL, 1, '2014-11-19', '20141119', '201447', '201411', '2014', 0, 2),
(65, NULL, 1, '2014-11-26', '20141126', '201448', '201411', '2014', 0, 2),
(66, NULL, 1, '2014-12-03', '20141203', '201449', '201412', '2014', 0, 2),
(67, NULL, 1, '2014-12-10', '20141210', '201450', '201412', '2014', 0, 2),
(68, NULL, 1, '2014-12-17', '20141217', '201451', '201412', '2014', 0, 2),
(69, NULL, 1, '2014-12-24', '20141224', '201452', '201412', '2014', 0, 2),
(70, NULL, 1, '2014-12-31', '20141231', '201401', '201412', '2014', 0, 2),
(71, NULL, 0, '2014-01-11', '20140111', '201402', '201401', '2014', 0, 2);

-- --------------------------------------------------------

--
-- Structure de la table `calendardefinition`
--

CREATE TABLE `calendardefinition` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `calendardefinition`
--

INSERT INTO `calendardefinition` (`id`, `name`, `sortOrder`, `idle`) VALUES
(1, 'default', 10, 0),
(2, '80%, out on wednesdays', NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `callfortender`
--

CREATE TABLE `callfortender` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idCallForTenderType` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `technicalRequirements` mediumtext,
  `businessRequirements` mediumtext,
  `otherRequirements` mediumtext,
  `creationDate` datetime DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `sendDateTime` datetime DEFAULT NULL,
  `expectedTenderDateTime` datetime DEFAULT NULL,
  `maxAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `deliveryDate` date DEFAULT NULL,
  `evaluationMaxValue` decimal(7,2) DEFAULT NULL,
  `fixValue` int(1) UNSIGNED DEFAULT '0',
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idProductVersion` int(12) UNSIGNED DEFAULT NULL,
  `idComponent` int(12) UNSIGNED DEFAULT NULL,
  `idComponentVersion` int(12) UNSIGNED DEFAULT NULL,
  `result` mediumtext,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `idleDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `checklist`
--

CREATE TABLE `checklist` (
  `id` int(12) UNSIGNED NOT NULL,
  `idChecklistDefinition` int(12) UNSIGNED DEFAULT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED DEFAULT NULL,
  `checkCount` int(3) DEFAULT '0',
  `comment` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `checklistable`
--

CREATE TABLE `checklistable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `checklistable`
--

INSERT INTO `checklistable` (`id`, `name`, `idle`) VALUES
(1, 'Ticket', 0),
(2, 'Activity', 0),
(3, 'Milestone', 0),
(4, 'Risk', 0),
(5, 'Action', 0),
(6, 'Issue', 0),
(7, 'Meeting', 0),
(8, 'Decision', 0),
(9, 'Question', 0),
(10, 'Document', 0),
(11, 'Requirement', 0),
(12, 'TestCase', 0),
(13, 'TestSession', 0),
(14, 'Command', 0),
(15, 'Opportunity', 0),
(16, 'Project', 0);

-- --------------------------------------------------------

--
-- Structure de la table `checklistdefinition`
--

CREATE TABLE `checklistdefinition` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idChecklistable` int(12) UNSIGNED DEFAULT NULL,
  `nameChecklistable` varchar(100) DEFAULT NULL,
  `idType` int(12) UNSIGNED DEFAULT NULL,
  `lineCount` int(3) DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `checklistdefinitionline`
--

CREATE TABLE `checklistdefinitionline` (
  `id` int(12) UNSIGNED NOT NULL,
  `idChecklistDefinition` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `check01` varchar(100) DEFAULT NULL,
  `check02` varchar(100) DEFAULT NULL,
  `check03` varchar(100) DEFAULT NULL,
  `check04` varchar(100) DEFAULT NULL,
  `check05` varchar(100) DEFAULT NULL,
  `title01` varchar(1000) DEFAULT NULL,
  `title02` varchar(1000) DEFAULT NULL,
  `title03` varchar(1000) DEFAULT NULL,
  `title04` varchar(1000) DEFAULT NULL,
  `title05` varchar(1000) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT '0',
  `exclusive` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `checklistline`
--

CREATE TABLE `checklistline` (
  `id` int(12) UNSIGNED NOT NULL,
  `idChecklist` int(12) UNSIGNED DEFAULT NULL,
  `idChecklistDefinitionLine` int(12) UNSIGNED DEFAULT NULL,
  `value01` int(1) UNSIGNED DEFAULT '0',
  `value02` int(1) UNSIGNED DEFAULT '0',
  `value03` int(1) UNSIGNED DEFAULT '0',
  `value04` int(1) UNSIGNED DEFAULT '0',
  `value05` int(1) UNSIGNED DEFAULT '0',
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `checkTime` datetime DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` mediumtext,
  `clientCode` varchar(25) DEFAULT NULL,
  `paymentDelay` int(3) DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `designation` varchar(100) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `complement` varchar(100) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `idClientType` int(12) UNSIGNED DEFAULT NULL,
  `paymentDelayEndOfMonth` int(1) UNSIGNED DEFAULT '0',
  `numTax` varchar(100) DEFAULT NULL,
  `idPaymentDelay` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`id`, `name`, `description`, `clientCode`, `paymentDelay`, `tax`, `idle`, `designation`, `street`, `complement`, `zip`, `city`, `state`, `country`, `idClientType`, `paymentDelayEndOfMonth`, `numTax`, `idPaymentDelay`) VALUES
(1, 'client one', NULL, '001', NULL, NULL, 0, NULL, '20 rue de Paris', NULL, '31000', 'TOULOUSE', NULL, 'France', NULL, 0, NULL, NULL),
(2, 'client two', NULL, '002', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(3, 'internal', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `collapsed`
--

CREATE TABLE `collapsed` (
  `id` int(12) UNSIGNED NOT NULL,
  `scope` varchar(200) NOT NULL,
  `idUser` int(12) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `collapsed`
--

INSERT INTO `collapsed` (`id`, `scope`, `idUser`) VALUES
(2, 'Today_WorkDiv', 1),
(3, 'Today_RespDiv', 1),
(4, 'CrossTable_menu_menuFinancial', 1),
(5, 'CrossTable_menu_menuRiskManagementPlan', 1),
(6, 'CrossTable_menu_menuReview', 1),
(7, 'CrossTable_menu_menuTool', 1),
(8, 'CrossTable_menu_menuFollowup', 1),
(9, 'CrossTable_menu_menuEnvironmentalParameter', 1),
(10, 'CrossTable_menu_menuListOfValues', 1),
(11, 'CrossTable_menu_menuAutomation', 1),
(12, 'CrossTable_menu_menuType', 1),
(13, 'CrossTable_menu_menuHabilitationParameter', 1),
(14, 'CrossTable_menu_menuParameter', 1),
(17, 'CrossTable_report_reportCategoryTicket', 1),
(18, 'CrossTable_report_reportCategoryStatus', 1),
(19, 'CrossTable_report_reportCategoryHistory', 1),
(20, 'CrossTable_report_reportCategoryCost', 1),
(21, 'CrossTable_report_reportCategoryBill', 1),
(23, 'CrossTable_report_reportCategoryPlan', 1),
(24, 'CrossTable_menuProject_menuReview', 1),
(25, 'CrossTable_menuProject_menuFinancial', 1),
(26, 'CrossTable_menuProject_menuRiskManagementPlan', 1),
(27, 'CrossTable_menuProject_menuTool', 1),
(28, 'CrossTable_menuProject_menuEnvironmentalParameter', 1),
(29, 'Document_Link', 1),
(32, 'CrossTable_menu_menuRequirementTest', 1),
(33, 'CrossTable_report_reportCategoryRequirementTest', 1),
(34, 'CrossTable_report_reportCategoryMisc', 1),
(35, 'CrossTable_menuProject_menuRequirementTest', 1);

-- --------------------------------------------------------

--
-- Structure de la table `columnselector`
--

CREATE TABLE `columnselector` (
  `id` int(12) UNSIGNED NOT NULL,
  `scope` varchar(10) DEFAULT NULL,
  `objectClass` varchar(50) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `field` varchar(100) DEFAULT NULL,
  `attribute` varchar(100) DEFAULT NULL,
  `hidden` int(1) UNSIGNED DEFAULT '0',
  `sortOrder` int(3) UNSIGNED DEFAULT '0',
  `widthPct` int(3) UNSIGNED DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `subItem` varchar(100) DEFAULT NULL,
  `formatter` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `columnselector`
--

INSERT INTO `columnselector` (`id`, `scope`, `objectClass`, `idUser`, `field`, `attribute`, `hidden`, `sortOrder`, `widthPct`, `name`, `subItem`, `formatter`) VALUES
(1, 'list', 'Client', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(2, 'list', 'Client', 1, 'name', 'name', 0, 2, 40, 'clientName', NULL, NULL),
(3, 'list', 'Client', 1, 'clientCode', 'clientCode', 0, 3, 20, 'clientCode', NULL, NULL),
(4, 'list', 'Client', 1, 'paymentDelay', 'paymentDelay', 0, 4, 15, 'paymentDelay', NULL, NULL),
(5, 'list', 'Client', 1, 'tax', 'tax', 0, 5, 10, 'tax', NULL, NULL),
(6, 'list', 'Client', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(7, 'list', 'Client', 1, 'designation', 'designation', 1, 7, 5, 'designation', NULL, NULL),
(8, 'list', 'Client', 1, 'street', 'street', 1, 8, 5, 'street', NULL, NULL),
(9, 'list', 'Client', 1, 'complement', 'complement', 1, 9, 5, 'complement', NULL, NULL),
(10, 'list', 'Client', 1, 'zip', 'zip', 1, 10, 5, 'zip', NULL, NULL),
(11, 'list', 'Client', 1, 'city', 'city', 1, 11, 5, 'city', NULL, NULL),
(12, 'list', 'Client', 1, 'state', 'state', 1, 12, 5, 'state', NULL, NULL),
(13, 'list', 'Client', 1, 'country', 'country', 1, 13, 5, 'country', NULL, NULL),
(14, 'list', 'Contact', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(15, 'list', 'Contact', 1, 'name', 'name', 0, 2, 20, 'name', NULL, NULL),
(16, 'list', 'Contact', 1, 'photo', 'photo', 0, 3, 5, 'photo', NULL, 'thumb16'),
(17, 'list', 'Contact', 1, 'initials', 'initials', 0, 4, 5, 'initials', NULL, NULL),
(18, 'list', 'Contact', 1, 'nameClient', 'idClient', 0, 5, 15, 'client', NULL, NULL),
(19, 'list', 'Contact', 1, 'nameRecipient', 'idRecipient', 0, 6, 10, 'recipient', NULL, NULL),
(20, 'list', 'Contact', 1, 'nameProfile', 'idProfile', 0, 7, 10, 'idProfile', NULL, 'translateFormatter'),
(21, 'list', 'Contact', 1, 'userName', 'userName', 0, 8, 15, 'userName', NULL, NULL),
(22, 'list', 'Contact', 1, 'isUser', 'isUser', 0, 9, 5, 'isUser', NULL, 'booleanFormatter'),
(23, 'list', 'Contact', 1, 'isResource', 'isResource', 0, 10, 5, 'isResource', NULL, 'booleanFormatter'),
(24, 'list', 'Contact', 1, 'idle', 'idle', 0, 11, 5, 'idle', NULL, 'booleanFormatter'),
(25, 'list', 'Contact', 1, 'email', 'email', 1, 12, 5, 'email', NULL, NULL),
(26, 'list', 'Contact', 1, 'phone', 'phone', 1, 13, 5, 'phone', NULL, NULL),
(27, 'list', 'Contact', 1, 'mobile', 'mobile', 1, 14, 5, 'mobile', NULL, NULL),
(28, 'list', 'Contact', 1, 'fax', 'fax', 1, 15, 5, 'fax', NULL, NULL),
(29, 'list', 'Contact', 1, 'designation', 'designation', 1, 16, 5, 'designation', NULL, NULL),
(30, 'list', 'Contact', 1, 'street', 'street', 1, 17, 5, 'street', NULL, NULL),
(31, 'list', 'Contact', 1, 'complement', 'complement', 1, 18, 5, 'complement', NULL, NULL),
(32, 'list', 'Contact', 1, 'zip', 'zip', 1, 19, 5, 'zip', NULL, NULL),
(33, 'list', 'Contact', 1, 'city', 'city', 1, 20, 5, 'city', NULL, NULL),
(34, 'list', 'Contact', 1, 'state', 'state', 1, 21, 5, 'state', NULL, NULL),
(35, 'list', 'Contact', 1, 'country', 'country', 1, 22, 5, 'country', NULL, NULL),
(85, 'list', 'TicketType', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(86, 'list', 'TicketType', 1, 'name', 'name', 0, 2, 50, 'name', NULL, NULL),
(87, 'list', 'TicketType', 1, 'code', 'code', 0, 3, 10, 'code', NULL, NULL),
(88, 'list', 'TicketType', 1, 'sortOrder', 'sortOrder', 0, 4, 5, 'sortOrderShort', NULL, NULL),
(89, 'list', 'TicketType', 1, 'nameWorkflow', 'idWorkflow', 0, 5, 20, 'idWorkflow', NULL, NULL),
(90, 'list', 'TicketType', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(91, 'list', 'TicketType', 1, 'mandatoryDescription', 'mandatoryDescription', 1, 7, 5, 'mandatoryDescription', NULL, 'booleanFormatter'),
(92, 'list', 'TicketType', 1, 'mandatoryResourceOnHandled', 'mandatoryResourceOnHandled', 1, 8, 5, 'mandatoryResourceOnHandled', NULL, 'booleanFormatter'),
(93, 'list', 'TicketType', 1, 'mandatoryResultOnDone', 'mandatoryResultOnDone', 1, 9, 5, 'mandatoryResultOnDone', NULL, 'booleanFormatter'),
(94, 'list', 'TicketType', 1, 'lockHandled', 'lockHandled', 1, 10, 5, 'lockHandled', NULL, 'booleanFormatter'),
(95, 'list', 'TicketType', 1, 'lockDone', 'lockDone', 1, 11, 5, 'lockDone', NULL, 'booleanFormatter'),
(96, 'list', 'TicketType', 1, 'lockIdle', 'lockIdle', 1, 12, 5, 'lockIdle', NULL, 'booleanFormatter'),
(97, 'list', 'TicketType', 1, 'lockCancelled', 'lockCancelled', 1, 13, 5, 'lockCancelled', NULL, 'booleanFormatter'),
(132, 'list', 'TicketSimple', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(133, 'list', 'TicketSimple', 1, 'nameProject', 'idProject', 0, 2, 10, 'idProject', NULL, NULL),
(134, 'list', 'TicketSimple', 1, 'name', 'name', 0, 3, 50, 'name', NULL, NULL),
(135, 'list', 'TicketSimple', 1, 'colorNameStatus', 'idStatus', 0, 4, 10, 'idStatus', NULL, 'colorNameFormatter'),
(136, 'list', 'TicketSimple', 1, 'actualDueDateTime', 'actualDueDateTime', 0, 5, 10, 'dueDate', NULL, 'dateTimeFormatter'),
(137, 'list', 'TicketSimple', 1, 'handled', 'handled', 0, 6, 5, 'handled', NULL, 'booleanFormatter'),
(138, 'list', 'TicketSimple', 1, 'done', 'done', 0, 7, 5, 'done', NULL, 'booleanFormatter'),
(139, 'list', 'TicketSimple', 1, 'idle', 'idle', 0, 8, 5, 'idle', NULL, 'booleanFormatter'),
(140, 'list', 'TicketSimple', 1, 'reference', 'reference', 1, 9, 5, 'reference', NULL, NULL),
(141, 'list', 'TicketSimple', 1, 'colorNameUrgency', 'idUrgency', 1, 10, 10, 'idUrgency', NULL, 'colorNameFormatter'),
(142, 'list', 'TicketSimple', 1, 'creationDateTime', 'creationDateTime', 1, 11, 10, 'creationDateTime', NULL, 'dateTimeFormatter'),
(143, 'list', 'TicketSimple', 1, 'nameResource', 'idResource', 1, 12, 10, 'idResource', NULL, 'thumbName22'),
(144, 'list', 'TicketSimple', 1, 'idleDateTime', 'idleDateTime', 1, 13, 10, 'idleDateTime', NULL, 'dateTimeFormatter'),
(145, 'list', 'TicketSimple', 1, 'cancelled', 'cancelled', 1, 14, 5, 'cancelled', NULL, 'booleanFormatter'),
(146, 'list', 'TicketSimple', 1, 'nameTargetVersion', 'idTargetVersion', 1, 15, 10, 'idTargetVersion', NULL, NULL),
(212, 'list', 'TicketSimple', 1, 'nameContext1', 'idContext1', 1, 16, 10, 'idContext1', NULL, NULL),
(213, 'list', 'TicketSimple', 1, 'nameContext2', 'idContext2', 1, 17, 10, 'idContext2', NULL, NULL),
(214, 'list', 'TicketSimple', 1, 'nameContext3', 'idContext3', 1, 18, 10, 'idContext3', NULL, NULL),
(215, 'list', 'TicketSimple', 1, 'nameOriginalVersion', 'idOriginalVersion', 1, 19, 10, 'idOriginalVersion', NULL, NULL),
(216, 'list', 'TicketSimple', 1, 'handledDateTime', 'handledDateTime', 1, 20, 10, 'handledDateTime', NULL, 'dateTimeFormatter'),
(217, 'list', 'TicketSimple', 1, 'doneDateTime', 'doneDateTime', 1, 21, 10, 'doneDateTime', NULL, 'dateTimeFormatter'),
(218, 'list', 'Resource', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(219, 'list', 'Resource', 1, 'name', 'name', 0, 2, 20, 'name', NULL, NULL),
(220, 'list', 'Resource', 1, 'photo', 'photo', 0, 3, 5, 'photo', NULL, 'thumb48'),
(221, 'list', 'Resource', 1, 'initials', 'initials', 0, 4, 10, 'initials', NULL, NULL),
(222, 'list', 'Resource', 1, 'nameTeam', 'idTeam', 0, 5, 15, 'team', NULL, NULL),
(223, 'list', 'Resource', 1, 'capacity', 'capacity', 0, 6, 10, 'capacity', NULL, NULL),
(224, 'list', 'Resource', 1, 'userName', 'userName', 0, 7, 20, 'userName', NULL, NULL),
(225, 'list', 'Resource', 1, 'isUser', 'isUser', 0, 8, 5, 'isUser', NULL, 'booleanFormatter'),
(226, 'list', 'Resource', 1, 'isContact', 'isContact', 0, 9, 5, 'isContact', NULL, 'booleanFormatter'),
(227, 'list', 'Resource', 1, 'idle', 'idle', 0, 10, 5, 'idle', NULL, 'booleanFormatter'),
(228, 'list', 'Resource', 1, 'nameProfile', 'idProfile', 1, 11, 10, 'idProfile', NULL, 'translateFormatter'),
(229, 'list', 'Resource', 1, 'nameCalendarDefinition', 'idCalendarDefinition', 1, 12, 10, 'idCalendarDefinition', NULL, NULL),
(230, 'list', 'Resource', 1, 'email', 'email', 1, 13, 5, 'email', NULL, NULL),
(231, 'list', 'Resource', 1, 'phone', 'phone', 1, 14, 5, 'phone', NULL, NULL),
(232, 'list', 'Resource', 1, 'mobile', 'mobile', 1, 15, 5, 'mobile', NULL, NULL),
(233, 'list', 'Resource', 1, 'fax', 'fax', 1, 16, 5, 'fax', NULL, NULL),
(234, 'list', 'Resource', 1, 'nameRole', 'idRole', 1, 17, 10, 'idRole', NULL, NULL),
(259, 'list', 'CalendarDefinition', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(260, 'list', 'CalendarDefinition', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(261, 'list', 'CalendarDefinition', 1, 'idle', 'idle', 0, 3, 5, 'idle', NULL, 'booleanFormatter'),
(262, 'list', 'Affectation', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(263, 'list', 'Affectation', 1, 'nameResourceSelect', 'idResourceSelect', 0, 2, 20, 'resourceName', NULL, 'thumbName22'),
(264, 'list', 'Affectation', 1, 'nameContact', 'idContact', 0, 3, 20, 'contactName', NULL, 'thumbName22'),
(265, 'list', 'Affectation', 1, 'nameUser', 'idUser', 0, 4, 20, 'userName', NULL, 'thumbName22'),
(266, 'list', 'Affectation', 1, 'nameProject', 'idProject', 0, 5, 20, 'projectName', NULL, NULL),
(267, 'list', 'Affectation', 1, 'rate', 'rate', 0, 6, 10, 'rate', NULL, 'percentFormatter'),
(268, 'list', 'Affectation', 1, 'idle', 'idle', 0, 7, 5, 'idle', NULL, 'booleanFormatter'),
(269, 'list', 'User', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(270, 'list', 'User', 1, 'name', 'name', 0, 2, 20, 'userName', NULL, NULL),
(271, 'list', 'User', 1, 'photo', 'photo', 0, 3, 5, 'photo', NULL, 'thumb48'),
(272, 'list', 'User', 1, 'nameProfile', 'idProfile', 0, 4, 15, 'idProfile', NULL, 'translateFormatter'),
(273, 'list', 'User', 1, 'resourceName', 'resourceName', 0, 5, 25, 'name', NULL, NULL),
(274, 'list', 'User', 1, 'initials', 'initials', 0, 6, 10, 'initials', NULL, NULL),
(275, 'list', 'User', 1, 'isResource', 'isResource', 0, 7, 5, 'isResource', NULL, 'booleanFormatter'),
(276, 'list', 'User', 1, 'isContact', 'isContact', 0, 8, 5, 'isContact', NULL, 'booleanFormatter'),
(277, 'list', 'User', 1, 'isLdap', 'isLdap', 0, 9, 5, 'isLdap', NULL, 'booleanFormatter'),
(278, 'list', 'User', 1, 'idle', 'idle', 0, 10, 5, 'idle', NULL, 'booleanFormatter'),
(279, 'list', 'User', 1, 'email', 'email', 1, 11, 5, 'email', NULL, NULL),
(280, 'list', 'User', 1, 'locked', 'locked', 1, 12, 5, 'locked', NULL, 'booleanFormatter'),
(281, 'list', 'Recipient', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(282, 'list', 'Recipient', 1, 'name', 'name', 0, 2, 20, 'name', NULL, NULL),
(283, 'list', 'Recipient', 1, 'companyNumber', 'companyNumber', 0, 3, 20, 'companyNumber', NULL, NULL),
(284, 'list', 'Recipient', 1, 'numTax', 'numTax', 0, 4, 20, 'numTax', NULL, NULL),
(285, 'list', 'Recipient', 1, 'bank', 'bank', 0, 5, 10, 'bank', NULL, NULL),
(286, 'list', 'Recipient', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(287, 'list', 'Recipient', 1, 'taxFree', 'taxFree', 1, 7, 5, 'taxFree', NULL, 'booleanFormatter'),
(288, 'list', 'Recipient', 1, 'ibanCountry', 'ibanCountry', 1, 8, 5, 'ibanCountry', NULL, NULL),
(289, 'list', 'Recipient', 1, 'ibanKey', 'ibanKey', 1, 9, 5, 'ibanKey', NULL, NULL),
(290, 'list', 'Recipient', 1, 'ibanBban', 'ibanBban', 1, 10, 5, 'ibanBban', NULL, NULL),
(291, 'list', 'Recipient', 1, 'designation', 'designation', 1, 11, 5, 'designation', NULL, NULL),
(292, 'list', 'Recipient', 1, 'street', 'street', 1, 12, 5, 'street', NULL, NULL),
(293, 'list', 'Recipient', 1, 'complement', 'complement', 1, 13, 5, 'complement', NULL, NULL),
(294, 'list', 'Recipient', 1, 'zip', 'zip', 1, 14, 5, 'zip', NULL, NULL),
(295, 'list', 'Recipient', 1, 'city', 'city', 1, 15, 5, 'city', NULL, NULL),
(296, 'list', 'Recipient', 1, 'state', 'state', 1, 16, 5, 'state', NULL, NULL),
(297, 'list', 'Recipient', 1, 'country', 'country', 1, 17, 5, 'country', NULL, NULL),
(298, 'list', 'Team', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(299, 'list', 'Team', 1, 'name', 'name', 0, 2, 85, 'name', NULL, NULL),
(300, 'list', 'Team', 1, 'idle', 'idle', 0, 3, 5, 'idle', NULL, 'booleanFormatter'),
(308, 'list', 'Version', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(309, 'list', 'Version', 1, 'name', 'name', 0, 2, 20, 'versionName', NULL, NULL),
(310, 'list', 'Version', 1, 'nameProduct', 'idProduct', 0, 3, 25, 'productName', NULL, NULL),
(311, 'list', 'Version', 1, 'plannedEisDate', 'plannedEisDate', 0, 4, 10, 'plannedEis', NULL, 'dateFormatter'),
(312, 'list', 'Version', 1, 'realEisDate', 'realEisDate', 0, 5, 10, 'realEis', NULL, 'dateFormatter'),
(313, 'list', 'Version', 1, 'plannedEndDate', 'plannedEndDate', 0, 6, 10, 'plannedEnd', NULL, 'dateFormatter'),
(314, 'list', 'Version', 1, 'realEndDate', 'realEndDate', 0, 7, 10, 'realEnd', NULL, 'dateFormatter'),
(315, 'list', 'Version', 1, 'isEis', 'isEis', 0, 8, 5, 'isEis', NULL, 'booleanFormatter'),
(316, 'list', 'Version', 1, 'idle', 'idle', 0, 9, 5, 'idle', NULL, 'booleanFormatter'),
(317, 'list', 'Version', 1, 'nameContact', 'idContact', 1, 10, 10, 'idContact', NULL, 'thumbName22'),
(318, 'list', 'Version', 1, 'nameResource', 'idResource', 1, 11, 10, 'idResource', NULL, 'thumbName22'),
(319, 'list', 'Version', 1, 'creationDate', 'creationDate', 1, 12, 10, 'creationDate', NULL, 'dateFormatter'),
(320, 'list', 'Version', 1, 'initialEisDate', 'initialEisDate', 1, 13, 10, 'initialEisDate', NULL, 'dateFormatter'),
(321, 'list', 'Version', 1, 'initialEndDate', 'initialEndDate', 1, 14, 10, 'initialEndDate', NULL, 'dateFormatter'),
(322, 'list', 'Context', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(323, 'list', 'Context', 1, 'nameContextType', 'idContextType', 0, 2, 30, 'idContextType', NULL, NULL),
(324, 'list', 'Context', 1, 'name', 'name', 0, 3, 50, 'name', NULL, NULL),
(325, 'list', 'Context', 1, 'sortOrder', 'sortOrder', 0, 4, 10, 'sortOrder', NULL, NULL),
(326, 'list', 'Context', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(327, 'list', 'DocumentDirectory', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(328, 'list', 'DocumentDirectory', 1, 'location', 'location', 0, 2, 45, 'location', NULL, NULL),
(329, 'list', 'DocumentDirectory', 1, 'name', 'name', 0, 3, 15, 'name', NULL, NULL),
(330, 'list', 'DocumentDirectory', 1, 'nameProject', 'idProject', 0, 4, 15, 'idProject', NULL, NULL),
(331, 'list', 'DocumentDirectory', 1, 'nameProduct', 'idProduct', 0, 5, 15, 'idProduct', NULL, NULL),
(332, 'list', 'DocumentDirectory', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(333, 'list', 'DocumentDirectory', 1, 'nameDocumentType', 'idDocumentType', 1, 7, 10, 'idDocumentType', NULL, NULL),
(334, 'list', 'Role', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(335, 'list', 'Role', 1, 'name', 'name', 0, 2, 75, 'name', NULL, NULL),
(336, 'list', 'Role', 1, 'sortOrder', 'sortOrder', 0, 3, 10, 'sortOrderShort', NULL, NULL),
(337, 'list', 'Role', 1, 'idle', 'idle', 0, 4, 5, 'idle', NULL, 'booleanFormatter'),
(338, 'list', 'Status', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(339, 'list', 'Status', 1, 'name', 'name', 0, 2, 30, 'name', NULL, NULL),
(340, 'list', 'Status', 1, 'setHandledStatus', 'setHandledStatus', 0, 3, 10, 'setHandledStatus', NULL, 'booleanFormatter'),
(341, 'list', 'Status', 1, 'setDoneStatus', 'setDoneStatus', 0, 4, 10, 'setDoneStatus', NULL, 'booleanFormatter'),
(342, 'list', 'Status', 1, 'setIdleStatus', 'setIdleStatus', 0, 5, 10, 'setIdleStatus', NULL, 'booleanFormatter'),
(343, 'list', 'Status', 1, 'setCancelledStatus', 'setCancelledStatus', 0, 6, 10, 'setCancelledStatus', NULL, 'booleanFormatter'),
(344, 'list', 'Status', 1, 'color', 'color', 0, 7, 10, 'color', NULL, 'colorFormatter'),
(345, 'list', 'Status', 1, 'sortOrder', 'sortOrder', 0, 8, 5, 'sortOrderShort', NULL, NULL),
(346, 'list', 'Status', 1, 'idle', 'idle', 0, 9, 5, 'idle', NULL, 'booleanFormatter'),
(347, 'list', 'Health', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(348, 'list', 'Health', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(349, 'list', 'Health', 1, 'color', 'color', 0, 3, 15, 'color', NULL, 'colorFormatter'),
(350, 'list', 'Health', 1, 'sortOrder', 'sortOrder', 0, 4, 10, 'sortOrderShort', NULL, NULL),
(351, 'list', 'Health', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(352, 'list', 'Health', 1, 'icon', 'icon', 1, 6, 5, 'icon', NULL, 'iconFormatter'),
(353, 'list', 'Quality', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(354, 'list', 'Quality', 1, 'name', 'name', 0, 2, 50, 'name', NULL, NULL),
(355, 'list', 'Quality', 1, 'color', 'color', 0, 3, 15, 'color', NULL, 'colorFormatter'),
(356, 'list', 'Quality', 1, 'icon', 'icon', 0, 4, 10, 'icon', NULL, 'iconFormatter'),
(357, 'list', 'Quality', 1, 'sortOrder', 'sortOrder', 0, 5, 10, 'sortOrderShort', NULL, NULL),
(358, 'list', 'Quality', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(359, 'list', 'OverallProgress', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(360, 'list', 'OverallProgress', 1, 'name', 'name', 0, 2, 75, 'name', NULL, NULL),
(361, 'list', 'OverallProgress', 1, 'sortOrder', 'sortOrder', 0, 3, 10, 'sortOrderShort', NULL, NULL),
(362, 'list', 'OverallProgress', 1, 'idle', 'idle', 0, 4, 5, 'idle', NULL, 'booleanFormatter'),
(363, 'list', 'Trend', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(364, 'list', 'Trend', 1, 'name', 'name', 0, 2, 50, 'name', NULL, NULL),
(365, 'list', 'Trend', 1, 'color', 'color', 0, 3, 15, 'color', NULL, 'colorFormatter'),
(366, 'list', 'Trend', 1, 'icon', 'icon', 0, 4, 10, 'icon', NULL, 'iconFormatter'),
(367, 'list', 'Trend', 1, 'sortOrder', 'sortOrder', 0, 5, 10, 'sortOrderShort', NULL, NULL),
(368, 'list', 'Trend', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(369, 'list', 'Likelihood', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(370, 'list', 'Likelihood', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(371, 'list', 'Likelihood', 1, 'value', 'value', 0, 3, 10, 'value', NULL, NULL),
(372, 'list', 'Likelihood', 1, 'color', 'color', 0, 4, 10, 'color', NULL, 'colorFormatter'),
(373, 'list', 'Likelihood', 1, 'sortOrder', 'sortOrder', 0, 5, 5, 'sortOrderShort', NULL, NULL),
(374, 'list', 'Likelihood', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(375, 'list', 'Criticality', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(376, 'list', 'Criticality', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(377, 'list', 'Criticality', 1, 'value', 'value', 0, 3, 10, 'value', NULL, NULL),
(378, 'list', 'Criticality', 1, 'color', 'color', 0, 4, 10, 'color', NULL, 'colorFormatter'),
(379, 'list', 'Criticality', 1, 'sortOrder', 'sortOrder', 0, 5, 5, 'sortOrderShort', NULL, NULL),
(380, 'list', 'Criticality', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(381, 'list', 'Severity', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(382, 'list', 'Severity', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(383, 'list', 'Severity', 1, 'value', 'value', 0, 3, 10, 'value', NULL, NULL),
(384, 'list', 'Severity', 1, 'color', 'color', 0, 4, 10, 'color', NULL, 'colorFormatter'),
(385, 'list', 'Severity', 1, 'sortOrder', 'sortOrder', 0, 5, 5, 'sortOrderShort', NULL, NULL),
(386, 'list', 'Severity', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(387, 'list', 'Urgency', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(388, 'list', 'Urgency', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(389, 'list', 'Urgency', 1, 'value', 'value', 0, 3, 10, 'value', NULL, NULL),
(390, 'list', 'Urgency', 1, 'color', 'color', 0, 4, 10, 'color', NULL, 'colorFormatter'),
(391, 'list', 'Urgency', 1, 'sortOrder', 'sortOrder', 0, 5, 5, 'sortOrderShort', NULL, NULL),
(392, 'list', 'Urgency', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(393, 'list', 'Priority', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(394, 'list', 'Priority', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(395, 'list', 'Priority', 1, 'value', 'value', 0, 3, 10, 'value', NULL, NULL),
(396, 'list', 'Priority', 1, 'color', 'color', 0, 4, 10, 'color', NULL, 'colorFormatter'),
(397, 'list', 'Priority', 1, 'sortOrder', 'sortOrder', 0, 5, 5, 'sortOrderShort', NULL, NULL),
(398, 'list', 'Priority', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(399, 'list', 'RiskLevel', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(400, 'list', 'RiskLevel', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(401, 'list', 'RiskLevel', 1, 'color', 'color', 0, 3, 15, 'color', NULL, 'colorFormatter'),
(402, 'list', 'RiskLevel', 1, 'sortOrder', 'sortOrder', 0, 4, 10, 'sortOrderShort', NULL, NULL),
(403, 'list', 'RiskLevel', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(404, 'list', 'Feasibility', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(405, 'list', 'Feasibility', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(406, 'list', 'Feasibility', 1, 'color', 'color', 0, 3, 15, 'color', NULL, 'colorFormatter'),
(407, 'list', 'Feasibility', 1, 'sortOrder', 'sortOrder', 0, 4, 10, 'sortOrderShort', NULL, NULL),
(408, 'list', 'Feasibility', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(409, 'list', 'Efficiency', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(410, 'list', 'Efficiency', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(411, 'list', 'Efficiency', 1, 'color', 'color', 0, 3, 15, 'color', NULL, 'colorFormatter'),
(412, 'list', 'Efficiency', 1, 'sortOrder', 'sortOrder', 0, 4, 10, 'sortOrderShort', NULL, NULL),
(413, 'list', 'Efficiency', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(414, 'list', 'PredefinedNote', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(415, 'list', 'PredefinedNote', 1, 'nameTextable', 'idTextable', 0, 2, 15, 'element', NULL, 'translateFormatter'),
(416, 'list', 'PredefinedNote', 1, 'nameType', 'idType', 0, 3, 15, 'type', NULL, NULL),
(417, 'list', 'PredefinedNote', 1, 'name', 'name', 0, 4, 55, 'name', NULL, NULL),
(418, 'list', 'PredefinedNote', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(419, 'list', 'Workflow', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(420, 'list', 'Workflow', 1, 'name', 'name', 0, 2, 75, 'name', NULL, NULL),
(421, 'list', 'Workflow', 1, 'sortOrder', 'sortOrder', 0, 3, 10, 'sortOrderShort', NULL, NULL),
(422, 'list', 'Workflow', 1, 'idle', 'idle', 0, 4, 5, 'idle', NULL, 'booleanFormatter'),
(423, 'list', 'StatusMail', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(424, 'list', 'StatusMail', 1, 'nameMailable', 'idMailable', 0, 2, 12, 'idMailable', NULL, 'translateFormatter'),
(425, 'list', 'StatusMail', 1, 'nameType', 'idType', 0, 3, 9, 'type', NULL, 'nameFormatter'),
(426, 'list', 'StatusMail', 1, 'colorNameStatus', 'idStatus', 0, 4, 10, 'newStatus', NULL, 'colorNameFormatter'),
(427, 'list', 'StatusMail', 1, 'nameEvent', 'idEvent', 0, 5, 10, 'orOtherEvent', NULL, 'translateFormatter'),
(428, 'list', 'StatusMail', 1, 'mailToContact', 'mailToContact', 0, 6, 7, 'mailToContact', NULL, 'booleanFormatter'),
(429, 'list', 'StatusMail', 1, 'mailToUser', 'mailToUser', 0, 7, 7, 'mailToUser', NULL, 'booleanFormatter'),
(430, 'list', 'StatusMail', 1, 'mailToResource', 'mailToResource', 0, 8, 7, 'mailToResource', NULL, 'booleanFormatter'),
(431, 'list', 'StatusMail', 1, 'mailToProject', 'mailToProject', 0, 9, 7, 'mailToProject', NULL, 'booleanFormatter'),
(432, 'list', 'StatusMail', 1, 'mailToLeader', 'mailToLeader', 0, 10, 7, 'mailToLeader', NULL, 'booleanFormatter'),
(433, 'list', 'StatusMail', 1, 'mailToManager', 'mailToManager', 0, 11, 7, 'mailToManager', NULL, 'booleanFormatter'),
(434, 'list', 'StatusMail', 1, 'mailToAssigned', 'mailToAssigned', 0, 12, 7, 'mailToAssigned', NULL, 'booleanFormatter'),
(435, 'list', 'StatusMail', 1, 'mailToOther', 'mailToOther', 0, 13, 7, 'mailToOther', NULL, 'booleanFormatter'),
(436, 'list', 'StatusMail', 1, 'idle', 'idle', 0, 14, 5, 'idle', NULL, 'booleanFormatter'),
(437, 'list', 'TicketDelay', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(438, 'list', 'TicketDelay', 1, 'nameTicketType', 'idTicketType', 0, 2, 25, 'idTicketType', NULL, NULL),
(439, 'list', 'TicketDelay', 1, 'nameUrgency', 'idUrgency', 0, 3, 25, 'urgency', NULL, NULL),
(440, 'list', 'TicketDelay', 1, 'value', 'value', 0, 4, 10, 'value', NULL, 'numericFormatter'),
(441, 'list', 'TicketDelay', 1, 'nameDelayUnit', 'idDelayUnit', 0, 5, 25, 'unit', NULL, 'translateFormatter'),
(442, 'list', 'TicketDelay', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(443, 'list', 'IndicatorDefinition', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(444, 'list', 'IndicatorDefinition', 1, 'nameIndicatorable', 'idIndicatorable', 0, 2, 15, 'element', NULL, 'translateFormatter'),
(445, 'list', 'IndicatorDefinition', 1, 'nameIndicator', 'idIndicator', 0, 3, 20, 'idIndicator', NULL, 'translateFormatter'),
(446, 'list', 'IndicatorDefinition', 1, 'nameType', 'idType', 0, 4, 10, 'type', NULL, NULL),
(447, 'list', 'IndicatorDefinition', 1, 'warningValue', 'warningValue', 0, 5, 8, 'warning', NULL, 'numericFormatter'),
(448, 'list', 'IndicatorDefinition', 1, 'nameWarningDelayUnit', 'idWarningDelayUnit', 0, 6, 12, 'unit', NULL, 'translateFormatter'),
(449, 'list', 'IndicatorDefinition', 1, 'alertValue', 'alertValue', 0, 7, 8, 'alert', NULL, 'numericFormatter'),
(450, 'list', 'IndicatorDefinition', 1, 'nameAlertDelayUnit', 'idAlertDelayUnit', 0, 8, 12, 'unit', NULL, 'translateFormatter'),
(451, 'list', 'IndicatorDefinition', 1, 'idle', 'idle', 0, 9, 5, 'idle', NULL, 'booleanFormatter'),
(452, 'list', 'IndicatorDefinition', 1, 'mailToContact', 'mailToContact', 1, 10, 5, 'mailToContact', NULL, 'booleanFormatter'),
(453, 'list', 'IndicatorDefinition', 1, 'mailToUser', 'mailToUser', 1, 11, 5, 'mailToUser', NULL, 'booleanFormatter'),
(454, 'list', 'IndicatorDefinition', 1, 'mailToResource', 'mailToResource', 1, 12, 5, 'mailToResource', NULL, 'booleanFormatter'),
(455, 'list', 'IndicatorDefinition', 1, 'mailToProject', 'mailToProject', 1, 13, 5, 'mailToProject', NULL, 'booleanFormatter'),
(456, 'list', 'IndicatorDefinition', 1, 'mailToLeader', 'mailToLeader', 1, 14, 5, 'mailToLeader', NULL, 'booleanFormatter'),
(457, 'list', 'IndicatorDefinition', 1, 'mailToManager', 'mailToManager', 1, 15, 5, 'mailToManager', NULL, 'booleanFormatter'),
(458, 'list', 'IndicatorDefinition', 1, 'mailToAssigned', 'mailToAssigned', 1, 16, 5, 'mailToAssigned', NULL, 'booleanFormatter'),
(459, 'list', 'IndicatorDefinition', 1, 'mailToOther', 'mailToOther', 1, 17, 5, 'mailToOther', NULL, 'booleanFormatter'),
(460, 'list', 'IndicatorDefinition', 1, 'alertToUser', 'alertToUser', 1, 18, 5, 'alertToUser', NULL, 'booleanFormatter'),
(461, 'list', 'IndicatorDefinition', 1, 'alertToResource', 'alertToResource', 1, 19, 5, 'alertToResource', NULL, 'booleanFormatter'),
(462, 'list', 'IndicatorDefinition', 1, 'alertToProject', 'alertToProject', 1, 20, 5, 'alertToProject', NULL, 'booleanFormatter'),
(463, 'list', 'IndicatorDefinition', 1, 'alertToContact', 'alertToContact', 1, 21, 5, 'alertToContact', NULL, 'booleanFormatter'),
(464, 'list', 'IndicatorDefinition', 1, 'alertToLeader', 'alertToLeader', 1, 22, 5, 'alertToLeader', NULL, 'booleanFormatter'),
(465, 'list', 'IndicatorDefinition', 1, 'alertToManager', 'alertToManager', 1, 23, 5, 'alertToManager', NULL, 'booleanFormatter'),
(466, 'list', 'IndicatorDefinition', 1, 'alertToAssigned', 'alertToAssigned', 1, 24, 5, 'alertToAssigned', NULL, 'booleanFormatter'),
(467, 'list', 'ProjectType', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(468, 'list', 'ProjectType', 1, 'name', 'name', 0, 2, 50, 'name', NULL, NULL),
(469, 'list', 'ProjectType', 1, 'code', 'code', 0, 3, 10, 'code', NULL, NULL),
(470, 'list', 'ProjectType', 1, 'sortOrder', 'sortOrder', 0, 4, 5, 'sortOrderShort', NULL, NULL),
(471, 'list', 'ProjectType', 1, 'nameWorkflow', 'idWorkflow', 0, 5, 20, 'idWorkflow', NULL, NULL),
(472, 'list', 'ProjectType', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(473, 'list', 'ProjectType', 1, 'mandatoryDescription', 'mandatoryDescription', 1, 7, 5, 'mandatoryDescription', NULL, 'booleanFormatter'),
(474, 'list', 'ProjectType', 1, 'lockDone', 'lockDone', 1, 8, 5, 'lockDone', NULL, 'booleanFormatter'),
(475, 'list', 'ProjectType', 1, 'lockIdle', 'lockIdle', 1, 9, 5, 'lockIdle', NULL, 'booleanFormatter'),
(476, 'list', 'ProjectType', 1, 'lockCancelled', 'lockCancelled', 1, 10, 5, 'lockCancelled', NULL, 'booleanFormatter'),
(477, 'list', 'IndividualExpenseType', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(478, 'list', 'IndividualExpenseType', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(479, 'list', 'IndividualExpenseType', 1, 'sortOrder', 'sortOrder', 0, 3, 5, 'sortOrderShort', NULL, NULL),
(480, 'list', 'IndividualExpenseType', 1, 'nameWorkflow', 'idWorkflow', 0, 4, 20, 'idWorkflow', NULL, NULL),
(481, 'list', 'IndividualExpenseType', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(482, 'list', 'IndividualExpenseType', 1, 'mandatoryDescription', 'mandatoryDescription', 1, 6, 5, 'mandatoryDescription', NULL, 'booleanFormatter'),
(483, 'list', 'IndividualExpenseType', 1, 'lockIdle', 'lockIdle', 1, 7, 5, 'lockIdle', NULL, 'booleanFormatter'),
(484, 'list', 'IndividualExpenseType', 1, 'lockCancelled', 'lockCancelled', 1, 8, 5, 'lockCancelled', NULL, 'booleanFormatter'),
(485, 'list', 'BillType', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(486, 'list', 'BillType', 1, 'name', 'name', 0, 2, 50, 'name', NULL, NULL),
(487, 'list', 'BillType', 1, 'code', 'code', 0, 3, 10, 'code', NULL, NULL),
(488, 'list', 'BillType', 1, 'sortOrder', 'sortOrder', 0, 4, 5, 'sortOrderShort', NULL, NULL),
(489, 'list', 'BillType', 1, 'nameWorkflow', 'idWorkflow', 0, 5, 20, 'idWorkflow', NULL, NULL),
(490, 'list', 'BillType', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(491, 'list', 'BillType', 1, 'mandatoryDescription', 'mandatoryDescription', 1, 7, 5, 'mandatoryDescription', NULL, 'booleanFormatter'),
(492, 'list', 'BillType', 1, 'lockDone', 'lockDone', 1, 8, 5, 'lockDone', NULL, 'booleanFormatter'),
(493, 'list', 'BillType', 1, 'lockIdle', 'lockIdle', 1, 9, 5, 'lockIdle', NULL, 'booleanFormatter'),
(494, 'list', 'BillType', 1, 'lockCancelled', 'lockCancelled', 1, 10, 5, 'lockCancelled', NULL, 'booleanFormatter'),
(495, 'list', 'Profile', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(496, 'list', 'Profile', 1, 'name', 'name', 0, 2, 85, 'name', NULL, 'translateFormatter'),
(497, 'list', 'Profile', 1, 'idle', 'idle', 0, 3, 5, 'idle', NULL, 'booleanFormatter'),
(498, 'list', 'Profile', 1, 'profileCode', 'profileCode', 1, 4, 5, 'profileCode', NULL, NULL),
(499, 'list', 'Profile', 1, 'sortOrder', 'sortOrder', 1, 5, 5, 'sortOrder', NULL, 'numericFormatter'),
(500, 'list', 'AccessProfile', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(501, 'list', 'AccessProfile', 1, 'name', 'name', 0, 2, 25, 'name', NULL, 'translateFormatter'),
(502, 'list', 'AccessProfile', 1, 'nameAccessScopeRead', 'idAccessScopeRead', 0, 3, 15, 'idAccessScopeRead', NULL, 'translateFormatter'),
(503, 'list', 'AccessProfile', 1, 'nameAccessScopeCreate', 'idAccessScopeCreate', 0, 4, 15, 'idAccessScopeCreate', NULL, 'translateFormatter'),
(504, 'list', 'AccessProfile', 1, 'nameAccessScopeUpdate', 'idAccessScopeUpdate', 0, 5, 15, 'idAccessScopeUpdate', NULL, 'translateFormatter'),
(505, 'list', 'AccessProfile', 1, 'nameAccessScopeDelete', 'idAccessScopeDelete', 0, 6, 15, 'idAccessScopeDelete', NULL, 'translateFormatter'),
(506, 'list', 'AccessProfile', 1, 'sortOrder', 'sortOrder', 0, 7, 5, 'sortOrderShort', NULL, NULL),
(507, 'list', 'AccessProfile', 1, 'idle', 'idle', 0, 8, 5, 'idle', NULL, 'booleanFormatter'),
(519, 'list', 'Action', 1, 'id', 'id', 0, 1, 4, 'id', NULL, 'numericFormatter'),
(520, 'list', 'Action', 1, 'nameProject', 'idProject', 0, 2, 10, 'idProject', NULL, NULL),
(521, 'list', 'Action', 1, 'name', 'name', 0, 3, 30, 'name', NULL, NULL),
(522, 'list', 'Action', 1, 'colorNamePriority', 'idPriority', 0, 4, 5, 'idPriority', NULL, 'colorNameFormatter'),
(523, 'list', 'Action', 1, 'actualDueDate', 'actualDueDate', 0, 5, 10, 'actualDueDate', NULL, 'dateFormatter'),
(524, 'list', 'Action', 1, 'colorNameStatus', 'idStatus', 0, 6, 10, 'idStatus', NULL, 'colorNameFormatter'),
(525, 'list', 'Action', 1, 'colorNameEfficiency', 'idEfficiency', 0, 7, 10, 'idEfficiency', NULL, 'colorNameFormatter'),
(526, 'list', 'Action', 1, 'nameResource', 'idResource', 0, 8, 9, 'responsible', NULL, 'thumbName22'),
(527, 'list', 'Action', 1, 'handled', 'handled', 0, 9, 4, 'handled', NULL, 'booleanFormatter'),
(528, 'list', 'Action', 1, 'done', 'done', 0, 10, 4, 'done', NULL, 'booleanFormatter'),
(529, 'list', 'Action', 1, 'idle', 'idle', 0, 11, 4, 'idle', NULL, 'booleanFormatter'),
(530, 'list', 'Action', 1, 'reference', 'reference', 1, 12, 5, 'reference', NULL, NULL),
(531, 'list', 'Action', 1, 'nameActionType', 'idActionType', 1, 13, 10, 'idActionType', NULL, NULL),
(532, 'list', 'Action', 1, 'creationDate', 'creationDate', 1, 14, 10, 'creationDate', NULL, 'dateFormatter'),
(533, 'list', 'Action', 1, 'nameUser', 'idUser', 1, 15, 10, 'idUser', NULL, 'thumbName22'),
(534, 'list', 'Action', 1, 'initialDueDate', 'initialDueDate', 1, 16, 10, 'initialDueDate', NULL, 'dateFormatter'),
(535, 'list', 'Action', 1, 'handledDate', 'handledDate', 1, 17, 10, 'handledDate', NULL, 'dateFormatter'),
(536, 'list', 'Action', 1, 'doneDate', 'doneDate', 1, 18, 10, 'doneDate', NULL, 'dateFormatter'),
(537, 'list', 'Action', 1, 'idleDate', 'idleDate', 1, 19, 10, 'idleDate', NULL, 'dateFormatter'),
(538, 'list', 'Action', 1, 'cancelled', 'cancelled', 1, 20, 5, 'cancelled', NULL, 'booleanFormatter'),
(569, 'list', 'IndividualExpense', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(570, 'list', 'IndividualExpense', 1, 'nameProject', 'idProject', 0, 2, 15, 'idProject', NULL, NULL),
(571, 'list', 'IndividualExpense', 1, 'nameIndividualExpenseType', 'idIndividualExpenseType', 0, 3, 15, 'type', NULL, NULL),
(572, 'list', 'IndividualExpense', 1, 'nameResource', 'idResource', 0, 4, 15, 'idResource', NULL, 'thumbName22'),
(573, 'list', 'IndividualExpense', 1, 'name', 'name', 0, 5, 25, 'name', NULL, NULL),
(574, 'list', 'IndividualExpense', 1, 'colorNameStatus', 'idStatus', 0, 6, 10, 'idStatus', NULL, 'colorNameFormatter'),
(575, 'list', 'IndividualExpense', 1, 'idle', 'idle', 0, 7, 5, 'idle', NULL, 'booleanFormatter'),
(576, 'list', 'IndividualExpense', 1, 'reference', 'reference', 1, 8, 5, 'reference', NULL, NULL),
(577, 'list', 'IndividualExpense', 1, 'expensePlannedDate', 'expensePlannedDate', 1, 9, 10, 'expensePlannedDate', NULL, 'dateFormatter'),
(578, 'list', 'IndividualExpense', 1, 'plannedAmount', 'plannedAmount', 1, 10, 5, 'plannedAmount', NULL, 'costFormatter'),
(579, 'list', 'IndividualExpense', 1, 'expenseRealDate', 'expenseRealDate', 1, 11, 10, 'expenseRealDate', NULL, 'dateFormatter'),
(580, 'list', 'IndividualExpense', 1, 'realAmount', 'realAmount', 1, 12, 5, 'realAmount', NULL, 'costFormatter'),
(581, 'list', 'IndividualExpense', 1, 'cancelled', 'cancelled', 1, 13, 5, 'cancelled', NULL, 'booleanFormatter'),
(582, 'list', 'ProjectExpense', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(583, 'list', 'ProjectExpense', 1, 'nameProject', 'idProject', 0, 2, 15, 'idProject', NULL, NULL),
(584, 'list', 'ProjectExpense', 1, 'nameProjectExpenseType', 'idProjectExpenseType', 0, 3, 15, 'type', NULL, NULL),
(585, 'list', 'ProjectExpense', 1, 'name', 'name', 0, 4, 50, 'name', NULL, NULL),
(586, 'list', 'ProjectExpense', 1, 'colorNameStatus', 'idStatus', 0, 5, 10, 'idStatus', NULL, 'colorNameFormatter'),
(587, 'list', 'ProjectExpense', 1, 'idle', 'idle', 0, 6, 5, 'idle', NULL, 'booleanFormatter'),
(588, 'list', 'ProjectExpense', 1, 'reference', 'reference', 1, 7, 5, 'reference', NULL, NULL),
(589, 'list', 'ProjectExpense', 1, 'expensePlannedDate', 'expensePlannedDate', 1, 8, 10, 'expensePlannedDate', NULL, 'dateFormatter'),
(590, 'list', 'ProjectExpense', 1, 'plannedAmount', 'plannedAmount', 1, 9, 5, 'plannedAmount', NULL, 'costFormatter'),
(591, 'list', 'ProjectExpense', 1, 'expenseRealDate', 'expenseRealDate', 1, 10, 10, 'expenseRealDate', NULL, 'dateFormatter'),
(592, 'list', 'ProjectExpense', 1, 'realAmount', 'realAmount', 1, 11, 5, 'realAmount', NULL, 'costFormatter'),
(593, 'list', 'ProjectExpense', 1, 'cancelled', 'cancelled', 1, 12, 5, 'cancelled', NULL, 'booleanFormatter'),
(594, 'list', 'Term', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(595, 'list', 'Term', 1, 'nameProject', 'idProject', 0, 2, 20, 'idProject', NULL, NULL),
(596, 'list', 'Term', 1, 'name', 'name', 0, 3, 30, 'name', NULL, NULL),
(597, 'list', 'Term', 1, 'amount', 'amount', 0, 4, 15, 'amount', NULL, NULL),
(598, 'list', 'Term', 1, 'date', 'date', 0, 5, 15, 'date', NULL, 'dateFormatter'),
(599, 'list', 'Term', 1, 'idBill', 'idBill', 0, 6, 10, 'isBilled', NULL, 'booleanFormatter'),
(600, 'list', 'Term', 1, 'idle', 'idle', 0, 7, 5, 'idle', NULL, 'booleanFormatter'),
(601, 'list', 'Term', 1, 'validatedAmount', 'validatedAmount', 1, 8, 5, 'validatedAmount', NULL, 'costFormatter'),
(602, 'list', 'Term', 1, 'plannedAmount', 'plannedAmount', 1, 9, 5, 'plannedAmount', NULL, 'costFormatter'),
(603, 'list', 'Term', 1, 'validatedDate', 'validatedDate', 1, 10, 10, 'validatedDate', NULL, 'dateFormatter'),
(604, 'list', 'Term', 1, 'plannedDate', 'plannedDate', 1, 11, 10, 'plannedDate', NULL, 'dateFormatter'),
(621, 'list', 'ActivityPrice', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(622, 'list', 'ActivityPrice', 1, 'name', 'name', 0, 2, 25, 'name', NULL, NULL),
(623, 'list', 'ActivityPrice', 1, 'nameProject', 'idProject', 0, 3, 20, 'idProject', NULL, NULL),
(624, 'list', 'ActivityPrice', 1, 'nameActivityType', 'idActivityType', 0, 4, 20, 'idActivityType', NULL, NULL),
(625, 'list', 'ActivityPrice', 1, 'priceCost', 'priceCost', 0, 5, 15, 'priceCost', NULL, NULL),
(626, 'list', 'ActivityPrice', 1, 'sortOrder', 'sortOrder', 0, 6, 10, 'sortOrderShort', NULL, NULL),
(627, 'list', 'ActivityPrice', 1, 'idle', 'idle', 0, 7, 5, 'idle', NULL, 'booleanFormatter'),
(628, 'list', 'Meeting', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(629, 'list', 'Meeting', 1, 'nameProject', 'idProject', 0, 2, 15, 'idProject', NULL, NULL),
(630, 'list', 'Meeting', 1, 'nameMeetingType', 'idMeetingType', 0, 3, 15, 'idMeetingType', NULL, NULL),
(631, 'list', 'Meeting', 1, 'meetingDate', 'meetingDate', 0, 4, 15, 'meetingDate', NULL, 'dateFormatter'),
(632, 'list', 'Meeting', 1, 'name', 'name', 0, 5, 25, 'name', NULL, NULL),
(633, 'list', 'Meeting', 1, 'colorNameStatus', 'idStatus', 0, 6, 10, 'idStatus', NULL, 'colorNameFormatter'),
(634, 'list', 'Meeting', 1, 'handled', 'handled', 0, 7, 5, 'handled', NULL, 'booleanFormatter'),
(635, 'list', 'Meeting', 1, 'done', 'done', 0, 8, 5, 'done', NULL, 'booleanFormatter'),
(636, 'list', 'Meeting', 1, 'idle', 'idle', 0, 9, 5, 'idle', NULL, 'booleanFormatter'),
(637, 'list', 'Meeting', 1, 'reference', 'reference', 1, 10, 5, 'reference', NULL, NULL),
(638, 'list', 'Meeting', 1, 'isPeriodic', 'isPeriodic', 1, 11, 5, 'isPeriodic', NULL, 'booleanFormatter'),
(639, 'list', 'Meeting', 1, 'meetingStartTime', 'meetingStartTime', 1, 12, 10, 'meetingStartTime', NULL, 'timeFormatter'),
(640, 'list', 'Meeting', 1, 'meetingEndTime', 'meetingEndTime', 1, 13, 10, 'meetingEndTime', NULL, 'timeFormatter'),
(641, 'list', 'Meeting', 1, 'location', 'location', 1, 14, 5, 'location', NULL, NULL),
(642, 'list', 'Meeting', 1, 'assignedWork', 'assignedWork', 1, 15, 5, 'assignedWork', 'MeetingPlanningElement', 'workFormatter'),
(643, 'list', 'Meeting', 1, 'realWork', 'realWork', 1, 16, 5, 'realWork', 'MeetingPlanningElement', 'workFormatter'),
(644, 'list', 'Meeting', 1, 'leftWork', 'leftWork', 1, 17, 5, 'leftWork', 'MeetingPlanningElement', 'workFormatter'),
(645, 'list', 'Meeting', 1, 'assignedCost', 'assignedCost', 1, 18, 5, 'assignedCost', 'MeetingPlanningElement', 'costFormatter'),
(646, 'list', 'Meeting', 1, 'realCost', 'realCost', 1, 19, 5, 'realCost', 'MeetingPlanningElement', 'costFormatter'),
(647, 'list', 'Meeting', 1, 'leftCost', 'leftCost', 1, 20, 5, 'leftCost', 'MeetingPlanningElement', 'costFormatter'),
(648, 'list', 'Meeting', 1, 'nameActivity', 'idActivity', 1, 15, 10, 'idActivity', NULL, NULL),
(649, 'list', 'Meeting', 1, 'nameResource', 'idResource', 1, 16, 10, 'idResource', NULL, 'thumbName22'),
(650, 'list', 'Meeting', 1, 'handledDate', 'handledDate', 1, 17, 10, 'handledDate', NULL, 'dateFormatter'),
(651, 'list', 'Meeting', 1, 'doneDate', 'doneDate', 1, 18, 10, 'doneDate', NULL, 'dateFormatter'),
(652, 'list', 'Meeting', 1, 'idleDate', 'idleDate', 1, 19, 10, 'idleDate', NULL, 'dateFormatter'),
(653, 'list', 'Meeting', 1, 'cancelled', 'cancelled', 1, 20, 5, 'cancelled', NULL, 'booleanFormatter'),
(654, 'list', 'PeriodicMeeting', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(655, 'list', 'PeriodicMeeting', 1, 'nameProject', 'idProject', 0, 2, 14, 'idProject', NULL, NULL),
(656, 'list', 'PeriodicMeeting', 1, 'nameMeetingType', 'idMeetingType', 0, 3, 14, 'idMeetingType', NULL, NULL),
(657, 'list', 'PeriodicMeeting', 1, 'name', 'name', 0, 4, 22, 'name', NULL, NULL),
(658, 'list', 'PeriodicMeeting', 1, 'periodicityStartDate', 'periodicityStartDate', 0, 5, 10, 'startDate', NULL, 'dateFormatter'),
(659, 'list', 'PeriodicMeeting', 1, 'periodicityEndDate', 'periodicityEndDate', 0, 6, 10, 'endDate', NULL, 'dateFormatter'),
(660, 'list', 'PeriodicMeeting', 1, 'periodicityTimes', 'periodicityTimes', 0, 7, 6, 'periodicityTimes', NULL, NULL),
(661, 'list', 'PeriodicMeeting', 1, 'meetingStartTime', 'meetingStartTime', 0, 8, 8, 'startTime', NULL, NULL),
(662, 'list', 'PeriodicMeeting', 1, 'meetingEndTime', 'meetingEndTime', 0, 9, 8, 'endTime', NULL, NULL),
(663, 'list', 'PeriodicMeeting', 1, 'idle', 'idle', 0, 10, 5, 'idle', NULL, 'booleanFormatter'),
(664, 'list', 'PeriodicMeeting', 1, 'location', 'location', 1, 11, 5, 'location', NULL, NULL),
(665, 'list', 'PeriodicMeeting', 1, 'assignedWork', 'assignedWork', 1, 12, 5, 'assignedWork', 'MeetingPlanningElement', 'workFormatter'),
(666, 'list', 'PeriodicMeeting', 1, 'realWork', 'realWork', 1, 13, 5, 'realWork', 'MeetingPlanningElement', 'workFormatter'),
(667, 'list', 'PeriodicMeeting', 1, 'leftWork', 'leftWork', 1, 14, 5, 'leftWork', 'MeetingPlanningElement', 'workFormatter'),
(668, 'list', 'PeriodicMeeting', 1, 'assignedCost', 'assignedCost', 1, 15, 5, 'assignedCost', 'MeetingPlanningElement', 'costFormatter'),
(669, 'list', 'PeriodicMeeting', 1, 'realCost', 'realCost', 1, 16, 5, 'realCost', 'MeetingPlanningElement', 'costFormatter'),
(670, 'list', 'PeriodicMeeting', 1, 'leftCost', 'leftCost', 1, 17, 5, 'leftCost', 'MeetingPlanningElement', 'costFormatter'),
(671, 'list', 'PeriodicMeeting', 1, 'nameActivity', 'idActivity', 1, 12, 10, 'idActivity', NULL, NULL),
(672, 'list', 'PeriodicMeeting', 1, 'nameResource', 'idResource', 1, 13, 10, 'idResource', NULL, 'thumbName22'),
(673, 'list', 'PeriodicMeeting', 1, 'namePeriodicity', 'idPeriodicity', 1, 14, 10, 'idPeriodicity', NULL, 'translateFormatter'),
(674, 'list', 'PeriodicMeeting', 1, 'periodicityOpenDays', 'periodicityOpenDays', 1, 15, 5, 'periodicityOpenDays', NULL, 'booleanFormatter'),
(711, 'list', 'TestCase', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(712, 'list', 'TestCase', 1, 'nameProject', 'idProject', 0, 2, 8, 'idProject', NULL, NULL),
(713, 'list', 'TestCase', 1, 'nameProduct', 'idProduct', 0, 3, 8, 'idProduct', NULL, NULL),
(714, 'list', 'TestCase', 1, 'nameVersion', 'idVersion', 0, 4, 8, 'idVersion', NULL, NULL),
(715, 'list', 'TestCase', 1, 'nameTestCaseType', 'idTestCaseType', 0, 5, 10, 'type', NULL, NULL),
(716, 'list', 'TestCase', 1, 'name', 'name', 0, 6, 20, 'name', NULL, NULL),
(717, 'list', 'TestCase', 1, 'colorNameRunStatus', 'idRunStatus', 0, 7, 6, 'testSummary', NULL, 'colorNameFormatter'),
(718, 'list', 'TestCase', 1, 'colorNameStatus', 'idStatus', 0, 8, 10, 'idStatus', NULL, 'colorNameFormatter'),
(719, 'list', 'TestCase', 1, 'nameResource', 'idResource', 0, 9, 10, 'responsible', NULL, 'thumbName22'),
(720, 'list', 'TestCase', 1, 'handled', 'handled', 0, 10, 5, 'handled', NULL, 'booleanFormatter'),
(721, 'list', 'TestCase', 1, 'done', 'done', 0, 11, 5, 'done', NULL, 'booleanFormatter'),
(722, 'list', 'TestCase', 1, 'idle', 'idle', 0, 12, 5, 'idle', NULL, 'booleanFormatter'),
(723, 'list', 'TestCase', 1, 'reference', 'reference', 1, 13, 5, 'reference', NULL, NULL),
(724, 'list', 'TestCase', 1, 'externalReference', 'externalReference', 1, 14, 5, 'externalReference', NULL, NULL),
(725, 'list', 'TestCase', 1, 'creationDateTime', 'creationDateTime', 1, 15, 10, 'creationDateTime', NULL, 'dateTimeFormatter'),
(726, 'list', 'TestCase', 1, 'nameContext1', 'idContext1', 1, 16, 10, 'idContext1', NULL, NULL),
(727, 'list', 'TestCase', 1, 'nameContext2', 'idContext2', 1, 17, 10, 'idContext2', NULL, NULL),
(728, 'list', 'TestCase', 1, 'nameContext3', 'idContext3', 1, 18, 10, 'idContext3', NULL, NULL),
(729, 'list', 'TestCase', 1, 'nameTestCase', 'idTestCase', 1, 19, 10, 'idTestCase', NULL, NULL),
(730, 'list', 'TestCase', 1, 'colorNamePriority', 'idPriority', 1, 20, 10, 'idPriority', NULL, 'colorNameFormatter'),
(731, 'list', 'TestCase', 1, 'handledDate', 'handledDate', 1, 21, 10, 'handledDate', NULL, 'dateFormatter'),
(732, 'list', 'TestCase', 1, 'doneDate', 'doneDate', 1, 22, 10, 'doneDate', NULL, 'dateFormatter'),
(733, 'list', 'TestCase', 1, 'idleDate', 'idleDate', 1, 23, 10, 'idleDate', NULL, 'dateFormatter'),
(734, 'list', 'TestCase', 1, 'cancelled', 'cancelled', 1, 24, 5, 'cancelled', NULL, 'booleanFormatter'),
(735, 'list', 'TestSession', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(736, 'list', 'TestSession', 1, 'nameProject', 'idProject', 0, 2, 8, 'idProject', NULL, NULL),
(737, 'list', 'TestSession', 1, 'nameProduct', 'idProduct', 0, 3, 8, 'idProduct', NULL, NULL),
(738, 'list', 'TestSession', 1, 'nameVersion', 'idVersion', 0, 4, 8, 'idVersion', NULL, NULL),
(739, 'list', 'TestSession', 1, 'nameTestSessionType', 'idTestSessionType', 0, 5, 10, 'type', NULL, NULL),
(740, 'list', 'TestSession', 1, 'name', 'name', 0, 6, 20, 'name', NULL, NULL),
(741, 'list', 'TestSession', 1, 'colorNameRunStatus', 'idRunStatus', 0, 7, 6, 'testSummary', NULL, 'colorNameFormatter'),
(742, 'list', 'TestSession', 1, 'colorNameStatus', 'idStatus', 0, 8, 10, 'idStatus', NULL, 'colorNameFormatter'),
(743, 'list', 'TestSession', 1, 'nameResource', 'idResource', 0, 9, 10, 'responsible', NULL, 'thumbName22'),
(744, 'list', 'TestSession', 1, 'handled', 'handled', 0, 10, 5, 'handled', NULL, 'booleanFormatter'),
(745, 'list', 'TestSession', 1, 'done', 'done', 0, 11, 5, 'done', NULL, 'booleanFormatter'),
(746, 'list', 'TestSession', 1, 'idle', 'idle', 0, 12, 5, 'idle', NULL, 'booleanFormatter'),
(747, 'list', 'TestSession', 1, 'reference', 'reference', 1, 13, 5, 'reference', NULL, NULL),
(748, 'list', 'TestSession', 1, 'externalReference', 'externalReference', 1, 14, 5, 'externalReference', NULL, NULL),
(749, 'list', 'TestSession', 1, 'creationDateTime', 'creationDateTime', 1, 15, 10, 'creationDateTime', NULL, 'dateTimeFormatter'),
(750, 'list', 'TestSession', 1, 'nameActivity', 'idActivity', 1, 16, 10, 'idActivity', NULL, NULL),
(751, 'list', 'TestSession', 1, 'nameTestSession', 'idTestSession', 1, 17, 10, 'idTestSession', NULL, NULL),
(752, 'list', 'TestSession', 1, 'handledDate', 'handledDate', 1, 18, 10, 'handledDate', NULL, 'dateFormatter'),
(753, 'list', 'TestSession', 1, 'doneDate', 'doneDate', 1, 19, 10, 'doneDate', NULL, 'dateFormatter'),
(754, 'list', 'TestSession', 1, 'idleDate', 'idleDate', 1, 20, 10, 'idleDate', NULL, 'dateFormatter'),
(755, 'list', 'TestSession', 1, 'cancelled', 'cancelled', 1, 21, 5, 'cancelled', NULL, 'booleanFormatter'),
(756, 'list', 'TestSession', 1, 'initialStartDate', 'initialStartDate', 1, 22, 10, 'initialStartDate', 'TestSessionPlanningElement', 'dateFormatter'),
(757, 'list', 'TestSession', 1, 'validatedStartDate', 'validatedStartDate', 1, 23, 10, 'validatedStartDate', 'TestSessionPlanningElement', 'dateFormatter'),
(758, 'list', 'TestSession', 1, 'plannedStartDate', 'plannedStartDate', 1, 24, 10, 'plannedStartDate', 'TestSessionPlanningElement', 'dateFormatter'),
(759, 'list', 'TestSession', 1, 'realStartDate', 'realStartDate', 1, 25, 10, 'realStartDate', 'TestSessionPlanningElement', 'dateFormatter'),
(760, 'list', 'TestSession', 1, 'priority', 'priority', 1, 26, 5, 'priority', 'TestSessionPlanningElement', 'numericFormatter'),
(761, 'list', 'TestSession', 1, 'initialEndDate', 'initialEndDate', 1, 27, 10, 'initialEndDate', 'TestSessionPlanningElement', 'dateFormatter'),
(762, 'list', 'TestSession', 1, 'validatedEndDate', 'validatedEndDate', 1, 28, 10, 'validatedEndDate', 'TestSessionPlanningElement', 'dateFormatter'),
(763, 'list', 'TestSession', 1, 'plannedEndDate', 'plannedEndDate', 1, 29, 10, 'plannedEndDate', 'TestSessionPlanningElement', 'dateFormatter'),
(764, 'list', 'TestSession', 1, 'realEndDate', 'realEndDate', 1, 30, 10, 'realEndDate', 'TestSessionPlanningElement', 'dateFormatter'),
(765, 'list', 'TestSession', 1, 'nameTestSessionPlanningMode', 'idTestSessionPlanningMode', 1, 31, 10, 'idTestSessionPlanningMode', 'TestSessionPlanningElement', 'translateFormatter'),
(766, 'list', 'TestSession', 1, 'initialDuration', 'initialDuration', 1, 32, 5, 'initialDuration', 'TestSessionPlanningElement', 'numericFormatter'),
(767, 'list', 'TestSession', 1, 'validatedDuration', 'validatedDuration', 1, 33, 5, 'validatedDuration', 'TestSessionPlanningElement', 'numericFormatter'),
(768, 'list', 'TestSession', 1, 'plannedDuration', 'plannedDuration', 1, 34, 5, 'plannedDuration', 'TestSessionPlanningElement', 'numericFormatter'),
(769, 'list', 'TestSession', 1, 'realDuration', 'realDuration', 1, 35, 5, 'realDuration', 'TestSessionPlanningElement', 'numericFormatter'),
(770, 'list', 'TestSession', 1, 'wbs', 'wbs', 1, 36, 5, 'wbs', 'TestSessionPlanningElement', NULL),
(771, 'list', 'TestSession', 1, 'validatedWork', 'validatedWork', 1, 37, 5, 'validatedWork', 'TestSessionPlanningElement', 'workFormatter'),
(772, 'list', 'TestSession', 1, 'assignedWork', 'assignedWork', 1, 38, 5, 'assignedWork', 'TestSessionPlanningElement', 'workFormatter'),
(773, 'list', 'TestSession', 1, 'plannedWork', 'plannedWork', 1, 39, 5, 'plannedWork', 'TestSessionPlanningElement', 'workFormatter'),
(774, 'list', 'TestSession', 1, 'realWork', 'realWork', 1, 40, 5, 'realWork', 'TestSessionPlanningElement', 'workFormatter'),
(775, 'list', 'TestSession', 1, 'leftWork', 'leftWork', 1, 41, 5, 'leftWork', 'TestSessionPlanningElement', 'workFormatter'),
(776, 'list', 'TestSession', 1, 'progress', 'progress', 1, 42, 5, 'progress', 'TestSessionPlanningElement', 'percentFormatter');
INSERT INTO `columnselector` (`id`, `scope`, `objectClass`, `idUser`, `field`, `attribute`, `hidden`, `sortOrder`, `widthPct`, `name`, `subItem`, `formatter`) VALUES
(777, 'list', 'TestSession', 1, 'validatedCost', 'validatedCost', 1, 43, 5, 'validatedCost', 'TestSessionPlanningElement', 'costFormatter'),
(778, 'list', 'TestSession', 1, 'assignedCost', 'assignedCost', 1, 44, 5, 'assignedCost', 'TestSessionPlanningElement', 'costFormatter'),
(779, 'list', 'TestSession', 1, 'plannedCost', 'plannedCost', 1, 45, 5, 'plannedCost', 'TestSessionPlanningElement', 'costFormatter'),
(780, 'list', 'TestSession', 1, 'realCost', 'realCost', 1, 46, 5, 'realCost', 'TestSessionPlanningElement', 'costFormatter'),
(781, 'list', 'TestSession', 1, 'leftCost', 'leftCost', 1, 47, 5, 'leftCost', 'TestSessionPlanningElement', 'costFormatter'),
(782, 'list', 'TestSession', 1, 'expectedProgress', 'expectedProgress', 1, 48, 5, 'expectedProgress', 'TestSessionPlanningElement', 'percentFormatter'),
(783, 'list', 'TestSession', 1, 'countTotal', 'countTotal', 1, 22, 5, 'countTotal', NULL, 'numericFormatter'),
(784, 'list', 'TestSession', 1, 'countPlanned', 'countPlanned', 1, 23, 5, 'countPlanned', NULL, 'numericFormatter'),
(785, 'list', 'TestSession', 1, 'countPassed', 'countPassed', 1, 24, 5, 'countPassed', NULL, 'numericFormatter'),
(786, 'list', 'TestSession', 1, 'countBlocked', 'countBlocked', 1, 25, 5, 'countBlocked', NULL, 'numericFormatter'),
(787, 'list', 'TestSession', 1, 'countFailed', 'countFailed', 1, 26, 5, 'countFailed', NULL, 'numericFormatter'),
(788, 'list', 'TestSession', 1, 'countIssues', 'countIssues', 1, 27, 5, 'countIssues', NULL, 'numericFormatter'),
(789, 'list', 'Resource', 1, 'dontReceiveTeamMails', 'dontReceiveTeamMails', 1, 18, 5, 'dontReceiveTeamMails', NULL, 'booleanFormatter'),
(790, 'list', 'ProjectExpenseType', 1, 'id', 'id', 0, 1, 10, 'id', NULL, 'numericFormatter'),
(791, 'list', 'ProjectExpenseType', 1, 'name', 'name', 0, 2, 60, 'name', NULL, NULL),
(792, 'list', 'ProjectExpenseType', 1, 'sortOrder', 'sortOrder', 0, 3, 5, 'sortOrderShort', NULL, NULL),
(793, 'list', 'ProjectExpenseType', 1, 'nameWorkflow', 'idWorkflow', 0, 4, 20, 'idWorkflow', NULL, NULL),
(794, 'list', 'ProjectExpenseType', 1, 'idle', 'idle', 0, 5, 5, 'idle', NULL, 'booleanFormatter'),
(795, 'list', 'ProjectExpenseType', 1, 'mandatoryDescription', 'mandatoryDescription', 1, 6, 5, 'mandatoryDescription', NULL, 'booleanFormatter'),
(796, 'list', 'ProjectExpenseType', 1, 'lockIdle', 'lockIdle', 1, 7, 5, 'lockIdle', NULL, 'booleanFormatter'),
(797, 'list', 'ProjectExpenseType', 1, 'lockCancelled', 'lockCancelled', 1, 8, 5, 'lockCancelled', NULL, 'booleanFormatter'),
(798, 'list', 'ExpenseDetailType', 1, 'id', 'id', 0, 1, 5, 'id', NULL, 'numericFormatter'),
(799, 'list', 'ExpenseDetailType', 1, 'name', 'name', 0, 2, 26, 'name', NULL, NULL),
(800, 'list', 'ExpenseDetailType', 1, 'sortOrder', 'sortOrder', 0, 3, 5, 'sortOrder', NULL, NULL),
(801, 'list', 'ExpenseDetailType', 1, 'value01', 'value01', 0, 4, 5, 'value', NULL, NULL),
(802, 'list', 'ExpenseDetailType', 1, 'unit01', 'unit01', 0, 5, 10, 'unit', NULL, NULL),
(803, 'list', 'ExpenseDetailType', 1, 'value02', 'value02', 0, 6, 5, 'value', NULL, NULL),
(804, 'list', 'ExpenseDetailType', 1, 'unit02', 'unit02', 0, 7, 10, 'unit', NULL, NULL),
(805, 'list', 'ExpenseDetailType', 1, 'value03', 'value03', 0, 8, 5, 'value', NULL, NULL),
(806, 'list', 'ExpenseDetailType', 1, 'unit03', 'unit03', 0, 9, 10, 'unit', NULL, NULL),
(807, 'list', 'ExpenseDetailType', 1, 'individual', 'individual', 0, 10, 7, 'individualExpense', NULL, 'booleanFormatter'),
(808, 'list', 'ExpenseDetailType', 1, 'project', 'project', 0, 11, 7, 'projectExpense', NULL, 'booleanFormatter'),
(809, 'list', 'ExpenseDetailType', 1, 'idle', 'idle', 0, 12, 5, 'idle', NULL, 'booleanFormatter'),
(810, 'list', 'Ticket', 1, 'id', 'id', 0, 1, 4, 'id', NULL, 'numericFormatter'),
(811, 'list', 'Ticket', 1, 'nameProject', 'idProject', 0, 2, 7, 'idProject', NULL, NULL),
(812, 'list', 'Ticket', 1, 'nameTicketType', 'idTicketType', 0, 3, 7, 'idTicketType', NULL, NULL),
(813, 'list', 'Ticket', 1, 'name', 'name', 0, 4, 17, 'name', NULL, NULL),
(814, 'list', 'Ticket', 1, 'nameUser', 'idUser', 0, 5, 10, 'issuer', NULL, 'thumbName22'),
(815, 'list', 'Ticket', 1, 'colorNameUrgency', 'idUrgency', 0, 6, 7, 'idUrgency', NULL, 'colorNameFormatter'),
(816, 'list', 'Ticket', 1, 'colorNamePriority', 'idPriority', 0, 7, 7, 'idPriority', NULL, 'colorNameFormatter'),
(817, 'list', 'Ticket', 1, 'colorNameStatus', 'idStatus', 0, 8, 7, 'idStatus', NULL, 'colorNameFormatter'),
(818, 'list', 'Ticket', 1, 'actualDueDateTime', 'actualDueDateTime', 0, 9, 7, 'actualDueDateTime', NULL, 'dateTimeFormatter'),
(819, 'list', 'Ticket', 1, 'nameTargetProductVersion', 'idTargetProductVersion', 0, 10, 7, 'idTargetProductVersion', NULL, NULL),
(820, 'list', 'Ticket', 1, 'nameResource', 'idResource', 0, 11, 10, 'responsible', NULL, 'thumbName22'),
(821, 'list', 'Ticket', 1, 'handled', 'handled', 0, 12, 3, 'handled', NULL, 'booleanFormatter'),
(822, 'list', 'Ticket', 1, 'done', 'done', 0, 13, 3, 'done', NULL, 'booleanFormatter'),
(823, 'list', 'Ticket', 1, 'idle', 'idle', 0, 14, 3, 'idle', NULL, 'booleanFormatter'),
(824, 'list', 'Ticket', 1, 'reference', 'reference', 1, 15, 5, 'reference', NULL, NULL),
(825, 'list', 'Ticket', 1, 'externalReference', 'externalReference', 1, 16, 5, 'externalReference', NULL, NULL),
(826, 'list', 'Ticket', 1, 'creationDateTime', 'creationDateTime', 1, 17, 10, 'creationDateTime', NULL, 'dateTimeFormatter'),
(827, 'list', 'Ticket', 1, 'lastUpdateDateTime', 'lastUpdateDateTime', 1, 18, 10, 'lastUpdateDateTime', NULL, 'dateTimeFormatter'),
(828, 'list', 'Ticket', 1, 'nameContact', 'idContact', 1, 19, 10, 'idContact', NULL, 'thumbName22'),
(829, 'list', 'Ticket', 1, 'nameTicket', 'idTicket', 1, 20, 10, 'idTicket', NULL, NULL),
(830, 'list', 'Ticket', 1, 'nameContext1', 'idContext1', 1, 21, 10, 'idContext1', NULL, NULL),
(831, 'list', 'Ticket', 1, 'nameContext2', 'idContext2', 1, 22, 10, 'idContext2', NULL, NULL),
(832, 'list', 'Ticket', 1, 'nameContext3', 'idContext3', 1, 23, 10, 'idContext3', NULL, NULL),
(833, 'list', 'Ticket', 1, 'nameActivity', 'idActivity', 1, 24, 10, 'idActivity', NULL, NULL),
(834, 'list', 'Ticket', 1, 'colorNameResolution', 'idResolution', 1, 25, 10, 'idResolution', NULL, 'colorNameFormatter'),
(835, 'list', 'Ticket', 1, 'colorNameCriticality', 'idCriticality', 1, 26, 10, 'idCriticality', NULL, 'colorNameFormatter'),
(836, 'list', 'Ticket', 1, 'initialDueDateTime', 'initialDueDateTime', 1, 27, 10, 'initialDueDateTime', NULL, 'dateTimeFormatter'),
(837, 'list', 'Ticket', 1, 'plannedWork', 'plannedWork', 1, 28, 5, 'plannedWork', 'WorkElement', 'workFormatter'),
(838, 'list', 'Ticket', 1, 'realWork', 'realWork', 1, 29, 5, 'realWork', 'WorkElement', 'workFormatter'),
(839, 'list', 'Ticket', 1, 'leftWork', 'leftWork', 1, 30, 5, 'leftWork', 'WorkElement', 'workFormatter'),
(840, 'list', 'Ticket', 1, 'handledDateTime', 'handledDateTime', 1, 28, 10, 'handledDateTime', NULL, 'dateTimeFormatter'),
(841, 'list', 'Ticket', 1, 'doneDateTime', 'doneDateTime', 1, 29, 10, 'doneDateTime', NULL, 'dateTimeFormatter'),
(842, 'list', 'Ticket', 1, 'solved', 'solved', 1, 30, 5, 'solved', NULL, 'booleanFormatter'),
(843, 'list', 'Ticket', 1, 'idleDateTime', 'idleDateTime', 1, 31, 10, 'idleDateTime', NULL, 'dateTimeFormatter'),
(844, 'list', 'Ticket', 1, 'cancelled', 'cancelled', 1, 32, 5, 'cancelled', NULL, 'booleanFormatter'),
(845, 'list', 'Ticket', 1, 'nameProduct', 'idProduct', 1, 33, 10, 'idProduct', NULL, NULL),
(846, 'list', 'Ticket', 1, 'nameComponent', 'idComponent', 1, 34, 10, 'idComponent', NULL, NULL),
(847, 'list', 'Ticket', 1, 'nameOriginalProductVersion', 'idOriginalProductVersion', 1, 35, 10, 'idOriginalProductVersion', NULL, NULL),
(848, 'list', 'Ticket', 1, 'nameOriginalComponentVersion', 'idOriginalComponentVersion', 1, 36, 10, 'idOriginalComponentVersion', NULL, NULL),
(849, 'list', 'Ticket', 1, 'nameTargetComponentVersion', 'idTargetComponentVersion', 1, 37, 10, 'idTargetComponentVersion', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `command`
--

CREATE TABLE `command` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idCommandType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `additionalInfo` mediumtext,
  `externalReference` varchar(100) DEFAULT NULL,
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `initialStartDate` date DEFAULT NULL,
  `initialEndDate` date DEFAULT NULL,
  `validatedEndDate` date DEFAULT NULL,
  `initialWork` decimal(12,2) DEFAULT '0.00',
  `initialPricePerDayAmount` decimal(12,2) DEFAULT '0.00',
  `untaxedAmount` decimal(12,2) DEFAULT NULL,
  `addWork` decimal(12,2) DEFAULT '0.00',
  `addPricePerDayAmount` decimal(12,2) DEFAULT '0.00',
  `addUntaxedAmount` decimal(12,2) DEFAULT NULL,
  `validatedWork` decimal(12,2) DEFAULT '0.00',
  `validatedPricePerDayAmount` decimal(12,2) DEFAULT '0.00',
  `totalUntaxedAmount` decimal(12,2) DEFAULT NULL,
  `comment` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `validatedStartDate` date DEFAULT NULL,
  `idActivityType` int(12) UNSIGNED DEFAULT NULL,
  `idClient` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `idPaymentDelay` int(12) UNSIGNED DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT NULL,
  `fullAmount` decimal(12,2) DEFAULT NULL,
  `addFullAmount` decimal(12,2) DEFAULT NULL,
  `totalFullAmount` decimal(12,2) DEFAULT NULL,
  `idDeliveryMode` int(12) UNSIGNED DEFAULT NULL,
  `receptionDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `context`
--

CREATE TABLE `context` (
  `id` int(12) UNSIGNED NOT NULL,
  `idContextType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `context`
--

INSERT INTO `context` (`id`, `idContextType`, `name`, `sortOrder`, `idle`) VALUES
(1, 1, 'Production', 100, 0),
(2, 1, 'Validation', 200, 0),
(3, 2, 'Windows 7', 100, 0),
(4, 2, 'Windows Vista', 110, 0),
(5, 2, 'Windows XP', 120, 0),
(6, 2, 'Mac OS X', 200, 0),
(7, 2, 'Mac OS <=9', 210, 0),
(8, 2, 'Linux', 210, 0),
(9, 3, 'IE 9', 100, 0),
(10, 3, 'IE 8', 110, 0),
(11, 3, 'IE 7', 120, 0),
(12, 3, 'IE <= 6', 130, 0),
(13, 3, 'FireFox >= 5', 200, 0),
(14, 3, 'FireFox <= 4', 210, 0),
(15, 3, 'Chrome', 300, 0),
(16, 3, 'Safari', 400, 0);

-- --------------------------------------------------------

--
-- Structure de la table `contexttype`
--

CREATE TABLE `contexttype` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `description` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `contexttype`
--

INSERT INTO `contexttype` (`id`, `name`, `idle`, `description`) VALUES
(1, 'environment', 0, NULL),
(2, 'OS', 0, NULL),
(3, 'browser', 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `copyable`
--

CREATE TABLE `copyable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `sortOrder` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `copyable`
--

INSERT INTO `copyable` (`id`, `name`, `idle`, `sortOrder`) VALUES
(1, 'Ticket', 0, 10),
(2, 'Activity', 0, 20),
(3, 'Milestone', 0, 30),
(4, 'IndividualExpense', 0, 40),
(5, 'ProjectExpense', 0, 50),
(6, 'Risk', 0, 60),
(7, 'Action', 0, 32),
(8, 'Issue', 0, 80),
(9, 'Meeting', 0, 90),
(10, 'Decision', 0, 100),
(11, 'Question', 0, 110),
(12, 'Requirement', 0, 35),
(13, 'Command', 0, 36),
(14, 'Quotation', 0, 37),
(15, 'Bill', 0, 38),
(16, 'Tender', 0, 120);

-- --------------------------------------------------------

--
-- Structure de la table `criticality`
--

CREATE TABLE `criticality` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` int(3) UNSIGNED DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `criticality`
--

INSERT INTO `criticality` (`id`, `name`, `value`, `color`, `sortOrder`, `idle`) VALUES
(1, 'Low', 1, '#32cd32', 10, 0),
(2, 'Medium', 2, '#ffd700', 20, 0),
(3, 'High', 4, '#ff0000', 30, 0),
(4, 'Critical', 8, '#000000', 40, 0);

-- --------------------------------------------------------

--
-- Structure de la table `cronexecution`
--

CREATE TABLE `cronexecution` (
  `id` int(12) UNSIGNED NOT NULL,
  `cron` varchar(100) DEFAULT NULL,
  `fileExecuted` varchar(500) DEFAULT NULL,
  `idle` int(1) DEFAULT NULL,
  `fonctionName` varchar(256) DEFAULT NULL,
  `nextTime` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `decision`
--

CREATE TABLE `decision` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idDecisionType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `decisionDate` date DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `decision`
--

INSERT INTO `decision` (`id`, `idProject`, `idDecisionType`, `name`, `description`, `creationDate`, `idUser`, `decisionDate`, `origin`, `idResource`, `idStatus`, `idle`, `reference`, `externalReference`, `cancelled`, `done`) VALUES
(1, 1, 33, 'Go for deployment', NULL, NULL, 1, '2012-03-15', 'Steering', NULL, 1, 0, '001-001-FUN-1', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `delay`
--

CREATE TABLE `delay` (
  `id` int(12) UNSIGNED NOT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `idType` int(12) UNSIGNED DEFAULT NULL,
  `idUrgency` int(12) UNSIGNED DEFAULT NULL,
  `value` decimal(6,3) DEFAULT NULL,
  `idDelayUnit` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `delay`
--

INSERT INTO `delay` (`id`, `scope`, `idType`, `idUrgency`, `value`, `idDelayUnit`, `idle`) VALUES
(1, 'Ticket', 16, 1, '2.000', 2, 0),
(2, 'Ticket', 16, 2, '1.000', 4, 0),
(3, 'Ticket', 17, 1, '1.000', 4, 0),
(4, 'Ticket', 17, 1, '4.000', 4, 0),
(5, 'Ticket', 18, 1, '4.000', 2, 0),
(6, 'Ticket', 18, 2, '2.000', 4, 0);

-- --------------------------------------------------------

--
-- Structure de la table `delayunit`
--

CREATE TABLE `delayunit` (
  `id` int(12) UNSIGNED NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `delayunit`
--

INSERT INTO `delayunit` (`id`, `code`, `name`, `type`, `sortOrder`, `idle`) VALUES
(1, 'HH', 'hours', 'delay', 100, 0),
(2, 'OH', 'openHours', 'delay', 200, 0),
(3, 'DD', 'days', 'delay', 300, 0),
(4, 'OD', 'openDays', 'delay', 400, 0),
(5, 'PCT', 'percent', 'percent', 500, 0);

-- --------------------------------------------------------

--
-- Structure de la table `deliverymode`
--

CREATE TABLE `deliverymode` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT '0',
  `idle` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `deliverymode`
--

INSERT INTO `deliverymode` (`id`, `name`, `sortOrder`, `idle`) VALUES
(1, 'email', 10, 0),
(2, 'postal mail', 20, 0),
(3, 'hand delivered', 30, 0),
(4, 'digital deposit', 40, 0);

-- --------------------------------------------------------

--
-- Structure de la table `dependable`
--

CREATE TABLE `dependable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `scope` varchar(10) DEFAULT 'PE',
  `idDefaultDependable` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `dependable`
--

INSERT INTO `dependable` (`id`, `name`, `idle`, `scope`, `idDefaultDependable`) VALUES
(1, 'Activity', 0, 'PE', 1),
(2, 'Milestone', 0, 'PE', 1),
(3, 'Project', 0, 'PE', 3),
(4, 'Requirement', 0, 'R', 4),
(5, 'TestCase', 0, 'TC', 5),
(6, 'TestSession', 0, 'PE', 6),
(7, 'Meeting', 0, 'PE', 1);

-- --------------------------------------------------------

--
-- Structure de la table `dependency`
--

CREATE TABLE `dependency` (
  `id` int(12) UNSIGNED NOT NULL,
  `predecessorId` int(12) UNSIGNED NOT NULL,
  `predecessorRefType` varchar(100) DEFAULT NULL,
  `predecessorRefId` int(12) UNSIGNED NOT NULL,
  `successorId` int(12) UNSIGNED DEFAULT NULL,
  `successorRefType` varchar(100) DEFAULT NULL,
  `successorRefId` int(12) UNSIGNED NOT NULL,
  `dependencyType` varchar(12) DEFAULT NULL,
  `dependencyDelay` int(3) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `dependency`
--

INSERT INTO `dependency` (`id`, `predecessorId`, `predecessorRefType`, `predecessorRefId`, `successorId`, `successorRefType`, `successorRefId`, `dependencyType`, `dependencyDelay`) VALUES
(1, 9, 'Activity', 3, 10, 'Activity', 4, 'E-S', 0),
(2, 10, 'Activity', 4, 11, 'Activity', 5, 'E-S', 0),
(3, 11, 'Activity', 5, 12, 'Milestone', 1, 'E-S', 0),
(4, 12, 'Milestone', 1, 13, 'Activity', 6, 'E-S', 0),
(6, 8, 'Activity', 2, NULL, 'Term', 1, 'E-S', 0),
(7, 0, 'Requirement', 1, NULL, 'Requirement', 2, 'E-S', 0),
(8, 0, 'TestCase', 1, NULL, 'TestCase', 2, 'E-S', 0),
(10, 10, 'Activity', 4, 15, 'TestSession', 1, 'E-S', 0);

-- --------------------------------------------------------

--
-- Structure de la table `document`
--

CREATE TABLE `document` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idDocumentType` int(12) UNSIGNED DEFAULT NULL,
  `idDocumentDirectory` int(12) UNSIGNED DEFAULT NULL,
  `idVersioningType` int(12) UNSIGNED DEFAULT NULL,
  `version` int(3) DEFAULT NULL,
  `revision` int(3) DEFAULT NULL,
  `draft` int(3) DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idDocumentVersion` int(12) UNSIGNED DEFAULT NULL,
  `idDocumentVersionRef` int(12) UNSIGNED DEFAULT NULL,
  `idAuthor` int(12) UNSIGNED DEFAULT NULL,
  `locked` int(1) UNSIGNED DEFAULT '0',
  `idLocker` int(12) UNSIGNED DEFAULT NULL,
  `lockedDate` datetime DEFAULT NULL,
  `fileName` varchar(100) DEFAULT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `documentReference` varchar(400) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `document`
--

INSERT INTO `document` (`id`, `reference`, `name`, `idProject`, `idProduct`, `idDocumentType`, `idDocumentDirectory`, `idVersioningType`, `version`, `revision`, `draft`, `idStatus`, `idDocumentVersion`, `idDocumentVersionRef`, `idAuthor`, `locked`, `idLocker`, `lockedDate`, `fileName`, `description`, `idle`, `documentReference`, `externalReference`, `cancelled`, `idUser`, `creationDate`) VALUES
(1, '001-001-GENCON-1', 'ARD - Architecture Dossier', 1, 2, 57, 5, 68, 1, 1, 1, 12, 4, 4, 3, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 3, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `documentdirectory`
--

CREATE TABLE `documentdirectory` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `location` varchar(4000) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idDocumentDirectory` int(12) UNSIGNED DEFAULT NULL,
  `idDocumentType` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `documentdirectory`
--

INSERT INTO `documentdirectory` (`id`, `reference`, `name`, `location`, `idProject`, `idProduct`, `idDocumentDirectory`, `idDocumentType`, `idle`) VALUES
(1, NULL, 'Project', '/Project', NULL, NULL, NULL, NULL, 0),
(2, NULL, 'Product', '/Product', NULL, NULL, NULL, NULL, 0),
(3, NULL, 'Need', '/Product/Need', NULL, NULL, 2, NULL, 0),
(4, NULL, 'Specification', '/Product/Specification', NULL, NULL, 2, NULL, 0),
(5, NULL, 'Conception', '/Product/Conception', NULL, NULL, 2, NULL, 0),
(7, NULL, 'Testing', '/Product/Testing', NULL, NULL, 2, NULL, 0),
(8, NULL, 'Deployment', '/Product/Deployment', NULL, NULL, 2, NULL, 0),
(9, NULL, 'Exploitation', '/Product/Exploitation', NULL, NULL, 2, NULL, 0),
(10, NULL, 'Contract', '/Project/Contract', NULL, NULL, 1, NULL, 0),
(11, NULL, 'Management', '/Project/Management', NULL, NULL, 1, NULL, 0),
(12, NULL, 'Reviews', '/Project/Reviews', NULL, NULL, 1, NULL, 0),
(13, NULL, 'Follow-up', '/Project/Follow-up', NULL, NULL, 1, NULL, 0),
(14, NULL, 'Financial', '/Project/Financial', NULL, NULL, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `documentversion`
--

CREATE TABLE `documentversion` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `fullName` varchar(200) DEFAULT NULL,
  `version` int(3) DEFAULT NULL,
  `revision` int(3) DEFAULT NULL,
  `draft` int(3) DEFAULT NULL,
  `fileName` varchar(400) DEFAULT NULL,
  `mimeType` varchar(100) DEFAULT NULL,
  `fileSize` int(12) DEFAULT NULL,
  `link` varchar(400) DEFAULT NULL,
  `versionDate` date DEFAULT NULL,
  `createDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `extension` varchar(100) DEFAULT NULL,
  `idDocument` int(12) UNSIGNED DEFAULT NULL,
  `idAuthor` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `isRef` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `approved` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `documentversion`
--

INSERT INTO `documentversion` (`id`, `name`, `fullName`, `version`, `revision`, `draft`, `fileName`, `mimeType`, `fileSize`, `link`, `versionDate`, `createDateTime`, `updateDateTime`, `extension`, `idDocument`, `idAuthor`, `idStatus`, `description`, `isRef`, `idle`, `approved`) VALUES
(3, 'V1.0', 'ARD - Architecture Dossier_V1.0', 1, 0, NULL, 'ARD-Architecture dossier-V1.0.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, '2012-03-16', '2012-03-16 14:47:00', '2012-05-03 18:45:22', NULL, 1, 1, 12, 'Initial version', 0, 0, 0),
(4, 'V1.1', 'ARD - Architecture Dossier_V1.1', 1, 1, NULL, 'ARD-Architecture dossier-V1.1.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, '2012-03-16', '2012-03-16 14:48:06', '2012-05-03 18:46:30', NULL, 1, 1, 12, 'Add a clustered architecture for the web server', 1, 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `efficiency`
--

CREATE TABLE `efficiency` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `efficiency`
--

INSERT INTO `efficiency` (`id`, `name`, `color`, `sortOrder`, `idle`) VALUES
(1, 'fully efficient', '#99FF99', 100, 0),
(2, 'partially efficient', '#87ceeb', 200, 0),
(3, 'not efficient', '#FF0000', 300, 0);

-- --------------------------------------------------------

--
-- Structure de la table `event`
--

CREATE TABLE `event` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `sortOrder` int(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `event`
--

INSERT INTO `event` (`id`, `name`, `idle`, `sortOrder`) VALUES
(1, 'responsibleChange', 0, 60),
(2, 'noteAdd', 0, 20),
(3, 'attachmentAdd', 0, 10),
(4, 'noteChange', 0, 30),
(5, 'descriptionChange', 0, 70),
(6, 'resultChange', 0, 80),
(7, 'assignmentAdd', 0, 40),
(8, 'assignmentChange', 0, 50),
(9, 'anyChange', 0, 90);

-- --------------------------------------------------------

--
-- Structure de la table `expense`
--

CREATE TABLE `expense` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idExpenseType` int(12) UNSIGNED DEFAULT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `expensePlannedDate` date DEFAULT NULL,
  `expenseRealDate` date DEFAULT NULL,
  `plannedAmount` decimal(11,2) DEFAULT NULL,
  `realAmount` decimal(11,2) DEFAULT NULL,
  `day` varchar(8) DEFAULT NULL,
  `week` varchar(6) DEFAULT NULL,
  `month` varchar(6) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idDocument` int(12) UNSIGNED DEFAULT NULL,
  `idProvider` int(12) UNSIGNED DEFAULT NULL,
  `sendDate` date DEFAULT NULL,
  `idDeliveryMode` int(12) UNSIGNED DEFAULT NULL,
  `deliveryDelay` varchar(100) DEFAULT NULL,
  `deliveryDate` date DEFAULT NULL,
  `paymentCondition` varchar(100) DEFAULT NULL,
  `receptionDate` date DEFAULT NULL,
  `result` mediumtext,
  `taxPct` decimal(5,2) DEFAULT NULL,
  `plannedFullAmount` decimal(11,2) DEFAULT '0.00',
  `realFullAmount` decimal(11,2) DEFAULT '0.00',
  `idleDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `idResponsible` int(12) UNSIGNED DEFAULT NULL,
  `paymentDone` int(1) UNSIGNED DEFAULT '0',
  `idContact` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `expense`
--

INSERT INTO `expense` (`id`, `idProject`, `idResource`, `idUser`, `idExpenseType`, `scope`, `name`, `idStatus`, `description`, `expensePlannedDate`, `expenseRealDate`, `plannedAmount`, `realAmount`, `day`, `week`, `month`, `year`, `idle`, `reference`, `externalReference`, `cancelled`, `idDocument`, `idProvider`, `sendDate`, `idDeliveryMode`, `deliveryDelay`, `deliveryDate`, `paymentCondition`, `receptionDate`, `result`, `taxPct`, `plannedFullAmount`, `realFullAmount`, `idleDate`, `handled`, `handledDate`, `done`, `doneDate`, `idResponsible`, `paymentDone`, `idContact`) VALUES
(1, 1, 3, 3, 39, 'IndividualExpense', 'Travel to London for Progress Meeting', 1, NULL, '2012-03-05', '2012-03-05', '1500.00', '1063.68', '20120305', '201210', '201203', '2012', 0, '001-001-EXP-1', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', '0.00', NULL, 0, NULL, 0, NULL, NULL, 0, NULL),
(2, 1, NULL, NULL, 40, 'ProjectExpense', 'Dev machines', 1, 'Machines for Dev environment :\n - 1 server Dual Proc, 4GB for Web Server\n - 1 server Quad Proc, 16GB for Database', '2012-03-01', '2012-03-06', '5000.00', '5234.00', '20120306', '201210', '201203', '2012', 0, '001-001-MAC-1', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5000.00', '5234.00', NULL, 0, NULL, 0, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `expensedetail`
--

CREATE TABLE `expensedetail` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idExpense` int(12) UNSIGNED DEFAULT NULL,
  `expenseDate` date DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idExpenseDetailType` int(12) UNSIGNED DEFAULT NULL,
  `value01` decimal(8,2) DEFAULT NULL,
  `value02` decimal(8,2) DEFAULT NULL,
  `value03` decimal(8,2) DEFAULT NULL,
  `unit01` varchar(20) DEFAULT NULL,
  `unit02` varchar(20) DEFAULT NULL,
  `unit03` varchar(20) DEFAULT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `amount` decimal(11,2) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `externalReference` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `expensedetail`
--

INSERT INTO `expensedetail` (`id`, `idProject`, `idExpense`, `expenseDate`, `name`, `idExpenseDetailType`, `value01`, `value02`, `value03`, `unit01`, `unit02`, `unit03`, `description`, `amount`, `idle`, `externalReference`) VALUES
(1, 1, 1, '2012-03-05', 'Travel to London - Plane', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '945.00', 0, NULL),
(2, 1, 1, '2012-03-05', 'Lunch', 3, '3.00', '32.00', NULL, 'guests', 'â‚¬/guest', NULL, NULL, '96.00', 0, NULL),
(3, 1, 1, '2012-03-05', 'Travel to Airport', 1, '42.00', '0.54', NULL, 'km', 'â‚¬/km', NULL, NULL, '22.68', 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `expensedetailtype`
--

CREATE TABLE `expensedetailtype` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `value01` decimal(8,2) DEFAULT NULL,
  `value02` decimal(8,2) DEFAULT NULL,
  `value03` decimal(8,2) DEFAULT NULL,
  `unit01` varchar(20) DEFAULT NULL,
  `unit02` varchar(20) DEFAULT NULL,
  `unit03` varchar(20) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `description` mediumtext,
  `individual` int(1) UNSIGNED DEFAULT '0',
  `project` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `expensedetailtype`
--

INSERT INTO `expensedetailtype` (`id`, `name`, `sortOrder`, `value01`, `value02`, `value03`, `unit01`, `unit02`, `unit03`, `idle`, `description`, `individual`, `project`) VALUES
(1, 'travel by car', 10, NULL, '0.54', NULL, 'km', 'â‚¬/km', NULL, 0, NULL, 1, 0),
(2, 'regular mission car travel', 20, NULL, NULL, '0.54', 'days', 'km/day', 'â‚¬/km', 0, NULL, 1, 0),
(3, 'lunch for guests', 30, NULL, NULL, NULL, 'guests', 'â‚¬/guest', NULL, 0, NULL, 1, 0),
(4, 'justified expense', 40, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `extrahiddenfield`
--

CREATE TABLE `extrahiddenfield` (
  `id` int(12) UNSIGNED NOT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `idType` int(12) UNSIGNED DEFAULT NULL,
  `field` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `favorite`
--

CREATE TABLE `favorite` (
  `id` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `idReport` int(12) UNSIGNED DEFAULT NULL,
  `idMenu` int(12) UNSIGNED DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `favoriteparameter`
--

CREATE TABLE `favoriteparameter` (
  `id` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idReport` int(12) UNSIGNED DEFAULT NULL,
  `idFavorite` int(12) UNSIGNED DEFAULT NULL,
  `parameterName` varchar(100) DEFAULT NULL,
  `parameterValue` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `feasibility`
--

CREATE TABLE `feasibility` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `feasibility`
--

INSERT INTO `feasibility` (`id`, `name`, `color`, `sortOrder`, `idle`) VALUES
(1, 'Yes', '#00FF00', 100, 0),
(2, 'Investigate', '#AAAA00', 200, 0),
(3, 'No', '#FF0000', 300, 0);

-- --------------------------------------------------------

--
-- Structure de la table `filter`
--

CREATE TABLE `filter` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `isShared` int(1) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `filtercriteria`
--

CREATE TABLE `filtercriteria` (
  `id` int(12) UNSIGNED NOT NULL,
  `idFilter` int(12) UNSIGNED NOT NULL,
  `dispAttribute` varchar(100) DEFAULT NULL,
  `dispOperator` varchar(100) DEFAULT NULL,
  `dispValue` varchar(4000) DEFAULT NULL,
  `sqlAttribute` varchar(100) DEFAULT NULL,
  `sqlOperator` varchar(100) DEFAULT NULL,
  `sqlValue` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `habilitation`
--

CREATE TABLE `habilitation` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProfile` int(12) UNSIGNED DEFAULT NULL,
  `idMenu` int(12) UNSIGNED DEFAULT NULL,
  `allowAccess` int(1) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `habilitation`
--

INSERT INTO `habilitation` (`id`, `idProfile`, `idMenu`, `allowAccess`) VALUES
(1, 1, 14, 1),
(2, 1, 13, 1),
(3, 1, 21, 1),
(4, 1, 17, 1),
(5, 2, 20, 1),
(6, 1, 1, 1),
(7, 2, 1, 1),
(8, 3, 1, 1),
(9, 4, 1, 1),
(10, 6, 1, 1),
(11, 7, 1, 1),
(12, 5, 1, 1),
(13, 1, 2, 1),
(14, 2, 2, 1),
(15, 3, 2, 1),
(16, 4, 2, 1),
(17, 6, 2, 1),
(18, 7, 2, 1),
(19, 5, 2, 1),
(20, 1, 3, 1),
(21, 2, 3, 1),
(22, 3, 3, 1),
(23, 4, 3, 0),
(24, 6, 3, 1),
(25, 7, 3, 0),
(26, 5, 3, 0),
(27, 1, 4, 1),
(28, 2, 4, 1),
(29, 3, 4, 1),
(30, 4, 4, 1),
(31, 6, 4, 1),
(32, 7, 4, 1),
(33, 5, 4, 1),
(34, 1, 5, 1),
(35, 2, 5, 1),
(36, 3, 5, 1),
(37, 4, 5, 0),
(38, 6, 5, 0),
(39, 7, 5, 0),
(40, 5, 5, 0),
(41, 1, 6, 1),
(42, 2, 6, 1),
(43, 3, 6, 1),
(44, 4, 6, 1),
(45, 6, 6, 1),
(46, 7, 6, 1),
(47, 5, 6, 1),
(48, 1, 7, 1),
(49, 2, 7, 1),
(50, 3, 7, 1),
(51, 4, 7, 1),
(52, 6, 7, 1),
(53, 7, 7, 1),
(54, 5, 7, 1),
(55, 1, 8, 1),
(56, 2, 8, 1),
(57, 3, 8, 1),
(58, 4, 8, 1),
(59, 6, 8, 1),
(60, 7, 8, 1),
(61, 5, 8, 1),
(62, 1, 9, 1),
(63, 2, 9, 1),
(64, 3, 9, 1),
(65, 4, 9, 1),
(66, 6, 9, 1),
(67, 7, 9, 1),
(68, 5, 9, 1),
(76, 1, 11, 1),
(77, 2, 11, 1),
(78, 3, 11, 1),
(79, 4, 11, 1),
(80, 6, 11, 1),
(81, 7, 11, 1),
(82, 5, 11, 1),
(83, 1, 12, 0),
(84, 2, 12, 0),
(85, 3, 12, 0),
(86, 4, 12, 0),
(87, 6, 12, 0),
(88, 7, 12, 0),
(89, 5, 12, 0),
(90, 2, 13, 1),
(91, 3, 13, 1),
(92, 4, 13, 1),
(93, 6, 13, 1),
(94, 7, 13, 1),
(95, 5, 13, 1),
(96, 2, 14, 1),
(97, 3, 14, 1),
(98, 4, 14, 0),
(99, 6, 14, 0),
(100, 7, 14, 0),
(101, 5, 14, 0),
(102, 1, 15, 1),
(103, 2, 15, 0),
(104, 3, 15, 0),
(105, 4, 15, 0),
(106, 6, 15, 0),
(107, 7, 15, 0),
(108, 5, 15, 0),
(109, 1, 16, 1),
(110, 2, 16, 1),
(111, 3, 16, 1),
(112, 4, 16, 0),
(113, 6, 16, 0),
(114, 7, 16, 0),
(115, 5, 16, 0),
(116, 2, 17, 0),
(117, 3, 17, 0),
(118, 4, 17, 0),
(119, 6, 17, 0),
(120, 7, 17, 0),
(121, 5, 17, 0),
(122, 2, 21, 0),
(123, 3, 21, 0),
(124, 4, 21, 0),
(125, 6, 21, 0),
(126, 7, 21, 0),
(127, 5, 21, 0),
(128, 1, 18, 1),
(129, 2, 18, 0),
(130, 3, 18, 0),
(131, 4, 18, 0),
(132, 6, 18, 0),
(133, 7, 18, 0),
(134, 5, 18, 0),
(135, 1, 19, 0),
(136, 2, 19, 0),
(137, 3, 19, 0),
(138, 4, 19, 0),
(139, 6, 19, 0),
(140, 7, 19, 0),
(141, 5, 19, 0),
(142, 1, 20, 1),
(143, 3, 20, 1),
(144, 4, 20, 1),
(145, 6, 20, 1),
(146, 7, 20, 1),
(147, 5, 20, 1),
(148, 1, 22, 1),
(149, 2, 22, 0),
(150, 3, 22, 1),
(151, 4, 22, 1),
(152, 6, 22, 1),
(153, 7, 22, 1),
(154, 5, 22, 0),
(155, 1, 23, 0),
(156, 2, 23, 0),
(157, 3, 23, 0),
(158, 4, 23, 0),
(159, 6, 23, 0),
(160, 7, 23, 0),
(161, 5, 23, 0),
(162, 1, 24, 0),
(163, 2, 24, 0),
(164, 3, 24, 0),
(165, 4, 24, 0),
(166, 6, 24, 0),
(167, 7, 24, 0),
(168, 5, 24, 0),
(169, 1, 25, 1),
(170, 2, 25, 0),
(171, 3, 25, 1),
(172, 4, 25, 1),
(173, 6, 25, 1),
(174, 7, 25, 1),
(175, 5, 25, 0),
(176, 1, 26, 1),
(177, 2, 26, 0),
(178, 3, 26, 1),
(179, 4, 26, 1),
(180, 6, 26, 1),
(181, 7, 26, 1),
(182, 5, 26, 0),
(183, 1, 32, 0),
(184, 2, 32, 0),
(185, 3, 32, 0),
(186, 4, 32, 0),
(187, 6, 32, 0),
(188, 7, 32, 0),
(189, 5, 32, 0),
(190, 1, 33, 0),
(191, 2, 33, 0),
(192, 3, 33, 0),
(193, 4, 33, 0),
(194, 6, 33, 0),
(195, 7, 33, 0),
(196, 5, 33, 0),
(197, 1, 34, 1),
(198, 2, 34, 0),
(199, 3, 34, 0),
(200, 4, 34, 0),
(201, 6, 34, 0),
(202, 7, 34, 0),
(203, 5, 34, 0),
(204, 1, 36, 1),
(205, 2, 36, 0),
(206, 3, 36, 0),
(207, 4, 36, 0),
(208, 6, 36, 0),
(209, 7, 36, 0),
(210, 5, 36, 0),
(211, 1, 37, 1),
(212, 2, 37, 0),
(213, 3, 37, 0),
(214, 4, 37, 0),
(215, 6, 37, 0),
(216, 7, 37, 0),
(217, 5, 37, 0),
(218, 1, 38, 1),
(219, 2, 38, 0),
(220, 3, 38, 0),
(221, 4, 38, 0),
(222, 6, 38, 0),
(223, 7, 38, 0),
(224, 5, 38, 0),
(225, 1, 39, 1),
(226, 2, 39, 0),
(227, 3, 39, 0),
(228, 4, 39, 0),
(229, 6, 39, 0),
(230, 7, 39, 0),
(231, 5, 39, 0),
(232, 1, 40, 1),
(233, 2, 40, 0),
(234, 3, 40, 0),
(235, 4, 40, 0),
(236, 6, 40, 0),
(237, 7, 40, 0),
(238, 5, 40, 0),
(239, 1, 42, 1),
(240, 2, 42, 0),
(241, 3, 42, 0),
(242, 4, 42, 0),
(243, 6, 42, 0),
(244, 7, 42, 0),
(245, 5, 42, 0),
(246, 1, 41, 1),
(247, 2, 41, 0),
(248, 3, 41, 0),
(249, 4, 41, 0),
(250, 6, 41, 0),
(251, 7, 41, 0),
(252, 5, 41, 0),
(253, 1, 43, 1),
(254, 2, 43, 1),
(255, 3, 43, 1),
(256, 4, 43, 0),
(257, 6, 43, 1),
(258, 7, 43, 0),
(259, 5, 43, 0),
(260, 1, 44, 1),
(261, 2, 44, 0),
(262, 3, 44, 1),
(263, 4, 44, 0),
(264, 6, 44, 0),
(265, 7, 44, 0),
(266, 5, 44, 0),
(267, 1, 45, 1),
(268, 2, 45, 0),
(269, 3, 45, 0),
(270, 4, 45, 0),
(271, 6, 45, 0),
(272, 7, 45, 0),
(273, 5, 45, 0),
(274, 1, 46, 1),
(275, 2, 46, 0),
(276, 3, 46, 0),
(277, 4, 46, 0),
(278, 6, 46, 0),
(279, 7, 46, 0),
(280, 5, 46, 0),
(281, 1, 50, 1),
(282, 2, 50, 0),
(283, 3, 50, 1),
(284, 4, 50, 0),
(285, 6, 50, 0),
(286, 7, 50, 0),
(287, 5, 50, 0),
(288, 1, 49, 1),
(289, 2, 49, 0),
(290, 3, 49, 0),
(291, 4, 49, 0),
(292, 6, 49, 0),
(293, 7, 49, 0),
(294, 5, 49, 0),
(295, 1, 47, 1),
(296, 2, 47, 0),
(297, 3, 47, 0),
(298, 4, 47, 0),
(299, 6, 47, 0),
(300, 7, 47, 0),
(301, 5, 47, 0),
(302, 1, 48, 1),
(303, 2, 48, 0),
(304, 3, 48, 0),
(305, 4, 48, 0),
(306, 6, 48, 0),
(307, 7, 48, 0),
(308, 5, 48, 0),
(309, 1, 51, 1),
(310, 2, 51, 0),
(311, 3, 51, 1),
(312, 4, 51, 0),
(313, 6, 51, 0),
(314, 7, 51, 0),
(315, 5, 51, 0),
(316, 1, 52, 1),
(317, 2, 52, 0),
(318, 3, 52, 0),
(319, 4, 52, 0),
(320, 6, 52, 0),
(321, 7, 52, 0),
(322, 5, 52, 0),
(323, 1, 53, 1),
(324, 2, 53, 0),
(325, 3, 53, 0),
(326, 4, 53, 0),
(327, 6, 53, 0),
(328, 7, 53, 0),
(329, 5, 53, 0),
(330, 1, 55, 1),
(331, 2, 55, 0),
(332, 3, 55, 0),
(333, 4, 55, 0),
(334, 6, 55, 0),
(335, 7, 55, 0),
(336, 5, 55, 0),
(337, 1, 56, 1),
(338, 2, 56, 0),
(339, 3, 56, 0),
(340, 4, 56, 0),
(341, 6, 56, 0),
(342, 7, 56, 0),
(343, 5, 56, 0),
(344, 1, 57, 1),
(345, 2, 57, 1),
(346, 3, 57, 1),
(347, 4, 57, 0),
(348, 6, 57, 0),
(349, 7, 57, 0),
(350, 5, 57, 0),
(351, 1, 58, 1),
(352, 2, 58, 0),
(353, 3, 58, 0),
(354, 4, 58, 0),
(355, 5, 58, 0),
(356, 6, 58, 0),
(357, 7, 58, 0),
(358, 1, 59, 1),
(359, 1, 60, 1),
(360, 1, 61, 1),
(361, 2, 61, 1),
(362, 3, 61, 1),
(363, 1, 62, 1),
(364, 2, 62, 1),
(365, 3, 62, 1),
(366, 4, 62, 1),
(367, 6, 62, 1),
(368, 7, 62, 1),
(369, 5, 62, 1),
(370, 1, 63, 1),
(371, 2, 63, 1),
(372, 3, 63, 1),
(373, 4, 63, 1),
(374, 6, 63, 1),
(375, 7, 63, 1),
(376, 5, 63, 1),
(377, 1, 64, 1),
(378, 2, 64, 1),
(379, 3, 64, 1),
(380, 4, 64, 1),
(381, 6, 64, 1),
(382, 7, 64, 1),
(383, 5, 64, 1),
(384, 1, 65, 1),
(385, 2, 65, 0),
(386, 3, 65, 0),
(387, 4, 65, 0),
(388, 6, 65, 0),
(389, 7, 65, 0),
(390, 5, 65, 0),
(391, 1, 66, 1),
(392, 2, 66, 0),
(393, 3, 66, 0),
(394, 4, 66, 0),
(395, 6, 66, 0),
(396, 7, 66, 0),
(397, 5, 66, 0),
(398, 1, 67, 1),
(399, 2, 67, 0),
(400, 3, 67, 0),
(401, 4, 67, 0),
(402, 6, 67, 0),
(403, 7, 67, 0),
(404, 5, 67, 0),
(405, 1, 68, 1),
(406, 2, 68, 0),
(407, 3, 68, 0),
(408, 4, 68, 0),
(409, 6, 68, 0),
(410, 7, 68, 0),
(411, 5, 68, 0),
(412, 1, 69, 1),
(413, 2, 69, 0),
(414, 3, 69, 1),
(415, 4, 69, 1),
(416, 6, 69, 0),
(417, 7, 69, 0),
(418, 5, 69, 0),
(419, 1, 70, 1),
(420, 2, 70, 0),
(421, 3, 70, 0),
(422, 4, 70, 0),
(423, 6, 70, 0),
(424, 7, 70, 0),
(425, 1, 71, 1),
(426, 2, 71, 0),
(427, 3, 71, 0),
(428, 4, 71, 0),
(429, 6, 71, 0),
(430, 7, 71, 0),
(431, 1, 72, 1),
(432, 1, 73, 1),
(433, 1, 74, 1),
(434, 2, 74, 1),
(435, 3, 74, 1),
(436, 1, 75, 1),
(437, 2, 75, 1),
(438, 3, 75, 1),
(439, 4, 75, 1),
(440, 1, 76, 1),
(441, 2, 76, 1),
(442, 3, 76, 1),
(443, 1, 77, 0),
(444, 2, 77, 0),
(445, 3, 77, 0),
(449, 1, 79, 1),
(450, 2, 79, 1),
(451, 3, 79, 1),
(452, 1, 80, 1),
(453, 2, 80, 1),
(454, 1, 81, 1),
(455, 2, 81, 1),
(456, 1, 82, 0),
(457, 2, 82, 0),
(460, 1, 84, 1),
(461, 2, 84, 1),
(462, 1, 85, 1),
(463, 2, 85, 1),
(464, 3, 85, 1),
(465, 1, 86, 1),
(466, 2, 86, 1),
(467, 3, 86, 1),
(468, 1, 87, 1),
(469, 2, 87, 1),
(470, 3, 87, 1),
(471, 1, 88, 1),
(472, 2, 88, 1),
(473, 3, 88, 1),
(474, 1, 89, 1),
(475, 2, 89, 1),
(476, 3, 89, 1),
(477, 1, 90, 1),
(478, 2, 90, 1),
(479, 3, 90, 1),
(480, 1, 91, 1),
(481, 2, 91, 1),
(482, 3, 91, 1),
(483, 4, 91, 1),
(484, 5, 91, 1),
(485, 6, 91, 1),
(486, 7, 91, 1),
(488, 1, 92, 1),
(489, 1, 93, 1),
(490, 2, 93, 1),
(491, 3, 93, 1),
(492, 1, 94, 1),
(493, 1, 95, 1),
(494, 1, 96, 1),
(495, 1, 97, 1),
(496, 1, 98, 1),
(497, 1, 99, 1),
(498, 1, 100, 1),
(499, 1, 101, 1),
(500, 1, 102, 1),
(501, 2, 102, 1),
(502, 3, 102, 1),
(503, 4, 102, 1),
(504, 6, 102, 1),
(505, 7, 102, 1),
(506, 1, 103, 1),
(507, 3, 103, 1),
(508, 1, 104, 1),
(509, 2, 59, 0),
(510, 3, 59, 0),
(511, 4, 59, 0),
(512, 5, 59, 0),
(513, 6, 59, 0),
(514, 7, 59, 0),
(515, 2, 60, 0),
(516, 3, 60, 0),
(517, 4, 60, 0),
(518, 5, 60, 0),
(519, 6, 60, 0),
(520, 7, 60, 0),
(521, 4, 61, 0),
(522, 5, 61, 0),
(523, 6, 61, 0),
(524, 7, 61, 0),
(525, 5, 70, 0),
(526, 5, 71, 0),
(527, 2, 72, 0),
(528, 3, 72, 0),
(529, 4, 72, 0),
(530, 5, 72, 0),
(531, 6, 72, 0),
(532, 7, 72, 0),
(533, 2, 73, 0),
(534, 3, 73, 0),
(535, 4, 73, 0),
(536, 5, 73, 0),
(537, 6, 73, 0),
(538, 7, 73, 0),
(539, 4, 74, 1),
(540, 5, 74, 0),
(541, 6, 74, 0),
(542, 7, 74, 0),
(543, 5, 75, 0),
(544, 6, 75, 0),
(545, 7, 75, 0),
(546, 4, 76, 0),
(547, 5, 76, 0),
(548, 6, 76, 0),
(549, 7, 76, 0),
(550, 4, 77, 0),
(551, 5, 77, 0),
(552, 6, 77, 0),
(553, 7, 77, 0),
(558, 4, 79, 0),
(559, 5, 79, 0),
(560, 6, 79, 0),
(561, 7, 79, 0),
(562, 3, 80, 0),
(563, 4, 80, 0),
(564, 5, 80, 0),
(565, 6, 80, 0),
(566, 7, 80, 0),
(567, 3, 81, 0),
(568, 4, 81, 0),
(569, 5, 81, 0),
(570, 6, 81, 0),
(571, 7, 81, 0),
(572, 3, 82, 0),
(573, 4, 82, 0),
(574, 5, 82, 0),
(575, 6, 82, 0),
(576, 7, 82, 0),
(582, 3, 84, 0),
(583, 4, 84, 0),
(584, 5, 84, 0),
(585, 6, 84, 0),
(586, 7, 84, 0),
(587, 4, 85, 0),
(588, 5, 85, 0),
(589, 6, 85, 0),
(590, 7, 85, 0),
(591, 4, 86, 0),
(592, 5, 86, 0),
(593, 6, 86, 0),
(594, 7, 86, 0),
(595, 4, 87, 0),
(596, 5, 87, 0),
(597, 6, 87, 0),
(598, 7, 87, 0),
(599, 4, 88, 0),
(600, 5, 88, 0),
(601, 6, 88, 0),
(602, 7, 88, 0),
(603, 4, 89, 0),
(604, 5, 89, 0),
(605, 6, 89, 0),
(606, 7, 89, 0),
(607, 4, 90, 0),
(608, 5, 90, 0),
(609, 6, 90, 0),
(610, 7, 90, 0),
(611, 2, 92, 0),
(612, 3, 92, 0),
(613, 4, 92, 0),
(614, 5, 92, 0),
(615, 6, 92, 0),
(616, 7, 92, 0),
(617, 4, 93, 0),
(618, 5, 93, 0),
(619, 6, 93, 0),
(620, 7, 93, 0),
(621, 2, 94, 0),
(622, 3, 94, 0),
(623, 4, 94, 0),
(624, 5, 94, 0),
(625, 6, 94, 0),
(626, 7, 94, 0),
(627, 2, 95, 0),
(628, 3, 95, 0),
(629, 4, 95, 0),
(630, 5, 95, 0),
(631, 6, 95, 0),
(632, 7, 95, 0),
(633, 2, 96, 0),
(634, 3, 96, 0),
(635, 4, 96, 0),
(636, 5, 96, 0),
(637, 6, 96, 0),
(638, 7, 96, 0),
(639, 2, 97, 0),
(640, 3, 97, 0),
(641, 4, 97, 0),
(642, 5, 97, 0),
(643, 6, 97, 0),
(644, 7, 97, 0),
(645, 2, 100, 0),
(646, 3, 100, 0),
(647, 4, 100, 0),
(648, 5, 100, 0),
(649, 6, 100, 0),
(650, 7, 100, 0),
(651, 2, 101, 0),
(652, 3, 101, 0),
(653, 4, 101, 0),
(654, 5, 101, 0),
(655, 6, 101, 0),
(656, 7, 101, 0),
(657, 5, 102, 0),
(658, 2, 103, 0),
(659, 4, 103, 0),
(660, 5, 103, 0),
(661, 6, 103, 0),
(662, 7, 103, 0),
(663, 2, 104, 0),
(664, 3, 104, 0),
(665, 4, 104, 0),
(666, 5, 104, 0),
(667, 6, 104, 0),
(668, 7, 104, 0),
(670, 1, 105, 1),
(671, 2, 105, 0),
(672, 3, 105, 0),
(673, 4, 105, 0),
(674, 5, 105, 0),
(675, 6, 105, 0),
(676, 7, 105, 0),
(677, 1, 106, 1),
(678, 2, 106, 1),
(679, 3, 106, 1),
(680, 4, 106, 1),
(681, 5, 106, 1),
(682, 6, 106, 1),
(683, 7, 106, 1),
(684, 1, 107, 1),
(685, 2, 107, 0),
(686, 3, 107, 0),
(687, 4, 107, 0),
(688, 5, 107, 0),
(689, 6, 107, 0),
(690, 7, 107, 0),
(691, 1, 108, 1),
(692, 2, 108, 0),
(693, 3, 108, 0),
(694, 4, 108, 0),
(695, 5, 108, 0),
(696, 6, 108, 0),
(697, 7, 108, 0),
(698, 1, 109, 1),
(699, 2, 109, 0),
(700, 3, 109, 0),
(701, 4, 109, 0),
(702, 5, 109, 0),
(703, 6, 109, 0),
(704, 7, 109, 0),
(705, 1, 111, 1),
(706, 2, 111, 1),
(707, 3, 111, 1),
(708, 4, 111, 1),
(709, 5, 111, 1),
(710, 6, 111, 1),
(711, 7, 111, 1),
(712, 1, 112, 1),
(713, 2, 112, 1),
(714, 3, 112, 1),
(715, 4, 112, 1),
(716, 5, 112, 1),
(717, 6, 112, 1),
(718, 7, 112, 1),
(719, 1, 113, 1),
(720, 2, 113, 1),
(721, 3, 113, 1),
(722, 4, 113, 1),
(723, 5, 113, 1),
(724, 6, 113, 1),
(725, 7, 113, 1),
(726, 1, 114, 1),
(727, 2, 114, 0),
(728, 3, 114, 0),
(729, 4, 114, 0),
(730, 5, 114, 0),
(731, 6, 114, 0),
(732, 7, 114, 0),
(733, 1, 115, 1),
(734, 2, 115, 0),
(735, 3, 115, 0),
(736, 4, 115, 0),
(737, 5, 115, 0),
(738, 6, 115, 0),
(739, 7, 115, 0),
(740, 1, 110, 1),
(741, 2, 110, 1),
(742, 3, 110, 1),
(743, 4, 110, 1),
(744, 5, 110, 1),
(745, 6, 110, 1),
(746, 7, 110, 1),
(747, 1, 116, 1),
(748, 2, 116, 0),
(749, 3, 116, 0),
(750, 4, 116, 0),
(751, 5, 116, 0),
(752, 6, 116, 0),
(753, 7, 116, 0),
(754, 1, 117, 1),
(755, 2, 117, 0),
(756, 3, 117, 0),
(757, 4, 117, 0),
(758, 5, 117, 0),
(759, 6, 117, 0),
(760, 7, 117, 0),
(761, 1, 118, 1),
(762, 2, 118, 0),
(763, 3, 118, 0),
(764, 4, 118, 0),
(765, 5, 118, 1),
(766, 6, 118, 0),
(767, 7, 118, 0),
(768, 1, 119, 1),
(769, 2, 119, 1),
(770, 3, 119, 1),
(771, 4, 119, 0),
(772, 6, 119, 1),
(773, 7, 119, 0),
(774, 5, 119, 0),
(775, 1, 120, 1),
(776, 2, 120, 0),
(777, 3, 120, 0),
(778, 4, 120, 0),
(779, 6, 120, 0),
(780, 7, 120, 0),
(781, 5, 120, 0),
(782, 1, 121, 1),
(783, 2, 121, 0),
(784, 3, 121, 0),
(785, 4, 121, 0),
(786, 5, 121, 0),
(787, 6, 121, 0),
(788, 7, 121, 0),
(789, 1, 122, 1),
(790, 2, 122, 0),
(791, 3, 122, 0),
(792, 4, 122, 0),
(793, 5, 122, 0),
(794, 6, 122, 0),
(795, 7, 122, 0),
(796, 1, 123, 1),
(797, 2, 123, 1),
(798, 3, 123, 1),
(799, 4, 123, 0),
(800, 5, 123, 0),
(801, 6, 123, 0),
(802, 7, 123, 0),
(803, 1, 124, 1),
(804, 2, 124, 1),
(805, 3, 124, 1),
(806, 4, 124, 1),
(807, 6, 124, 1),
(808, 7, 124, 1),
(809, 5, 124, 1),
(810, 1, 125, 1),
(811, 2, 125, 1),
(812, 3, 125, 1),
(813, 4, 125, 0),
(814, 5, 125, 0),
(815, 6, 125, 0),
(816, 7, 125, 0),
(817, 1, 126, 1),
(818, 2, 126, 0),
(819, 3, 126, 0),
(820, 4, 126, 0),
(821, 5, 126, 0),
(822, 6, 126, 0),
(823, 7, 126, 0),
(824, 1, 127, 1),
(825, 2, 127, 0),
(826, 3, 127, 0),
(827, 4, 127, 0),
(828, 5, 127, 0),
(829, 6, 127, 0),
(830, 7, 127, 0),
(831, 1, 128, 1),
(832, 2, 128, 0),
(833, 3, 128, 0),
(834, 4, 128, 0),
(835, 5, 128, 0),
(836, 6, 128, 0),
(837, 7, 128, 0),
(838, 1, 129, 1),
(839, 2, 129, 0),
(840, 3, 129, 0),
(841, 4, 129, 0),
(842, 5, 129, 0),
(843, 6, 129, 0),
(844, 7, 129, 0),
(845, 1, 130, 1),
(846, 2, 130, 0),
(847, 3, 130, 0),
(848, 4, 130, 0),
(849, 5, 130, 0),
(850, 6, 130, 0),
(851, 7, 130, 0),
(852, 1, 131, 1),
(853, 2, 131, 1),
(854, 3, 131, 1),
(855, 4, 131, 0),
(856, 5, 131, 0),
(857, 6, 131, 0),
(858, 7, 131, 0),
(859, 1, 132, 1),
(860, 2, 132, 0),
(861, 3, 132, 0),
(862, 4, 132, 0),
(863, 5, 132, 0),
(864, 6, 132, 0),
(865, 7, 132, 0),
(866, 1, 133, 1),
(867, 2, 133, 1),
(868, 3, 133, 1),
(869, 4, 133, 1),
(870, 5, 133, 0),
(871, 6, 133, 0),
(872, 7, 133, 0),
(873, 1, 134, 1),
(874, 2, 134, 0),
(875, 3, 134, 0),
(876, 4, 134, 0),
(877, 5, 134, 0),
(878, 6, 134, 0),
(879, 7, 134, 0),
(880, 1, 135, 1),
(881, 2, 135, 0),
(882, 3, 135, 0),
(883, 4, 135, 0),
(884, 5, 135, 0),
(885, 6, 135, 0),
(886, 7, 135, 0),
(887, 1, 136, 1),
(888, 2, 136, 0),
(889, 3, 136, 0),
(890, 4, 136, 0),
(891, 5, 136, 0),
(892, 6, 136, 0),
(893, 7, 136, 0),
(894, 1, 137, 1),
(895, 2, 137, 0),
(896, 3, 137, 0),
(897, 4, 137, 0),
(898, 5, 137, 0),
(899, 6, 137, 0),
(900, 7, 137, 0),
(901, 1, 138, 1),
(902, 2, 138, 0),
(903, 3, 138, 0),
(904, 4, 138, 0),
(905, 5, 138, 0),
(906, 6, 138, 0),
(907, 7, 138, 0),
(908, 1, 139, 1),
(909, 2, 139, 0),
(910, 3, 139, 0),
(911, 4, 139, 0),
(912, 5, 139, 0),
(913, 6, 139, 0),
(914, 7, 139, 0),
(915, 1, 140, 1),
(916, 2, 140, 0),
(917, 3, 140, 0),
(918, 4, 140, 0),
(919, 5, 140, 0),
(920, 6, 140, 0),
(921, 7, 140, 0),
(922, 1, 78, 1),
(923, 2, 78, 0),
(924, 3, 78, 0),
(925, 4, 78, 0),
(926, 5, 78, 0),
(927, 6, 78, 0),
(928, 7, 78, 0),
(929, 1, 83, 1),
(930, 2, 83, 0),
(931, 3, 83, 0),
(932, 4, 83, 0),
(933, 5, 83, 0),
(934, 6, 83, 0),
(935, 7, 83, 0),
(936, 1, 141, 1),
(937, 2, 141, 0),
(938, 3, 141, 0),
(939, 4, 141, 0),
(940, 5, 141, 0),
(941, 6, 141, 0),
(942, 7, 141, 0),
(943, 1, 142, 1),
(944, 2, 142, 0),
(945, 3, 142, 0),
(946, 4, 142, 0),
(947, 5, 142, 0),
(948, 6, 142, 0),
(949, 7, 142, 0),
(950, 1, 143, 1),
(951, 2, 143, 0),
(952, 3, 143, 0),
(953, 4, 143, 0),
(954, 5, 143, 0),
(955, 6, 143, 0),
(956, 7, 143, 0),
(957, 1, 144, 1),
(958, 2, 144, 0),
(959, 3, 144, 0),
(960, 4, 144, 0),
(961, 5, 144, 0),
(962, 6, 144, 0),
(963, 7, 144, 0),
(964, 1, 145, 1),
(965, 2, 145, 0),
(966, 3, 145, 0),
(967, 4, 145, 0),
(968, 5, 145, 0),
(969, 6, 145, 0),
(970, 7, 145, 0),
(971, 1, 146, 1),
(972, 2, 146, 1),
(973, 3, 146, 1),
(974, 4, 146, 0),
(975, 5, 146, 0),
(976, 6, 146, 0),
(977, 7, 146, 0),
(978, 1, 150, 1),
(979, 2, 150, 1),
(980, 3, 150, 1),
(981, 4, 150, 1),
(982, 5, 150, 0),
(983, 6, 150, 0),
(984, 7, 150, 0),
(985, 1, 147, 1),
(986, 2, 147, 0),
(987, 3, 147, 0),
(988, 4, 147, 0),
(989, 5, 147, 0),
(990, 6, 147, 0),
(991, 7, 147, 0),
(992, 1, 148, 1),
(993, 2, 148, 0),
(994, 3, 148, 0),
(995, 4, 148, 0),
(996, 5, 148, 0),
(997, 6, 148, 0),
(998, 7, 148, 0),
(999, 1, 149, 1),
(1000, 2, 149, 0),
(1001, 3, 149, 0),
(1002, 4, 149, 0),
(1003, 5, 149, 0),
(1004, 6, 149, 0),
(1005, 7, 149, 0),
(1006, 1, 153, 1),
(1007, 2, 153, 1),
(1008, 3, 153, 1),
(1009, 4, 153, 0),
(1010, 5, 153, 0),
(1011, 6, 153, 0),
(1012, 7, 153, 0),
(1013, 1, 154, 1),
(1014, 2, 154, 1),
(1015, 3, 154, 1),
(1016, 4, 154, 0),
(1017, 5, 154, 0),
(1018, 6, 154, 0),
(1019, 7, 154, 0),
(1020, 1, 155, 1),
(1021, 2, 155, 0),
(1022, 3, 155, 0),
(1023, 4, 155, 0),
(1024, 5, 155, 0),
(1025, 6, 155, 0),
(1026, 7, 155, 0),
(1027, 1, 156, 1),
(1028, 2, 156, 0),
(1029, 3, 156, 0),
(1030, 4, 156, 0),
(1031, 5, 156, 0),
(1032, 6, 156, 0),
(1033, 7, 156, 0),
(1034, 1, 157, 1),
(1035, 2, 157, 0),
(1036, 3, 157, 0),
(1037, 4, 157, 0),
(1038, 6, 157, 0),
(1039, 7, 157, 0),
(1040, 5, 157, 0),
(1041, 1, 151, 1),
(1042, 2, 151, 1),
(1043, 3, 151, 1),
(1044, 4, 151, 1),
(1045, 5, 151, 0),
(1046, 6, 151, 0),
(1047, 7, 151, 0),
(1048, 1, 152, 1),
(1049, 2, 152, 1),
(1050, 3, 152, 1),
(1051, 4, 152, 0),
(1052, 5, 152, 0),
(1053, 6, 152, 0),
(1054, 7, 152, 0);

-- --------------------------------------------------------

--
-- Structure de la table `habilitationother`
--

CREATE TABLE `habilitationother` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProfile` int(12) UNSIGNED DEFAULT NULL,
  `scope` varchar(20) DEFAULT NULL,
  `rightAccess` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `habilitationother`
--

INSERT INTO `habilitationother` (`id`, `idProfile`, `scope`, `rightAccess`) VALUES
(1, 1, 'imputation', '4'),
(2, 2, 'imputation', '2'),
(3, 3, 'imputation', '3'),
(4, 4, 'imputation', '2'),
(5, 6, 'imputation', '1'),
(6, 7, 'imputation', '1'),
(7, 5, 'imputation', '1'),
(8, 1, 'work', '4'),
(9, 2, 'work', '4'),
(10, 3, 'work', '4'),
(11, 4, 'work', '4'),
(12, 6, 'work', '2'),
(13, 7, 'work', '1'),
(14, 5, 'work', '1'),
(15, 1, 'cost', '4'),
(16, 2, 'cost', '4'),
(17, 3, 'cost', '4'),
(18, 4, 'cost', '1'),
(19, 6, 'cost', '2'),
(20, 7, 'cost', '1'),
(21, 5, 'cost', '1'),
(22, 1, 'combo', '1'),
(23, 2, 'combo', '2'),
(24, 3, 'combo', '1'),
(25, 4, 'combo', '2'),
(26, 6, 'combo', '2'),
(27, 7, 'combo', '2'),
(28, 5, 'combo', '2'),
(29, 1, 'planning', '1'),
(30, 2, 'planning', '2'),
(31, 3, 'planning', '1'),
(32, 4, 'planning', '2'),
(33, 6, 'planning', '2'),
(34, 7, 'planning', '2'),
(35, 5, 'planning', '2'),
(36, 1, 'document', '1'),
(37, 2, 'document', '2'),
(38, 3, 'document', '1'),
(39, 4, 'document', '2'),
(40, 6, 'document', '2'),
(41, 7, 'document', '2'),
(42, 5, 'document', '2'),
(43, 1, 'requirement', '1'),
(44, 2, 'requirement', '2'),
(45, 3, 'requirement', '1'),
(46, 4, 'requirement', '2'),
(47, 6, 'requirement', '2'),
(48, 7, 'requirement', '2'),
(49, 5, 'requirement', '2'),
(50, 1, 'workValid', '4'),
(51, 2, 'workValid', '2'),
(52, 3, 'workValid', '3'),
(53, 4, 'workValid', '2'),
(54, 6, 'workValid', '1'),
(55, 7, 'workValid', '1'),
(56, 5, 'workValid', '1'),
(57, 1, 'checklist', '1'),
(58, 2, 'checklist', '1'),
(59, 3, 'checklist', '1'),
(60, 4, 'checklist', '1'),
(61, 6, 'checklist', '2'),
(62, 7, 'checklist', '2'),
(63, 5, 'checklist', '2'),
(64, 1, 'assignmentView', '1'),
(65, 2, 'assignmentView', '1'),
(66, 3, 'assignmentView', '1'),
(67, 4, 'assignmentView', '1'),
(68, 6, 'assignmentView', '2'),
(69, 7, 'assignmentView', '2'),
(70, 5, 'assignmentView', '2'),
(71, 1, 'assignmentEdit', '1'),
(72, 2, 'assignmentEdit', '2'),
(73, 3, 'assignmentEdit', '1'),
(74, 4, 'assignmentEdit', '2'),
(75, 6, 'assignmentEdit', '2'),
(76, 7, 'assignmentEdit', '2'),
(77, 5, 'assignmentEdit', '2'),
(78, 1, 'diary', '4'),
(79, 2, 'diary', '2'),
(80, 3, 'diary', '3'),
(81, 4, 'diary', '2'),
(82, 6, 'diary', '1'),
(83, 7, 'diary', '1'),
(84, 5, 'diary', '1'),
(85, 1, 'resourcePlanning', '1'),
(86, 2, 'resourcePlanning', '1'),
(87, 3, 'resourcePlanning', '1'),
(88, 4, 'resourcePlanning', '2'),
(89, 6, 'resourcePlanning', '2'),
(90, 7, 'resourcePlanning', '2'),
(91, 5, 'resourcePlanning', '2'),
(92, 1, 'reportResourceAll', '1'),
(93, 2, 'reportResourceAll', '1'),
(94, 3, 'reportResourceAll', '1'),
(95, 4, 'reportResourceAll', '2'),
(96, 6, 'reportResourceAll', '2'),
(97, 7, 'reportResourceAll', '2'),
(98, 5, 'reportResourceAll', '2'),
(99, 1, 'canUpdateCreation', '1'),
(100, 2, 'canUpdateCreation', '2'),
(101, 3, 'canUpdateCreation', '2'),
(102, 4, 'canUpdateCreation', '2'),
(103, 6, 'canUpdateCreation', '2'),
(104, 7, 'canUpdateCreation', '2'),
(105, 5, 'canUpdateCreation', '2'),
(106, 1, 'viewComponents', '1'),
(107, 2, 'viewComponents', '1'),
(108, 3, 'viewComponents', '1'),
(109, 4, 'viewComponents', '1'),
(110, 6, 'viewComponents', '2'),
(111, 7, 'viewComponents', '2'),
(112, 5, 'viewComponents', '2');

-- --------------------------------------------------------

--
-- Structure de la table `habilitationreport`
--

CREATE TABLE `habilitationreport` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProfile` int(12) UNSIGNED DEFAULT NULL,
  `idReport` int(12) UNSIGNED DEFAULT NULL,
  `allowAccess` int(1) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `habilitationreport`
--

INSERT INTO `habilitationreport` (`id`, `idProfile`, `idReport`, `allowAccess`) VALUES
(1, 1, 1, 1),
(2, 1, 2, 1),
(3, 1, 3, 1),
(4, 1, 4, 1),
(5, 1, 5, 1),
(6, 1, 6, 1),
(7, 1, 7, 1),
(8, 1, 8, 1),
(9, 1, 9, 1),
(10, 1, 10, 1),
(11, 1, 11, 1),
(12, 1, 12, 1),
(13, 1, 13, 1),
(14, 1, 14, 1),
(15, 1, 15, 1),
(16, 1, 16, 1),
(17, 1, 17, 1),
(18, 1, 18, 1),
(19, 1, 19, 1),
(20, 1, 20, 1),
(21, 1, 21, 1),
(22, 1, 22, 1),
(23, 1, 23, 1),
(24, 1, 24, 1),
(25, 1, 25, 1),
(26, 2, 1, 1),
(27, 2, 2, 1),
(28, 2, 3, 1),
(29, 2, 4, 1),
(30, 2, 5, 1),
(31, 2, 6, 1),
(32, 2, 7, 1),
(33, 2, 8, 1),
(34, 2, 9, 1),
(35, 2, 10, 1),
(36, 2, 11, 1),
(37, 2, 12, 1),
(38, 2, 13, 1),
(39, 2, 14, 1),
(40, 2, 15, 1),
(41, 2, 16, 1),
(42, 2, 17, 1),
(43, 2, 18, 1),
(44, 2, 19, 1),
(45, 2, 20, 1),
(46, 2, 21, 1),
(47, 2, 22, 1),
(48, 2, 23, 1),
(49, 3, 1, 1),
(50, 3, 2, 1),
(51, 3, 3, 1),
(52, 3, 4, 1),
(53, 3, 5, 1),
(54, 3, 6, 1),
(55, 3, 7, 1),
(56, 3, 8, 1),
(57, 3, 9, 1),
(58, 3, 10, 1),
(59, 3, 11, 1),
(60, 3, 12, 1),
(61, 3, 13, 1),
(62, 3, 14, 1),
(63, 3, 15, 1),
(64, 3, 16, 1),
(65, 3, 17, 1),
(66, 3, 18, 1),
(67, 3, 19, 1),
(68, 3, 20, 1),
(69, 3, 21, 1),
(70, 3, 22, 1),
(71, 3, 23, 1),
(72, 1, 26, 1),
(73, 1, 27, 1),
(74, 2, 26, 1),
(75, 2, 27, 1),
(76, 3, 26, 1),
(77, 3, 27, 1),
(78, 1, 28, 1),
(79, 1, 29, 1),
(80, 1, 30, 1),
(81, 2, 28, 1),
(82, 2, 29, 1),
(83, 2, 30, 1),
(84, 3, 28, 1),
(85, 3, 29, 1),
(86, 3, 30, 1),
(87, 1, 31, 1),
(88, 2, 31, 1),
(89, 3, 31, 1),
(90, 1, 32, 1),
(91, 2, 32, 1),
(92, 3, 32, 1),
(93, 1, 33, 1),
(94, 2, 33, 1),
(95, 3, 33, 1),
(96, 1, 34, 1),
(97, 2, 34, 1),
(98, 3, 34, 1),
(99, 1, 35, 1),
(100, 2, 35, 1),
(101, 3, 35, 1),
(102, 1, 36, 1),
(103, 2, 36, 1),
(104, 3, 36, 1),
(105, 1, 37, 1),
(106, 2, 37, 0),
(107, 3, 37, 0),
(108, 4, 37, 0),
(109, 5, 37, 0),
(110, 6, 37, 0),
(111, 7, 37, 0),
(112, 1, 39, 1),
(113, 2, 39, 1),
(114, 3, 39, 1),
(115, 4, 39, 0),
(116, 5, 39, 0),
(117, 6, 39, 0),
(118, 7, 39, 0),
(119, 1, 44, 1),
(120, 2, 44, 1),
(121, 3, 44, 1),
(122, 4, 44, 0),
(123, 5, 44, 0),
(124, 6, 44, 0),
(125, 7, 44, 0),
(126, 1, 41, 1),
(127, 2, 41, 1),
(128, 3, 41, 1),
(129, 4, 41, 0),
(130, 5, 41, 0),
(131, 6, 41, 0),
(132, 7, 41, 0),
(133, 1, 42, 1),
(134, 2, 42, 1),
(135, 3, 42, 1),
(136, 4, 42, 0),
(137, 5, 42, 0),
(138, 6, 42, 0),
(139, 7, 42, 0),
(140, 1, 43, 1),
(141, 2, 43, 1),
(142, 3, 43, 1),
(143, 4, 43, 0),
(144, 5, 43, 0),
(145, 6, 43, 0),
(146, 7, 43, 0),
(147, 1, 45, 1),
(148, 2, 45, 1),
(149, 3, 45, 0),
(150, 4, 45, 0),
(151, 1, 46, 1),
(152, 2, 46, 1),
(153, 3, 46, 0),
(154, 4, 46, 0),
(155, 1, 48, 1),
(156, 2, 48, 0),
(157, 3, 48, 0),
(158, 4, 48, 0),
(163, 1, 49, 1),
(164, 2, 49, 1),
(165, 3, 49, 1),
(166, 1, 50, 1),
(167, 2, 50, 1),
(168, 3, 50, 1),
(169, 1, 51, 1),
(170, 2, 51, 1),
(171, 3, 51, 1),
(172, 1, 52, 1),
(173, 2, 52, 1),
(174, 3, 52, 1),
(175, 1, 53, 1),
(176, 2, 53, 1),
(177, 3, 53, 1),
(178, 4, 53, 0),
(179, 5, 53, 0),
(180, 6, 53, 0),
(181, 7, 53, 0),
(182, 1, 54, 1),
(183, 2, 54, 1),
(184, 3, 54, 1),
(185, 4, 54, 1),
(186, 5, 54, 0),
(187, 6, 54, 0),
(188, 7, 54, 0),
(189, 1, 55, 1),
(190, 2, 55, 1),
(191, 3, 55, 1),
(192, 4, 55, 1),
(193, 5, 55, 0),
(194, 6, 55, 0),
(195, 7, 55, 0),
(196, 1, 56, 1),
(197, 2, 56, 1),
(198, 3, 56, 1),
(199, 4, 56, 1),
(200, 5, 56, 0),
(201, 6, 56, 0),
(202, 7, 56, 0),
(203, 1, 57, 1),
(204, 2, 57, 1),
(205, 3, 57, 1),
(206, 4, 57, 1),
(207, 1, 58, 1),
(208, 2, 58, 1),
(209, 3, 58, 1),
(210, 4, 58, 1);

-- --------------------------------------------------------

--
-- Structure de la table `health`
--

CREATE TABLE `health` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `icon` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `health`
--

INSERT INTO `health` (`id`, `name`, `color`, `sortOrder`, `idle`, `icon`) VALUES
(1, 'secured', '#32CD32', 100, 0, NULL),
(2, 'surveyed', '#ffd700', 200, 0, NULL),
(3, 'in danger', '#FF0000', 300, 0, NULL),
(4, 'crashed', '#000000', 400, 0, NULL),
(5, 'paused', '#E0E0E0', 500, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `history`
--

CREATE TABLE `history` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) NOT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `operation` varchar(10) DEFAULT NULL,
  `colName` varchar(100) DEFAULT NULL,
  `oldValue` mediumtext,
  `newValue` mediumtext,
  `operationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `isWorkHistory` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `history`
--

INSERT INTO `history` (`id`, `refType`, `refId`, `operation`, `colName`, `oldValue`, `newValue`, `operationDate`, `idUser`, `isWorkHistory`) VALUES
(1, 'Project', 1, 'insert', NULL, NULL, NULL, '2011-09-01 16:48:44', NULL, 0),
(2, 'ProjectPlanningElement', 1, 'insert', NULL, NULL, NULL, '2011-09-01 16:48:44', NULL, 0),
(3, 'Client', 1, 'insert', NULL, NULL, NULL, '2011-09-01 16:50:04', 1, 0),
(4, 'Client', 2, 'insert', NULL, NULL, NULL, '2011-09-01 16:50:14', 1, 0),
(5, 'Client', 2, 'update', 'clientCode', NULL, '002', '2011-09-01 16:50:18', 1, 0),
(6, 'Client', 3, 'insert', NULL, NULL, NULL, '2011-09-01 16:50:25', 1, 0),
(7, 'Project', 1, 'update', 'name', 'Default project', 'project one', '2011-09-01 16:51:13', 1, 0),
(8, 'Project', 1, 'update', 'idClient', NULL, '1', '2011-09-01 16:51:13', 1, 0),
(9, 'Project', 1, 'update', 'projectCode', NULL, '001-001', '2011-09-01 16:51:13', 1, 0),
(10, 'Project', 1, 'update', 'contractCode', NULL, 'X23-472-722', '2011-09-01 16:51:13', 1, 0),
(11, 'ProjectPlanningElement', 1, 'update', 'idProject', NULL, '1', '2011-09-01 16:51:13', 1, 0),
(12, 'ProjectPlanningElement', 1, 'update', 'refName', 'Default project', 'project one', '2011-09-01 16:51:13', 1, 0),
(13, 'Project', 1, 'update', 'color', '#0000FF', '#4169e1', '2011-09-01 16:51:20', 1, 0),
(14, 'Project', 1, 'update', 'description', 'Default project\nFor example use only.\nRemove or rename this project when initializing your own data.', '1st project\nFor example use only.\nRemove or rename this project when initializing your own data.', '2011-09-01 16:51:34', 1, 0),
(15, 'Project', 1, 'update', 'description', '1st project\nFor example use only.\nRemove or rename this project when initializing your own data.', '1st project\nThis project has 2 sub-projects', '2011-09-01 16:51:49', 1, 0),
(16, 'Project', 2, 'insert', NULL, NULL, NULL, '2011-09-01 16:51:56', 1, 0),
(17, 'ProjectPlanningElement', 2, 'insert', NULL, NULL, NULL, '2011-09-01 16:51:56', 1, 0),
(18, 'Project', 2, 'update', 'name', 'project one', 'project one - subproject 1', '2011-09-01 16:52:14', 1, 0),
(19, 'Project', 2, 'update', 'projectCode', '001-001', '001-001-1', '2011-09-01 16:52:14', 1, 0),
(20, 'ProjectPlanningElement', 2, 'update', 'idProject', '1', '2', '2011-09-01 16:52:14', 1, 0),
(21, 'ProjectPlanningElement', 2, 'update', 'refName', 'project one', 'project one - subproject 1', '2011-09-01 16:52:14', 1, 0),
(22, 'Project', 2, 'update', 'idProject', NULL, '1', '2011-09-01 16:52:20', 1, 0),
(23, 'ProjectPlanningElement', 2, 'update', 'wbs', '2', '1.1', '2011-09-01 16:52:20', 1, 0),
(24, 'ProjectPlanningElement', 2, 'update', 'wbsSortable', '002', '001.001', '2011-09-01 16:52:20', 1, 0),
(25, 'ProjectPlanningElement', 2, 'update', 'topId', NULL, '1', '2011-09-01 16:52:20', 1, 0),
(26, 'ProjectPlanningElement', 2, 'update', 'topRefType', NULL, 'Project', '2011-09-01 16:52:20', 1, 0),
(27, 'ProjectPlanningElement', 2, 'update', 'topRefId', NULL, '1', '2011-09-01 16:52:20', 1, 0),
(28, 'PlanningElement', 1, 'update', 'elementary', '1', '0', '2011-09-01 16:52:20', 1, 0),
(29, 'Resource', 3, 'insert', NULL, NULL, NULL, '2011-09-01 16:52:58', 1, 0),
(30, 'Resource', 3, 'update', 'idRole', NULL, '1', '2011-09-01 16:53:01', 1, 0),
(31, 'ResourceCost', 1, 'insert', NULL, NULL, NULL, '2011-09-01 16:53:07', 1, 0),
(32, 'Resource', 4, 'insert', NULL, NULL, NULL, '2011-09-01 16:54:02', 1, 0),
(33, 'Resource', 4, 'update', 'idRole', NULL, '2', '2011-09-01 16:54:06', 1, 0),
(34, 'Resource', 3, 'update', 'isUser', '0', '1', '2011-09-01 16:54:34', 1, 0),
(35, 'Resource', 3, 'update', 'userName', NULL, 'pl', '2011-09-01 16:54:34', 1, 0),
(36, 'Team', 1, 'insert', NULL, NULL, NULL, '2011-09-01 16:55:03', 1, 0),
(37, 'Team', 2, 'insert', NULL, NULL, NULL, '2011-09-01 16:55:14', 1, 0),
(38, 'Product', 1, 'insert', NULL, NULL, NULL, '2011-09-01 16:55:51', 1, 0),
(39, 'Contact', 5, 'insert', NULL, NULL, NULL, '2011-09-01 16:56:39', 1, 0),
(40, 'Contact', 5, 'update', 'userName', NULL, 'extprolea', '2011-09-01 16:57:10', 1, 0),
(41, 'Contact', 6, 'insert', NULL, NULL, NULL, '2011-09-01 16:57:18', 1, 0),
(42, 'Contact', 6, 'update', 'name', 'external project leader one', 'external project leader two', '2011-09-01 16:57:37', 1, 0),
(43, 'Contact', 6, 'update', 'idClient', '1', '2', '2011-09-01 16:57:37', 1, 0),
(44, 'Contact', 6, 'update', 'userName', 'extprolea', 'external2', '2011-09-01 16:57:37', 1, 0),
(45, 'Contact', 5, 'update', 'userName', 'extprolea', 'external1', '2011-09-01 16:57:45', 1, 0),
(46, 'Contact', 7, 'insert', NULL, NULL, NULL, '2011-09-01 16:58:14', 1, 0),
(47, 'Contact', 7, 'update', 'idProfile', NULL, '5', '2011-09-01 16:58:24', 1, 0),
(48, 'Contact', 5, 'update', 'isUser', '0', '1', '2011-09-01 17:46:37', 1, 0),
(49, 'Contact', 6, 'update', 'isUser', '0', '1', '2011-09-01 17:46:43', 1, 0),
(50, 'Project', 3, 'insert', NULL, NULL, NULL, '2011-09-01 17:47:06', 1, 0),
(51, 'ProjectPlanningElement', 3, 'insert', NULL, NULL, NULL, '2011-09-01 17:47:06', 1, 0),
(52, 'Project', 3, 'update', 'name', 'project one - subproject 1', 'project one - subproject 2', '2011-09-01 17:47:26', 1, 0),
(53, 'Project', 3, 'update', 'projectCode', '001-001-1', '001-001-2', '2011-09-01 17:47:26', 1, 0),
(54, 'ProjectPlanningElement', 3, 'update', 'idProject', '2', '3', '2011-09-01 17:47:26', 1, 0),
(55, 'ProjectPlanningElement', 3, 'update', 'refName', 'project one - subproject 1', 'project one - subproject 2', '2011-09-01 17:47:26', 1, 0),
(56, 'Project', 4, 'insert', NULL, NULL, NULL, '2011-09-01 17:47:50', 1, 0),
(57, 'ProjectPlanningElement', 4, 'insert', NULL, NULL, NULL, '2011-09-01 17:47:50', 1, 0),
(58, 'Project', 4, 'update', 'name', 'project one', 'project two', '2011-09-01 17:48:32', 1, 0),
(59, 'Project', 4, 'update', 'idClient', '1', '2', '2011-09-01 17:48:32', 1, 0),
(60, 'Project', 4, 'update', 'projectCode', '001-001', '002-002', '2011-09-01 17:48:32', 1, 0),
(61, 'Project', 4, 'update', 'contractCode', 'X23-472-722', 'X24-001-007', '2011-09-01 17:48:32', 1, 0),
(62, 'ProjectPlanningElement', 4, 'update', 'idProject', '1', '4', '2011-09-01 17:48:32', 1, 0),
(63, 'ProjectPlanningElement', 4, 'update', 'refName', 'project one', 'project two', '2011-09-01 17:48:32', 1, 0),
(64, 'Project', 4, 'update', 'idUser', NULL, '6', '2011-09-01 17:48:46', 1, 0),
(65, 'Project', 1, 'update', 'idUser', NULL, '5', '2011-09-01 17:48:53', 1, 0),
(66, 'Project', 2, 'update', 'idUser', NULL, '5', '2011-09-01 17:49:00', 1, 0),
(67, 'Project', 3, 'update', 'idUser', NULL, '5', '2011-09-01 17:49:06', 1, 0),
(68, 'Product', 2, 'insert', NULL, NULL, NULL, '2011-09-01 17:50:04', 1, 0),
(69, 'Product', 1, 'update', 'idContact', NULL, '5', '2011-09-01 17:50:19', 1, 0),
(70, 'Version', 1, 'insert', NULL, NULL, NULL, '2011-09-01 17:50:53', 1, 0),
(71, 'VersionProject', 1, 'insert', NULL, NULL, NULL, '2011-09-01 17:51:07', 1, 0),
(72, 'VersionProject', 2, 'insert', NULL, NULL, NULL, '2011-09-01 17:51:15', 1, 0),
(73, 'Project', 2, 'update', 'name', 'project one - subproject 1', 'project one - subproject 1 - maintenance', '2011-09-01 17:52:11', 1, 0),
(74, 'Project', 2, 'update', 'description', '1st project\nThis project has 2 sub-projects', 'This project is dedicated to maintenance of web app V1.0', '2011-09-01 17:52:11', 1, 0),
(75, 'ProjectPlanningElement', 2, 'update', 'refName', 'project one - subproject 1', 'project one - subproject 1 - maintenance', '2011-09-01 17:52:11', 1, 0),
(76, 'Project', 2, 'update', 'description', 'This project is dedicated to maintenance of web app V1.0', 'This project is dedicated to maintenance of "web application" V1.0', '2011-09-01 17:52:23', 1, 0),
(77, 'Project', 2, 'update', 'description', 'This project is dedicated to maintenance of "web application" V1.0', 'This project is dedicated to maintenance of \'\'web application\'\' V1.0\nIt is sub-project of project one.', '2011-09-01 17:52:38', 1, 0),
(78, 'Project', 3, 'update', 'name', 'project one - subproject 2', 'project one - subproject 2 - developement', '2011-09-01 17:52:46', 1, 0),
(79, 'ProjectPlanningElement', 3, 'update', 'refName', 'project one - subproject 2', 'project one - subproject 2 - developement', '2011-09-01 17:52:46', 1, 0),
(80, 'Project', 3, 'update', 'description', '1st project\nThis project has 2 sub-projects', 'This project is dedicated to developement of \'\'web application\'\' V2.0\nIt is sub-project of project one.', '2011-09-01 17:53:25', 1, 0),
(81, 'Project', 5, 'insert', NULL, NULL, NULL, '2011-09-01 18:31:03', 1, 0),
(82, 'ProjectPlanningElement', 5, 'insert', NULL, NULL, NULL, '2011-09-01 18:31:03', 1, 0),
(83, 'Project', 5, 'update', 'description', 'internal project', 'internal project\nout of project work', '2011-09-01 18:31:31', 1, 0),
(84, 'ProjectPlanningElement', 5, 'update', 'idProject', NULL, '5', '2011-09-01 18:31:31', 1, 0),
(85, 'Project', 6, 'insert', NULL, NULL, NULL, '2011-09-01 18:32:16', 1, 0),
(86, 'ProjectPlanningElement', 6, 'insert', NULL, NULL, NULL, '2011-09-01 18:32:16', 1, 0),
(87, 'PlanningElement', 5, 'update', 'elementary', '1', '0', '2011-09-01 18:32:16', 1, 0),
(88, 'Version', 2, 'insert', NULL, NULL, NULL, '2011-09-01 18:33:15', 1, 0),
(89, 'Version', 1, 'update', 'name', 'wa W1.0', 'wa V1.0', '2011-09-01 18:33:25', 1, 0),
(90, 'VersionProject', 3, 'insert', NULL, NULL, NULL, '2011-09-01 18:33:35', 1, 0),
(91, 'VersionProject', 4, 'insert', NULL, NULL, NULL, '2011-09-01 18:33:41', 1, 0),
(92, 'Product', 3, 'insert', NULL, NULL, NULL, '2011-09-01 19:01:15', 1, 0),
(93, 'Product', 3, 'delete', NULL, NULL, NULL, '2011-09-01 19:01:41', 1, 0),
(94, 'Project', 2, 'update', 'color', '#4169e1', '#6495ed', '2011-09-01 19:39:00', 1, 0),
(95, 'Project', 3, 'update', 'color', '#4169e1', '#87ceeb', '2011-09-01 19:39:09', 1, 0),
(96, 'Project', 1, 'update', 'color', '#4169e1', '#6a5acd', '2011-09-01 19:39:20', 1, 0),
(97, 'Project', 4, 'update', 'color', '#4169e1', '#b22222', '2011-09-01 19:39:31', 1, 0),
(98, 'Project', 5, 'update', 'color', NULL, '#008b8b', '2011-09-01 19:39:42', 1, 0),
(99, 'Project', 6, 'update', 'color', NULL, '#20b2aa', '2011-09-01 19:39:54', 1, 0),
(100, 'ProjectPlanningElement', 6, 'update', 'idProject', NULL, '6', '2011-09-01 19:39:54', 1, 0),
(101, 'Version', 3, 'insert', NULL, NULL, NULL, '2011-09-01 19:55:43', 1, 0),
(102, 'Version', 3, 'update', 'idContact', NULL, '6', '2011-09-01 19:55:52', 1, 0),
(103, 'Version', 3, 'update', 'idResource', NULL, '3', '2011-09-01 19:55:52', 1, 0),
(104, 'VersionProject', 5, 'insert', NULL, NULL, NULL, '2011-09-01 19:56:15', 1, 0),
(105, 'VersionProject', 5, 'update', 'startDate', NULL, '2011-09-01', '2011-09-01 19:56:31', 1, 0),
(106, 'VersionProject', 5, 'update', 'endDate', NULL, '2011-12-31', '2011-09-01 19:56:31', 1, 0),
(107, 'User', 3, 'update', 'name', 'pl', 'manager1', '2011-09-01 19:59:24', 1, 0),
(108, 'User', 4, 'update', 'name', 'John DOE', 'memeber1', '2011-09-01 19:59:39', 1, 0),
(109, 'Resource', 4, 'update', 'idTeam', NULL, '1', '2011-09-01 20:00:29', 1, 0),
(110, 'Resource', 3, 'update', 'idTeam', NULL, '1', '2011-09-01 20:00:39', 1, 0),
(111, 'Team', 1, 'update', 'name', 'developement team', 'web team', '2011-09-01 20:00:52', 1, 0),
(112, 'Team', 2, 'update', 'name', 'maintenance team', 'swing team', '2011-09-01 20:01:01', 1, 0),
(113, 'Resource', 8, 'insert', NULL, NULL, NULL, '2011-09-01 20:01:59', 1, 0),
(114, 'Resource', 8, 'update', 'idRole', NULL, '2', '2011-09-01 20:02:07', 1, 0),
(115, 'Resource', 9, 'insert', NULL, NULL, NULL, '2011-09-01 20:02:45', 1, 0),
(116, 'Resource', 9, 'update', 'idRole', NULL, '2', '2011-09-01 20:02:49', 1, 0),
(117, 'Resource', 10, 'insert', NULL, NULL, NULL, '2011-09-01 20:03:28', 1, 0),
(118, 'Resource', 10, 'update', 'idRole', NULL, '3', '2011-09-01 20:03:34', 1, 0),
(119, 'Resource', 11, 'insert', NULL, NULL, NULL, '2011-09-01 20:04:09', 1, 0),
(120, 'Resource', 12, 'insert', NULL, NULL, NULL, '2011-09-01 20:04:42', 1, 0),
(121, 'Affectation', 1, 'insert', NULL, NULL, NULL, '2011-09-01 20:10:13', 1, 0),
(122, 'Affectation', 2, 'insert', NULL, NULL, NULL, '2011-09-01 20:10:29', 1, 0),
(123, 'Affectation', 3, 'insert', NULL, NULL, NULL, '2011-09-01 20:10:50', 1, 0),
(124, 'Affectation', 4, 'insert', NULL, NULL, NULL, '2011-09-01 20:11:30', 1, 0),
(125, 'Affectation', 5, 'insert', NULL, NULL, NULL, '2011-09-01 20:11:41', 1, 0),
(126, 'Affectation', 6, 'insert', NULL, NULL, NULL, '2011-09-01 20:11:58', 1, 0),
(127, 'Affectation', 7, 'insert', NULL, NULL, NULL, '2011-09-01 20:12:12', 1, 0),
(128, 'Affectation', 8, 'insert', NULL, NULL, NULL, '2011-09-01 20:12:26', 1, 0),
(129, 'Affectation', 9, 'insert', NULL, NULL, NULL, '2011-09-01 20:12:41', 1, 0),
(130, 'Affectation', 10, 'insert', NULL, NULL, NULL, '2011-09-01 20:13:08', 1, 0),
(131, 'Affectation', 11, 'insert', NULL, NULL, NULL, '2011-09-01 20:13:25', 1, 0),
(132, 'Affectation', 12, 'insert', NULL, NULL, NULL, '2011-09-01 20:13:39', 1, 0),
(133, 'Affectation', 13, 'insert', NULL, NULL, NULL, '2011-09-01 20:15:15', 1, 0),
(134, 'Affectation', 7, 'update', 'rate', '100', '0', '2011-09-01 20:21:56', 1, 0),
(135, 'Affectation', 8, 'update', 'rate', '100', '0', '2011-09-01 20:22:04', 1, 0),
(136, 'Affectation', 9, 'update', 'rate', '100', '0', '2011-09-01 20:22:16', 1, 0),
(137, 'Resource', 10, 'update', 'name', 'web devloper', 'web developer', '2011-09-01 20:23:16', 1, 0),
(138, 'Resource', 12, 'update', 'name', 'multi devloper', 'multi developer', '2011-09-01 20:23:28', 1, 0),
(139, 'Resource', 11, 'update', 'name', 'swing devloper', 'swing developer', '2011-09-01 20:23:34', 1, 0),
(140, 'Resource', 4, 'update', 'userName', 'memeber1', 'member1', '2011-09-01 20:23:47', 1, 0),
(141, 'Calendar', 1, 'insert', NULL, NULL, NULL, '2011-09-01 20:24:51', 1, 0),
(142, 'Calendar', 2, 'insert', NULL, NULL, NULL, '2011-09-01 20:25:15', 1, 0),
(143, 'Affectation', 14, 'insert', NULL, NULL, NULL, '2011-09-01 20:33:01', 1, 0),
(144, 'Affectation', 15, 'insert', NULL, NULL, NULL, '2011-09-01 20:34:21', 1, 0),
(145, 'Affectation', 16, 'insert', NULL, NULL, NULL, '2011-09-01 20:34:56', 1, 0),
(146, 'Affectation', 17, 'insert', NULL, NULL, NULL, '2011-09-01 20:36:04', 1, 0),
(147, 'Affectation', 17, 'delete', NULL, NULL, NULL, '2011-09-01 20:36:17', 1, 0),
(148, 'Ticket', 1, 'insert', NULL, NULL, NULL, '2011-09-01 23:45:12', 1, 0),
(149, 'Ticket', 1, 'update', 'idUrgency', NULL, '2', '2011-09-01 23:54:51', 1, 0),
(150, 'Ticket', 1, 'update', 'creationDateTime', '2011-09-02 01:44:00', '2011-09-01 12:00:00', '2011-09-01 23:54:51', 1, 0),
(151, 'Ticket', 1, 'update', 'idOriginalVersion', NULL, '1', '2011-09-01 23:54:51', 1, 0),
(152, 'Ticket', 1, 'update', 'idStatus', '1', '3', '2011-09-01 23:54:51', 1, 0),
(153, 'Ticket', 1, 'update', 'idResource', NULL, '3', '2011-09-01 23:54:51', 1, 0),
(154, 'Ticket', 1, 'update', 'idCriticality', NULL, '1', '2011-09-01 23:54:51', 1, 0),
(155, 'Ticket', 1, 'update', 'idPriority', NULL, '1', '2011-09-01 23:54:52', 1, 0),
(156, 'Ticket', 1, 'update', 'initialDueDateTime', NULL, '2011-09-02 18:00:00', '2011-09-01 23:54:52', 1, 0),
(157, 'Ticket', 1, 'update', 'actualDueDateTime', NULL, '2011-09-02 18:30:00', '2011-09-01 23:54:52', 1, 0),
(158, 'Ticket', 1, 'update', 'handled', '0', '1', '2011-09-01 23:54:52', 1, 0),
(159, 'Ticket', 1, 'update', 'handledDateTime', NULL, '2011-09-02 01:54:00', '2011-09-01 23:54:52', 1, 0),
(160, 'Activity', 1, 'insert', NULL, NULL, NULL, '2011-09-02 08:13:01', 1, 0),
(161, 'ActivityPlanningElement', 7, 'insert', NULL, NULL, NULL, '2011-09-02 08:13:01', 1, 0),
(162, 'Activity', 1, 'update', 'idStatus', '1', '3', '2011-09-02 08:13:19', 1, 0),
(163, 'Activity', 1, 'update', 'idResource', NULL, '3', '2011-09-02 08:13:19', 1, 0),
(164, 'Activity', 1, 'update', 'handled', '0', '1', '2011-09-02 08:13:19', 1, 0),
(165, 'Activity', 1, 'update', 'handledDate', NULL, '2011-09-01', '2011-09-02 08:13:19', 1, 0),
(166, 'Assignment', 1, 'insert', NULL, NULL, NULL, '2011-09-02 08:13:20', 1, 0),
(167, 'ActivityPlanningElement', 7, 'update', 'validatedStartDate', NULL, '2011-09-01', '2011-09-02 08:13:33', 1, 0),
(168, 'ActivityPlanningElement', 7, 'update', 'validatedEndDate', NULL, '2011-12-31', '2011-09-02 08:13:33', 1, 0),
(169, 'ActivityPlanningElement', 7, 'update', 'validatedDuration', NULL, '87', '2011-09-02 08:13:33', 1, 0),
(170, 'Activity', 1, 'update', 'idProject', '1', '2', '2011-09-02 08:13:48', 1, 0),
(171, 'ActivityPlanningElement', 7, 'update', 'idProject', '1', '2', '2011-09-02 08:13:49', 1, 0),
(172, 'ActivityPlanningElement', 7, 'update', 'wbs', '1.3', '1.1.1', '2011-09-02 08:13:49', 1, 0),
(173, 'ActivityPlanningElement', 7, 'update', 'wbsSortable', '001.003', '001.001.001', '2011-09-02 08:13:49', 1, 0),
(174, 'ActivityPlanningElement', 7, 'update', 'topId', '1', '2', '2011-09-02 08:13:49', 1, 0),
(175, 'ActivityPlanningElement', 7, 'update', 'topRefId', '1', '2', '2011-09-02 08:13:49', 1, 0),
(176, 'PlanningElement', 2, 'update', 'elementary', '1', '0', '2011-09-02 08:13:49', 1, 0),
(177, 'Assignment', 1, 'update', 'idProject', '1', '2', '2011-09-02 08:13:49', 1, 0),
(178, 'Assignment', 1, 'update', 'realWork', NULL, '0', '2011-09-02 08:13:49', 1, 0),
(179, 'Assignment', 1, 'update', 'plannedWork', NULL, '0', '2011-09-02 08:13:49', 1, 0),
(180, 'Assignment', 1, 'update', 'assignedCost', NULL, '0', '2011-09-02 08:13:49', 1, 0),
(181, 'Assignment', 1, 'update', 'leftCost', NULL, '0', '2011-09-02 08:13:49', 1, 0),
(182, 'Assignment', 1, 'update', 'plannedCost', NULL, '0', '2011-09-02 08:13:49', 1, 0),
(183, 'Assignment', 1, 'update', 'assignedWork', NULL, '10', '2011-09-02 08:17:59', 1, 0),
(184, 'Assignment', 1, 'update', 'leftWork', NULL, '10', '2011-09-02 08:17:59', 1, 0),
(185, 'Assignment', 1, 'update', 'plannedWork', '0.00', '10', '2011-09-02 08:17:59', 1, 0),
(186, 'Assignment', 1, 'update', 'rate', '100', '20', '2011-09-02 08:17:59', 1, 0),
(187, 'Assignment', 1, 'update', 'assignedCost', '0.00', '5000', '2011-09-02 08:17:59', 1, 0),
(188, 'Assignment', 1, 'update', 'leftCost', '0.00', '5000', '2011-09-02 08:17:59', 1, 0),
(189, 'Assignment', 1, 'update', 'plannedCost', '0.00', '5000', '2011-09-02 08:17:59', 1, 0),
(190, 'ActivityPlanningElement', 7, 'update', 'idActivityPlanningMode', '1', '3', '2011-09-02 08:18:09', 1, 0),
(191, 'ActivityPlanningElement', 7, 'update', 'idActivityPlanningMode', '3', '7', '2011-09-02 08:18:23', 1, 0),
(192, 'Assignment', 2, 'insert', NULL, NULL, NULL, '2011-09-02 08:18:55', 1, 0),
(193, 'ResourceCost', 2, 'insert', NULL, NULL, NULL, '2011-09-02 08:22:45', 1, 0),
(194, 'ResourceCost', 3, 'insert', NULL, NULL, NULL, '2011-09-02 08:22:52', 1, 0),
(195, 'ResourceCost', 4, 'insert', NULL, NULL, NULL, '2011-09-02 08:22:59', 1, 0),
(196, 'ResourceCost', 5, 'insert', NULL, NULL, NULL, '2011-09-02 08:23:06', 1, 0),
(197, 'Assignment', 2, 'update', 'realWork', NULL, '0', '2011-09-02 08:23:06', 1, 0),
(198, 'Assignment', 2, 'update', 'dailyCost', NULL, '220.00', '2011-09-02 08:23:07', 1, 0),
(199, 'Assignment', 2, 'update', 'newDailyCost', NULL, '220.00', '2011-09-02 08:23:07', 1, 0),
(200, 'Assignment', 2, 'update', 'assignedCost', NULL, '0', '2011-09-02 08:23:07', 1, 0),
(201, 'Assignment', 2, 'update', 'realCost', NULL, '0', '2011-09-02 08:23:07', 1, 0),
(202, 'Assignment', 2, 'update', 'leftCost', NULL, '22000', '2011-09-02 08:23:07', 1, 0),
(203, 'Assignment', 2, 'update', 'plannedCost', NULL, '22000', '2011-09-02 08:23:07', 1, 0),
(204, 'ResourceCost', 6, 'insert', NULL, NULL, NULL, '2011-09-02 08:23:14', 1, 0),
(205, 'ResourceCost', 7, 'insert', NULL, NULL, NULL, '2011-09-02 08:23:21', 1, 0),
(206, 'Assignment', 2, 'update', 'assignedCost', '0.00', '22000', '2011-09-02 08:23:36', 1, 0),
(207, 'Activity', 2, 'insert', NULL, NULL, NULL, '2011-09-02 09:05:06', 1, 0),
(208, 'ActivityPlanningElement', 8, 'insert', NULL, NULL, NULL, '2011-09-02 09:05:06', 1, 0),
(209, 'PlanningElement', 3, 'update', 'elementary', '1', '0', '2011-09-02 09:05:06', 1, 0),
(210, 'Activity', 3, 'insert', NULL, NULL, NULL, '2011-09-02 09:05:28', 1, 0),
(211, 'ActivityPlanningElement', 9, 'insert', NULL, NULL, NULL, '2011-09-02 09:05:28', 1, 0),
(212, 'Activity', 3, 'update', 'idProject', '1', '3', '2011-09-02 09:05:57', 1, 0),
(213, 'Activity', 3, 'update', 'idActivity', NULL, '2', '2011-09-02 09:05:57', 1, 0),
(214, 'ActivityPlanningElement', 9, 'update', 'idProject', '1', '3', '2011-09-02 09:05:57', 1, 0),
(215, 'ActivityPlanningElement', 9, 'update', 'wbs', '1.3', '1.2.1.1', '2011-09-02 09:05:58', 1, 0),
(216, 'ActivityPlanningElement', 9, 'update', 'wbsSortable', '001.003', '001.002.001.001', '2011-09-02 09:05:58', 1, 0),
(217, 'ActivityPlanningElement', 9, 'update', 'topId', '1', '8', '2011-09-02 09:05:58', 1, 0),
(218, 'ActivityPlanningElement', 9, 'update', 'topRefType', 'Project', 'Activity', '2011-09-02 09:05:58', 1, 0),
(219, 'ActivityPlanningElement', 9, 'update', 'topRefId', '1', '2', '2011-09-02 09:05:58', 1, 0),
(220, 'PlanningElement', 8, 'update', 'elementary', '1', '0', '2011-09-02 09:05:58', 1, 0),
(221, 'Project', 2, 'update', 'name', 'project one - subproject 1 - maintenance', 'project one - maintenance', '2011-09-02 09:06:24', 1, 0),
(222, 'ProjectPlanningElement', 2, 'update', 'refName', 'project one - subproject 1 - maintenance', 'project one - maintenance', '2011-09-02 09:06:25', 1, 0),
(223, 'Project', 3, 'update', 'name', 'project one - subproject 2 - developement', 'project one - developement', '2011-09-02 09:06:32', 1, 0),
(224, 'ProjectPlanningElement', 3, 'update', 'refName', 'project one - subproject 2 - developement', 'project one - developement', '2011-09-02 09:06:32', 1, 0),
(225, 'Activity', 4, 'insert', NULL, NULL, NULL, '2011-09-02 09:07:05', 1, 0),
(226, 'ActivityPlanningElement', 10, 'insert', NULL, NULL, NULL, '2011-09-02 09:07:05', 1, 0),
(227, 'Dependency', 1, 'insert', NULL, NULL, NULL, '2011-09-02 09:07:29', 1, 0),
(228, 'Activity', 4, 'update', 'idProject', '1', '3', '2011-09-02 09:07:43', 1, 0),
(229, 'Activity', 4, 'update', 'idActivity', NULL, '2', '2011-09-02 09:07:44', 1, 0),
(230, 'ActivityPlanningElement', 10, 'update', 'idProject', '1', '3', '2011-09-02 09:07:44', 1, 0),
(231, 'ActivityPlanningElement', 10, 'update', 'wbs', '1.3', '1.2.1.2', '2011-09-02 09:07:44', 1, 0),
(232, 'ActivityPlanningElement', 10, 'update', 'wbsSortable', '001.003', '001.002.001.002', '2011-09-02 09:07:44', 1, 0),
(233, 'ActivityPlanningElement', 10, 'update', 'topId', '1', '8', '2011-09-02 09:07:44', 1, 0),
(234, 'ActivityPlanningElement', 10, 'update', 'topRefType', 'Project', 'Activity', '2011-09-02 09:07:44', 1, 0),
(235, 'ActivityPlanningElement', 10, 'update', 'topRefId', '1', '2', '2011-09-02 09:07:44', 1, 0),
(236, 'Activity', 5, 'insert', NULL, NULL, NULL, '2011-09-02 09:08:12', 1, 0),
(237, 'ActivityPlanningElement', 11, 'insert', NULL, NULL, NULL, '2011-09-02 09:08:12', 1, 0),
(238, 'Dependency', 2, 'insert', NULL, NULL, NULL, '2011-09-02 09:08:26', 1, 0),
(239, 'Milestone', 1, 'insert', NULL, NULL, NULL, '2011-09-02 15:26:06', 1, 0),
(240, 'MilestonePlanningElement', 12, 'insert', NULL, NULL, NULL, '2011-09-02 15:26:06', 1, 0),
(241, 'Dependency', 3, 'insert', NULL, NULL, NULL, '2011-09-02 15:26:23', 1, 0),
(242, 'Assignment', 3, 'insert', NULL, NULL, NULL, '2011-09-02 15:27:07', 1, 0),
(243, 'Assignment', 4, 'insert', NULL, NULL, NULL, '2011-09-02 15:27:25', 1, 0),
(244, 'Assignment', 5, 'insert', NULL, NULL, NULL, '2011-09-02 15:27:45', 1, 0),
(245, 'PlanningElement', 12, 'update', 'plannedStartDate', NULL, '2011-09-27', '2011-09-02 15:27:53', 1, 0),
(246, 'PlanningElement', 12, 'update', 'plannedEndDate', NULL, '2011-09-27', '2011-09-02 15:27:53', 1, 0),
(247, 'PlanningElement', 12, 'update', 'plannedDuration', NULL, '1', '2011-09-02 15:27:53', 1, 0),
(248, 'Assignment', 2, 'update', 'rate', '100', '50', '2011-09-02 15:29:30', 1, 0),
(249, 'Milestone', 1, 'update', 'idActivity', NULL, '2', '2011-09-02 15:30:16', 1, 0),
(250, 'Milestone', 1, 'update', 'idStatus', '0', '1', '2011-09-02 15:30:16', 1, 0),
(251, 'MilestonePlanningElement', 12, 'update', 'wbs', '1.2.2', '1.2.1.4', '2011-09-02 15:30:16', 1, 0),
(252, 'MilestonePlanningElement', 12, 'update', 'wbsSortable', '001.002.002', '001.002.001.004', '2011-09-02 15:30:16', 1, 0),
(253, 'MilestonePlanningElement', 12, 'update', 'topId', '3', '8', '2011-09-02 15:30:16', 1, 0),
(254, 'MilestonePlanningElement', 12, 'update', 'topRefType', 'Project', 'Activity', '2011-09-02 15:30:16', 1, 0),
(255, 'MilestonePlanningElement', 12, 'update', 'topRefId', '3', '2', '2011-09-02 15:30:16', 1, 0),
(256, 'MilestonePlanningElement', 12, 'update', 'initialDuration', NULL, '0', '2011-09-02 15:30:16', 1, 0),
(257, 'MilestonePlanningElement', 12, 'update', 'validatedDuration', NULL, '0', '2011-09-02 15:30:17', 1, 0),
(258, 'MilestonePlanningElement', 12, 'update', 'initialWork', NULL, '0', '2011-09-02 15:30:17', 1, 0),
(259, 'MilestonePlanningElement', 12, 'update', 'validatedWork', NULL, '0', '2011-09-02 15:30:17', 1, 0),
(260, 'MilestonePlanningElement', 12, 'update', 'plannedWork', NULL, '0', '2011-09-02 15:30:17', 1, 0),
(261, 'MilestonePlanningElement', 12, 'update', 'realWork', NULL, '0', '2011-09-02 15:30:17', 1, 0),
(262, 'Resource', 8, 'update', 'capacity', '0.50', '1', '2011-09-02 15:31:54', 1, 0),
(263, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-09-27', '2011-09-15', '2011-09-02 15:32:06', 1, 0),
(264, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-09-27', '2011-09-15', '2011-09-02 15:32:06', 1, 0),
(265, 'Activity', 6, 'insert', NULL, NULL, NULL, '2011-09-02 15:39:52', 1, 0),
(266, 'ActivityPlanningElement', 13, 'insert', NULL, NULL, NULL, '2011-09-02 15:39:52', 1, 0),
(267, 'Activity', 6, 'update', 'idStatus', '0', '1', '2011-09-02 15:40:17', 1, 0),
(268, 'ActivityPlanningElement', 13, 'update', 'idActivityPlanningMode', '1', '8', '2011-09-02 15:40:17', 1, 0),
(269, 'ActivityPlanningElement', 13, 'update', 'validatedDuration', NULL, '5', '2011-09-02 15:40:18', 1, 0),
(270, 'Dependency', 4, 'insert', NULL, NULL, NULL, '2011-09-02 15:40:51', 1, 0),
(271, 'PlanningElement', 13, 'update', 'plannedStartDate', NULL, '2011-09-16', '2011-09-02 15:40:58', 1, 0),
(272, 'PlanningElement', 13, 'update', 'plannedEndDate', NULL, '2011-09-22', '2011-09-02 15:40:58', 1, 0),
(273, 'PlanningElement', 13, 'update', 'plannedDuration', NULL, '5', '2011-09-02 15:40:58', 1, 0),
(274, 'Assignment', 2, 'update', 'assignedWork', '100.00', '75', '2011-09-02 15:45:05', 1, 0),
(275, 'Assignment', 2, 'update', 'leftWork', '100.00', '75', '2011-09-02 15:45:05', 1, 0),
(276, 'Assignment', 2, 'update', 'plannedWork', '100.00', '75', '2011-09-02 15:45:05', 1, 0),
(277, 'Assignment', 2, 'update', 'assignedCost', '22000.00', '16500', '2011-09-02 15:45:05', 1, 0),
(278, 'Assignment', 2, 'update', 'leftCost', '22000.00', '16500', '2011-09-02 15:45:05', 1, 0),
(279, 'Assignment', 2, 'update', 'plannedCost', '22000.00', '16500', '2011-09-02 15:45:05', 1, 0),
(280, 'Assignment', 3, 'update', 'realWork', '0.00', '2.5', '2011-09-02 15:47:46', 1, 0),
(281, 'Assignment', 3, 'update', 'leftWork', '5.00', '2.5', '2011-09-02 15:47:46', 1, 0),
(282, 'Assignment', 3, 'update', 'realStartDate', NULL, '2011-09-05', '2011-09-02 15:47:46', 1, 0),
(283, 'Assignment', 3, 'update', 'realEndDate', NULL, '2011-09-07', '2011-09-02 15:47:46', 1, 0),
(284, 'Assignment', 3, 'update', 'realCost', NULL, '750', '2011-09-02 15:47:46', 1, 0),
(285, 'Assignment', 3, 'update', 'leftCost', '1500.00', '750', '2011-09-02 15:47:46', 1, 0),
(286, 'Assignment', 5, 'update', 'realCost', NULL, '0', '2011-09-02 15:47:46', 1, 0),
(287, 'Assignment', 5, 'update', 'comment', NULL, 'Work could be anticipated to prepar tests', '2011-09-02 15:50:29', 1, 0),
(288, 'Assignment', 5, 'update', 'comment', 'Work could be anticipated to prepar tests', 'Work could be anticipated to prepare tests', '2011-09-02 15:50:36', 1, 0),
(289, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-09-15', '2011-09-20', '2011-09-02 16:22:41', 1, 0),
(290, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-09-15', '2011-09-20', '2011-09-02 16:22:41', 1, 0),
(291, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-09-16', '2011-09-21', '2011-09-02 16:22:42', 1, 0),
(292, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-09-22', '2011-09-27', '2011-09-02 16:22:42', 1, 0),
(293, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-09-20', '2011-09-19', '2011-09-02 16:23:49', 1, 0),
(294, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-09-20', '2011-09-19', '2011-09-02 16:23:49', 1, 0),
(295, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-09-21', '2011-09-20', '2011-09-02 16:23:49', 1, 0),
(296, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-09-27', '2011-09-26', '2011-09-02 16:23:49', 1, 0),
(297, 'Workflow', 2, 'update', 'workflowUpdate', '[      ]', '[     ]', '2011-09-02 22:53:35', 1, 0),
(298, 'Activity', 2, 'update', 'idStatus', '1', '3', '2011-09-02 23:11:55', 1, 0),
(299, 'Activity', 2, 'update', 'idResource', NULL, '8', '2011-09-02 23:11:55', 1, 0),
(300, 'Activity', 2, 'update', 'handled', '0', '1', '2011-09-02 23:11:56', 1, 0),
(301, 'Activity', 2, 'update', 'handledDate', NULL, '2011-09-03', '2011-09-02 23:11:56', 1, 0),
(302, 'Affectation', 18, 'insert', NULL, NULL, NULL, '2011-09-02 23:12:32', 1, 0),
(303, 'Activity', 2, 'update', 'idVersion', NULL, '2', '2011-09-02 23:16:09', 1, 0),
(304, 'Assignment', 3, 'update', 'assignedWork', '5.00', '3', '2011-09-02 23:46:01', 1, 0),
(305, 'Assignment', 3, 'update', 'leftWork', '2.50', '0.5', '2011-09-02 23:46:01', 1, 0),
(306, 'Assignment', 3, 'update', 'plannedWork', '5.00', '3', '2011-09-02 23:46:01', 1, 0),
(307, 'Assignment', 3, 'update', 'assignedCost', '1500.00', '900', '2011-09-02 23:46:01', 1, 0),
(308, 'Assignment', 3, 'update', 'leftCost', '750.00', '150', '2011-09-02 23:46:01', 1, 0),
(309, 'Assignment', 3, 'update', 'plannedCost', '1500.00', '900', '2011-09-02 23:46:01', 1, 0),
(310, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-09-19', '2011-09-13', '2011-09-02 23:46:08', 1, 0),
(311, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-09-19', '2011-09-13', '2011-09-02 23:46:08', 1, 0),
(312, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-09-20', '2011-09-14', '2011-09-02 23:46:08', 1, 0),
(313, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-09-26', '2011-09-20', '2011-09-02 23:46:08', 1, 0),
(314, 'Assignment', 3, 'update', 'assignedWork', '3.00', '5', '2011-09-02 23:46:51', 1, 0),
(315, 'Assignment', 3, 'update', 'leftWork', '0.50', '2.5', '2011-09-02 23:46:51', 1, 0),
(316, 'Assignment', 3, 'update', 'plannedWork', '3.00', '5', '2011-09-02 23:46:51', 1, 0),
(317, 'Assignment', 3, 'update', 'assignedCost', '900.00', '1500', '2011-09-02 23:46:51', 1, 0),
(318, 'Assignment', 3, 'update', 'leftCost', '150.00', '750', '2011-09-02 23:46:51', 1, 0),
(319, 'Assignment', 3, 'update', 'plannedCost', '900.00', '1500', '2011-09-02 23:46:51', 1, 0),
(320, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-09-13', '2011-09-19', '2011-09-02 23:46:57', 1, 0),
(321, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-09-13', '2011-09-19', '2011-09-02 23:46:57', 1, 0),
(322, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-09-14', '2011-09-20', '2011-09-02 23:46:57', 1, 0),
(323, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-09-20', '2011-09-26', '2011-09-02 23:46:57', 1, 0),
(324, 'Habilitation', 487, 'delete', NULL, NULL, NULL, '2011-10-13 15:24:06', NULL, 0),
(325, 'Ticket', 1, 'update', 'actualDueDateTime', '2011-09-02 18:30:00', '2011-09-09 18:30:00', '2011-10-13 15:24:39', 1, 0),
(326, 'User', 3, 'update', 'password', NULL, '6d361b76b20af1a3ebbf75a00b501766', '2011-10-13 15:31:47', 1, 0),
(327, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-09-19', '2011-10-26', '2011-10-13 15:54:53', 1, 0),
(328, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-09-19', '2011-10-26', '2011-10-13 15:54:54', 1, 0),
(329, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-09-20', '2011-10-27', '2011-10-13 15:54:54', 1, 0),
(330, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-09-26', '2011-11-02', '2011-10-13 15:54:54', 1, 0),
(331, 'Affectation', 19, 'insert', NULL, NULL, NULL, '2011-10-13 16:25:42', 1, 0),
(332, 'Affectation', 20, 'insert', NULL, NULL, NULL, '2011-10-13 16:25:51', 1, 0),
(333, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-10-26', '2011-10-21', '2011-10-13 16:33:16', 1, 0),
(334, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-10-26', '2011-10-21', '2011-10-13 16:33:16', 1, 0),
(335, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-10-27', '2011-10-24', '2011-10-13 16:33:17', 1, 0),
(336, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-11-02', '2011-10-28', '2011-10-13 16:33:17', 1, 0),
(337, 'Assignment', 3, 'update', 'realWork', '2.50000', '5.7', '2011-10-13 16:33:49', 1, 0),
(338, 'Assignment', 3, 'update', 'leftWork', '2.50000', '0', '2011-10-13 16:33:49', 1, 0),
(339, 'Assignment', 3, 'update', 'plannedWork', '5.00000', '5.7', '2011-10-13 16:33:49', 1, 0),
(340, 'Assignment', 3, 'update', 'realEndDate', '2011-09-07', '2011-10-13', '2011-10-13 16:33:50', 1, 0),
(341, 'Assignment', 3, 'update', 'realCost', '750.00', '1710', '2011-10-13 16:33:50', 1, 0),
(342, 'Assignment', 3, 'update', 'leftCost', '750.00', '0', '2011-10-13 16:33:50', 1, 0),
(343, 'Assignment', 3, 'update', 'plannedCost', '1500.00', '1710', '2011-10-13 16:33:50', 1, 0),
(344, 'Dependency', 5, 'insert', NULL, NULL, NULL, '2011-10-15 09:03:30', 1, 0),
(345, 'Calendar', 3, 'insert', NULL, NULL, NULL, '2011-10-15 17:37:55', 1, 0),
(346, 'Calendar', 3, 'update', 'isOffDay', '1', '0', '2011-10-15 17:38:19', 1, 0),
(347, 'Activity', 1, 'update', 'reference', NULL, '001-001-1-TAS-1', '2012-01-31 22:21:13', NULL, 0),
(348, 'Activity', 2, 'update', 'reference', NULL, '001-001-2-EVO-1', '2012-01-31 22:21:14', NULL, 0),
(349, 'Activity', 3, 'update', 'reference', NULL, '001-001-2-TAS-1', '2012-01-31 22:21:14', NULL, 0),
(350, 'Activity', 4, 'update', 'reference', NULL, '001-001-2-TAS-2', '2012-01-31 22:21:14', NULL, 0),
(351, 'Activity', 5, 'update', 'reference', NULL, '001-001-2-TAS-3', '2012-01-31 22:21:14', NULL, 0),
(352, 'Activity', 6, 'update', 'reference', NULL, '001-001-2-EVO-2', '2012-01-31 22:21:14', NULL, 0),
(353, 'Milestone', 1, 'update', 'reference', NULL, '001-001-2-KEY-1', '2012-01-31 22:21:14', NULL, 0),
(354, 'Ticket', 1, 'update', 'reference', NULL, '001-001-INC-1', '2012-01-31 22:21:15', NULL, 0),
(355, 'Affectation', 14, 'update', 'idResource', NULL, '7', '2012-01-31 22:21:15', NULL, 0),
(356, 'Affectation', 15, 'update', 'idResource', NULL, '5', '2012-01-31 22:21:15', NULL, 0),
(357, 'Affectation', 16, 'update', 'idResource', NULL, '6', '2012-01-31 22:21:15', NULL, 0),
(358, 'Affectation', 19, 'update', 'idResource', NULL, '1', '2012-01-31 22:21:15', NULL, 0),
(359, 'Affectation', 20, 'update', 'idResource', NULL, '1', '2012-01-31 22:21:15', NULL, 0),
(360, 'PlanningElement', 1, 'update', 'plannedDuration', '103', '104', '2012-03-13 17:01:13', NULL, 0),
(361, 'PlanningElement', 1, 'update', 'progress', '0', '5.49662487946', '2012-03-13 17:01:13', NULL, 0),
(362, 'PlanningElement', 2, 'update', 'plannedDuration', '78', '79', '2012-03-13 17:01:13', NULL, 0),
(363, 'PlanningElement', 3, 'update', 'plannedDuration', '40', '41', '2012-03-13 17:01:13', NULL, 0),
(364, 'PlanningElement', 3, 'update', 'progress', '0', '30.48128342246', '2012-03-13 17:01:14', NULL, 0),
(365, 'PlanningElement', 7, 'update', 'validatedDuration', '87', '88', '2012-03-13 17:01:14', NULL, 0),
(366, 'PlanningElement', 7, 'update', 'plannedDuration', '78', '79', '2012-03-13 17:01:14', NULL, 0),
(367, 'PlanningElement', 8, 'update', 'progress', '0', '30.48128342246', '2012-03-13 17:01:14', NULL, 0),
(368, 'PlanningElement', 9, 'update', 'progress', '0', '100', '2012-03-13 17:01:14', NULL, 0),
(369, 'Assignment', 2, 'update', 'realWork', '0.00000', '4', '2012-03-14 13:09:32', 1, 0),
(370, 'Assignment', 2, 'update', 'leftWork', '75.00000', '71', '2012-03-14 13:09:32', 1, 0),
(371, 'Assignment', 2, 'update', 'realStartDate', NULL, '2012-03-12', '2012-03-14 13:09:32', 1, 0),
(372, 'Assignment', 2, 'update', 'realEndDate', NULL, '2012-03-15', '2012-03-14 13:09:32', 1, 0),
(373, 'Assignment', 2, 'update', 'realCost', '0.00', '880', '2012-03-14 13:09:32', 1, 0),
(374, 'Assignment', 2, 'update', 'leftCost', '16500.00', '15620', '2012-03-14 13:09:32', 1, 0),
(375, 'Assignment', 4, 'update', 'realCost', NULL, '0', '2012-03-14 13:09:33', 1, 0),
(376, 'Assignment', 2, 'update', 'realWork', '4.00000', '8.2', '2012-03-14 13:09:54', 1, 0),
(377, 'Assignment', 2, 'update', 'leftWork', '71.00000', '66.8', '2012-03-14 13:09:54', 1, 0),
(378, 'Assignment', 2, 'update', 'realStartDate', '2012-03-12', '2012-03-05', '2012-03-14 13:09:54', 1, 0),
(379, 'Assignment', 2, 'update', 'realCost', '880.00', '1804', '2012-03-14 13:09:54', 1, 0),
(380, 'Assignment', 2, 'update', 'leftCost', '15620.00', '14696', '2012-03-14 13:09:54', 1, 0),
(381, 'Assignment', 2, 'update', 'realWork', '8.20000', '8.5', '2012-03-14 13:11:14', 1, 0),
(382, 'Assignment', 2, 'update', 'leftWork', '66.80000', '66.5', '2012-03-14 13:11:14', 1, 0),
(383, 'Assignment', 2, 'update', 'realEndDate', '2012-03-15', '2012-03-16', '2012-03-14 13:11:14', 1, 0),
(384, 'Assignment', 2, 'update', 'realCost', '1804.00', '1870', '2012-03-14 13:11:14', 1, 0),
(385, 'Assignment', 2, 'update', 'leftCost', '14696.00', '14630', '2012-03-14 13:11:14', 1, 0),
(386, 'ActivityPlanningElement', 7, 'update', 'validatedWork', NULL, '0', '2012-03-14 20:30:22', 1, 0),
(387, 'ActivityPlanningElement', 7, 'update', 'realWork', '8.50000', '0', '2012-03-14 20:30:22', 1, 0),
(388, 'ActivityPlanningElement', 7, 'update', 'leftWork', '76.50000', '0', '2012-03-14 20:30:22', 1, 0),
(389, 'ActivityPlanningElement', 7, 'update', 'progress', '10', '0', '2012-03-14 20:30:22', 1, 0),
(390, 'ActivityPlanningElement', 7, 'update', 'initialWork', NULL, '0', '2012-03-14 20:30:22', 1, 0),
(391, 'Assignment', 2, 'update', 'realWork', '8.50000', '7.5', '2012-03-14 20:31:14', 1, 0),
(392, 'Assignment', 2, 'update', 'leftWork', '66.50000', '67.5', '2012-03-14 20:31:14', 1, 0),
(393, 'Assignment', 2, 'update', 'realCost', '1870.00', '1650', '2012-03-14 20:31:14', 1, 0),
(394, 'Assignment', 2, 'update', 'leftCost', '14630.00', '14850', '2012-03-14 20:31:14', 1, 0),
(395, 'Assignment', 2, 'update', 'realWork', '7.50000', '8.5', '2012-03-14 20:31:28', 1, 0),
(396, 'Assignment', 2, 'update', 'leftWork', '67.50000', '66.5', '2012-03-14 20:31:28', 1, 0),
(397, 'Assignment', 2, 'update', 'realCost', '1650.00', '1870', '2012-03-14 20:31:28', 1, 0),
(398, 'Assignment', 2, 'update', 'leftCost', '14850.00', '14630', '2012-03-14 20:31:28', 1, 0),
(399, 'Assignment', 2, 'update', 'realWork', '8.50000', '8', '2012-03-14 20:33:30', 1, 0),
(400, 'Assignment', 2, 'update', 'leftWork', '66.50000', '67', '2012-03-14 20:33:30', 1, 0),
(401, 'Assignment', 2, 'update', 'realCost', '1870.00', '1760', '2012-03-14 20:33:30', 1, 0),
(402, 'Assignment', 2, 'update', 'leftCost', '14630.00', '14740', '2012-03-14 20:33:30', 1, 0),
(403, 'Assignment', 2, 'update', 'realWork', '8.00000', '8.5', '2012-03-14 20:42:24', 1, 0),
(404, 'Assignment', 2, 'update', 'leftWork', '67.00000', '66.5', '2012-03-14 20:42:24', 1, 0),
(405, 'Assignment', 2, 'update', 'realCost', '1760.00', '1870', '2012-03-14 20:42:25', 1, 0),
(406, 'Assignment', 2, 'update', 'leftCost', '14740.00', '14630', '2012-03-14 20:42:25', 1, 0),
(407, 'Assignment', 2, 'update', 'assignedWork', '75.00000', '75.1', '2012-03-14 20:47:06', 1, 0),
(408, 'Assignment', 2, 'update', 'leftWork', '66.50000', '66.6', '2012-03-14 20:47:06', 1, 0),
(409, 'Assignment', 2, 'update', 'plannedWork', '75.00000', '75.1', '2012-03-14 20:47:06', 1, 0),
(410, 'Assignment', 2, 'update', 'assignedCost', '16500.00', '0', '2012-03-14 20:47:06', 1, 0),
(411, 'Assignment', 2, 'update', 'leftCost', '14630.00', '14652', '2012-03-14 20:47:06', 1, 0),
(412, 'Assignment', 2, 'update', 'plannedCost', '16500.00', '16522', '2012-03-14 20:47:06', 1, 0),
(413, 'Assignment', 2, 'update', 'assignedWork', '75.10000', '75.2', '2012-03-14 20:55:49', 1, 0),
(414, 'Assignment', 2, 'update', 'leftWork', '66.60000', '66.7', '2012-03-14 20:55:49', 1, 0),
(415, 'Assignment', 2, 'update', 'plannedWork', '75.10000', '75.2', '2012-03-14 20:55:49', 1, 0),
(416, 'Assignment', 2, 'update', 'leftCost', '14652.00', '14674', '2012-03-14 20:55:49', 1, 0),
(417, 'Assignment', 2, 'update', 'plannedCost', '16522.00', '16544', '2012-03-14 20:55:49', 1, 0),
(418, 'Action', 1, 'insert', NULL, NULL, NULL, '2012-03-14 21:56:11', 1, 0),
(419, 'Risk', 1, 'insert', NULL, NULL, NULL, '2012-03-14 22:01:48', 1, 0),
(420, 'Link', 1, 'insert', NULL, NULL, NULL, '2012-03-14 22:02:06', 1, 0),
(421, 'Issue', 1, 'insert', NULL, NULL, NULL, '2012-03-14 22:04:22', 1, 0),
(422, 'Issue', 1, 'update', 'idResource', NULL, '3', '2012-03-14 22:04:50', 1, 0),
(423, 'Link', 2, 'insert', NULL, NULL, NULL, '2012-03-14 22:05:02', 1, 0),
(424, 'Link', 3, 'insert', NULL, NULL, NULL, '2012-03-14 22:05:20', 1, 0),
(425, 'PlanningElement', 13, 'update', 'plannedStartDate', '2011-10-24', '2012-03-26', '2012-03-14 22:13:38', 1, 0),
(426, 'PlanningElement', 13, 'update', 'plannedEndDate', '2011-10-28', '2012-03-30', '2012-03-14 22:13:38', 1, 0),
(427, 'PlanningElement', 1, 'update', 'plannedStartDate', '2011-10-21', '2011-09-05', '2012-03-14 22:13:41', 1, 0),
(428, 'PlanningElement', 1, 'update', 'plannedEndDate', '2012-05-22', NULL, '2012-03-14 22:13:41', 1, 0),
(429, 'PlanningElement', 1, 'update', 'plannedDuration', '154', NULL, '2012-03-14 22:13:41', 1, 0),
(430, 'PlanningElement', 1, 'update', 'progress', '14', '13.666987487969', '2012-03-14 22:13:41', 1, 0),
(431, 'PlanningElement', 1, 'update', 'assignedCost', '26144.00', '9600.00', '2012-03-14 22:13:41', 1, 0),
(432, 'PlanningElement', 2, 'update', 'plannedStartDate', '2012-03-05', '2011-10-10', '2012-03-14 22:13:41', 1, 0),
(433, 'PlanningElement', 2, 'update', 'plannedDuration', '57', '163', '2012-03-14 22:13:41', 1, 0),
(434, 'PlanningElement', 2, 'update', 'progress', '10', '9.9765258215962', '2012-03-14 22:13:41', 1, 0),
(435, 'PlanningElement', 2, 'update', 'assignedCost', '21544.00', '5000.00', '2012-03-14 22:13:41', 1, 0),
(436, 'PlanningElement', 3, 'update', 'plannedStartDate', '2011-10-21', '2011-09-05', '2012-03-14 22:13:41', 1, 0),
(437, 'PlanningElement', 3, 'update', 'plannedDuration', '117', '151', '2012-03-14 22:13:41', 1, 0),
(438, 'PlanningElement', 3, 'update', 'progress', '30', '30.48128342246', '2012-03-14 22:13:41', 1, 0),
(439, 'PlanningElement', 8, 'update', 'plannedStartDate', '2011-10-21', '2011-09-05', '2012-03-14 22:13:42', 1, 0),
(440, 'PlanningElement', 8, 'update', 'plannedEndDate', '2012-03-23', '2012-03-26', '2012-03-14 22:13:42', 1, 0),
(441, 'PlanningElement', 8, 'update', 'plannedDuration', '112', '147', '2012-03-14 22:13:42', 1, 0),
(442, 'PlanningElement', 8, 'update', 'progress', '30', '30.48128342246', '2012-03-14 22:13:42', 1, 0),
(443, 'PlanningElement', 12, 'update', 'plannedStartDate', '2011-10-21', '2012-03-26', '2012-03-14 22:13:42', 1, 0),
(444, 'PlanningElement', 12, 'update', 'plannedEndDate', '2011-10-21', '2012-03-26', '2012-03-14 22:13:42', 1, 0),
(445, 'PlanningElement', 1, 'update', 'progress', '14', '13.666987487969', '2012-03-14 22:13:42', 1, 0),
(446, 'PlanningElement', 2, 'update', 'progress', '10', '9.9765258215962', '2012-03-14 22:13:42', 1, 0),
(447, 'PlanningElement', 3, 'update', 'progress', '30', '30.48128342246', '2012-03-14 22:13:42', 1, 0),
(448, 'PlanningElement', 8, 'update', 'progress', '30', '30.48128342246', '2012-03-14 22:13:42', 1, 0),
(449, 'IndividualExpense', 1, 'insert', NULL, NULL, NULL, '2012-03-15 13:55:07', 1, 0),
(450, 'IndividualExpense', 1, 'update', 'name', 'Travel to London for Progress', 'Travel to London for Progress Meeting', '2012-03-15 13:55:13', 1, 0),
(451, 'IndividualExpense', 1, 'update', 'expensePlannedDate', NULL, '2012-03-05', '2012-03-15 13:55:20', 1, 0),
(452, 'IndividualExpense', 1, 'update', 'plannedAmount', NULL, '1500', '2012-03-15 13:55:20', 1, 0),
(453, 'IndividualExpense', 1, 'update', 'day', NULL, '20120305', '2012-03-15 13:55:20', 1, 0),
(454, 'IndividualExpense', 1, 'update', 'week', '01', '201210', '2012-03-15 13:55:20', 1, 0),
(455, 'IndividualExpense', 1, 'update', 'month', NULL, '201203', '2012-03-15 13:55:20', 1, 0),
(456, 'IndividualExpense', 1, 'update', 'year', NULL, '2012', '2012-03-15 13:55:21', 1, 0),
(457, 'ExpenseDetail', 1, 'insert', NULL, NULL, NULL, '2012-03-15 13:55:45', 1, 0),
(458, 'Expense', 1, 'update', 'expenseRealDate', NULL, '2012-03-05', '2012-03-15 13:55:45', 1, 0),
(459, 'Expense', 1, 'update', 'realAmount', NULL, '945', '2012-03-15 13:55:45', 1, 0),
(460, 'ExpenseDetail', 2, 'insert', NULL, NULL, NULL, '2012-03-15 13:56:16', 1, 0),
(461, 'Expense', 1, 'update', 'realAmount', '945.00', '1041', '2012-03-15 13:56:16', 1, 0),
(462, 'ExpenseDetail', 3, 'insert', NULL, NULL, NULL, '2012-03-15 13:56:42', 1, 0),
(463, 'Expense', 1, 'update', 'realAmount', '1041.00', '1063.68', '2012-03-15 13:56:42', 1, 0),
(464, 'ProjectExpense', 2, 'insert', NULL, NULL, NULL, '2012-03-15 14:09:43', 1, 0),
(465, 'ProjectExpense', 2, 'update', 'expensePlannedDate', NULL, '2012-03-01', '2012-03-15 14:10:02', 1, 0),
(466, 'ProjectExpense', 2, 'update', 'plannedAmount', NULL, '5000', '2012-03-15 14:10:02', 1, 0),
(467, 'ProjectExpense', 2, 'update', 'expenseRealDate', NULL, '2012-03-06', '2012-03-15 14:10:02', 1, 0),
(468, 'ProjectExpense', 2, 'update', 'realAmount', NULL, '5234', '2012-03-15 14:10:02', 1, 0),
(469, 'ProjectExpense', 2, 'update', 'day', NULL, '20120306', '2012-03-15 14:10:03', 1, 0),
(470, 'ProjectExpense', 2, 'update', 'week', '01', '201210', '2012-03-15 14:10:03', 1, 0),
(471, 'ProjectExpense', 2, 'update', 'month', NULL, '201203', '2012-03-15 14:10:03', 1, 0),
(472, 'ProjectExpense', 2, 'update', 'year', NULL, '2012', '2012-03-15 14:10:03', 1, 0),
(473, 'Term', 1, 'insert', NULL, NULL, NULL, '2012-03-15 14:17:11', 1, 0),
(474, 'Dependency', 6, 'insert', NULL, NULL, NULL, '2012-03-15 14:17:22', 1, 0),
(475, 'Term', 1, 'update', 'name', 'March 2012', 'March 2012 - 50%', '2012-03-15 14:23:44', 1, 0),
(476, 'Term', 1, 'update', 'amount', NULL, '2400', '2012-03-15 14:23:44', 1, 0),
(477, 'Term', 1, 'update', 'date', NULL, '2012-03-31', '2012-03-15 14:23:44', 1, 0),
(478, 'Bill', 1, 'insert', NULL, NULL, NULL, '2012-03-15 17:32:48', 1, 0),
(479, 'Bill', 1, 'update', 'date', NULL, '2012-03-31', '2012-03-15 17:33:03', 1, 0),
(480, 'Bill', 1, 'update', 'idContact', NULL, '7', '2012-03-15 17:33:03', 1, 0),
(481, 'Bill', 1, 'update', 'untaxedAmount', NULL, '0', '2012-03-15 17:33:04', 1, 0),
(482, 'Bill', 1, 'update', 'fullAmount', NULL, '0', '2012-03-15 17:33:04', 1, 0),
(483, 'Recipient', 1, 'insert', NULL, NULL, NULL, '2012-03-15 17:34:35', 1, 0),
(484, 'Recipient', 1, 'update', 'designation', NULL, 'M. CLIENT', '2012-03-15 17:35:19', 1, 0),
(485, 'Recipient', 1, 'update', 'street', NULL, 'rue blanche', '2012-03-15 17:35:19', 1, 0),
(486, 'Recipient', 1, 'update', 'zip', NULL, '75001', '2012-03-15 17:35:19', 1, 0),
(487, 'Recipient', 1, 'update', 'city', NULL, 'PARIS', '2012-03-15 17:35:19', 1, 0),
(488, 'Recipient', 1, 'update', 'country', NULL, 'FRANCE', '2012-03-15 17:35:19', 1, 0),
(489, 'Bill', 1, 'update', 'idRecipient', NULL, '1', '2012-03-15 17:35:31', 1, 0),
(490, 'Recipient', 1, 'update', 'name', 'Client 1 Recipeint', 'Client 1 Recipient', '2012-03-15 17:35:44', 1, 0),
(491, 'Project', 1, 'update', 'idProjectType', NULL, '49', '2012-03-15 17:36:22', 1, 0),
(492, 'ProjectPlanningElement', 1, 'update', 'progress', '14', '13.666987487969', '2012-03-15 17:36:23', 1, 0),
(493, 'ProjectPlanningElement', 1, 'update', 'validatedWork', NULL, '0', '2012-03-15 17:36:23', 1, 0),
(494, 'ProjectPlanningElement', 1, 'update', 'initialWork', NULL, '0', '2012-03-15 17:36:23', 1, 0),
(495, 'Project', 1, 'update', 'idProjectType', '49', '48', '2012-03-15 17:36:27', 1, 0),
(496, 'ProjectPlanningElement', 1, 'update', 'progress', '14', '13.666987487969', '2012-03-15 17:36:27', 1, 0),
(497, 'Bill', 1, 'update', 'billingType', NULL, 'E', '2012-03-15 17:36:40', 1, 0),
(498, 'Bill', 1, 'update', 'tax', NULL, '19.6', '2012-03-15 17:36:53', 1, 0),
(499, 'Term', 1, 'update', 'date', '2012-03-31', '2012-03-15', '2012-03-15 17:55:04', 1, 0),
(500, 'Term', 1, 'update', 'idBill', NULL, '1', '2012-03-15 17:56:11', 1, 0),
(501, 'PlanningElement', 8, 'update', 'progress', '30', '30.48128342246', '2012-03-15 17:56:11', 1, 0),
(502, 'PlanningElement', 8, 'update', 'idBill', NULL, '1', '2012-03-15 17:56:11', 1, 0),
(503, 'Bill', 1, 'update', 'untaxedAmount', '0.00', '2400', '2012-03-15 17:56:11', 1, 0),
(504, 'Bill', 1, 'update', 'fullAmount', '0.00', '2870.4', '2012-03-15 17:56:11', 1, 0),
(505, 'Project', 4, 'update', 'idProjectType', NULL, '49', '2012-03-15 18:00:16', 1, 0),
(506, 'ProjectPlanningElement', 4, 'update', 'validatedWork', NULL, '0', '2012-03-15 18:00:16', 1, 0),
(507, 'ProjectPlanningElement', 4, 'update', 'assignedWork', NULL, '0', '2012-03-15 18:00:16', 1, 0),
(508, 'ProjectPlanningElement', 4, 'update', 'plannedWork', NULL, '0', '2012-03-15 18:00:16', 1, 0),
(509, 'ProjectPlanningElement', 4, 'update', 'realWork', NULL, '0', '2012-03-15 18:00:17', 1, 0),
(510, 'ProjectPlanningElement', 4, 'update', 'leftWork', NULL, '0', '2012-03-15 18:00:17', 1, 0),
(511, 'ProjectPlanningElement', 4, 'update', 'initialWork', NULL, '0', '2012-03-15 18:00:17', 1, 0),
(512, 'Bill', 2, 'insert', NULL, NULL, NULL, '2012-03-15 18:00:33', 1, 0),
(513, 'Bill', 2, 'update', 'idProject', '1', '4', '2012-03-15 18:00:47', 1, 0),
(514, 'Bill', 2, 'update', 'untaxedAmount', NULL, '0', '2012-03-15 18:00:47', 1, 0),
(515, 'Bill', 2, 'update', 'fullAmount', NULL, '0', '2012-03-15 18:00:47', 1, 0),
(516, 'Bill', 2, 'update', 'billingType', 'E', 'R', '2012-03-15 18:00:47', 1, 0),
(517, 'Project', 4, 'update', 'idProjectType', '49', '50', '2012-03-15 18:01:25', 1, 0),
(518, 'Bill', 2, 'update', 'billingType', 'R', 'P', '2012-03-15 18:01:38', 1, 0),
(519, 'ProjectType', 75, 'insert', NULL, NULL, NULL, '2012-03-15 18:02:44', 1, 0),
(520, 'Project', 4, 'update', 'idProjectType', '50', '75', '2012-03-15 18:02:57', 1, 0),
(521, 'Bill', 2, 'update', 'billingType', 'P', 'M', '2012-03-15 18:03:08', 1, 0),
(522, 'Bill', 2, 'update', 'untaxedAmount', '0.00', '9000', '2012-03-15 18:04:40', 1, 0),
(523, 'Bill', 2, 'update', 'fullAmount', '0.00', '9000', '2012-03-15 18:04:40', 1, 0),
(524, 'Project', 4, 'update', 'idProjectType', '75', '49', '2012-03-15 18:05:21', 1, 0),
(525, 'Bill', 2, 'update', 'billingType', 'M', 'R', '2012-03-15 18:05:43', 1, 0),
(526, 'ActivityPrice', 1, 'insert', NULL, NULL, NULL, '2012-03-15 18:06:25', 1, 0);
INSERT INTO `history` (`id`, `refType`, `refId`, `operation`, `colName`, `oldValue`, `newValue`, `operationDate`, `idUser`, `isWorkHistory`) VALUES
(527, 'ActivityPrice', 1, 'update', 'priceCost', '0.00', '900', '2012-03-15 18:06:29', 1, 0),
(528, 'ActivityPrice', 1, 'update', 'idActivityType', '26', '21', '2012-03-15 18:07:08', 1, 0),
(529, 'ActivityPrice', 1, 'update', 'name', 'Architecture design', 'Management (not included in fixed price)', '2012-03-15 18:07:08', 1, 0),
(530, 'ActivityPrice', 1, 'update', 'idProject', '1', '4', '2012-03-15 18:07:27', 1, 0),
(531, 'Activity', 7, 'insert', NULL, NULL, NULL, '2012-03-15 18:08:02', 1, 0),
(532, 'ActivityPlanningElement', 14, 'insert', NULL, NULL, NULL, '2012-03-15 18:08:03', 1, 0),
(533, 'PlanningElement', 1, 'update', 'progress', '14', '13.666987487969', '2012-03-15 18:08:03', 1, 0),
(534, 'Activity', 7, 'update', 'idActivityType', '26', '21', '2012-03-15 18:08:07', 1, 0),
(535, 'Activity', 7, 'update', 'idProject', '1', '4', '2012-03-15 18:08:13', 1, 0),
(536, 'ActivityPlanningElement', 14, 'update', 'idProject', '1', '4', '2012-03-15 18:08:13', 1, 0),
(537, 'ActivityPlanningElement', 14, 'update', 'wbs', '1.3', '2.1', '2012-03-15 18:08:13', 1, 0),
(538, 'ActivityPlanningElement', 14, 'update', 'wbsSortable', '001.003', '002.001', '2012-03-15 18:08:13', 1, 0),
(539, 'ActivityPlanningElement', 14, 'update', 'topId', '1', '4', '2012-03-15 18:08:13', 1, 0),
(540, 'ActivityPlanningElement', 14, 'update', 'topRefId', '1', '4', '2012-03-15 18:08:13', 1, 0),
(541, 'PlanningElement', 4, 'update', 'elementary', '1', '0', '2012-03-15 18:08:13', 1, 0),
(542, 'Activity', 7, 'update', 'idResource', NULL, '3', '2012-03-15 18:08:18', 1, 0),
(543, 'Assignment', 6, 'insert', NULL, NULL, NULL, '2012-03-15 18:08:18', 1, 0),
(544, 'Assignment', 1, 'update', 'realCost', NULL, '0', '2012-03-15 18:08:38', 1, 0),
(545, 'Assignment', 6, 'update', 'realWork', NULL, '5', '2012-03-15 18:08:39', 1, 0),
(546, 'Assignment', 6, 'update', 'leftWork', NULL, '0', '2012-03-15 18:08:39', 1, 0),
(547, 'Assignment', 6, 'update', 'plannedWork', NULL, '5', '2012-03-15 18:08:39', 1, 0),
(548, 'Assignment', 6, 'update', 'realStartDate', NULL, '2012-03-12', '2012-03-15 18:08:39', 1, 0),
(549, 'Assignment', 6, 'update', 'realEndDate', NULL, '2012-03-16', '2012-03-15 18:08:39', 1, 0),
(550, 'Assignment', 6, 'update', 'assignedCost', NULL, '0', '2012-03-15 18:08:39', 1, 0),
(551, 'Assignment', 6, 'update', 'realCost', NULL, '2500', '2012-03-15 18:08:39', 1, 0),
(552, 'Assignment', 6, 'update', 'leftCost', NULL, '0', '2012-03-15 18:08:40', 1, 0),
(553, 'Assignment', 6, 'update', 'plannedCost', NULL, '2500', '2012-03-15 18:08:40', 1, 0),
(554, 'Assignment', 6, 'update', 'billedWork', '0.00', '5', '2012-03-15 18:09:11', 1, 0),
(555, 'Bill', 2, 'update', 'untaxedAmount', '9000.00', '13500', '2012-03-15 18:09:11', 1, 0),
(556, 'Bill', 2, 'update', 'fullAmount', '9000.00', '13500', '2012-03-15 18:09:11', 1, 0),
(557, 'Bill', 3, 'insert', NULL, NULL, NULL, '2012-03-15 19:13:24', 1, 0),
(558, 'Bill', 3, 'update', 'idStatus', '1', '3', '2012-03-15 19:22:10', 1, 0),
(559, 'Bill', 3, 'update', 'untaxedAmount', NULL, '0', '2012-03-15 19:22:10', 1, 0),
(560, 'Bill', 3, 'update', 'fullAmount', NULL, '0', '2012-03-15 19:22:10', 1, 0),
(561, 'Bill', 3, 'update', 'date', NULL, '2012-03-15', '2012-03-15 19:23:13', 1, 0),
(562, 'Bill', 3, 'update', 'idContact', NULL, '7', '2012-03-15 19:23:13', 1, 0),
(563, 'Bill', 3, 'update', 'idRecipient', NULL, '1', '2012-03-15 19:23:13', 1, 0),
(564, 'Bill', 1, 'update', 'billId', NULL, '10000', '2012-03-15 19:23:33', 1, 0),
(565, 'Bill', 1, 'update', 'idStatus', '1', '4', '2012-03-15 19:23:33', 1, 0),
(566, 'Bill', 1, 'update', 'done', '0', '1', '2012-03-15 19:23:33', 1, 0),
(567, 'Meeting', 1, 'insert', NULL, NULL, NULL, '2012-03-15 20:27:45', 1, 0),
(568, 'Decision', 1, 'insert', NULL, NULL, NULL, '2012-03-15 20:28:39', 1, 0),
(569, 'Link', 4, 'insert', NULL, NULL, NULL, '2012-03-15 20:28:42', 1, 0),
(570, 'Question', 1, 'insert', NULL, NULL, NULL, '2012-03-15 20:30:17', 1, 0),
(571, 'Link', 5, 'insert', NULL, NULL, NULL, '2012-03-15 20:30:21', 1, 0),
(572, 'Question', 1, 'update', 'name', 'What will be first deployed users', 'Who will be first deployed users ?', '2012-03-15 20:30:34', 1, 0),
(573, 'Document', 1, 'insert', NULL, NULL, NULL, '2012-03-16 13:26:11', 1, 0),
(574, 'DocumentVersion', 1, 'insert', NULL, NULL, NULL, '2012-03-16 13:42:39', 1, 0),
(575, 'Document', 1, 'update', 'idDocumentVersion', NULL, '1', '2012-03-16 13:42:39', 1, 0),
(576, 'Document', 1, 'update', 'idDocumentVersionRef', NULL, '1', '2012-03-16 13:42:39', 1, 0),
(577, 'Document', 1, 'update', 'idStatus', NULL, '1', '2012-03-16 13:42:39', 1, 0),
(578, 'Document', 1, 'update', 'version', NULL, '1', '2012-03-16 13:42:39', 1, 0),
(579, 'Document', 1, 'update', 'revision', NULL, '0', '2012-03-16 13:42:39', 1, 0),
(580, 'DocumentVersion', 2, 'insert', NULL, NULL, NULL, '2012-03-16 13:43:35', 1, 0),
(581, 'Document', 1, 'update', 'idDocumentVersion', '1', '2', '2012-03-16 13:43:35', 1, 0),
(582, 'Document', 1, 'update', 'revision', '0', '1', '2012-03-16 13:43:35', 1, 0),
(583, 'Document', 1, 'update', 'draft', NULL, '1', '2012-03-16 13:43:35', 1, 0),
(584, 'DocumentVersion', 1, 'update', 'updateDateTime', NULL, '2012-03-16 14:43:50', '2012-03-16 13:43:50', 1, 0),
(585, 'DocumentVersion', 1, 'update', 'idStatus', '1', '4', '2012-03-16 13:43:50', 1, 0),
(586, 'DocumentVersion', 1, 'update', 'updateDateTime', '2012-03-16 14:43:50', '2012-03-16 14:43:58', '2012-03-16 13:43:58', 1, 0),
(587, 'DocumentVersion', 1, 'update', 'idStatus', '4', '12', '2012-03-16 13:43:58', 1, 0),
(588, 'DocumentVersion', 2, 'update', 'updateDateTime', NULL, '2012-03-16 14:44:56', '2012-03-16 13:44:56', 1, 0),
(589, 'DocumentVersion', 2, 'update', 'description', 'ARD - Taking into accound remarks from architect', 'ARD - Taking into accound evolution of the clustered architecture :\r\nTwo web servers in cluster replacing a single web server', '2012-03-16 13:44:56', 1, 0),
(590, 'DocumentVersion', 2, 'delete', NULL, NULL, NULL, '2012-03-16 13:45:48', 1, 0),
(591, 'Document', 1, 'update', 'idDocumentVersion', '2', NULL, '2012-03-16 13:45:49', 1, 0),
(592, 'Document', 1, 'update', 'version', '1', NULL, '2012-03-16 13:45:49', 1, 0),
(593, 'Document', 1, 'update', 'revision', '1', NULL, '2012-03-16 13:45:49', 1, 0),
(594, 'Document', 1, 'update', 'draft', '1', NULL, '2012-03-16 13:45:49', 1, 0),
(595, 'DocumentVersion', 1, 'update', 'updateDateTime', '2012-03-16 14:43:58', '2012-03-16 14:45:49', '2012-03-16 13:45:49', 1, 0),
(596, 'Document', 1, 'update', 'idDocumentVersion', '2', '1', '2012-03-16 13:45:49', 1, 0),
(597, 'Document', 1, 'update', 'idStatus', '1', '12', '2012-03-16 13:45:49', 1, 0),
(598, 'Document', 1, 'update', 'revision', '1', '0', '2012-03-16 13:45:49', 1, 0),
(599, 'Document', 1, 'update', 'draft', '1', NULL, '2012-03-16 13:45:49', 1, 0),
(600, 'DocumentVersion', 1, 'delete', NULL, NULL, NULL, '2012-03-16 13:46:41', 1, 0),
(601, 'Document', 1, 'update', 'idDocumentVersion', '1', NULL, '2012-03-16 13:46:41', 1, 0),
(602, 'Document', 1, 'update', 'revision', '0', NULL, '2012-03-16 13:46:41', 1, 0),
(603, 'DocumentVersion', 3, 'insert', NULL, NULL, NULL, '2012-03-16 13:47:00', 1, 0),
(604, 'Document', 1, 'update', 'idDocumentVersion', NULL, '3', '2012-03-16 13:47:00', 1, 0),
(605, 'Document', 1, 'update', 'idStatus', '12', '1', '2012-03-16 13:47:00', 1, 0),
(606, 'Document', 1, 'update', 'version', NULL, '1', '2012-03-16 13:47:00', 1, 0),
(607, 'Document', 1, 'update', 'revision', NULL, '0', '2012-03-16 13:47:00', 1, 0),
(608, 'DocumentVersion', 3, 'update', 'updateDateTime', NULL, '2012-03-16 14:47:09', '2012-03-16 13:47:09', 1, 0),
(609, 'DocumentVersion', 3, 'update', 'idStatus', '1', '4', '2012-03-16 13:47:09', 1, 0),
(610, 'Document', 1, 'update', 'idStatus', '1', '4', '2012-03-16 13:47:09', 1, 0),
(611, 'DocumentVersion', 3, 'update', 'updateDateTime', '2012-03-16 14:47:09', '2012-03-16 14:47:21', '2012-03-16 13:47:21', 1, 0),
(612, 'DocumentVersion', 3, 'update', 'idStatus', '4', '12', '2012-03-16 13:47:21', 1, 0),
(613, 'DocumentVersion', 3, 'update', 'isRef', '0', '1', '2012-03-16 13:47:21', 1, 0),
(614, 'Document', 1, 'update', 'idDocumentVersionRef', '1', '3', '2012-03-16 13:47:21', 1, 0),
(615, 'Document', 1, 'update', 'idStatus', '4', '12', '2012-03-16 13:47:21', 1, 0),
(616, 'DocumentVersion', 3, 'update', 'updateDateTime', '2012-03-16 14:47:21', '2012-03-16 14:47:46', '2012-03-16 13:47:47', 1, 0),
(617, 'DocumentVersion', 3, 'update', 'description', NULL, 'Initial version', '2012-03-16 13:47:47', 1, 0),
(618, 'DocumentVersion', 4, 'insert', NULL, NULL, NULL, '2012-03-16 13:48:06', 1, 0),
(619, 'Document', 1, 'update', 'idDocumentVersion', '3', '4', '2012-03-16 13:48:06', 1, 0),
(620, 'Document', 1, 'update', 'idStatus', '12', '1', '2012-03-16 13:48:06', 1, 0),
(621, 'Document', 1, 'update', 'revision', '0', '1', '2012-03-16 13:48:06', 1, 0),
(622, 'Document', 1, 'update', 'draft', NULL, '1', '2012-03-16 13:48:06', 1, 0),
(623, 'DocumentVersion', 4, 'update', 'updateDateTime', NULL, '2012-03-16 14:48:47', '2012-03-16 13:48:47', 1, 0),
(624, 'DocumentVersion', 4, 'update', 'idStatus', '1', '3', '2012-03-16 13:48:47', 1, 0),
(625, 'DocumentVersion', 4, 'update', 'description', NULL, 'Add a clustered architecture for the web server', '2012-03-16 13:48:47', 1, 0),
(626, 'Document', 1, 'update', 'idStatus', '1', '3', '2012-03-16 13:48:47', 1, 0),
(627, 'Document', 1, 'update', 'locked', '0', '1', '2012-03-16 14:07:11', 1, 0),
(628, 'Document', 1, 'update', 'idLocker', NULL, '1', '2012-03-16 14:07:11', 1, 0),
(629, 'Document', 1, 'update', 'lockedDate', NULL, '2012-03-16 15:07:00', '2012-03-16 14:07:11', 1, 0),
(630, 'Habilitation', 669, 'delete', NULL, NULL, NULL, '2012-05-03 11:57:07', NULL, 0),
(631, 'Approver', 1, 'insert', NULL, NULL, NULL, '2012-05-03 16:34:04', 1, 0),
(632, 'Approver', 2, 'insert', NULL, NULL, NULL, '2012-05-03 16:34:05', 1, 0),
(633, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-03-16 14:48:47', '2012-05-03 18:34:05', '2012-05-03 16:34:05', 1, 0),
(634, 'Approver', 3, 'insert', NULL, NULL, NULL, '2012-05-03 16:34:05', 1, 0),
(635, 'Approver', 4, 'insert', NULL, NULL, NULL, '2012-05-03 16:34:05', 1, 0),
(636, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:34:05', '2012-05-03 18:34:06', '2012-05-03 16:34:06', 1, 0),
(637, 'Approver', 5, 'insert', NULL, NULL, NULL, '2012-05-03 16:34:06', 1, 0),
(638, 'Approver', 6, 'insert', NULL, NULL, NULL, '2012-05-03 16:34:06', 1, 0),
(639, 'Approver', 5, 'delete', NULL, NULL, NULL, '2012-05-03 16:41:33', 1, 0),
(640, 'Approver', 6, 'delete', NULL, NULL, NULL, '2012-05-03 16:41:33', 1, 0),
(641, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:34:06', '2012-05-03 18:41:33', '2012-05-03 16:41:33', 1, 0),
(642, 'Approver', 3, 'delete', NULL, NULL, NULL, '2012-05-03 16:41:45', 1, 0),
(643, 'Approver', 4, 'delete', NULL, NULL, NULL, '2012-05-03 16:41:45', 1, 0),
(644, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:41:33', '2012-05-03 18:41:45', '2012-05-03 16:41:45', 1, 0),
(645, 'Approver', 2, 'update', 'approved', '0', '1', '2012-05-03 16:42:00', 1, 0),
(646, 'Approver', 2, 'update', 'approvedDate', NULL, '2012-05-03 18:42', '2012-05-03 16:42:00', 1, 0),
(647, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:41:45', '2012-05-03 18:42:01', '2012-05-03 16:42:01', 1, 0),
(648, 'DocumentVersion', 4, 'update', 'approved', '0', '1', '2012-05-03 16:42:01', 1, 0),
(649, 'Document', 1, 'update', 'locked', '1', '0', '2012-05-03 16:45:11', 1, 0),
(650, 'Document', 1, 'update', 'idLocker', '1', NULL, '2012-05-03 16:45:11', 1, 0),
(651, 'Document', 1, 'update', 'lockedDate', '2012-03-16 15:07:00', NULL, '2012-05-03 16:45:11', 1, 0),
(652, 'DocumentVersion', 4, 'update', 'name', 'V1.1_draft1', 'V1.1', '2012-05-03 16:45:21', 1, 0),
(653, 'DocumentVersion', 4, 'update', 'fullName', 'ARD - Architecture Dossier_V1.1_draft1', 'ARD - Architecture Dossier_V1.1', '2012-05-03 16:45:21', 1, 0),
(654, 'DocumentVersion', 4, 'update', 'draft', '1', NULL, '2012-05-03 16:45:22', 1, 0),
(655, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:42:01', '2012-05-03 18:45:21', '2012-05-03 16:45:22', 1, 0),
(656, 'DocumentVersion', 4, 'update', 'idStatus', '3', NULL, '2012-05-03 16:45:22', 1, 0),
(657, 'DocumentVersion', 4, 'update', 'isRef', '0', '1', '2012-05-03 16:45:22', 1, 0),
(658, 'DocumentVersion', 3, 'update', 'updateDateTime', '2012-03-16 14:47:46', '2012-05-03 18:45:22', '2012-05-03 16:45:22', 1, 0),
(659, 'DocumentVersion', 3, 'update', 'isRef', '1', '0', '2012-05-03 16:45:22', 1, 0),
(660, 'Document', 1, 'update', 'idDocumentVersionRef', '3', '4', '2012-05-03 16:45:22', 1, 0),
(661, 'Document', 1, 'update', 'idStatus', '3', NULL, '2012-05-03 16:45:22', 1, 0),
(662, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:45:21', '2012-05-03 18:45:37', '2012-05-03 16:45:37', 1, 0),
(663, 'DocumentVersion', 4, 'update', 'idStatus', NULL, '1', '2012-05-03 16:45:38', 1, 0),
(664, 'Document', 1, 'update', 'idStatus', NULL, '1', '2012-05-03 16:45:38', 1, 0),
(665, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:45:37', '2012-05-03 18:46:01', '2012-05-03 16:46:01', 1, 0),
(666, 'DocumentVersion', 4, 'update', 'idStatus', '1', '3', '2012-05-03 16:46:01', 1, 0),
(667, 'Document', 1, 'update', 'idStatus', '1', '3', '2012-05-03 16:46:01', 1, 0),
(668, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:46:01', '2012-05-03 18:46:15', '2012-05-03 16:46:16', 1, 0),
(669, 'DocumentVersion', 4, 'update', 'idStatus', '3', '4', '2012-05-03 16:46:16', 1, 0),
(670, 'Document', 1, 'update', 'idStatus', '3', '4', '2012-05-03 16:46:16', 1, 0),
(671, 'DocumentVersion', 4, 'update', 'updateDateTime', '2012-05-03 18:46:15', '2012-05-03 18:46:30', '2012-05-03 16:46:30', 1, 0),
(672, 'DocumentVersion', 4, 'update', 'idStatus', '4', '12', '2012-05-03 16:46:31', 1, 0),
(673, 'Document', 1, 'update', 'idStatus', '4', '12', '2012-05-03 16:46:31', 1, 0),
(674, 'Calendar', 4, 'insert', NULL, NULL, NULL, '2012-05-05 19:10:59', 1, 0),
(675, 'Calendar', 4, 'delete', NULL, NULL, NULL, '2012-05-05 19:11:03', 1, 0),
(676, 'Calendar', 5, 'insert', NULL, NULL, NULL, '2012-05-05 19:12:30', 1, 0),
(677, 'Calendar', 6, 'insert', NULL, NULL, NULL, '2012-05-05 19:12:44', 1, 0),
(678, 'Calendar', 7, 'insert', NULL, NULL, NULL, '2012-05-05 19:13:00', 1, 0),
(679, 'Calendar', 8, 'insert', NULL, NULL, NULL, '2012-05-05 19:13:04', 1, 0),
(680, 'Calendar', 9, 'insert', NULL, NULL, NULL, '2012-05-05 19:13:14', 1, 0),
(681, 'Calendar', 10, 'insert', NULL, NULL, NULL, '2012-05-05 19:13:39', 1, 0),
(682, 'Calendar', 11, 'insert', NULL, NULL, NULL, '2012-05-05 19:14:40', 1, 0),
(683, 'Calendar', 12, 'insert', NULL, NULL, NULL, '2012-05-05 19:16:15', 1, 0),
(684, 'Calendar', 12, 'delete', NULL, NULL, NULL, '2012-05-05 19:16:28', 1, 0),
(685, 'Calendar', 13, 'insert', NULL, NULL, NULL, '2012-05-05 19:16:47', 1, 0),
(686, 'Calendar', 14, 'insert', NULL, NULL, NULL, '2012-05-05 19:17:14', 1, 0),
(687, 'Ticket', 1, 'update', 'idProject', '1', '2', '2012-05-05 20:44:48', 1, 0),
(688, 'WorkElement', 1, 'insert', NULL, NULL, NULL, '2012-05-05 20:44:49', 1, 0),
(689, 'Link', 6, 'insert', NULL, NULL, NULL, '2012-05-05 20:46:00', 1, 0),
(690, 'Link', 7, 'insert', NULL, NULL, NULL, '2012-05-05 20:46:27', 1, 0),
(691, 'Link', 8, 'insert', NULL, NULL, NULL, '2012-05-05 20:53:27', 1, 0),
(692, 'Link', 9, 'insert', NULL, NULL, NULL, '2012-05-05 20:54:42', 1, 0),
(693, 'User', 1, 'update', 'isResource', '0', '1', '2012-05-06 14:07:45', 1, 0),
(694, 'User', 1, 'update', 'resourceName', NULL, 'admin', '2012-05-06 14:07:46', 1, 0),
(695, 'Affectation', 19, 'update', 'idResourceSelect', NULL, '1', '2012-05-06 14:07:46', 1, 0),
(696, 'Affectation', 20, 'update', 'idResourceSelect', NULL, '1', '2012-05-06 14:07:46', 1, 0),
(697, 'WorkElement', 1, 'update', 'plannedWork', NULL, '0', '2012-05-06 14:11:24', 1, 0),
(698, 'WorkElement', 1, 'update', 'realWork', NULL, '0', '2012-05-06 14:11:24', 1, 0),
(699, 'WorkElement', 1, 'update', 'leftWork', NULL, '0', '2012-05-06 14:11:24', 1, 0),
(700, 'WorkElement', 1, 'update', 'ongoing', '0', '1', '2012-05-06 14:11:24', 1, 0),
(701, 'WorkElement', 1, 'update', 'ongoingStartDateTime', NULL, '2012-05-06 16:11', '2012-05-06 14:11:24', 1, 0),
(702, 'Contact', 5, 'update', 'email', NULL, 'project.leader@external.com', '2012-05-06 14:18:57', 1, 0),
(703, 'Affectation', 15, 'update', 'idResource', NULL, '5', '2012-05-06 14:18:57', 1, 0),
(704, 'Contact', 5, 'update', 'initials', NULL, 'EPL', '2012-05-06 14:19:03', 1, 0),
(705, 'Affectation', 15, 'update', 'idResource', NULL, '5', '2012-05-06 14:19:03', 1, 0),
(706, 'User', 1, 'update', 'email', NULL, 'admin@toolware.fr', '2012-05-06 14:19:32', 1, 0),
(707, 'Meeting', 1, 'update', 'attendees', NULL, '"admin" <admin@toolware.fr>, "project manager" <project.manager@toolware.fr>, "external project leader one" <project.leader@external.com>', '2012-05-06 14:19:58', 1, 0),
(708, 'Meeting', 1, 'update', 'attendees', '"admin" <admin@toolware.fr>, "project manager" <project.manager@toolware.fr>, "external project leader one" <project.leader@external.com>', NULL, '2012-05-06 14:20:47', 1, 0),
(709, 'Meeting', 1, 'update', 'attendees', NULL, '"admin" <admin@toolware.fr>, "project manager" <project.manager@toolware.fr>, "external project leader one" <project.leader@external.com>', '2012-05-06 14:20:51', 1, 0),
(710, 'Meeting', 1, 'update', 'attendees', '"admin" <admin@toolware.fr>, "project manager" <project.manager@toolware.fr>, "external project leader one" <project.leader@external.com>', '"admin" <support@toolware.fr>, "project manager" <project.manager@toolware.fr>, "external project leader one" <project.leader@external.com>', '2012-05-06 14:22:40', 1, 0),
(711, 'Meeting', 1, 'update', 'meetingStartTime', NULL, '16:00:00', '2012-05-06 14:33:06', 1, 0),
(712, 'Meeting', 1, 'update', 'meetingEndTime', NULL, '18:00:00', '2012-05-06 14:33:06', 1, 0),
(713, 'PlanningElement', 1, 'update', 'plannedEndDate', '2012-05-22', '2012-08-03', '2012-05-29 20:04:48', 1, 0),
(714, 'PlanningElement', 1, 'update', 'plannedDuration', '57', '107', '2012-05-29 20:04:48', 1, 0),
(715, 'PlanningElement', 2, 'update', 'plannedEndDate', '2012-05-22', '2012-08-03', '2012-05-29 20:04:48', 1, 0),
(716, 'PlanningElement', 2, 'update', 'plannedDuration', '57', '107', '2012-05-29 20:04:48', 1, 0),
(717, 'PlanningElement', 7, 'update', 'plannedEndDate', '2012-05-22', '2012-08-03', '2012-05-29 20:04:48', 1, 0),
(718, 'PlanningElement', 7, 'update', 'plannedDuration', '57', '107', '2012-05-29 20:04:48', 1, 0),
(719, 'PlanningElement', 3, 'update', 'plannedEndDate', '2012-03-30', '2012-06-12', '2012-05-29 20:04:49', 1, 0),
(720, 'PlanningElement', 3, 'update', 'plannedDuration', '13', '62', '2012-05-29 20:04:49', 1, 0),
(721, 'PlanningElement', 8, 'update', 'plannedEndDate', '2012-03-26', '2012-06-07', '2012-05-29 20:04:49', 1, 0),
(722, 'PlanningElement', 8, 'update', 'plannedDuration', '9', '58', '2012-05-29 20:04:49', 1, 0),
(723, 'PlanningElement', 10, 'update', 'plannedStartDate', '2012-03-14', '2012-05-29', '2012-05-29 20:04:49', 1, 0),
(724, 'PlanningElement', 10, 'update', 'plannedEndDate', '2012-03-20', '2012-06-01', '2012-05-29 20:04:49', 1, 0),
(725, 'PlanningElement', 10, 'update', 'plannedDuration', '5', '4', '2012-05-29 20:04:49', 1, 0),
(726, 'PlanningElement', 11, 'update', 'plannedStartDate', '2012-03-21', '2012-06-04', '2012-05-29 20:04:49', 1, 0),
(727, 'PlanningElement', 11, 'update', 'plannedEndDate', '2012-03-23', '2012-06-06', '2012-05-29 20:04:49', 1, 0),
(728, 'PlanningElement', 12, 'update', 'plannedStartDate', '2012-03-26', '2012-06-07', '2012-05-29 20:04:49', 1, 0),
(729, 'PlanningElement', 12, 'update', 'plannedEndDate', '2012-03-26', '2012-06-07', '2012-05-29 20:04:49', 1, 0),
(730, 'PlanningElement', 13, 'update', 'plannedStartDate', '2012-03-26', '2012-06-07', '2012-05-29 20:04:50', 1, 0),
(731, 'PlanningElement', 13, 'update', 'plannedEndDate', '2012-03-30', '2012-06-12', '2012-05-29 20:04:50', 1, 0),
(732, 'PlanningElement', 10, 'update', 'wbs', '1.2.1.2', '1.2.1.3', '2012-05-29 20:16:31', 1, 0),
(733, 'PlanningElement', 10, 'update', 'wbsSortable', '001.002.001.002', '001.002.001.003', '2012-05-29 20:16:31', 1, 0),
(734, 'PlanningElement', 11, 'update', 'wbs', '1.2.1.3', '1.2.1.2', '2012-05-29 20:16:32', 1, 0),
(735, 'PlanningElement', 11, 'update', 'wbsSortable', '001.002.001.003', '001.002.001.002', '2012-05-29 20:16:32', 1, 0),
(736, 'WorkElement', 1, 'update', 'realWork', '0.00000', '13.904166666667', '2012-05-29 21:25:54', 1, 0),
(737, 'WorkElement', 1, 'update', 'idUser', '1', NULL, '2012-05-29 21:25:54', 1, 0),
(738, 'WorkElement', 1, 'update', 'ongoing', '1', '0', '2012-05-29 21:25:54', 1, 0),
(739, 'WorkElement', 1, 'update', 'ongoingStartDateTime', '2012-05-06 16:11:00', NULL, '2012-05-29 21:25:54', 1, 0),
(740, 'Requirement', 1, 'insert', NULL, NULL, NULL, '2012-08-05 15:02:01', 1, 0),
(741, 'Requirement', 1, 'update', 'idStatus', '1', '4', '2012-08-05 15:02:42', 1, 0),
(742, 'Requirement', 1, 'update', 'idResource', NULL, '3', '2012-08-05 15:02:42', 1, 0),
(743, 'Requirement', 1, 'update', 'idCriticality', NULL, '1', '2012-08-05 15:02:42', 1, 0),
(744, 'Requirement', 1, 'update', 'idFeasibility', NULL, '1', '2012-08-05 15:02:42', 1, 0),
(745, 'Requirement', 1, 'update', 'idRiskLevel', NULL, '2', '2012-08-05 15:02:42', 1, 0),
(746, 'Requirement', 1, 'update', 'handled', '0', '1', '2012-08-05 15:02:42', 1, 0),
(747, 'Requirement', 1, 'update', 'handledDate', NULL, '2012-08-05', '2012-08-05 15:02:42', 1, 0),
(748, 'Requirement', 1, 'update', 'done', '0', '1', '2012-08-05 15:02:42', 1, 0),
(749, 'Requirement', 1, 'update', 'doneDate', NULL, '2012-08-05', '2012-08-05 15:02:42', 1, 0),
(750, 'TestCase', 1, 'insert', NULL, NULL, NULL, '2012-08-05 15:05:08', 1, 0),
(751, 'Link', 10, 'insert', NULL, NULL, NULL, '2012-08-05 15:05:11', 1, 0),
(752, 'TestCase', 2, 'insert', NULL, NULL, NULL, '2012-08-05 15:06:43', 1, 0),
(753, 'Link', 11, 'insert', NULL, NULL, NULL, '2012-08-05 15:06:45', 1, 0),
(754, 'TestSession', 1, 'insert', NULL, NULL, NULL, '2012-08-05 15:07:31', 1, 0),
(755, 'TestCaseRun', 1, 'insert', NULL, NULL, NULL, '2012-08-05 15:07:38', 1, 0),
(756, 'TestSession', 1, 'insert', 'TestCase', '#2', '#2', '2012-08-05 15:07:38', 1, 0),
(757, 'TestCaseRun', 2, 'insert', NULL, NULL, NULL, '2012-08-05 15:07:39', 1, 0),
(758, 'TestSession', 1, 'insert', 'TestCase', '#1', '#1', '2012-08-05 15:07:39', 1, 0),
(759, 'TestCaseRun', 1, 'update', 'idRunStatus', '1', '2', '2012-08-05 15:07:53', 1, 0),
(760, 'TestSession', 1, 'update', 'idRunStatus|TestCase|1', '1', '2', '2012-08-05 15:07:53', 1, 0),
(761, 'TestCaseRun', 1, 'update', 'statusDateTime', NULL, '2012-08-05 17:07:53', '2012-08-05 15:07:53', 1, 0),
(762, 'TestSession', 1, 'update', 'statusDateTime|TestCase|1', NULL, '2012-08-05 17:07:53', '2012-08-05 15:07:53', 1, 0),
(763, 'TestCaseRun', 2, 'update', 'idRunStatus', '1', '2', '2012-08-05 15:08:17', 1, 0),
(764, 'TestSession', 1, 'update', 'idRunStatus|TestCase|2', '1', '2', '2012-08-05 15:08:17', 1, 0),
(765, 'TestCaseRun', 2, 'update', 'statusDateTime', NULL, '2012-08-05 17:08:17', '2012-08-05 15:08:17', 1, 0),
(766, 'TestSession', 1, 'update', 'statusDateTime|TestCase|2', NULL, '2012-08-05 17:08:17', '2012-08-05 15:08:17', 1, 0),
(767, 'Ticket', 2, 'insert', NULL, NULL, NULL, '2012-08-05 15:09:07', 1, 0),
(768, 'WorkElement', 2, 'insert', NULL, NULL, NULL, '2012-08-05 15:09:07', 1, 0),
(769, 'TestCaseRun', 1, 'update', 'idRunStatus', '2', '3', '2012-08-05 15:09:10', 1, 0),
(770, 'TestSession', 1, 'update', 'idRunStatus|TestCase|1', '2', '3', '2012-08-05 15:09:10', 1, 0),
(771, 'TestCaseRun', 1, 'update', 'statusDateTime', '2012-08-05 17:07:53', '2012-08-05 17:09:10', '2012-08-05 15:09:10', 1, 0),
(772, 'TestSession', 1, 'update', 'statusDateTime|TestCase|1', '2012-08-05 17:07:53', '2012-08-05 17:09:10', '2012-08-05 15:09:10', 1, 0),
(773, 'TestCaseRun', 1, 'update', 'idTicket', NULL, '2', '2012-08-05 15:09:10', 1, 0),
(774, 'TestSession', 1, 'update', 'idTicket|TestCase|1', NULL, '2', '2012-08-05 15:09:10', 1, 0),
(775, 'Link', 12, 'insert', NULL, NULL, NULL, '2012-08-05 15:09:10', 1, 0),
(776, 'Link', 13, 'insert', NULL, NULL, NULL, '2012-08-05 15:09:11', 1, 0),
(777, 'Requirement', 1, 'update', 'idContact', NULL, '6', '2012-08-05 17:34:35', 1, 0),
(778, 'Requirement', 2, 'insert', NULL, NULL, NULL, '2012-08-05 17:39:14', 1, 0),
(779, 'HabilitationReport', 159, 'delete', NULL, NULL, NULL, '2014-01-04 17:26:46', NULL, 0),
(780, 'HabilitationReport', 160, 'delete', NULL, NULL, NULL, '2014-01-04 17:26:46', NULL, 0),
(781, 'HabilitationReport', 161, 'delete', NULL, NULL, NULL, '2014-01-04 17:26:46', NULL, 0),
(782, 'HabilitationReport', 162, 'delete', NULL, NULL, NULL, '2014-01-04 17:26:46', NULL, 0),
(783, 'ColumnSelector', 1, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(784, 'ColumnSelector', 2, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(785, 'ColumnSelector', 3, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(786, 'ColumnSelector', 4, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(787, 'ColumnSelector', 5, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(788, 'ColumnSelector', 6, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(789, 'ColumnSelector', 7, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(790, 'ColumnSelector', 8, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(791, 'ColumnSelector', 9, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(792, 'ColumnSelector', 10, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(793, 'ColumnSelector', 11, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(794, 'ColumnSelector', 12, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(795, 'ColumnSelector', 13, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:04', 1, 0),
(796, 'Client', 1, 'update', 'street', NULL, '20 rue de Paris', '2014-01-04 17:27:30', 1, 0),
(797, 'Client', 1, 'update', 'zip', NULL, '31000', '2014-01-04 17:27:30', 1, 0),
(798, 'Client', 1, 'update', 'city', NULL, 'TOULOUSE', '2014-01-04 17:27:30', 1, 0),
(799, 'Client', 1, 'update', 'country', NULL, 'France', '2014-01-04 17:27:30', 1, 0),
(800, 'ColumnSelector', 14, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(801, 'ColumnSelector', 15, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(802, 'ColumnSelector', 16, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(803, 'ColumnSelector', 17, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(804, 'ColumnSelector', 18, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(805, 'ColumnSelector', 19, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(806, 'ColumnSelector', 20, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(807, 'ColumnSelector', 21, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(808, 'ColumnSelector', 22, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(809, 'ColumnSelector', 23, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(810, 'ColumnSelector', 24, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(811, 'ColumnSelector', 25, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(812, 'ColumnSelector', 26, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(813, 'ColumnSelector', 27, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(814, 'ColumnSelector', 28, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(815, 'ColumnSelector', 29, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(816, 'ColumnSelector', 30, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(817, 'ColumnSelector', 31, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(818, 'ColumnSelector', 32, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(819, 'ColumnSelector', 33, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(820, 'ColumnSelector', 34, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(821, 'ColumnSelector', 35, 'insert', NULL, NULL, NULL, '2014-01-04 17:27:41', 1, 0),
(822, 'ColumnSelector', 36, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(823, 'ColumnSelector', 37, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(824, 'ColumnSelector', 38, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(825, 'ColumnSelector', 39, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(826, 'ColumnSelector', 40, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(827, 'ColumnSelector', 41, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(828, 'ColumnSelector', 42, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(829, 'ColumnSelector', 43, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(830, 'ColumnSelector', 44, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(831, 'ColumnSelector', 45, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(832, 'ColumnSelector', 46, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(833, 'ColumnSelector', 47, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(834, 'ColumnSelector', 48, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(835, 'ColumnSelector', 49, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(836, 'ColumnSelector', 50, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(837, 'ColumnSelector', 51, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(838, 'ColumnSelector', 52, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(839, 'ColumnSelector', 53, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(840, 'ColumnSelector', 54, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(841, 'ColumnSelector', 55, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(842, 'ColumnSelector', 56, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(843, 'ColumnSelector', 57, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(844, 'ColumnSelector', 58, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(845, 'ColumnSelector', 59, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(846, 'ColumnSelector', 60, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(847, 'ColumnSelector', 61, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(848, 'ColumnSelector', 62, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(849, 'ColumnSelector', 63, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(850, 'ColumnSelector', 64, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(851, 'ColumnSelector', 65, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(852, 'ColumnSelector', 66, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(853, 'ColumnSelector', 67, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(854, 'ColumnSelector', 68, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(855, 'ColumnSelector', 69, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(856, 'ColumnSelector', 70, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(857, 'ColumnSelector', 71, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(858, 'ColumnSelector', 72, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(859, 'ColumnSelector', 73, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(860, 'ColumnSelector', 74, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(861, 'ColumnSelector', 75, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(862, 'ColumnSelector', 76, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(863, 'ColumnSelector', 77, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(864, 'ColumnSelector', 78, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(865, 'ColumnSelector', 79, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(866, 'ColumnSelector', 80, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(867, 'ColumnSelector', 81, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(868, 'ColumnSelector', 82, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(869, 'ColumnSelector', 83, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(870, 'ColumnSelector', 84, 'insert', NULL, NULL, NULL, '2014-01-04 17:28:17', 1, 0),
(871, 'Project', 1, 'update', 'idHealth', NULL, '2', '2014-01-04 17:29:26', 1, 0),
(872, 'Project', 1, 'update', 'idQuality', NULL, '1', '2014-01-04 17:29:26', 1, 0),
(873, 'Project', 1, 'update', 'idTrend', NULL, '2', '2014-01-04 17:29:26', 1, 0),
(874, 'Project', 1, 'update', 'idOverallProgress', NULL, '3', '2014-01-04 17:29:26', 1, 0),
(875, 'Project', 2, 'update', 'idProjectType', NULL, '75', '2014-01-04 17:29:59', 1, 0),
(876, 'Project', 2, 'update', 'idHealth', NULL, '1', '2014-01-04 17:29:59', 1, 0),
(877, 'Project', 2, 'update', 'idQuality', NULL, '1', '2014-01-04 17:29:59', 1, 0),
(878, 'Project', 2, 'update', 'idTrend', NULL, '1', '2014-01-04 17:29:59', 1, 0),
(879, 'Project', 2, 'update', 'idOverallProgress', NULL, '2', '2014-01-04 17:29:59', 1, 0),
(880, 'ProjectPlanningElement', 2, 'update', 'validatedWork', NULL, '0', '2014-01-04 17:29:59', 1, 0),
(881, 'ProjectPlanningElement', 2, 'update', 'initialWork', NULL, '0', '2014-01-04 17:29:59', 1, 0),
(882, 'Project', 1, 'update', 'idOverallProgress', '3', '2', '2014-01-04 17:30:14', 1, 0),
(883, 'Project', 3, 'update', 'idProjectType', NULL, '75', '2014-01-04 17:30:42', 1, 0),
(884, 'Project', 3, 'update', 'idHealth', NULL, '3', '2014-01-04 17:30:42', 1, 0),
(885, 'Project', 3, 'update', 'idQuality', NULL, '3', '2014-01-04 17:30:42', 1, 0),
(886, 'Project', 3, 'update', 'idTrend', NULL, '3', '2014-01-04 17:30:42', 1, 0),
(887, 'Project', 3, 'update', 'idOverallProgress', NULL, '4', '2014-01-04 17:30:42', 1, 0),
(888, 'ProjectPlanningElement', 3, 'update', 'validatedWork', NULL, '0', '2014-01-04 17:30:42', 1, 0),
(889, 'ProjectPlanningElement', 3, 'update', 'initialWork', NULL, '0', '2014-01-04 17:30:42', 1, 0),
(890, 'Project', 4, 'update', 'idHealth', NULL, '1', '2014-01-04 17:31:04', 1, 0),
(891, 'Project', 4, 'update', 'idQuality', NULL, '1', '2014-01-04 17:31:04', 1, 0),
(892, 'Project', 4, 'update', 'idTrend', NULL, '2', '2014-01-04 17:31:04', 1, 0),
(893, 'Project', 4, 'update', 'idOverallProgress', NULL, '7', '2014-01-04 17:31:04', 1, 0),
(894, 'Project', 6, 'update', 'idProjectType', NULL, '52', '2014-01-04 17:34:38', 1, 0),
(895, 'Project', 6, 'update', 'codeType', 'OPE', 'ADM', '2014-01-04 17:34:38', 1, 0),
(896, 'ProjectPlanningElement', 6, 'update', 'validatedWork', NULL, '0', '2014-01-04 17:34:38', 1, 0),
(897, 'ProjectPlanningElement', 6, 'update', 'assignedWork', NULL, '0', '2014-01-04 17:34:38', 1, 0),
(898, 'ProjectPlanningElement', 6, 'update', 'initialWork', NULL, '0', '2014-01-04 17:34:38', 1, 0),
(899, 'Project', 5, 'update', 'idProjectType', NULL, '52', '2014-01-04 17:35:19', 1, 0),
(900, 'Project', 5, 'update', 'codeType', 'OPE', 'ADM', '2014-01-04 17:35:19', 1, 0),
(901, 'ProjectPlanningElement', 5, 'update', 'validatedWork', NULL, '0', '2014-01-04 17:35:19', 1, 0),
(902, 'ProjectPlanningElement', 5, 'update', 'initialWork', NULL, '0', '2014-01-04 17:35:19', 1, 0),
(903, 'Project', 6, 'update', 'idProjectType', '52', '53', '2014-01-04 17:35:34', 1, 0),
(904, 'Project', 6, 'update', 'codeType', 'ADM', 'TMP', '2014-01-04 17:35:34', 1, 0),
(905, 'Project', 6, 'update', 'idProjectType', '53', '52', '2014-01-04 17:36:06', 1, 0),
(906, 'Project', 6, 'update', 'codeType', 'TMP', 'ADM', '2014-01-04 17:36:06', 1, 0),
(907, 'ColumnSelector', 85, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(908, 'ColumnSelector', 86, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(909, 'ColumnSelector', 87, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(910, 'ColumnSelector', 88, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(911, 'ColumnSelector', 89, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(912, 'ColumnSelector', 90, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(913, 'ColumnSelector', 91, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(914, 'ColumnSelector', 92, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(915, 'ColumnSelector', 93, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(916, 'ColumnSelector', 94, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(917, 'ColumnSelector', 95, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(918, 'ColumnSelector', 96, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(919, 'ColumnSelector', 97, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:22', 1, 0),
(920, 'ColumnSelector', 98, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(921, 'ColumnSelector', 99, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(922, 'ColumnSelector', 100, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(923, 'ColumnSelector', 101, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(924, 'ColumnSelector', 102, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(925, 'ColumnSelector', 103, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(926, 'ColumnSelector', 104, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(927, 'ColumnSelector', 105, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(928, 'ColumnSelector', 106, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(929, 'ColumnSelector', 107, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(930, 'ColumnSelector', 108, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(931, 'ColumnSelector', 109, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(932, 'ColumnSelector', 110, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(933, 'ColumnSelector', 111, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(934, 'ColumnSelector', 112, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(935, 'ColumnSelector', 113, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(936, 'ColumnSelector', 114, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(937, 'ColumnSelector', 115, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(938, 'ColumnSelector', 116, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(939, 'ColumnSelector', 117, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(940, 'ColumnSelector', 118, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(941, 'ColumnSelector', 119, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(942, 'ColumnSelector', 120, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(943, 'ColumnSelector', 121, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(944, 'ColumnSelector', 122, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(945, 'ColumnSelector', 123, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(946, 'ColumnSelector', 124, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(947, 'ColumnSelector', 125, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(948, 'ColumnSelector', 126, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(949, 'ColumnSelector', 127, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(950, 'ColumnSelector', 128, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(951, 'ColumnSelector', 129, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(952, 'ColumnSelector', 130, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(953, 'ColumnSelector', 131, 'insert', NULL, NULL, NULL, '2014-01-04 17:54:27', 1, 0),
(954, 'Habilitation', 761, 'update', 'allowAccess', '0', '1', '2014-01-04 18:07:43', 1, 0),
(955, 'ColumnSelector', 132, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(956, 'ColumnSelector', 133, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(957, 'ColumnSelector', 134, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(958, 'ColumnSelector', 135, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(959, 'ColumnSelector', 136, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(960, 'ColumnSelector', 137, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(961, 'ColumnSelector', 138, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(962, 'ColumnSelector', 139, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(963, 'ColumnSelector', 140, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(964, 'ColumnSelector', 141, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(965, 'ColumnSelector', 142, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(966, 'ColumnSelector', 143, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(967, 'ColumnSelector', 144, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(968, 'ColumnSelector', 145, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(969, 'ColumnSelector', 146, 'insert', NULL, NULL, NULL, '2014-01-04 18:07:54', 1, 0),
(970, 'Ticket', 1, 'update', 'idStatus', '3', '4', '2014-01-04 18:08:22', 1, 0),
(971, 'Ticket', 1, 'update', 'idStatus', '4', '8', '2014-01-04 18:17:54', 1, 0),
(972, 'Ticket', 1, 'update', 'idStatus', '8', '9', '2014-01-04 18:38:58', 1, 0),
(973, 'Ticket', 1, 'update', 'idle', '0', '1', '2014-01-04 18:38:58', 1, 0),
(974, 'Ticket', 1, 'update', 'idleDateTime', NULL, '2014-01-04 19:18:00', '2014-01-04 18:38:58', 1, 0),
(975, 'Ticket', 1, 'update', 'cancelled', '0', '1', '2014-01-04 18:38:58', 1, 0),
(976, 'ColumnSelector', 147, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(977, 'ColumnSelector', 148, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(978, 'ColumnSelector', 149, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(979, 'ColumnSelector', 150, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(980, 'ColumnSelector', 151, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(981, 'ColumnSelector', 152, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(982, 'ColumnSelector', 153, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(983, 'ColumnSelector', 154, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(984, 'ColumnSelector', 155, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(985, 'ColumnSelector', 156, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(986, 'ColumnSelector', 157, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(987, 'ColumnSelector', 158, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(988, 'ColumnSelector', 159, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(989, 'ColumnSelector', 160, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(990, 'ColumnSelector', 161, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(991, 'ColumnSelector', 162, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(992, 'ColumnSelector', 163, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(993, 'ColumnSelector', 164, 'insert', NULL, NULL, NULL, '2014-01-04 18:45:32', 1, 0),
(994, 'ColumnSelector', 165, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(995, 'ColumnSelector', 166, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(996, 'ColumnSelector', 167, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(997, 'ColumnSelector', 168, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(998, 'ColumnSelector', 169, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(999, 'ColumnSelector', 170, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1000, 'ColumnSelector', 171, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1001, 'ColumnSelector', 172, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1002, 'ColumnSelector', 173, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1003, 'ColumnSelector', 174, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1004, 'ColumnSelector', 175, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1005, 'ColumnSelector', 176, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1006, 'ColumnSelector', 177, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1007, 'ColumnSelector', 178, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1008, 'ColumnSelector', 179, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1009, 'ColumnSelector', 180, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1010, 'ColumnSelector', 181, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1011, 'ColumnSelector', 182, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1012, 'ColumnSelector', 183, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1013, 'ColumnSelector', 184, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1014, 'ColumnSelector', 185, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:15', 1, 0),
(1015, 'ColumnSelector', 186, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1016, 'ColumnSelector', 187, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1017, 'ColumnSelector', 188, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1018, 'ColumnSelector', 189, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1019, 'ColumnSelector', 190, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1020, 'ColumnSelector', 191, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1021, 'ColumnSelector', 192, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1022, 'ColumnSelector', 193, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1023, 'ColumnSelector', 194, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1024, 'ColumnSelector', 195, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1025, 'ColumnSelector', 196, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1026, 'ColumnSelector', 197, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1027, 'ColumnSelector', 198, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1028, 'ColumnSelector', 199, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1029, 'ColumnSelector', 200, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1030, 'ColumnSelector', 201, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1031, 'ColumnSelector', 202, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1032, 'ColumnSelector', 203, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1033, 'ColumnSelector', 204, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1034, 'ColumnSelector', 205, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1035, 'ColumnSelector', 206, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1036, 'ColumnSelector', 207, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1037, 'ColumnSelector', 208, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1038, 'ColumnSelector', 209, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1039, 'ColumnSelector', 210, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1040, 'ColumnSelector', 211, 'insert', NULL, NULL, NULL, '2014-01-04 19:33:16', 1, 0),
(1041, 'ColumnSelector', 212, 'insert', NULL, NULL, NULL, '2014-01-04 19:43:18', 1, 0),
(1042, 'ColumnSelector', 213, 'insert', NULL, NULL, NULL, '2014-01-04 19:43:18', 1, 0),
(1043, 'ColumnSelector', 214, 'insert', NULL, NULL, NULL, '2014-01-04 19:43:18', 1, 0),
(1044, 'ColumnSelector', 215, 'insert', NULL, NULL, NULL, '2014-01-04 19:43:18', 1, 0),
(1045, 'ColumnSelector', 216, 'insert', NULL, NULL, NULL, '2014-01-04 19:43:18', 1, 0),
(1046, 'ColumnSelector', 217, 'insert', NULL, NULL, NULL, '2014-01-04 19:43:18', 1, 0),
(1047, 'ActivityPlanningElement', 7, 'update', 'validatedEndDate', '2011-12-31', '2014-12-31', '2014-01-04 19:48:13', 1, 0),
(1048, 'ActivityPlanningElement', 7, 'update', 'validatedDuration', '88', '864', '2014-01-04 19:48:13', 1, 0),
(1049, 'ActivityPlanningElement', 7, 'update', 'validatedWork', '0.00000', '100', '2014-01-04 19:48:44', 1, 0),
(1050, 'ActivityPlanningElement', 7, 'update', 'expectedProgress', '0', '9', '2014-01-04 19:48:44', 1, 0),
(1051, 'ColumnSelector', 218, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1052, 'ColumnSelector', 219, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1053, 'ColumnSelector', 220, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1054, 'ColumnSelector', 221, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1055, 'ColumnSelector', 222, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1056, 'ColumnSelector', 223, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1057, 'ColumnSelector', 224, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1058, 'ColumnSelector', 225, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1059, 'ColumnSelector', 226, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1060, 'ColumnSelector', 227, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1061, 'ColumnSelector', 228, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1062, 'ColumnSelector', 229, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1063, 'ColumnSelector', 230, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1064, 'ColumnSelector', 231, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1065, 'ColumnSelector', 232, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1066, 'ColumnSelector', 233, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1067, 'ColumnSelector', 234, 'insert', NULL, NULL, NULL, '2014-01-04 23:17:18', 1, 0),
(1068, 'Affectation', 18, 'delete', NULL, NULL, NULL, '2014-01-04 23:20:06', 1, 0),
(1069, 'Resource', 3, 'update', 'userName', 'manager1', 'manager', '2014-01-04 23:22:34', 1, 0),
(1070, 'ColumnSelector', 235, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1071, 'ColumnSelector', 236, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1072, 'ColumnSelector', 237, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1073, 'ColumnSelector', 238, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1074, 'ColumnSelector', 239, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1075, 'ColumnSelector', 240, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1076, 'ColumnSelector', 241, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1077, 'ColumnSelector', 242, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1078, 'ColumnSelector', 243, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1079, 'ColumnSelector', 244, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0);
INSERT INTO `history` (`id`, `refType`, `refId`, `operation`, `colName`, `oldValue`, `newValue`, `operationDate`, `idUser`, `isWorkHistory`) VALUES
(1080, 'ColumnSelector', 245, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1081, 'ColumnSelector', 246, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1082, 'ColumnSelector', 247, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1083, 'ColumnSelector', 248, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1084, 'ColumnSelector', 249, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1085, 'ColumnSelector', 250, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1086, 'ColumnSelector', 251, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1087, 'ColumnSelector', 252, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1088, 'ColumnSelector', 253, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1089, 'ColumnSelector', 254, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1090, 'ColumnSelector', 255, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1091, 'ColumnSelector', 256, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1092, 'ColumnSelector', 257, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1093, 'ColumnSelector', 258, 'insert', NULL, NULL, NULL, '2014-01-05 10:29:08', 1, 0),
(1094, 'ColumnSelector', 259, 'insert', NULL, NULL, NULL, '2014-01-05 10:44:36', 1, 0),
(1095, 'ColumnSelector', 260, 'insert', NULL, NULL, NULL, '2014-01-05 10:44:36', 1, 0),
(1096, 'ColumnSelector', 261, 'insert', NULL, NULL, NULL, '2014-01-05 10:44:36', 1, 0),
(1097, 'CalendarDefinition', 2, 'insert', NULL, NULL, NULL, '2014-01-05 13:10:43', 1, 0),
(1098, 'CalendarDefinition', 3, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:04', 1, 0),
(1099, 'Calendar', 15, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:10', 1, 0),
(1100, 'Calendar', 15, 'delete', NULL, NULL, NULL, '2014-01-05 13:18:14', 1, 0),
(1101, 'CalendarDefinition', 3, 'delete', NULL, NULL, NULL, '2014-01-05 13:18:14', 1, 0),
(1102, 'Calendar', 16, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:20', 1, 0),
(1103, 'Calendar', 17, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:22', 1, 0),
(1104, 'Calendar', 18, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:29', 1, 0),
(1105, 'Calendar', 19, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:30', 1, 0),
(1106, 'Calendar', 20, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:32', 1, 0),
(1107, 'Calendar', 21, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:33', 1, 0),
(1108, 'Calendar', 21, 'delete', NULL, NULL, NULL, '2014-01-05 13:18:35', 1, 0),
(1109, 'Calendar', 22, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:36', 1, 0),
(1110, 'Calendar', 23, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:39', 1, 0),
(1111, 'Calendar', 24, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:40', 1, 0),
(1112, 'Calendar', 25, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:42', 1, 0),
(1113, 'Calendar', 26, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:44', 1, 0),
(1114, 'Calendar', 27, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:45', 1, 0),
(1115, 'Calendar', 28, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:46', 1, 0),
(1116, 'Calendar', 29, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:48', 1, 0),
(1117, 'Calendar', 28, 'delete', NULL, NULL, NULL, '2014-01-05 13:18:49', 1, 0),
(1118, 'Calendar', 30, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:51', 1, 0),
(1119, 'Calendar', 31, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:55', 1, 0),
(1120, 'Calendar', 32, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:56', 1, 0),
(1121, 'Calendar', 33, 'insert', NULL, NULL, NULL, '2014-01-05 13:18:59', 1, 0),
(1122, 'Calendar', 34, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:01', 1, 0),
(1123, 'Calendar', 35, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:04', 1, 0),
(1124, 'Calendar', 36, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:11', 1, 0),
(1125, 'Calendar', 37, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:12', 1, 0),
(1126, 'Calendar', 38, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:14', 1, 0),
(1127, 'Calendar', 39, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:17', 1, 0),
(1128, 'Calendar', 40, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:19', 1, 0),
(1129, 'Calendar', 41, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:20', 1, 0),
(1130, 'Calendar', 42, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:22', 1, 0),
(1131, 'Calendar', 43, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:24', 1, 0),
(1132, 'Calendar', 44, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:26', 1, 0),
(1133, 'Calendar', 45, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:27', 1, 0),
(1134, 'Calendar', 46, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:28', 1, 0),
(1135, 'Calendar', 47, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:29', 1, 0),
(1136, 'Calendar', 48, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:30', 1, 0),
(1137, 'Calendar', 49, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:35', 1, 0),
(1138, 'Calendar', 50, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:36', 1, 0),
(1139, 'Calendar', 51, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:38', 1, 0),
(1140, 'Calendar', 52, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:39', 1, 0),
(1141, 'Calendar', 53, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:41', 1, 0),
(1142, 'Calendar', 54, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:43', 1, 0),
(1143, 'Calendar', 55, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:44', 1, 0),
(1144, 'Calendar', 56, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:45', 1, 0),
(1145, 'Calendar', 57, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:47', 1, 0),
(1146, 'Calendar', 58, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:48', 1, 0),
(1147, 'Calendar', 59, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:50', 1, 0),
(1148, 'Calendar', 60, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:51', 1, 0),
(1149, 'Calendar', 61, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:52', 1, 0),
(1150, 'Calendar', 62, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:54', 1, 0),
(1151, 'Calendar', 63, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:56', 1, 0),
(1152, 'Calendar', 64, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:57', 1, 0),
(1153, 'Calendar', 65, 'insert', NULL, NULL, NULL, '2014-01-05 13:19:58', 1, 0),
(1154, 'Calendar', 66, 'insert', NULL, NULL, NULL, '2014-01-05 13:20:00', 1, 0),
(1155, 'Calendar', 67, 'insert', NULL, NULL, NULL, '2014-01-05 13:20:01', 1, 0),
(1156, 'Calendar', 68, 'insert', NULL, NULL, NULL, '2014-01-05 13:20:02', 1, 0),
(1157, 'Calendar', 69, 'insert', NULL, NULL, NULL, '2014-01-05 13:20:03', 1, 0),
(1158, 'Calendar', 70, 'insert', NULL, NULL, NULL, '2014-01-05 13:20:05', 1, 0),
(1159, 'Calendar', 71, 'insert', NULL, NULL, NULL, '2014-01-05 13:26:34', 1, 0),
(1160, 'ColumnSelector', 262, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1161, 'ColumnSelector', 263, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1162, 'ColumnSelector', 264, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1163, 'ColumnSelector', 265, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1164, 'ColumnSelector', 266, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1165, 'ColumnSelector', 267, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1166, 'ColumnSelector', 268, 'insert', NULL, NULL, NULL, '2014-01-05 13:35:40', 1, 0),
(1167, 'ColumnSelector', 269, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1168, 'ColumnSelector', 270, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1169, 'ColumnSelector', 271, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1170, 'ColumnSelector', 272, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1171, 'ColumnSelector', 273, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1172, 'ColumnSelector', 274, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1173, 'ColumnSelector', 275, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1174, 'ColumnSelector', 276, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1175, 'ColumnSelector', 277, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1176, 'ColumnSelector', 278, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1177, 'ColumnSelector', 279, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1178, 'ColumnSelector', 280, 'insert', NULL, NULL, NULL, '2014-01-05 13:36:19', 1, 0),
(1179, 'ColumnSelector', 281, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1180, 'ColumnSelector', 282, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1181, 'ColumnSelector', 283, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1182, 'ColumnSelector', 284, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1183, 'ColumnSelector', 285, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1184, 'ColumnSelector', 286, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1185, 'ColumnSelector', 287, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1186, 'ColumnSelector', 288, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1187, 'ColumnSelector', 289, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1188, 'ColumnSelector', 290, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1189, 'ColumnSelector', 291, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1190, 'ColumnSelector', 292, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1191, 'ColumnSelector', 293, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1192, 'ColumnSelector', 294, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1193, 'ColumnSelector', 295, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1194, 'ColumnSelector', 296, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1195, 'ColumnSelector', 297, 'insert', NULL, NULL, NULL, '2014-01-05 13:39:27', 1, 0),
(1196, 'ColumnSelector', 298, 'insert', NULL, NULL, NULL, '2014-01-05 13:41:43', 1, 0),
(1197, 'ColumnSelector', 299, 'insert', NULL, NULL, NULL, '2014-01-05 13:41:43', 1, 0),
(1198, 'ColumnSelector', 300, 'insert', NULL, NULL, NULL, '2014-01-05 13:41:43', 1, 0),
(1199, 'ColumnSelector', 301, 'insert', NULL, NULL, NULL, '2014-01-05 13:42:59', 1, 0),
(1200, 'ColumnSelector', 302, 'insert', NULL, NULL, NULL, '2014-01-05 13:42:59', 1, 0),
(1201, 'ColumnSelector', 303, 'insert', NULL, NULL, NULL, '2014-01-05 13:42:59', 1, 0),
(1202, 'ColumnSelector', 304, 'insert', NULL, NULL, NULL, '2014-01-05 13:42:59', 1, 0),
(1203, 'ColumnSelector', 305, 'insert', NULL, NULL, NULL, '2014-01-05 13:43:00', 1, 0),
(1204, 'ColumnSelector', 306, 'insert', NULL, NULL, NULL, '2014-01-05 13:43:00', 1, 0),
(1205, 'ColumnSelector', 307, 'insert', NULL, NULL, NULL, '2014-01-05 13:43:00', 1, 0),
(1206, 'ColumnSelector', 308, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1207, 'ColumnSelector', 309, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1208, 'ColumnSelector', 310, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1209, 'ColumnSelector', 311, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1210, 'ColumnSelector', 312, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1211, 'ColumnSelector', 313, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1212, 'ColumnSelector', 314, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1213, 'ColumnSelector', 315, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1214, 'ColumnSelector', 316, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1215, 'ColumnSelector', 317, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1216, 'ColumnSelector', 318, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1217, 'ColumnSelector', 319, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1218, 'ColumnSelector', 320, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1219, 'ColumnSelector', 321, 'insert', NULL, NULL, NULL, '2014-01-05 13:46:43', 1, 0),
(1220, 'VersionProject', 1, 'delete', NULL, NULL, NULL, '2014-01-05 13:48:02', 1, 0),
(1221, 'ColumnSelector', 322, 'insert', NULL, NULL, NULL, '2014-01-05 13:49:23', 1, 0),
(1222, 'ColumnSelector', 323, 'insert', NULL, NULL, NULL, '2014-01-05 13:49:23', 1, 0),
(1223, 'ColumnSelector', 324, 'insert', NULL, NULL, NULL, '2014-01-05 13:49:23', 1, 0),
(1224, 'ColumnSelector', 325, 'insert', NULL, NULL, NULL, '2014-01-05 13:49:23', 1, 0),
(1225, 'ColumnSelector', 326, 'insert', NULL, NULL, NULL, '2014-01-05 13:49:23', 1, 0),
(1226, 'ColumnSelector', 327, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:08', 1, 0),
(1227, 'ColumnSelector', 328, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:08', 1, 0),
(1228, 'ColumnSelector', 329, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:08', 1, 0),
(1229, 'ColumnSelector', 330, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:08', 1, 0),
(1230, 'ColumnSelector', 331, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:08', 1, 0),
(1231, 'ColumnSelector', 332, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:08', 1, 0),
(1232, 'ColumnSelector', 333, 'insert', NULL, NULL, NULL, '2014-01-05 13:52:09', 1, 0),
(1233, 'ColumnSelector', 334, 'insert', NULL, NULL, NULL, '2014-01-05 13:53:45', 1, 0),
(1234, 'ColumnSelector', 335, 'insert', NULL, NULL, NULL, '2014-01-05 13:53:45', 1, 0),
(1235, 'ColumnSelector', 336, 'insert', NULL, NULL, NULL, '2014-01-05 13:53:45', 1, 0),
(1236, 'ColumnSelector', 337, 'insert', NULL, NULL, NULL, '2014-01-05 13:53:45', 1, 0),
(1237, 'ColumnSelector', 338, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1238, 'ColumnSelector', 339, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1239, 'ColumnSelector', 340, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1240, 'ColumnSelector', 341, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1241, 'ColumnSelector', 342, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1242, 'ColumnSelector', 343, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1243, 'ColumnSelector', 344, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1244, 'ColumnSelector', 345, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1245, 'ColumnSelector', 346, 'insert', NULL, NULL, NULL, '2014-01-05 14:01:45', 1, 0),
(1246, 'ColumnSelector', 347, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:19', 1, 0),
(1247, 'ColumnSelector', 348, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:19', 1, 0),
(1248, 'ColumnSelector', 349, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:19', 1, 0),
(1249, 'ColumnSelector', 350, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:19', 1, 0),
(1250, 'ColumnSelector', 351, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:19', 1, 0),
(1251, 'ColumnSelector', 352, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:19', 1, 0),
(1252, 'ColumnSelector', 353, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:56', 1, 0),
(1253, 'ColumnSelector', 354, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:56', 1, 0),
(1254, 'ColumnSelector', 355, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:56', 1, 0),
(1255, 'ColumnSelector', 356, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:56', 1, 0),
(1256, 'ColumnSelector', 357, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:56', 1, 0),
(1257, 'ColumnSelector', 358, 'insert', NULL, NULL, NULL, '2014-01-05 14:02:56', 1, 0),
(1258, 'ColumnSelector', 359, 'insert', NULL, NULL, NULL, '2014-01-05 14:37:13', 1, 0),
(1259, 'ColumnSelector', 360, 'insert', NULL, NULL, NULL, '2014-01-05 14:37:13', 1, 0),
(1260, 'ColumnSelector', 361, 'insert', NULL, NULL, NULL, '2014-01-05 14:37:13', 1, 0),
(1261, 'ColumnSelector', 362, 'insert', NULL, NULL, NULL, '2014-01-05 14:37:13', 1, 0),
(1262, 'ColumnSelector', 363, 'insert', NULL, NULL, NULL, '2014-01-05 14:38:18', 1, 0),
(1263, 'ColumnSelector', 364, 'insert', NULL, NULL, NULL, '2014-01-05 14:38:18', 1, 0),
(1264, 'ColumnSelector', 365, 'insert', NULL, NULL, NULL, '2014-01-05 14:38:18', 1, 0),
(1265, 'ColumnSelector', 366, 'insert', NULL, NULL, NULL, '2014-01-05 14:38:18', 1, 0),
(1266, 'ColumnSelector', 367, 'insert', NULL, NULL, NULL, '2014-01-05 14:38:18', 1, 0),
(1267, 'ColumnSelector', 368, 'insert', NULL, NULL, NULL, '2014-01-05 14:38:18', 1, 0),
(1268, 'ColumnSelector', 369, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:01', 1, 0),
(1269, 'ColumnSelector', 370, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:01', 1, 0),
(1270, 'ColumnSelector', 371, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:01', 1, 0),
(1271, 'ColumnSelector', 372, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:01', 1, 0),
(1272, 'ColumnSelector', 373, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:01', 1, 0),
(1273, 'ColumnSelector', 374, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:01', 1, 0),
(1274, 'ColumnSelector', 375, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:36', 1, 0),
(1275, 'ColumnSelector', 376, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:36', 1, 0),
(1276, 'ColumnSelector', 377, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:36', 1, 0),
(1277, 'ColumnSelector', 378, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:36', 1, 0),
(1278, 'ColumnSelector', 379, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:36', 1, 0),
(1279, 'ColumnSelector', 380, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:36', 1, 0),
(1280, 'ColumnSelector', 381, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:56', 1, 0),
(1281, 'ColumnSelector', 382, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:56', 1, 0),
(1282, 'ColumnSelector', 383, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:56', 1, 0),
(1283, 'ColumnSelector', 384, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:56', 1, 0),
(1284, 'ColumnSelector', 385, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:56', 1, 0),
(1285, 'ColumnSelector', 386, 'insert', NULL, NULL, NULL, '2014-01-05 14:46:56', 1, 0),
(1286, 'ColumnSelector', 387, 'insert', NULL, NULL, NULL, '2014-01-05 14:47:36', 1, 0),
(1287, 'ColumnSelector', 388, 'insert', NULL, NULL, NULL, '2014-01-05 14:47:36', 1, 0),
(1288, 'ColumnSelector', 389, 'insert', NULL, NULL, NULL, '2014-01-05 14:47:36', 1, 0),
(1289, 'ColumnSelector', 390, 'insert', NULL, NULL, NULL, '2014-01-05 14:47:36', 1, 0),
(1290, 'ColumnSelector', 391, 'insert', NULL, NULL, NULL, '2014-01-05 14:47:36', 1, 0),
(1291, 'ColumnSelector', 392, 'insert', NULL, NULL, NULL, '2014-01-05 14:47:36', 1, 0),
(1292, 'ColumnSelector', 393, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:05', 1, 0),
(1293, 'ColumnSelector', 394, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:05', 1, 0),
(1294, 'ColumnSelector', 395, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:05', 1, 0),
(1295, 'ColumnSelector', 396, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:05', 1, 0),
(1296, 'ColumnSelector', 397, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:05', 1, 0),
(1297, 'ColumnSelector', 398, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:05', 1, 0),
(1298, 'ColumnSelector', 399, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:29', 1, 0),
(1299, 'ColumnSelector', 400, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:29', 1, 0),
(1300, 'ColumnSelector', 401, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:29', 1, 0),
(1301, 'ColumnSelector', 402, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:29', 1, 0),
(1302, 'ColumnSelector', 403, 'insert', NULL, NULL, NULL, '2014-01-05 14:48:29', 1, 0),
(1303, 'ColumnSelector', 404, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:10', 1, 0),
(1304, 'ColumnSelector', 405, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:10', 1, 0),
(1305, 'ColumnSelector', 406, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:10', 1, 0),
(1306, 'ColumnSelector', 407, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:10', 1, 0),
(1307, 'ColumnSelector', 408, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:10', 1, 0),
(1308, 'ColumnSelector', 409, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:33', 1, 0),
(1309, 'ColumnSelector', 410, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:33', 1, 0),
(1310, 'ColumnSelector', 411, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:33', 1, 0),
(1311, 'ColumnSelector', 412, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:33', 1, 0),
(1312, 'ColumnSelector', 413, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:33', 1, 0),
(1313, 'ColumnSelector', 414, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:58', 1, 0),
(1314, 'ColumnSelector', 415, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:58', 1, 0),
(1315, 'ColumnSelector', 416, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:58', 1, 0),
(1316, 'ColumnSelector', 417, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:58', 1, 0),
(1317, 'ColumnSelector', 418, 'insert', NULL, NULL, NULL, '2014-01-05 14:49:58', 1, 0),
(1318, 'PredefinedNote', 1, 'insert', NULL, NULL, NULL, '2014-01-05 14:51:13', 1, 0),
(1319, 'ColumnSelector', 419, 'insert', NULL, NULL, NULL, '2014-01-05 14:53:17', 1, 0),
(1320, 'ColumnSelector', 420, 'insert', NULL, NULL, NULL, '2014-01-05 14:53:17', 1, 0),
(1321, 'ColumnSelector', 421, 'insert', NULL, NULL, NULL, '2014-01-05 14:53:17', 1, 0),
(1322, 'ColumnSelector', 422, 'insert', NULL, NULL, NULL, '2014-01-05 14:53:17', 1, 0),
(1323, 'ColumnSelector', 423, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1324, 'ColumnSelector', 424, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1325, 'ColumnSelector', 425, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1326, 'ColumnSelector', 426, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1327, 'ColumnSelector', 427, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1328, 'ColumnSelector', 428, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1329, 'ColumnSelector', 429, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1330, 'ColumnSelector', 430, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1331, 'ColumnSelector', 431, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1332, 'ColumnSelector', 432, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1333, 'ColumnSelector', 433, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1334, 'ColumnSelector', 434, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1335, 'ColumnSelector', 435, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1336, 'ColumnSelector', 436, 'insert', NULL, NULL, NULL, '2014-01-05 14:57:00', 1, 0),
(1337, 'ColumnSelector', 437, 'insert', NULL, NULL, NULL, '2014-01-05 15:01:42', 1, 0),
(1338, 'ColumnSelector', 438, 'insert', NULL, NULL, NULL, '2014-01-05 15:01:42', 1, 0),
(1339, 'ColumnSelector', 439, 'insert', NULL, NULL, NULL, '2014-01-05 15:01:42', 1, 0),
(1340, 'ColumnSelector', 440, 'insert', NULL, NULL, NULL, '2014-01-05 15:01:42', 1, 0),
(1341, 'ColumnSelector', 441, 'insert', NULL, NULL, NULL, '2014-01-05 15:01:42', 1, 0),
(1342, 'ColumnSelector', 442, 'insert', NULL, NULL, NULL, '2014-01-05 15:01:42', 1, 0),
(1343, 'ColumnSelector', 443, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1344, 'ColumnSelector', 444, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1345, 'ColumnSelector', 445, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1346, 'ColumnSelector', 446, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1347, 'ColumnSelector', 447, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1348, 'ColumnSelector', 448, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1349, 'ColumnSelector', 449, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1350, 'ColumnSelector', 450, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1351, 'ColumnSelector', 451, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1352, 'ColumnSelector', 452, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1353, 'ColumnSelector', 453, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1354, 'ColumnSelector', 454, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1355, 'ColumnSelector', 455, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1356, 'ColumnSelector', 456, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1357, 'ColumnSelector', 457, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1358, 'ColumnSelector', 458, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1359, 'ColumnSelector', 459, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1360, 'ColumnSelector', 460, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1361, 'ColumnSelector', 461, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1362, 'ColumnSelector', 462, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1363, 'ColumnSelector', 463, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1364, 'ColumnSelector', 464, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1365, 'ColumnSelector', 465, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1366, 'ColumnSelector', 466, 'insert', NULL, NULL, NULL, '2014-01-05 15:02:18', 1, 0),
(1367, 'ColumnSelector', 467, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1368, 'ColumnSelector', 468, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1369, 'ColumnSelector', 469, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1370, 'ColumnSelector', 470, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1371, 'ColumnSelector', 471, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1372, 'ColumnSelector', 472, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1373, 'ColumnSelector', 473, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1374, 'ColumnSelector', 474, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1375, 'ColumnSelector', 475, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1376, 'ColumnSelector', 476, 'insert', NULL, NULL, NULL, '2014-01-05 15:03:31', 1, 0),
(1377, 'ColumnSelector', 477, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1378, 'ColumnSelector', 478, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1379, 'ColumnSelector', 479, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1380, 'ColumnSelector', 480, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1381, 'ColumnSelector', 481, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1382, 'ColumnSelector', 482, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1383, 'ColumnSelector', 483, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1384, 'ColumnSelector', 484, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:12', 1, 0),
(1385, 'ColumnSelector', 485, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1386, 'ColumnSelector', 486, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1387, 'ColumnSelector', 487, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1388, 'ColumnSelector', 488, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1389, 'ColumnSelector', 489, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1390, 'ColumnSelector', 490, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1391, 'ColumnSelector', 491, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1392, 'ColumnSelector', 492, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1393, 'ColumnSelector', 493, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1394, 'ColumnSelector', 494, 'insert', NULL, NULL, NULL, '2014-01-05 15:07:37', 1, 0),
(1395, 'ColumnSelector', 495, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:11', 1, 0),
(1396, 'ColumnSelector', 496, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:11', 1, 0),
(1397, 'ColumnSelector', 497, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:11', 1, 0),
(1398, 'ColumnSelector', 498, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:11', 1, 0),
(1399, 'ColumnSelector', 499, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:11', 1, 0),
(1400, 'ColumnSelector', 500, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1401, 'ColumnSelector', 501, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1402, 'ColumnSelector', 502, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1403, 'ColumnSelector', 503, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1404, 'ColumnSelector', 504, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1405, 'ColumnSelector', 505, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1406, 'ColumnSelector', 506, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1407, 'ColumnSelector', 507, 'insert', NULL, NULL, NULL, '2014-01-05 15:09:52', 1, 0),
(1408, 'ColumnSelector', 508, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1409, 'ColumnSelector', 509, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1410, 'ColumnSelector', 510, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1411, 'ColumnSelector', 511, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1412, 'ColumnSelector', 512, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1413, 'ColumnSelector', 513, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1414, 'ColumnSelector', 514, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1415, 'ColumnSelector', 515, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1416, 'ColumnSelector', 516, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1417, 'ColumnSelector', 517, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1418, 'ColumnSelector', 518, 'insert', NULL, NULL, NULL, '2014-01-05 15:17:22', 1, 0),
(1419, 'Attachment', 6, 'insert', NULL, NULL, NULL, '2015-06-25 20:42:36', 1, 0),
(1420, 'Ticket', 2, 'insert', '|Attachement|6', NULL, 'license.txt', '2014-01-05 15:21:04', 1, 0),
(1421, 'Attachment', 6, 'update', 'subDirectory', NULL, '${attachementDirectory}\\attachement_6\\', '2015-06-25 20:42:36', 1, 0),
(1422, 'Ticket', 2, 'update', 'subDirectory|Attachement|6', NULL, '${attachementDirectory}\\attachement_6\\', '2014-01-05 15:21:04', 1, 0),
(1423, 'Attachment', 6, 'update', 'idTeam', '1', NULL, '2015-06-25 20:42:36', 1, 0),
(1424, 'Ticket', 2, 'update', 'idTeam|Attachement|6', '1', NULL, '2014-01-05 15:21:04', 1, 0),
(1425, 'Attachment', 7, 'insert', NULL, NULL, NULL, '2015-06-25 20:42:36', 1, 0),
(1426, 'Ticket', 2, 'insert', '|Attachement|7', NULL, 'Tel.doc', '2014-01-05 15:22:01', 1, 0),
(1427, 'Attachment', 7, 'update', 'subDirectory', NULL, '${attachementDirectory}\\attachement_7\\', '2015-06-25 20:42:36', 1, 0),
(1428, 'Ticket', 2, 'update', 'subDirectory|Attachement|7', NULL, '${attachementDirectory}\\attachement_7\\', '2014-01-05 15:22:01', 1, 0),
(1429, 'Attachment', 7, 'update', 'idTeam', '1', NULL, '2015-06-25 20:42:36', 1, 0),
(1430, 'Ticket', 2, 'update', 'idTeam|Attachement|7', '1', NULL, '2014-01-05 15:22:01', 1, 0),
(1431, 'Attachment', 8, 'insert', NULL, NULL, NULL, '2015-06-25 20:42:36', 1, 0),
(1432, 'Ticket', 2, 'insert', '|Attachement|8', NULL, 'recent', '2014-01-05 15:22:58', 1, 0),
(1433, 'Note', 2, 'insert', NULL, NULL, NULL, '2014-01-05 15:32:53', 1, 0),
(1434, 'Ticket', 2, 'insert', '|Note|2', NULL, 'New comment.\n... for testing.', '2014-01-05 15:32:53', 1, 0),
(1435, 'ColumnSelector', 519, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1436, 'ColumnSelector', 520, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1437, 'ColumnSelector', 521, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1438, 'ColumnSelector', 522, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1439, 'ColumnSelector', 523, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1440, 'ColumnSelector', 524, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1441, 'ColumnSelector', 525, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:32', 1, 0),
(1442, 'ColumnSelector', 526, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1443, 'ColumnSelector', 527, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1444, 'ColumnSelector', 528, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1445, 'ColumnSelector', 529, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1446, 'ColumnSelector', 530, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1447, 'ColumnSelector', 531, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1448, 'ColumnSelector', 532, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1449, 'ColumnSelector', 533, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1450, 'ColumnSelector', 534, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1451, 'ColumnSelector', 535, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1452, 'ColumnSelector', 536, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1453, 'ColumnSelector', 537, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1454, 'ColumnSelector', 538, 'insert', NULL, NULL, NULL, '2014-01-05 15:44:33', 1, 0),
(1455, 'WorkPeriod', 1, 'insert', NULL, NULL, NULL, '2014-01-05 15:51:11', 1, 0),
(1456, 'Assignment', 1, 'update', 'realWork', '0.00000', '1', '2014-01-05 15:51:11', 1, 0),
(1457, 'Assignment', 1, 'update', 'leftWork', '10.00000', '9', '2014-01-05 15:51:11', 1, 0),
(1458, 'Assignment', 1, 'update', 'realStartDate', NULL, '2013-12-31', '2014-01-05 15:51:11', 1, 0),
(1459, 'Assignment', 1, 'update', 'realEndDate', NULL, '2013-12-31', '2014-01-05 15:51:11', 1, 0),
(1460, 'Assignment', 1, 'update', 'realCost', '0.00', '500', '2014-01-05 15:51:11', 1, 0),
(1461, 'Assignment', 1, 'update', 'leftCost', '5000.00', '4500', '2014-01-05 15:51:11', 1, 0),
(1462, 'Assignment', 6, 'update', 'realWork', '5.00000', '7', '2014-01-05 15:51:12', 1, 0),
(1463, 'Assignment', 6, 'update', 'plannedWork', '5.00000', '7', '2014-01-05 15:51:12', 1, 0),
(1464, 'Assignment', 6, 'update', 'realEndDate', '2012-03-16', '2014-01-01', '2014-01-05 15:51:12', 1, 0),
(1465, 'Assignment', 6, 'update', 'realCost', '2500.00', '3500', '2014-01-05 15:51:12', 1, 0),
(1466, 'Assignment', 6, 'update', 'plannedCost', '2500.00', '3500', '2014-01-05 15:51:12', 1, 0),
(1467, 'Assignment', 1, 'update', 'realWork', '1.00000', '2', '2014-01-05 15:51:27', 1, 0),
(1468, 'Assignment', 1, 'update', 'leftWork', '9.00000', '8', '2014-01-05 15:51:27', 1, 0),
(1469, 'Assignment', 1, 'update', 'realStartDate', '2013-12-31', '2013-12-30', '2014-01-05 15:51:27', 1, 0),
(1470, 'Assignment', 1, 'update', 'realCost', '500.00', '1000', '2014-01-05 15:51:27', 1, 0),
(1471, 'Assignment', 1, 'update', 'leftCost', '4500.00', '4000', '2014-01-05 15:51:27', 1, 0),
(1472, 'PlanningElement', 1, 'update', 'plannedStartDate', '2012-03-05', '2011-09-05', '2014-01-05 15:53:25', 1, 0),
(1473, 'PlanningElement', 1, 'update', 'plannedEndDate', '2012-08-03', '2015-01-09', '2014-01-05 15:53:25', 1, 0),
(1474, 'PlanningElement', 1, 'update', 'plannedDuration', '107', '869', '2014-01-05 15:53:25', 1, 0),
(1475, 'PlanningElement', 2, 'update', 'plannedEndDate', '2012-08-03', '2015-01-09', '2014-01-05 15:53:25', 1, 0),
(1476, 'PlanningElement', 2, 'update', 'plannedDuration', '107', '738', '2014-01-05 15:53:25', 1, 0),
(1477, 'PlanningElement', 7, 'update', 'plannedEndDate', '2012-08-03', '2015-01-09', '2014-01-05 15:53:25', 1, 0),
(1478, 'PlanningElement', 7, 'update', 'plannedDuration', '107', '738', '2014-01-05 15:53:25', 1, 0),
(1479, 'PlanningElement', 3, 'update', 'plannedStartDate', '2012-03-14', '2011-09-05', '2014-01-05 15:53:25', 1, 0),
(1480, 'PlanningElement', 3, 'update', 'plannedEndDate', '2012-06-12', '2014-01-20', '2014-01-05 15:53:25', 1, 0),
(1481, 'PlanningElement', 3, 'update', 'plannedDuration', '62', '615', '2014-01-05 15:53:25', 1, 0),
(1482, 'PlanningElement', 8, 'update', 'plannedStartDate', '2012-03-14', '2011-09-05', '2014-01-05 15:53:25', 1, 0),
(1483, 'PlanningElement', 8, 'update', 'plannedEndDate', '2012-06-07', '2014-01-14', '2014-01-05 15:53:25', 1, 0),
(1484, 'PlanningElement', 8, 'update', 'plannedDuration', '58', '611', '2014-01-05 15:53:25', 1, 0),
(1485, 'PlanningElement', 11, 'update', 'plannedStartDate', '2012-06-04', '2014-01-09', '2014-01-05 15:53:25', 1, 0),
(1486, 'PlanningElement', 11, 'update', 'plannedEndDate', '2012-06-06', '2014-01-13', '2014-01-05 15:53:25', 1, 0),
(1487, 'PlanningElement', 10, 'update', 'plannedStartDate', '2012-05-29', '2014-01-06', '2014-01-05 15:53:25', 1, 0),
(1488, 'PlanningElement', 10, 'update', 'plannedEndDate', '2012-06-01', '2014-01-08', '2014-01-05 15:53:25', 1, 0),
(1489, 'PlanningElement', 10, 'update', 'plannedDuration', '4', '3', '2014-01-05 15:53:25', 1, 0),
(1490, 'PlanningElement', 12, 'update', 'plannedStartDate', '2012-06-07', '2014-01-14', '2014-01-05 15:53:25', 1, 0),
(1491, 'PlanningElement', 12, 'update', 'plannedEndDate', '2012-06-07', '2014-01-14', '2014-01-05 15:53:25', 1, 0),
(1492, 'PlanningElement', 13, 'update', 'plannedStartDate', '2012-06-07', '2014-01-14', '2014-01-05 15:53:25', 1, 0),
(1493, 'PlanningElement', 13, 'update', 'plannedEndDate', '2012-06-12', '2014-01-20', '2014-01-05 15:53:25', 1, 0),
(1494, 'PlanningElement', 4, 'update', 'plannedStartDate', NULL, '2012-03-12', '2014-01-05 15:53:25', 1, 0),
(1495, 'PlanningElement', 4, 'update', 'plannedEndDate', NULL, '2014-01-01', '2014-01-05 15:53:25', 1, 0),
(1496, 'PlanningElement', 4, 'update', 'plannedDuration', NULL, '466', '2014-01-05 15:53:25', 1, 0),
(1497, 'PlanningElement', 11, 'update', 'wbs', '1.2.1.2', '1.2.1.3', '2014-01-05 15:53:33', 1, 0),
(1498, 'PlanningElement', 11, 'update', 'wbsSortable', '001.002.001.002', '001.002.001.003', '2014-01-05 15:53:33', 1, 0),
(1499, 'PlanningElement', 10, 'update', 'wbs', '1.2.1.3', '1.2.1.2', '2014-01-05 15:53:33', 1, 0),
(1500, 'PlanningElement', 10, 'update', 'wbsSortable', '001.002.001.003', '001.002.001.002', '2014-01-05 15:53:33', 1, 0),
(1501, 'Assignment', 3, 'update', 'leftWork', '0.00000', '5', '2014-01-05 15:53:56', 1, 0),
(1502, 'Assignment', 3, 'update', 'plannedWork', '5.70000', '10.7', '2014-01-05 15:53:56', 1, 0),
(1503, 'Assignment', 3, 'update', 'leftCost', '0.00', '1500', '2014-01-05 15:53:56', 1, 0),
(1504, 'Assignment', 3, 'update', 'plannedCost', '1710.00', '3210', '2014-01-05 15:53:56', 1, 0),
(1505, 'ActivityPlanningElement', 9, 'update', 'realEndDate', NULL, '2011-10-13', '2014-01-05 15:53:57', 1, 0),
(1506, 'ActivityPlanningElement', 9, 'update', 'realDuration', NULL, '29', '2014-01-05 15:53:57', 1, 0),
(1507, 'ActivityPlanningElement', 9, 'update', 'validatedWork', NULL, '0', '2014-01-05 15:53:57', 1, 0),
(1508, 'ActivityPlanningElement', 9, 'update', 'plannedWork', '10.70000', '5.7', '2014-01-05 15:53:57', 1, 0),
(1509, 'ActivityPlanningElement', 9, 'update', 'leftWork', '5.00000', '0', '2014-01-05 15:53:57', 1, 0),
(1510, 'ActivityPlanningElement', 9, 'update', 'progress', '53', '100', '2014-01-05 15:53:57', 1, 0),
(1511, 'ActivityPlanningElement', 9, 'update', 'plannedCost', '3210.00', '1710', '2014-01-05 15:53:57', 1, 0),
(1512, 'ActivityPlanningElement', 9, 'update', 'leftCost', '1500.00', '0', '2014-01-05 15:53:57', 1, 0),
(1513, 'ActivityPlanningElement', 9, 'update', 'initialWork', NULL, '0', '2014-01-05 15:53:57', 1, 0),
(1514, 'PlanningElement', 1, 'update', 'plannedStartDate', '2012-03-05', '2011-09-05', '2014-01-05 15:54:09', 1, 0),
(1515, 'PlanningElement', 1, 'update', 'plannedEndDate', '2015-01-09', '2015-01-07', '2014-01-05 15:54:09', 1, 0),
(1516, 'PlanningElement', 1, 'update', 'plannedDuration', '738', '867', '2014-01-05 15:54:09', 1, 0),
(1517, 'PlanningElement', 2, 'update', 'plannedEndDate', '2015-01-09', '2015-01-07', '2014-01-05 15:54:09', 1, 0),
(1518, 'PlanningElement', 2, 'update', 'plannedDuration', '738', '736', '2014-01-05 15:54:09', 1, 0),
(1519, 'PlanningElement', 7, 'update', 'plannedEndDate', '2015-01-09', '2015-01-07', '2014-01-05 15:54:09', 1, 0),
(1520, 'PlanningElement', 7, 'update', 'plannedDuration', '738', '736', '2014-01-05 15:54:09', 1, 0),
(1521, 'PlanningElement', 3, 'update', 'plannedStartDate', '2014-01-06', '2011-09-05', '2014-01-05 15:54:09', 1, 0),
(1522, 'PlanningElement', 3, 'update', 'plannedEndDate', '2014-01-20', '2014-01-15', '2014-01-05 15:54:09', 1, 0),
(1523, 'PlanningElement', 3, 'update', 'plannedDuration', '11', '612', '2014-01-05 15:54:09', 1, 0),
(1524, 'PlanningElement', 8, 'update', 'plannedStartDate', '2014-01-06', '2011-09-05', '2014-01-05 15:54:09', 1, 0),
(1525, 'PlanningElement', 8, 'update', 'plannedEndDate', '2014-01-14', '2014-01-09', '2014-01-05 15:54:09', 1, 0),
(1526, 'PlanningElement', 8, 'update', 'plannedDuration', '7', '608', '2014-01-05 15:54:09', 1, 0),
(1527, 'PlanningElement', 9, 'update', 'plannedStartDate', NULL, '2013-12-30', '2014-01-05 15:54:09', 1, 0),
(1528, 'PlanningElement', 9, 'update', 'plannedEndDate', NULL, '2014-01-03', '2014-01-05 15:54:09', 1, 0),
(1529, 'PlanningElement', 9, 'update', 'plannedDuration', NULL, '5', '2014-01-05 15:54:09', 1, 0),
(1530, 'PlanningElement', 10, 'update', 'plannedStartDate', '2014-01-06', '2013-12-30', '2014-01-05 15:54:09', 1, 0),
(1531, 'PlanningElement', 10, 'update', 'plannedEndDate', '2014-01-08', '2014-01-01', '2014-01-05 15:54:09', 1, 0),
(1532, 'PlanningElement', 11, 'update', 'plannedStartDate', '2014-01-09', '2014-01-06', '2014-01-05 15:54:09', 1, 0),
(1533, 'PlanningElement', 11, 'update', 'plannedEndDate', '2014-01-13', '2014-01-08', '2014-01-05 15:54:09', 1, 0),
(1534, 'PlanningElement', 12, 'update', 'plannedStartDate', '2014-01-14', '2014-01-09', '2014-01-05 15:54:09', 1, 0),
(1535, 'PlanningElement', 12, 'update', 'plannedEndDate', '2014-01-14', '2014-01-09', '2014-01-05 15:54:09', 1, 0),
(1536, 'PlanningElement', 13, 'update', 'plannedStartDate', '2014-01-14', '2014-01-09', '2014-01-05 15:54:09', 1, 0),
(1537, 'PlanningElement', 13, 'update', 'plannedEndDate', '2014-01-20', '2014-01-15', '2014-01-05 15:54:09', 1, 0),
(1538, 'Assignment', 6, 'update', 'assignedWork', NULL, '0', '2014-01-05 15:54:31', 1, 0),
(1539, 'Assignment', 6, 'update', 'leftWork', '0.00000', '10', '2014-01-05 15:54:31', 1, 0),
(1540, 'Assignment', 6, 'update', 'plannedWork', '7.00000', '17', '2014-01-05 15:54:31', 1, 0),
(1541, 'Assignment', 6, 'update', 'leftCost', '0.00', '5000', '2014-01-05 15:54:31', 1, 0),
(1542, 'Assignment', 6, 'update', 'plannedCost', '3500.00', '8500', '2014-01-05 15:54:31', 1, 0),
(1543, 'ActivityPlanningElement', 14, 'update', 'validatedStartDate', NULL, '2013-12-30', '2014-01-05 15:55:07', 1, 0),
(1544, 'ActivityPlanningElement', 14, 'update', 'validatedEndDate', NULL, '2014-01-31', '2014-01-05 15:55:07', 1, 0),
(1545, 'ActivityPlanningElement', 14, 'update', 'idActivityPlanningMode', '1', '7', '2014-01-05 15:55:07', 1, 0),
(1546, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', NULL, '25', '2014-01-05 15:55:07', 1, 0),
(1547, 'PlanningElement', 4, 'update', 'plannedStartDate', NULL, '2012-03-12', '2014-01-05 15:55:12', 1, 0),
(1548, 'PlanningElement', 4, 'update', 'plannedEndDate', NULL, '2015-03-09', '2014-01-05 15:55:12', 1, 0),
(1549, 'PlanningElement', 4, 'update', 'plannedDuration', NULL, '774', '2014-01-05 15:55:12', 1, 0),
(1550, 'PlanningElement', 14, 'update', 'plannedStartDate', NULL, '2015-01-08', '2014-01-05 15:55:12', 1, 0),
(1551, 'PlanningElement', 14, 'update', 'plannedEndDate', NULL, '2015-03-09', '2014-01-05 15:55:12', 1, 0),
(1552, 'PlanningElement', 14, 'update', 'plannedDuration', NULL, '43', '2014-01-05 15:55:12', 1, 0),
(1553, 'Assignment', 6, 'update', 'leftWork', '10.00000', '2', '2014-01-05 15:55:30', 1, 0),
(1554, 'Assignment', 6, 'update', 'plannedWork', '17.00000', '9', '2014-01-05 15:55:30', 1, 0),
(1555, 'Assignment', 6, 'update', 'leftCost', '5000.00', '1000', '2014-01-05 15:55:30', 1, 0),
(1556, 'Assignment', 6, 'update', 'plannedCost', '8500.00', '4500', '2014-01-05 15:55:30', 1, 0),
(1557, 'PlanningElement', 4, 'update', 'plannedEndDate', '2015-03-09', '2015-01-12', '2014-01-05 15:55:35', 1, 0),
(1558, 'PlanningElement', 4, 'update', 'plannedDuration', '774', '734', '2014-01-05 15:55:35', 1, 0),
(1559, 'PlanningElement', 14, 'update', 'plannedEndDate', '2015-03-09', '2015-01-12', '2014-01-05 15:55:35', 1, 0),
(1560, 'PlanningElement', 14, 'update', 'plannedDuration', '774', '734', '2014-01-05 15:55:35', 1, 0),
(1561, 'Assignment', 3, 'update', 'leftWork', '5.00000', '10', '2014-01-05 15:57:25', 1, 0),
(1562, 'Assignment', 3, 'update', 'plannedWork', '10.70000', '15.7', '2014-01-05 15:57:25', 1, 0),
(1563, 'Assignment', 3, 'update', 'leftCost', '1500.00', '3000', '2014-01-05 15:57:25', 1, 0),
(1564, 'Assignment', 3, 'update', 'plannedCost', '3210.00', '4710', '2014-01-05 15:57:25', 1, 0),
(1565, 'ActivityPlanningElement', 9, 'update', 'validatedWork', '0.00000', '10', '2014-01-05 15:57:32', 1, 0),
(1566, 'ActivityPlanningElement', 9, 'update', 'expectedProgress', '0', '57', '2014-01-05 15:57:32', 1, 0),
(1567, 'PlanningElement', 3, 'update', 'plannedEndDate', '2014-01-15', '2014-01-27', '2014-01-05 15:57:44', 1, 0),
(1568, 'PlanningElement', 3, 'update', 'plannedDuration', '612', '620', '2014-01-05 15:57:44', 1, 0),
(1569, 'PlanningElement', 8, 'update', 'plannedEndDate', '2014-01-09', '2014-01-21', '2014-01-05 15:57:44', 1, 0),
(1570, 'PlanningElement', 8, 'update', 'plannedDuration', '608', '616', '2014-01-05 15:57:44', 1, 0),
(1571, 'PlanningElement', 9, 'update', 'plannedEndDate', '2014-01-03', '2014-01-10', '2014-01-05 15:57:44', 1, 0),
(1572, 'PlanningElement', 9, 'update', 'plannedDuration', '604', '609', '2014-01-05 15:57:44', 1, 0),
(1573, 'PlanningElement', 10, 'update', 'plannedStartDate', '2013-12-30', '2014-01-13', '2014-01-05 15:57:44', 1, 0),
(1574, 'PlanningElement', 10, 'update', 'plannedEndDate', '2014-01-01', '2014-01-15', '2014-01-05 15:57:44', 1, 0),
(1575, 'PlanningElement', 11, 'update', 'plannedStartDate', '2014-01-06', '2014-01-16', '2014-01-05 15:57:44', 1, 0),
(1576, 'PlanningElement', 11, 'update', 'plannedEndDate', '2014-01-08', '2014-01-20', '2014-01-05 15:57:44', 1, 0),
(1577, 'PlanningElement', 12, 'update', 'plannedStartDate', '2014-01-09', '2014-01-21', '2014-01-05 15:57:44', 1, 0),
(1578, 'PlanningElement', 12, 'update', 'plannedEndDate', '2014-01-09', '2014-01-21', '2014-01-05 15:57:44', 1, 0),
(1579, 'PlanningElement', 13, 'update', 'plannedStartDate', '2014-01-09', '2014-01-21', '2014-01-05 15:57:44', 1, 0),
(1580, 'PlanningElement', 13, 'update', 'plannedEndDate', '2014-01-15', '2014-01-27', '2014-01-05 15:57:44', 1, 0),
(1581, 'ColumnSelector', 539, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1582, 'ColumnSelector', 540, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1583, 'ColumnSelector', 541, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1584, 'ColumnSelector', 542, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1585, 'ColumnSelector', 543, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1586, 'ColumnSelector', 544, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1587, 'ColumnSelector', 545, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1588, 'ColumnSelector', 546, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1589, 'ColumnSelector', 547, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1590, 'ColumnSelector', 548, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1591, 'ColumnSelector', 549, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1592, 'ColumnSelector', 550, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1593, 'ColumnSelector', 551, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1594, 'ColumnSelector', 552, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1595, 'ColumnSelector', 553, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1596, 'ColumnSelector', 554, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1597, 'ColumnSelector', 555, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1598, 'ColumnSelector', 556, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1599, 'ColumnSelector', 557, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1600, 'ColumnSelector', 558, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1601, 'ColumnSelector', 559, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1602, 'ColumnSelector', 560, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1603, 'ColumnSelector', 561, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1604, 'ColumnSelector', 562, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1605, 'ColumnSelector', 563, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1606, 'ColumnSelector', 564, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1607, 'ColumnSelector', 565, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1608, 'ColumnSelector', 566, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1609, 'ColumnSelector', 567, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1610, 'ColumnSelector', 568, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:02', 1, 0),
(1611, 'ColumnSelector', 569, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1612, 'ColumnSelector', 570, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1613, 'ColumnSelector', 571, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1614, 'ColumnSelector', 572, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1615, 'ColumnSelector', 573, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1616, 'ColumnSelector', 574, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1617, 'ColumnSelector', 575, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1618, 'ColumnSelector', 576, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1619, 'ColumnSelector', 577, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1620, 'ColumnSelector', 578, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1621, 'ColumnSelector', 579, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1622, 'ColumnSelector', 580, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1623, 'ColumnSelector', 581, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:28', 1, 0),
(1624, 'ColumnSelector', 582, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1625, 'ColumnSelector', 583, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1626, 'ColumnSelector', 584, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1627, 'ColumnSelector', 585, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1628, 'ColumnSelector', 586, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1629, 'ColumnSelector', 587, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1630, 'ColumnSelector', 588, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1631, 'ColumnSelector', 589, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1632, 'ColumnSelector', 590, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1633, 'ColumnSelector', 591, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0);
INSERT INTO `history` (`id`, `refType`, `refId`, `operation`, `colName`, `oldValue`, `newValue`, `operationDate`, `idUser`, `isWorkHistory`) VALUES
(1634, 'ColumnSelector', 592, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1635, 'ColumnSelector', 593, 'insert', NULL, NULL, NULL, '2014-01-05 16:16:56', 1, 0),
(1636, 'ColumnSelector', 594, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1637, 'ColumnSelector', 595, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1638, 'ColumnSelector', 596, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1639, 'ColumnSelector', 597, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1640, 'ColumnSelector', 598, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1641, 'ColumnSelector', 599, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1642, 'ColumnSelector', 600, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1643, 'ColumnSelector', 601, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1644, 'ColumnSelector', 602, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1645, 'ColumnSelector', 603, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1646, 'ColumnSelector', 604, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:17', 1, 0),
(1647, 'ColumnSelector', 605, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1648, 'ColumnSelector', 606, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1649, 'ColumnSelector', 607, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1650, 'ColumnSelector', 608, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1651, 'ColumnSelector', 609, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1652, 'ColumnSelector', 610, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1653, 'ColumnSelector', 611, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1654, 'ColumnSelector', 612, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1655, 'ColumnSelector', 613, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1656, 'ColumnSelector', 614, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1657, 'ColumnSelector', 615, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1658, 'ColumnSelector', 616, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1659, 'ColumnSelector', 617, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1660, 'ColumnSelector', 618, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1661, 'ColumnSelector', 619, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1662, 'ColumnSelector', 620, 'insert', NULL, NULL, NULL, '2014-01-05 16:17:39', 1, 0),
(1663, 'ColumnSelector', 621, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1664, 'ColumnSelector', 622, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1665, 'ColumnSelector', 623, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1666, 'ColumnSelector', 624, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1667, 'ColumnSelector', 625, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1668, 'ColumnSelector', 626, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1669, 'ColumnSelector', 627, 'insert', NULL, NULL, NULL, '2014-01-05 16:18:01', 1, 0),
(1670, 'ColumnSelector', 628, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1671, 'ColumnSelector', 629, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1672, 'ColumnSelector', 630, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1673, 'ColumnSelector', 631, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1674, 'ColumnSelector', 632, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1675, 'ColumnSelector', 633, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1676, 'ColumnSelector', 634, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1677, 'ColumnSelector', 635, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1678, 'ColumnSelector', 636, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1679, 'ColumnSelector', 637, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1680, 'ColumnSelector', 638, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1681, 'ColumnSelector', 639, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1682, 'ColumnSelector', 640, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1683, 'ColumnSelector', 641, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1684, 'ColumnSelector', 642, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1685, 'ColumnSelector', 643, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1686, 'ColumnSelector', 644, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1687, 'ColumnSelector', 645, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1688, 'ColumnSelector', 646, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1689, 'ColumnSelector', 647, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1690, 'ColumnSelector', 648, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1691, 'ColumnSelector', 649, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1692, 'ColumnSelector', 650, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1693, 'ColumnSelector', 651, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1694, 'ColumnSelector', 652, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1695, 'ColumnSelector', 653, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:01', 1, 0),
(1696, 'ColumnSelector', 654, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1697, 'ColumnSelector', 655, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1698, 'ColumnSelector', 656, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1699, 'ColumnSelector', 657, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1700, 'ColumnSelector', 658, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1701, 'ColumnSelector', 659, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1702, 'ColumnSelector', 660, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1703, 'ColumnSelector', 661, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1704, 'ColumnSelector', 662, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1705, 'ColumnSelector', 663, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1706, 'ColumnSelector', 664, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1707, 'ColumnSelector', 665, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1708, 'ColumnSelector', 666, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1709, 'ColumnSelector', 667, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1710, 'ColumnSelector', 668, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1711, 'ColumnSelector', 669, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1712, 'ColumnSelector', 670, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1713, 'ColumnSelector', 671, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1714, 'ColumnSelector', 672, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1715, 'ColumnSelector', 673, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1716, 'ColumnSelector', 674, 'insert', NULL, NULL, NULL, '2014-01-05 16:19:03', 1, 0),
(1717, 'ColumnSelector', 675, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1718, 'ColumnSelector', 676, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1719, 'ColumnSelector', 677, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1720, 'ColumnSelector', 678, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1721, 'ColumnSelector', 679, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1722, 'ColumnSelector', 680, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1723, 'ColumnSelector', 681, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1724, 'ColumnSelector', 682, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1725, 'ColumnSelector', 683, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1726, 'ColumnSelector', 684, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1727, 'ColumnSelector', 685, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1728, 'ColumnSelector', 686, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1729, 'ColumnSelector', 687, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1730, 'ColumnSelector', 688, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1731, 'ColumnSelector', 689, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1732, 'ColumnSelector', 690, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1733, 'ColumnSelector', 691, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1734, 'ColumnSelector', 692, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1735, 'ColumnSelector', 693, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1736, 'ColumnSelector', 694, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1737, 'ColumnSelector', 695, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1738, 'ColumnSelector', 696, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1739, 'ColumnSelector', 697, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1740, 'ColumnSelector', 698, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1741, 'ColumnSelector', 699, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1742, 'ColumnSelector', 700, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1743, 'ColumnSelector', 701, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1744, 'ColumnSelector', 702, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1745, 'ColumnSelector', 703, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1746, 'ColumnSelector', 704, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1747, 'ColumnSelector', 705, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1748, 'ColumnSelector', 706, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1749, 'ColumnSelector', 707, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1750, 'ColumnSelector', 708, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1751, 'ColumnSelector', 709, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1752, 'ColumnSelector', 710, 'insert', NULL, NULL, NULL, '2014-01-05 16:20:44', 1, 0),
(1753, 'Requirement', 2, 'update', 'name', 'test', 'field "2" msut be numeric', '2014-01-05 16:28:13', 1, 0),
(1754, 'Requirement', 2, 'update', 'name', 'field "2" msut be numeric', 'field "2" must be numeric', '2014-01-05 16:28:18', 1, 0),
(1755, 'Dependency', 7, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:24', 1, 0),
(1756, 'ColumnSelector', 711, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1757, 'ColumnSelector', 712, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1758, 'ColumnSelector', 713, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1759, 'ColumnSelector', 714, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1760, 'ColumnSelector', 715, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1761, 'ColumnSelector', 716, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1762, 'ColumnSelector', 717, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1763, 'ColumnSelector', 718, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1764, 'ColumnSelector', 719, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1765, 'ColumnSelector', 720, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1766, 'ColumnSelector', 721, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1767, 'ColumnSelector', 722, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1768, 'ColumnSelector', 723, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1769, 'ColumnSelector', 724, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1770, 'ColumnSelector', 725, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1771, 'ColumnSelector', 726, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1772, 'ColumnSelector', 727, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1773, 'ColumnSelector', 728, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1774, 'ColumnSelector', 729, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1775, 'ColumnSelector', 730, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1776, 'ColumnSelector', 731, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1777, 'ColumnSelector', 732, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1778, 'ColumnSelector', 733, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1779, 'ColumnSelector', 734, 'insert', NULL, NULL, NULL, '2014-01-05 16:28:59', 1, 0),
(1780, 'Dependency', 8, 'insert', NULL, NULL, NULL, '2014-01-05 16:31:05', 1, 0),
(1781, 'ColumnSelector', 735, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1782, 'ColumnSelector', 736, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1783, 'ColumnSelector', 737, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1784, 'ColumnSelector', 738, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1785, 'ColumnSelector', 739, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1786, 'ColumnSelector', 740, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1787, 'ColumnSelector', 741, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1788, 'ColumnSelector', 742, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1789, 'ColumnSelector', 743, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1790, 'ColumnSelector', 744, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1791, 'ColumnSelector', 745, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1792, 'ColumnSelector', 746, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:06', 1, 0),
(1793, 'ColumnSelector', 747, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1794, 'ColumnSelector', 748, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1795, 'ColumnSelector', 749, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1796, 'ColumnSelector', 750, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1797, 'ColumnSelector', 751, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1798, 'ColumnSelector', 752, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1799, 'ColumnSelector', 753, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1800, 'ColumnSelector', 754, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1801, 'ColumnSelector', 755, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1802, 'ColumnSelector', 756, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1803, 'ColumnSelector', 757, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1804, 'ColumnSelector', 758, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1805, 'ColumnSelector', 759, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1806, 'ColumnSelector', 760, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1807, 'ColumnSelector', 761, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1808, 'ColumnSelector', 762, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1809, 'ColumnSelector', 763, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1810, 'ColumnSelector', 764, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1811, 'ColumnSelector', 765, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1812, 'ColumnSelector', 766, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1813, 'ColumnSelector', 767, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1814, 'ColumnSelector', 768, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1815, 'ColumnSelector', 769, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1816, 'ColumnSelector', 770, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1817, 'ColumnSelector', 771, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1818, 'ColumnSelector', 772, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1819, 'ColumnSelector', 773, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1820, 'ColumnSelector', 774, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1821, 'ColumnSelector', 775, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1822, 'ColumnSelector', 776, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1823, 'ColumnSelector', 777, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1824, 'ColumnSelector', 778, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1825, 'ColumnSelector', 779, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1826, 'ColumnSelector', 780, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1827, 'ColumnSelector', 781, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1828, 'ColumnSelector', 782, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1829, 'ColumnSelector', 783, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1830, 'ColumnSelector', 784, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1831, 'ColumnSelector', 785, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1832, 'ColumnSelector', 786, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1833, 'ColumnSelector', 787, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1834, 'ColumnSelector', 788, 'insert', NULL, NULL, NULL, '2014-01-05 16:32:07', 1, 0),
(1835, 'TestSession', 1, 'update', 'idProject', NULL, '1', '2014-01-05 16:35:00', 1, 0),
(1836, 'TestSessionPlanningElement', 15, 'insert', NULL, NULL, NULL, '2014-01-05 16:35:00', 1, 0),
(1837, 'Assignment', 7, 'insert', NULL, NULL, NULL, '2014-01-05 16:35:09', 1, 0),
(1838, 'TestSessionPlanningElement', 15, 'update', 'validatedStartDate', NULL, '2014-01-07', '2014-01-05 16:35:46', 1, 0),
(1839, 'TestSessionPlanningElement', 15, 'update', 'validatedEndDate', NULL, '2014-01-09', '2014-01-05 16:35:46', 1, 0),
(1840, 'TestSessionPlanningElement', 15, 'update', 'validatedDuration', NULL, '3', '2014-01-05 16:35:46', 1, 0),
(1841, 'PlanningElement', 15, 'update', 'plannedStartDate', NULL, '2014-01-07', '2014-01-05 16:35:59', 1, 0),
(1842, 'PlanningElement', 15, 'update', 'plannedEndDate', NULL, '2014-01-07', '2014-01-05 16:35:59', 1, 0),
(1843, 'PlanningElement', 15, 'update', 'plannedDuration', NULL, '1', '2014-01-05 16:35:59', 1, 0),
(1844, 'User', 1, 'update', 'apiKey', NULL, 'e6e4941e966def9ca59890c08181fa30', '2015-06-25 20:42:36', NULL, 0),
(1845, 'User', 1, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1846, 'User', 2, 'update', 'apiKey', NULL, '5d742be3c93871efc7bab039ef08bfa6', '2015-06-25 20:42:36', NULL, 0),
(1847, 'User', 2, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1848, 'User', 3, 'update', 'apiKey', NULL, '35adac1dd9888f4940a83440691284ac', '2015-06-25 20:42:36', NULL, 0),
(1849, 'User', 3, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1850, 'User', 4, 'update', 'apiKey', NULL, '154413d8c292ad77497f084efecf1da3', '2015-06-25 20:42:36', NULL, 0),
(1851, 'User', 4, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1852, 'User', 5, 'update', 'apiKey', NULL, 'f5d8e7a228d7ab2ffb4ac2d5254dcfba', '2015-06-25 20:42:36', NULL, 0),
(1853, 'User', 5, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1854, 'Affectation', 15, 'update', 'idResource', NULL, '5', '2015-06-25 20:42:36', NULL, 0),
(1855, 'User', 6, 'update', 'apiKey', NULL, '04b6870607489958284551cf605b5c59', '2015-06-25 20:42:36', NULL, 0),
(1856, 'User', 6, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1857, 'Affectation', 16, 'update', 'idResource', NULL, '6', '2015-06-25 20:42:36', NULL, 0),
(1858, 'User', 8, 'update', 'apiKey', NULL, 'f2a3a9c843208ce20dd2ebb1599155c9', '2015-06-25 20:42:36', NULL, 0),
(1859, 'User', 8, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1860, 'User', 9, 'update', 'apiKey', NULL, '15c97db66fe436b3f727a8a99bae2b44', '2015-06-25 20:42:36', NULL, 0),
(1861, 'User', 9, 'update', 'passwordChangeDate', NULL, '2015-06-25', '2015-06-25 20:42:36', NULL, 0),
(1862, 'Attachment', 1, 'update', 'subDirectory', 'D:\\TEMP\\attachement_1\\', 'D:\\TEMP\\attachment_1\\', '2015-06-25 20:42:37', NULL, 0),
(1863, 'Anomaly', 3, 'update', 'subDirectory|Attachment|1', 'D:\\TEMP\\attachement_1\\', 'D:\\TEMP\\attachment_1\\', '2015-06-25 20:42:37', NULL, 0),
(1864, 'Attachment', 2, 'update', 'subDirectory', '../files/attach//attachement_2/', '../files/attach//attachment_2/', '2015-06-25 20:42:37', NULL, 0),
(1865, 'Ticket', 1, 'update', 'subDirectory|Attachment|2', '../files/attach//attachement_2/', '../files/attach//attachment_2/', '2015-06-25 20:42:37', NULL, 0),
(1866, 'Attachment', 6, 'update', 'subDirectory', '${attachementDirectory}\\attachement_6\\', '${attachmentDirectory}\\attachment_6\\', '2015-06-25 20:42:37', NULL, 0),
(1867, 'Ticket', 2, 'update', 'subDirectory|Attachment|6', '${attachementDirectory}\\attachement_6\\', '${attachmentDirectory}\\attachment_6\\', '2015-06-25 20:42:37', NULL, 0),
(1868, 'Attachment', 7, 'update', 'subDirectory', '${attachementDirectory}\\attachement_7\\', '${attachmentDirectory}\\attachment_7\\', '2015-06-25 20:42:37', NULL, 0),
(1869, 'Ticket', 2, 'update', 'subDirectory|Attachment|7', '${attachementDirectory}\\attachement_7\\', '${attachmentDirectory}\\attachment_7\\', '2015-06-25 20:42:37', NULL, 0),
(1870, 'ProjectPlanningElement', 1, 'update', 'plannedEndDate', '2015-01-07', '2015-08-19', '2015-06-25 20:44:08', 1, 0),
(1871, 'ProjectPlanningElement', 1, 'update', 'plannedDuration', '867', '1027', '2015-06-25 20:44:08', 1, 0),
(1872, 'ProjectPlanningElement', 2, 'update', 'plannedEndDate', '2015-01-07', '2015-08-19', '2015-06-25 20:44:08', 1, 0),
(1873, 'ProjectPlanningElement', 2, 'update', 'plannedDuration', '736', '896', '2015-06-25 20:44:08', 1, 0),
(1874, 'ActivityPlanningElement', 7, 'update', 'plannedEndDate', '2015-01-07', '2015-08-19', '2015-06-25 20:44:08', 1, 0),
(1875, 'ActivityPlanningElement', 7, 'update', 'plannedEndFraction', '1.00000', '0.2', '2015-06-25 20:44:08', 1, 0),
(1876, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '736', '896', '2015-06-25 20:44:08', 1, 0),
(1877, 'ProjectPlanningElement', 3, 'update', 'plannedEndDate', '2014-01-27', '2015-07-24', '2015-06-25 20:44:08', 1, 0),
(1878, 'ProjectPlanningElement', 3, 'update', 'plannedDuration', '620', '1009', '2015-06-25 20:44:08', 1, 0),
(1879, 'ActivityPlanningElement', 8, 'update', 'plannedEndDate', '2014-01-21', '2015-07-20', '2015-06-25 20:44:08', 1, 0),
(1880, 'ActivityPlanningElement', 8, 'update', 'plannedDuration', '616', '1005', '2015-06-25 20:44:08', 1, 0),
(1881, 'ActivityPlanningElement', 9, 'update', 'plannedEndDate', '2014-01-10', '2015-07-08', '2015-06-25 20:44:08', 1, 0),
(1882, 'ActivityPlanningElement', 9, 'update', 'plannedDuration', '609', '997', '2015-06-25 20:44:08', 1, 0),
(1883, 'ActivityPlanningElement', 10, 'update', 'plannedStartDate', '2014-01-13', '2015-07-09', '2015-06-25 20:44:08', 1, 0),
(1884, 'ActivityPlanningElement', 10, 'update', 'plannedStartFraction', '0.00000', '0.5', '2015-06-25 20:44:08', 1, 0),
(1885, 'ActivityPlanningElement', 10, 'update', 'plannedEndDate', '2014-01-15', '2015-07-14', '2015-06-25 20:44:08', 1, 0),
(1886, 'ActivityPlanningElement', 10, 'update', 'plannedDuration', '3', '4', '2015-06-25 20:44:08', 1, 0),
(1887, 'ActivityPlanningElement', 11, 'update', 'plannedStartDate', '2014-01-16', '2015-07-15', '2015-06-25 20:44:08', 1, 0),
(1888, 'ActivityPlanningElement', 11, 'update', 'plannedEndDate', '2014-01-20', '2015-07-17', '2015-06-25 20:44:08', 1, 0),
(1889, 'MilestonePlanningElement', 12, 'update', 'plannedStartDate', '2014-01-21', '2015-07-20', '2015-06-25 20:44:08', 1, 0),
(1890, 'MilestonePlanningElement', 12, 'update', 'plannedEndDate', '2014-01-21', '2015-07-20', '2015-06-25 20:44:08', 1, 0),
(1891, 'MilestonePlanningElement', 12, 'update', 'plannedEndFraction', '1.00000', '0.00000', '2015-06-25 20:44:08', 1, 0),
(1892, 'ActivityPlanningElement', 13, 'update', 'plannedStartDate', '2014-01-21', '2015-07-20', '2015-06-25 20:44:08', 1, 0),
(1893, 'ActivityPlanningElement', 13, 'update', 'plannedEndDate', '2014-01-27', '2015-07-24', '2015-06-25 20:44:08', 1, 0),
(1894, 'TestSessionPlanningElement', 15, 'update', 'plannedStartDate', '2014-01-07', '2015-06-25', '2015-06-25 20:44:08', 1, 0),
(1895, 'TestSessionPlanningElement', 15, 'update', 'plannedStartFraction', '0.00000', '0.5', '2015-06-25 20:44:08', 1, 0),
(1896, 'TestSessionPlanningElement', 15, 'update', 'plannedEndDate', '2014-01-07', '2015-06-25', '2015-06-25 20:44:08', 1, 0),
(1897, 'TestSessionPlanningElement', 15, 'update', 'plannedEndFraction', '1.00000', '0.9', '2015-06-25 20:44:08', 1, 0),
(1898, 'ProjectPlanningElement', 4, 'update', 'plannedEndDate', '2015-01-12', '2015-08-24', '2015-06-25 20:44:08', 1, 0),
(1899, 'ProjectPlanningElement', 4, 'update', 'plannedDuration', '734', '894', '2015-06-25 20:44:08', 1, 0),
(1900, 'ActivityPlanningElement', 14, 'update', 'plannedEndDate', '2015-01-12', '2015-08-24', '2015-06-25 20:44:08', 1, 0),
(1901, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '734', '894', '2015-06-25 20:44:08', 1, 0),
(1902, 'ProjectPlanningElement', 1, 'update', 'initialStartDate', NULL, '2011-09-05', '2015-06-25 20:44:14', 1, 0),
(1903, 'ProjectPlanningElement', 1, 'update', 'validatedStartDate', NULL, '2011-09-05', '2015-06-25 20:44:14', 1, 0),
(1904, 'ProjectPlanningElement', 1, 'update', 'initialEndDate', NULL, '2015-08-19', '2015-06-25 20:44:14', 1, 0),
(1905, 'ProjectPlanningElement', 1, 'update', 'validatedEndDate', NULL, '2015-08-19', '2015-06-25 20:44:14', 1, 0),
(1906, 'ProjectPlanningElement', 1, 'update', 'initialDuration', NULL, '1027', '2015-06-25 20:44:14', 1, 0),
(1907, 'ProjectPlanningElement', 1, 'update', 'validatedDuration', NULL, '1027', '2015-06-25 20:44:14', 1, 0),
(1908, 'ProjectPlanningElement', 2, 'update', 'initialStartDate', NULL, '2012-03-05', '2015-06-25 20:44:14', 1, 0),
(1909, 'ProjectPlanningElement', 2, 'update', 'validatedStartDate', NULL, '2012-03-05', '2015-06-25 20:44:14', 1, 0),
(1910, 'ProjectPlanningElement', 2, 'update', 'initialEndDate', NULL, '2015-08-19', '2015-06-25 20:44:14', 1, 0),
(1911, 'ProjectPlanningElement', 2, 'update', 'validatedEndDate', NULL, '2015-08-19', '2015-06-25 20:44:14', 1, 0),
(1912, 'ProjectPlanningElement', 2, 'update', 'initialDuration', NULL, '896', '2015-06-25 20:44:14', 1, 0),
(1913, 'ProjectPlanningElement', 2, 'update', 'validatedDuration', NULL, '896', '2015-06-25 20:44:14', 1, 0),
(1914, 'ActivityPlanningElement', 7, 'update', 'initialStartDate', NULL, '2012-03-05', '2015-06-25 20:44:15', 1, 0),
(1915, 'ActivityPlanningElement', 7, 'update', 'validatedStartDate', '2011-09-01', '2012-03-05', '2015-06-25 20:44:15', 1, 0),
(1916, 'ActivityPlanningElement', 7, 'update', 'initialEndDate', NULL, '2015-08-19', '2015-06-25 20:44:15', 1, 0),
(1917, 'ActivityPlanningElement', 7, 'update', 'validatedEndDate', '2014-12-31', '2015-08-19', '2015-06-25 20:44:15', 1, 0),
(1918, 'ActivityPlanningElement', 7, 'update', 'initialDuration', NULL, '896', '2015-06-25 20:44:15', 1, 0),
(1919, 'ActivityPlanningElement', 7, 'update', 'validatedDuration', '864', '896', '2015-06-25 20:44:15', 1, 0),
(1920, 'ProjectPlanningElement', 3, 'update', 'initialStartDate', NULL, '2011-09-05', '2015-06-25 20:44:15', 1, 0),
(1921, 'ProjectPlanningElement', 3, 'update', 'validatedStartDate', NULL, '2011-09-05', '2015-06-25 20:44:15', 1, 0),
(1922, 'ProjectPlanningElement', 3, 'update', 'initialEndDate', NULL, '2015-07-24', '2015-06-25 20:44:15', 1, 0),
(1923, 'ProjectPlanningElement', 3, 'update', 'validatedEndDate', NULL, '2015-07-24', '2015-06-25 20:44:15', 1, 0),
(1924, 'ProjectPlanningElement', 3, 'update', 'initialDuration', NULL, '1009', '2015-06-25 20:44:15', 1, 0),
(1925, 'ProjectPlanningElement', 3, 'update', 'validatedDuration', NULL, '1009', '2015-06-25 20:44:15', 1, 0),
(1926, 'ActivityPlanningElement', 8, 'update', 'initialStartDate', NULL, '2011-09-05', '2015-06-25 20:44:15', 1, 0),
(1927, 'ActivityPlanningElement', 8, 'update', 'validatedStartDate', NULL, '2011-09-05', '2015-06-25 20:44:15', 1, 0),
(1928, 'ActivityPlanningElement', 8, 'update', 'initialEndDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1929, 'ActivityPlanningElement', 8, 'update', 'validatedEndDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1930, 'ActivityPlanningElement', 8, 'update', 'initialDuration', NULL, '1005', '2015-06-25 20:44:15', 1, 0),
(1931, 'ActivityPlanningElement', 8, 'update', 'validatedDuration', NULL, '1005', '2015-06-25 20:44:15', 1, 0),
(1932, 'ActivityPlanningElement', 9, 'update', 'initialStartDate', NULL, '2011-09-05', '2015-06-25 20:44:15', 1, 0),
(1933, 'ActivityPlanningElement', 9, 'update', 'validatedStartDate', NULL, '2011-09-05', '2015-06-25 20:44:15', 1, 0),
(1934, 'ActivityPlanningElement', 9, 'update', 'initialEndDate', NULL, '2015-07-08', '2015-06-25 20:44:15', 1, 0),
(1935, 'ActivityPlanningElement', 9, 'update', 'validatedEndDate', NULL, '2015-07-08', '2015-06-25 20:44:15', 1, 0),
(1936, 'ActivityPlanningElement', 9, 'update', 'initialDuration', NULL, '997', '2015-06-25 20:44:15', 1, 0),
(1937, 'ActivityPlanningElement', 9, 'update', 'validatedDuration', NULL, '997', '2015-06-25 20:44:15', 1, 0),
(1938, 'ActivityPlanningElement', 10, 'update', 'initialStartDate', NULL, '2015-07-09', '2015-06-25 20:44:15', 1, 0),
(1939, 'ActivityPlanningElement', 10, 'update', 'validatedStartDate', NULL, '2015-07-09', '2015-06-25 20:44:15', 1, 0),
(1940, 'ActivityPlanningElement', 10, 'update', 'initialEndDate', NULL, '2015-07-14', '2015-06-25 20:44:15', 1, 0),
(1941, 'ActivityPlanningElement', 10, 'update', 'validatedEndDate', NULL, '2015-07-14', '2015-06-25 20:44:15', 1, 0),
(1942, 'ActivityPlanningElement', 10, 'update', 'initialDuration', NULL, '4', '2015-06-25 20:44:15', 1, 0),
(1943, 'ActivityPlanningElement', 10, 'update', 'validatedDuration', NULL, '4', '2015-06-25 20:44:15', 1, 0),
(1944, 'ActivityPlanningElement', 11, 'update', 'initialStartDate', NULL, '2015-07-15', '2015-06-25 20:44:15', 1, 0),
(1945, 'ActivityPlanningElement', 11, 'update', 'validatedStartDate', NULL, '2015-07-15', '2015-06-25 20:44:15', 1, 0),
(1946, 'ActivityPlanningElement', 11, 'update', 'initialEndDate', NULL, '2015-07-17', '2015-06-25 20:44:15', 1, 0),
(1947, 'ActivityPlanningElement', 11, 'update', 'validatedEndDate', NULL, '2015-07-17', '2015-06-25 20:44:15', 1, 0),
(1948, 'ActivityPlanningElement', 11, 'update', 'initialDuration', NULL, '3', '2015-06-25 20:44:15', 1, 0),
(1949, 'ActivityPlanningElement', 11, 'update', 'validatedDuration', NULL, '3', '2015-06-25 20:44:15', 1, 0),
(1950, 'MilestonePlanningElement', 12, 'update', 'initialStartDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1951, 'MilestonePlanningElement', 12, 'update', 'validatedStartDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1952, 'MilestonePlanningElement', 12, 'update', 'initialEndDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1953, 'MilestonePlanningElement', 12, 'update', 'validatedEndDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1954, 'MilestonePlanningElement', 12, 'update', 'initialDuration', '0', '1', '2015-06-25 20:44:15', 1, 0),
(1955, 'MilestonePlanningElement', 12, 'update', 'validatedDuration', '0', '1', '2015-06-25 20:44:15', 1, 0),
(1956, 'ActivityPlanningElement', 13, 'update', 'initialStartDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1957, 'ActivityPlanningElement', 13, 'update', 'validatedStartDate', NULL, '2015-07-20', '2015-06-25 20:44:15', 1, 0),
(1958, 'ActivityPlanningElement', 13, 'update', 'initialEndDate', NULL, '2015-07-24', '2015-06-25 20:44:15', 1, 0),
(1959, 'ActivityPlanningElement', 13, 'update', 'validatedEndDate', NULL, '2015-07-24', '2015-06-25 20:44:15', 1, 0),
(1960, 'ActivityPlanningElement', 13, 'update', 'initialDuration', NULL, '5', '2015-06-25 20:44:15', 1, 0),
(1961, 'TestSessionPlanningElement', 15, 'update', 'initialStartDate', NULL, '2015-06-25', '2015-06-25 20:44:15', 1, 0),
(1962, 'TestSessionPlanningElement', 15, 'update', 'validatedStartDate', '2014-01-07', '2015-06-25', '2015-06-25 20:44:15', 1, 0),
(1963, 'TestSessionPlanningElement', 15, 'update', 'initialEndDate', NULL, '2015-06-25', '2015-06-25 20:44:15', 1, 0),
(1964, 'TestSessionPlanningElement', 15, 'update', 'validatedEndDate', '2014-01-09', '2015-06-25', '2015-06-25 20:44:15', 1, 0),
(1965, 'TestSessionPlanningElement', 15, 'update', 'initialDuration', NULL, '1', '2015-06-25 20:44:15', 1, 0),
(1966, 'TestSessionPlanningElement', 15, 'update', 'validatedDuration', '3', '1', '2015-06-25 20:44:15', 1, 0),
(1967, 'ProjectPlanningElement', 4, 'update', 'initialStartDate', NULL, '2012-03-12', '2015-06-25 20:44:15', 1, 0),
(1968, 'ProjectPlanningElement', 4, 'update', 'validatedStartDate', NULL, '2012-03-12', '2015-06-25 20:44:15', 1, 0),
(1969, 'ProjectPlanningElement', 4, 'update', 'initialEndDate', NULL, '2015-08-24', '2015-06-25 20:44:15', 1, 0),
(1970, 'ProjectPlanningElement', 4, 'update', 'validatedEndDate', NULL, '2015-08-24', '2015-06-25 20:44:15', 1, 0),
(1971, 'ProjectPlanningElement', 4, 'update', 'initialDuration', NULL, '894', '2015-06-25 20:44:15', 1, 0),
(1972, 'ProjectPlanningElement', 4, 'update', 'validatedDuration', NULL, '894', '2015-06-25 20:44:15', 1, 0),
(1973, 'ActivityPlanningElement', 14, 'update', 'initialStartDate', NULL, '2012-03-12', '2015-06-25 20:44:15', 1, 0),
(1974, 'ActivityPlanningElement', 14, 'update', 'validatedStartDate', '2013-12-30', '2012-03-12', '2015-06-25 20:44:15', 1, 0),
(1975, 'ActivityPlanningElement', 14, 'update', 'initialEndDate', NULL, '2015-08-24', '2015-06-25 20:44:15', 1, 0),
(1976, 'ActivityPlanningElement', 14, 'update', 'validatedEndDate', '2014-01-31', '2015-08-24', '2015-06-25 20:44:15', 1, 0),
(1977, 'ActivityPlanningElement', 14, 'update', 'initialDuration', NULL, '894', '2015-06-25 20:44:15', 1, 0),
(1978, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', '25', '894', '2015-06-25 20:44:15', 1, 0),
(1979, 'Bill', 1, 'update', 'reference', NULL, 'BILL10000_FR', '2015-10-26 17:47:19', NULL, 0),
(1980, 'WorkPeriod', 2, 'insert', NULL, NULL, NULL, '2015-10-26 17:50:47', 1, 0),
(1981, 'Assignment', 3, 'update', 'realWork', '5.70000', '3.2', '2015-10-26 17:50:47', 1, 0),
(1982, 'Assignment', 3, 'update', 'leftWork', '10.00000', '12.5', '2015-10-26 17:50:47', 1, 0),
(1983, 'Assignment', 3, 'update', 'realStartDate', '2011-09-05', '2011-10-10', '2015-10-26 17:50:47', 1, 0),
(1984, 'Assignment', 3, 'update', 'realCost', '1710.00', '960', '2015-10-26 17:50:47', 1, 0),
(1985, 'Assignment', 3, 'update', 'leftCost', '3000.00', '3750', '2015-10-26 17:50:47', 1, 0),
(1986, 'ActivityPlanningElement', 9, 'update', 'plannedStartDate', '2011-09-05', '2011-10-10', '2015-10-26 17:50:48', 1, 1),
(1987, 'ActivityPlanningElement', 9, 'update', 'realStartDate', '2011-09-05', '2011-10-10', '2015-10-26 17:50:48', 1, 1),
(1988, 'ActivityPlanningElement', 9, 'update', 'plannedDuration', '997', '972', '2015-10-26 17:50:48', 1, 1),
(1989, 'ActivityPlanningElement', 9, 'update', 'realWork', '5.70000', '3.2', '2015-10-26 17:50:48', 1, 1),
(1990, 'ActivityPlanningElement', 9, 'update', 'leftWork', '10.00000', '12.5', '2015-10-26 17:50:48', 1, 1),
(1991, 'ActivityPlanningElement', 9, 'update', 'realCost', '1710.00', '960', '2015-10-26 17:50:48', 1, 1),
(1992, 'ActivityPlanningElement', 9, 'update', 'leftCost', '3000.00', '3750', '2015-10-26 17:50:48', 1, 1),
(1993, 'ActivityPlanningElement', 9, 'update', 'progress', '36', '20', '2015-10-26 17:50:48', 1, 1),
(1994, 'ActivityPlanningElement', 9, 'update', 'expectedProgress', '57', '32', '2015-10-26 17:50:48', 1, 1),
(1995, 'ActivityPlanningElement', 9, 'update', 'workElementEstimatedWork', NULL, '0', '2015-10-26 17:50:48', 1, 1),
(1996, 'ActivityPlanningElement', 9, 'update', 'workElementRealWork', NULL, '0', '2015-10-26 17:50:48', 1, 1),
(1997, 'ActivityPlanningElement', 9, 'update', 'workElementLeftWork', NULL, '0', '2015-10-26 17:50:48', 1, 1),
(1998, 'ActivityPlanningElement', 8, 'update', 'plannedStartDate', '2011-09-05', '2011-10-10', '2015-10-26 17:50:48', 1, 1),
(1999, 'ActivityPlanningElement', 8, 'update', 'realStartDate', '2011-09-05', '2011-10-10', '2015-10-26 17:50:48', 1, 1),
(2000, 'ActivityPlanningElement', 8, 'update', 'plannedDuration', '1005', '980', '2015-10-26 17:50:48', 1, 1),
(2001, 'ActivityPlanningElement', 8, 'update', 'validatedWork', NULL, '10', '2015-10-26 17:50:48', 1, 1),
(2002, 'ActivityPlanningElement', 8, 'update', 'realWork', '5.70000', '3.2', '2015-10-26 17:50:48', 1, 1),
(2003, 'ActivityPlanningElement', 8, 'update', 'leftWork', '23.00000', '25.5', '2015-10-26 17:50:48', 1, 1),
(2004, 'ActivityPlanningElement', 8, 'update', 'realCost', '1710.00', '960', '2015-10-26 17:50:48', 1, 1),
(2005, 'ActivityPlanningElement', 8, 'update', 'leftCost', '6100.00', '6850', '2015-10-26 17:50:48', 1, 1),
(2006, 'ActivityPlanningElement', 8, 'update', 'progress', '20', '11', '2015-10-26 17:50:48', 1, 1),
(2007, 'ActivityPlanningElement', 8, 'update', 'expectedProgress', '0', '32', '2015-10-26 17:50:48', 1, 1),
(2008, 'ActivityPlanningElement', 8, 'update', 'workElementEstimatedWork', NULL, '0', '2015-10-26 17:50:48', 1, 1),
(2009, 'ActivityPlanningElement', 8, 'update', 'workElementRealWork', NULL, '0', '2015-10-26 17:50:48', 1, 1),
(2010, 'ActivityPlanningElement', 8, 'update', 'workElementLeftWork', NULL, '0', '2015-10-26 17:50:48', 1, 1),
(2011, 'ActivityPlanningElement', 8, 'update', 'validatedCalculated', '0', '1', '2015-10-26 17:50:48', 1, 1),
(2012, 'WorkPeriod', 3, 'insert', NULL, NULL, NULL, '2015-10-26 17:51:28', 1, 0),
(2013, 'Assignment', 3, 'update', 'realWork', '3.20000', '0', '2015-10-26 17:51:28', 1, 0),
(2014, 'Assignment', 3, 'update', 'leftWork', '12.50000', '15.7', '2015-10-26 17:51:28', 1, 0),
(2015, 'Assignment', 3, 'update', 'realStartDate', '2011-10-10', NULL, '2015-10-26 17:51:28', 1, 0),
(2016, 'Assignment', 3, 'update', 'realEndDate', '2011-10-13', NULL, '2015-10-26 17:51:28', 1, 0),
(2017, 'Assignment', 3, 'update', 'realCost', '960.00', '0', '2015-10-26 17:51:28', 1, 0),
(2018, 'Assignment', 3, 'update', 'leftCost', '3750.00', '4710', '2015-10-26 17:51:28', 1, 0),
(2019, 'ActivityPlanningElement', 9, 'update', 'plannedStartDate', '2011-10-10', '2015-06-25', '2015-10-26 17:51:28', 1, 1),
(2020, 'ActivityPlanningElement', 9, 'update', 'realStartDate', '2011-10-10', NULL, '2015-10-26 17:51:28', 1, 1),
(2021, 'ActivityPlanningElement', 9, 'update', 'plannedDuration', '972', '10', '2015-10-26 17:51:28', 1, 1),
(2022, 'ActivityPlanningElement', 9, 'update', 'realWork', '3.20000', '0', '2015-10-26 17:51:28', 1, 1),
(2023, 'ActivityPlanningElement', 9, 'update', 'leftWork', '12.50000', '15.7', '2015-10-26 17:51:28', 1, 1),
(2024, 'ActivityPlanningElement', 9, 'update', 'realCost', '960.00', '0', '2015-10-26 17:51:28', 1, 1),
(2025, 'ActivityPlanningElement', 9, 'update', 'leftCost', '3750.00', '4710', '2015-10-26 17:51:28', 1, 1),
(2026, 'ActivityPlanningElement', 9, 'update', 'progress', '20', '0', '2015-10-26 17:51:28', 1, 1),
(2027, 'ActivityPlanningElement', 9, 'update', 'expectedProgress', '32', '0', '2015-10-26 17:51:28', 1, 1),
(2028, 'ActivityPlanningElement', 8, 'update', 'plannedStartDate', '2011-10-10', '2015-06-25', '2015-10-26 17:51:28', 1, 1),
(2029, 'ActivityPlanningElement', 8, 'update', 'realStartDate', '2011-10-10', NULL, '2015-10-26 17:51:28', 1, 1),
(2030, 'ActivityPlanningElement', 8, 'update', 'plannedDuration', '980', '18', '2015-10-26 17:51:28', 1, 1),
(2031, 'ActivityPlanningElement', 8, 'update', 'realWork', '3.20000', '0', '2015-10-26 17:51:28', 1, 1),
(2032, 'ActivityPlanningElement', 8, 'update', 'leftWork', '25.50000', '28.7', '2015-10-26 17:51:28', 1, 1),
(2033, 'ActivityPlanningElement', 8, 'update', 'realCost', '960.00', '0', '2015-10-26 17:51:28', 1, 1),
(2034, 'ActivityPlanningElement', 8, 'update', 'leftCost', '6850.00', '7810', '2015-10-26 17:51:28', 1, 1),
(2035, 'ActivityPlanningElement', 8, 'update', 'progress', '11', '0', '2015-10-26 17:51:28', 1, 1),
(2036, 'ActivityPlanningElement', 8, 'update', 'expectedProgress', '32', '0', '2015-10-26 17:51:28', 1, 1),
(2037, 'WorkPeriod', 4, 'insert', NULL, NULL, NULL, '2015-10-26 17:52:36', 1, 0),
(2038, 'Assignment', 2, 'update', 'realWork', '8.50000', '4.3', '2015-10-26 17:52:36', 1, 0),
(2039, 'Assignment', 2, 'update', 'leftWork', '66.70000', '70.9', '2015-10-26 17:52:36', 1, 0),
(2040, 'Assignment', 2, 'update', 'realStartDate', '2012-03-05', '2012-03-12', '2015-10-26 17:52:36', 1, 0),
(2041, 'Assignment', 2, 'update', 'realCost', '1870.00', '946', '2015-10-26 17:52:36', 1, 0),
(2042, 'Assignment', 2, 'update', 'leftCost', '14674.00', '15598', '2015-10-26 17:52:36', 1, 0),
(2043, 'ActivityPlanningElement', 7, 'update', 'plannedStartDate', '2012-03-05', '2012-03-12', '2015-10-26 17:52:36', 1, 1),
(2044, 'ActivityPlanningElement', 7, 'update', 'realStartDate', '2012-03-05', '2012-03-12', '2015-10-26 17:52:36', 1, 1),
(2045, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '896', '891', '2015-10-26 17:52:36', 1, 1),
(2046, 'ActivityPlanningElement', 7, 'update', 'realWork', '10.50000', '6.3', '2015-10-26 17:52:36', 1, 1),
(2047, 'ActivityPlanningElement', 7, 'update', 'leftWork', '74.70000', '78.9', '2015-10-26 17:52:36', 1, 1),
(2048, 'ActivityPlanningElement', 7, 'update', 'realCost', '2870.00', '1946', '2015-10-26 17:52:36', 1, 1),
(2049, 'ActivityPlanningElement', 7, 'update', 'leftCost', '18674.00', '19598', '2015-10-26 17:52:36', 1, 1),
(2050, 'ActivityPlanningElement', 7, 'update', 'progress', '12', '7', '2015-10-26 17:52:36', 1, 1),
(2051, 'ActivityPlanningElement', 7, 'update', 'expectedProgress', '11', '6', '2015-10-26 17:52:36', 1, 1),
(2052, 'ActivityPlanningElement', 7, 'update', 'workElementEstimatedWork', NULL, '0', '2015-10-26 17:52:36', 1, 1),
(2053, 'ActivityPlanningElement', 7, 'update', 'workElementRealWork', NULL, '0', '2015-10-26 17:52:36', 1, 1),
(2054, 'ActivityPlanningElement', 7, 'update', 'workElementLeftWork', NULL, '0', '2015-10-26 17:52:36', 1, 1),
(2055, 'Assignment', 7, 'update', 'realWork', NULL, '0', '2015-10-26 17:52:37', 1, 0),
(2056, 'Assignment', 7, 'update', 'realCost', NULL, '0', '2015-10-26 17:52:37', 1, 0),
(2057, 'WorkPeriod', 5, 'insert', NULL, NULL, NULL, '2015-10-26 17:52:50', 1, 0),
(2058, 'Assignment', 2, 'update', 'realWork', '4.30000', '0', '2015-10-26 17:52:50', 1, 0),
(2059, 'Assignment', 2, 'update', 'leftWork', '70.90000', '75.2', '2015-10-26 17:52:50', 1, 0),
(2060, 'Assignment', 2, 'update', 'realStartDate', '2012-03-12', NULL, '2015-10-26 17:52:50', 1, 0),
(2061, 'Assignment', 2, 'update', 'realEndDate', '2012-03-16', NULL, '2015-10-26 17:52:50', 1, 0),
(2062, 'Assignment', 2, 'update', 'realCost', '946.00', '0', '2015-10-26 17:52:50', 1, 0),
(2063, 'Assignment', 2, 'update', 'leftCost', '15598.00', '16544', '2015-10-26 17:52:50', 1, 0),
(2064, 'ActivityPlanningElement', 7, 'update', 'plannedStartDate', '2012-03-12', '2013-12-30', '2015-10-26 17:52:50', 1, 1),
(2065, 'ActivityPlanningElement', 7, 'update', 'realStartDate', '2012-03-12', '2013-12-30', '2015-10-26 17:52:50', 1, 1),
(2066, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '891', '428', '2015-10-26 17:52:50', 1, 1),
(2067, 'ActivityPlanningElement', 7, 'update', 'realWork', '6.30000', '2', '2015-10-26 17:52:50', 1, 1),
(2068, 'ActivityPlanningElement', 7, 'update', 'leftWork', '78.90000', '83.2', '2015-10-26 17:52:50', 1, 1),
(2069, 'ActivityPlanningElement', 7, 'update', 'realCost', '1946.00', '1000', '2015-10-26 17:52:50', 1, 1),
(2070, 'ActivityPlanningElement', 7, 'update', 'leftCost', '19598.00', '20544', '2015-10-26 17:52:50', 1, 1),
(2071, 'ActivityPlanningElement', 7, 'update', 'progress', '7', '2', '2015-10-26 17:52:50', 1, 1),
(2072, 'ActivityPlanningElement', 7, 'update', 'expectedProgress', '6', '2', '2015-10-26 17:52:50', 1, 1),
(2073, 'WorkPeriod', 6, 'insert', NULL, NULL, NULL, '2015-10-26 17:53:15', 1, 0),
(2074, 'Assignment', 6, 'update', 'realWork', '7.00000', '2', '2015-10-26 17:53:16', 1, 0),
(2075, 'Assignment', 6, 'update', 'leftWork', '2.00000', '7', '2015-10-26 17:53:16', 1, 0),
(2076, 'Assignment', 6, 'update', 'realStartDate', '2012-03-12', '2013-12-31', '2015-10-26 17:53:16', 1, 0),
(2077, 'Assignment', 6, 'update', 'realCost', '3500.00', '1000', '2015-10-26 17:53:16', 1, 0),
(2078, 'Assignment', 6, 'update', 'leftCost', '1000.00', '3500', '2015-10-26 17:53:16', 1, 0),
(2079, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2012-03-12', '2013-12-31', '2015-10-26 17:53:16', 1, 1),
(2080, 'ActivityPlanningElement', 14, 'update', 'realStartDate', '2012-03-12', '2013-12-31', '2015-10-26 17:53:16', 1, 1),
(2081, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '894', '430', '2015-10-26 17:53:16', 1, 1),
(2082, 'ActivityPlanningElement', 14, 'update', 'realWork', '7.00000', '2', '2015-10-26 17:53:16', 1, 1),
(2083, 'ActivityPlanningElement', 14, 'update', 'leftWork', '2.00000', '7', '2015-10-26 17:53:16', 1, 1),
(2084, 'ActivityPlanningElement', 14, 'update', 'realCost', '3500.00', '1000', '2015-10-26 17:53:16', 1, 1),
(2085, 'ActivityPlanningElement', 14, 'update', 'leftCost', '1000.00', '3500', '2015-10-26 17:53:16', 1, 1),
(2086, 'ActivityPlanningElement', 14, 'update', 'progress', '78', '22', '2015-10-26 17:53:16', 1, 1),
(2087, 'ActivityPlanningElement', 14, 'update', 'workElementEstimatedWork', NULL, '0', '2015-10-26 17:53:16', 1, 1),
(2088, 'ActivityPlanningElement', 14, 'update', 'workElementRealWork', NULL, '0', '2015-10-26 17:53:16', 1, 1),
(2089, 'ActivityPlanningElement', 14, 'update', 'workElementLeftWork', NULL, '0', '2015-10-26 17:53:16', 1, 1),
(2090, 'Ticket', 1, 'update', 'idStatus', '9', '8', '2015-10-26 17:54:25', 1, 0),
(2091, 'Ticket', 1, 'update', 'handled', '1', '0', '2015-10-26 17:54:25', 1, 0),
(2092, 'Ticket', 1, 'update', 'handledDateTime', '2011-09-02 01:54:00', NULL, '2015-10-26 17:54:25', 1, 0),
(2093, 'Ticket', 1, 'update', 'idle', '1', '0', '2015-10-26 17:54:25', 1, 0),
(2094, 'Ticket', 1, 'update', 'idleDateTime', '2014-01-04 19:18:00', NULL, '2015-10-26 17:54:25', 1, 0),
(2095, 'Ticket', 1, 'update', 'cancelled', '1', '0', '2015-10-26 17:54:25', 1, 0),
(2096, 'WorkElement', 1, 'update', 'realWork', '13.90417', '13.9', '2015-10-26 17:54:25', 1, 0),
(2097, 'WorkElement', 1, 'update', 'realWork', '13.90000', '0', '2015-10-26 17:54:27', 1, 0),
(2098, 'Assignment', 1, 'update', 'realWork', '2.00000', '0', '2015-10-26 17:55:21', 1, 0),
(2099, 'Assignment', 1, 'update', 'leftWork', '8.00000', '10', '2015-10-26 17:55:21', 1, 0),
(2100, 'Assignment', 1, 'update', 'realStartDate', '2013-12-30', NULL, '2015-10-26 17:55:21', 1, 0),
(2101, 'Assignment', 1, 'update', 'realEndDate', '2013-12-31', NULL, '2015-10-26 17:55:21', 1, 0),
(2102, 'Assignment', 1, 'update', 'realCost', '1000.00', '0', '2015-10-26 17:55:21', 1, 0),
(2103, 'Assignment', 1, 'update', 'leftCost', '4000.00', '5000', '2015-10-26 17:55:21', 1, 0),
(2104, 'ActivityPlanningElement', 7, 'update', 'plannedStartDate', '2013-12-30', '2015-06-25', '2015-10-26 17:55:21', 1, 1),
(2105, 'ActivityPlanningElement', 7, 'update', 'realStartDate', '2013-12-30', NULL, '2015-10-26 17:55:21', 1, 1),
(2106, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '428', '40', '2015-10-26 17:55:21', 1, 1),
(2107, 'ActivityPlanningElement', 7, 'update', 'realWork', '2.00000', '0', '2015-10-26 17:55:21', 1, 1),
(2108, 'ActivityPlanningElement', 7, 'update', 'leftWork', '83.20000', '85.2', '2015-10-26 17:55:21', 1, 1),
(2109, 'ActivityPlanningElement', 7, 'update', 'realCost', '1000.00', '0', '2015-10-26 17:55:21', 1, 1),
(2110, 'ActivityPlanningElement', 7, 'update', 'leftCost', '20544.00', '21544', '2015-10-26 17:55:21', 1, 1),
(2111, 'ActivityPlanningElement', 7, 'update', 'progress', '2', '0', '2015-10-26 17:55:21', 1, 1),
(2112, 'ActivityPlanningElement', 7, 'update', 'expectedProgress', '2', '0', '2015-10-26 17:55:21', 1, 1),
(2113, 'Assignment', 6, 'update', 'realWork', '2.00000', '0', '2015-10-26 17:55:21', 1, 0),
(2114, 'Assignment', 6, 'update', 'leftWork', '7.00000', '9', '2015-10-26 17:55:21', 1, 0),
(2115, 'Assignment', 6, 'update', 'realStartDate', '2013-12-31', NULL, '2015-10-26 17:55:21', 1, 0),
(2116, 'Assignment', 6, 'update', 'realEndDate', '2014-01-01', NULL, '2015-10-26 17:55:21', 1, 0),
(2117, 'Assignment', 6, 'update', 'realCost', '1000.00', '0', '2015-10-26 17:55:21', 1, 0),
(2118, 'Assignment', 6, 'update', 'leftCost', '3500.00', '4500', '2015-10-26 17:55:21', 1, 0),
(2119, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2013-12-31', '2015-08-20', '2015-10-26 17:55:21', 1, 1),
(2120, 'ActivityPlanningElement', 14, 'update', 'realStartDate', '2013-12-31', NULL, '2015-10-26 17:55:21', 1, 1),
(2121, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '430', '3', '2015-10-26 17:55:21', 1, 1),
(2122, 'ActivityPlanningElement', 14, 'update', 'realWork', '2.00000', '0', '2015-10-26 17:55:21', 1, 1),
(2123, 'ActivityPlanningElement', 14, 'update', 'leftWork', '7.00000', '9', '2015-10-26 17:55:21', 1, 1),
(2124, 'ActivityPlanningElement', 14, 'update', 'realCost', '1000.00', '0', '2015-10-26 17:55:21', 1, 1),
(2125, 'ActivityPlanningElement', 14, 'update', 'leftCost', '3500.00', '4500', '2015-10-26 17:55:21', 1, 1),
(2126, 'ActivityPlanningElement', 14, 'update', 'progress', '22', '0', '2015-10-26 17:55:21', 1, 1),
(2127, 'ProjectPlanningElement', 1, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2128, 'ProjectPlanningElement', 1, 'update', 'plannedEndDate', '2015-08-19', '2016-01-01', '2015-10-26 17:55:46', 1, 0),
(2129, 'ProjectPlanningElement', 1, 'update', 'plannedDuration', '40', '50', '2015-10-26 17:55:46', 1, 0),
(2130, 'ProjectPlanningElement', 2, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2131, 'ProjectPlanningElement', 2, 'update', 'plannedEndDate', '2015-08-19', '2016-01-01', '2015-10-26 17:55:46', 1, 0),
(2132, 'ProjectPlanningElement', 2, 'update', 'plannedDuration', '40', '50', '2015-10-26 17:55:46', 1, 0);
INSERT INTO `history` (`id`, `refType`, `refId`, `operation`, `colName`, `oldValue`, `newValue`, `operationDate`, `idUser`, `isWorkHistory`) VALUES
(2133, 'ActivityPlanningElement', 7, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2134, 'ActivityPlanningElement', 7, 'update', 'plannedEndDate', '2015-08-19', '2016-01-01', '2015-10-26 17:55:46', 1, 0),
(2135, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '40', '50', '2015-10-26 17:55:46', 1, 0),
(2136, 'ProjectPlanningElement', 3, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2137, 'ProjectPlanningElement', 3, 'update', 'plannedEndDate', '2015-07-24', '2015-12-02', '2015-10-26 17:55:46', 1, 0),
(2138, 'ProjectPlanningElement', 3, 'update', 'plannedDuration', '22', '28', '2015-10-26 17:55:46', 1, 0),
(2139, 'ActivityPlanningElement', 8, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2140, 'ActivityPlanningElement', 8, 'update', 'plannedEndDate', '2015-07-20', '2015-11-26', '2015-10-26 17:55:46', 1, 0),
(2141, 'ActivityPlanningElement', 8, 'update', 'plannedDuration', '18', '24', '2015-10-26 17:55:46', 1, 0),
(2142, 'ActivityPlanningElement', 9, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2143, 'ActivityPlanningElement', 9, 'update', 'plannedEndDate', '2015-07-08', '2015-11-16', '2015-10-26 17:55:46', 1, 0),
(2144, 'ActivityPlanningElement', 9, 'update', 'plannedEndFraction', '1.00000', '0.7', '2015-10-26 17:55:46', 1, 0),
(2145, 'ActivityPlanningElement', 9, 'update', 'plannedDuration', '10', '16', '2015-10-26 17:55:46', 1, 0),
(2146, 'ActivityPlanningElement', 10, 'update', 'plannedStartDate', '2015-07-09', '2015-11-17', '2015-10-26 17:55:46', 1, 0),
(2147, 'ActivityPlanningElement', 10, 'update', 'plannedEndDate', '2015-07-14', '2015-11-20', '2015-10-26 17:55:46', 1, 0),
(2148, 'ActivityPlanningElement', 11, 'update', 'plannedStartDate', '2015-07-15', '2015-11-23', '2015-10-26 17:55:46', 1, 0),
(2149, 'ActivityPlanningElement', 11, 'update', 'plannedEndDate', '2015-07-17', '2015-11-25', '2015-10-26 17:55:46', 1, 0),
(2150, 'MilestonePlanningElement', 12, 'update', 'plannedStartDate', '2015-07-20', '2015-11-26', '2015-10-26 17:55:46', 1, 0),
(2151, 'MilestonePlanningElement', 12, 'update', 'plannedEndDate', '2015-07-20', '2015-11-26', '2015-10-26 17:55:46', 1, 0),
(2152, 'ActivityPlanningElement', 13, 'update', 'plannedStartDate', '2015-07-20', '2015-11-26', '2015-10-26 17:55:46', 1, 0),
(2153, 'ActivityPlanningElement', 13, 'update', 'plannedEndDate', '2015-07-24', '2015-12-02', '2015-10-26 17:55:46', 1, 0),
(2154, 'TestSessionPlanningElement', 15, 'update', 'plannedStartDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2155, 'TestSessionPlanningElement', 15, 'update', 'plannedEndDate', '2015-06-25', '2015-10-26', '2015-10-26 17:55:46', 1, 0),
(2156, 'ProjectPlanningElement', 4, 'update', 'plannedStartDate', '2015-08-20', '2016-01-04', '2015-10-26 17:55:46', 1, 0),
(2157, 'ProjectPlanningElement', 4, 'update', 'plannedEndDate', '2015-08-24', '2016-02-29', '2015-10-26 17:55:46', 1, 0),
(2158, 'ProjectPlanningElement', 4, 'update', 'plannedDuration', '3', '41', '2015-10-26 17:55:46', 1, 0),
(2159, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2015-08-20', '2016-01-04', '2015-10-26 17:55:46', 1, 0),
(2160, 'ActivityPlanningElement', 14, 'update', 'plannedEndDate', '2015-08-24', '2016-02-29', '2015-10-26 17:55:46', 1, 0),
(2161, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '3', '41', '2015-10-26 17:55:46', 1, 0),
(2162, 'ProjectPlanningElement', 1, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2163, 'ProjectPlanningElement', 1, 'update', 'plannedEndDate', '2016-01-01', '2016-01-08', '2015-10-26 17:56:12', 1, 0),
(2164, 'ProjectPlanningElement', 2, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2165, 'ProjectPlanningElement', 2, 'update', 'plannedEndDate', '2016-01-01', '2016-01-08', '2015-10-26 17:56:12', 1, 0),
(2166, 'ActivityPlanningElement', 7, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2167, 'ActivityPlanningElement', 7, 'update', 'plannedEndDate', '2016-01-01', '2016-01-08', '2015-10-26 17:56:12', 1, 0),
(2168, 'ProjectPlanningElement', 3, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2169, 'ProjectPlanningElement', 3, 'update', 'plannedEndDate', '2015-12-02', '2015-12-09', '2015-10-26 17:56:12', 1, 0),
(2170, 'ActivityPlanningElement', 8, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2171, 'ActivityPlanningElement', 8, 'update', 'plannedEndDate', '2015-11-26', '2015-12-03', '2015-10-26 17:56:12', 1, 0),
(2172, 'ActivityPlanningElement', 9, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2173, 'ActivityPlanningElement', 9, 'update', 'plannedEndDate', '2015-11-16', '2015-11-23', '2015-10-26 17:56:12', 1, 0),
(2174, 'ActivityPlanningElement', 10, 'update', 'plannedStartDate', '2015-11-17', '2015-11-24', '2015-10-26 17:56:12', 1, 0),
(2175, 'ActivityPlanningElement', 10, 'update', 'plannedEndDate', '2015-11-20', '2015-11-27', '2015-10-26 17:56:12', 1, 0),
(2176, 'ActivityPlanningElement', 11, 'update', 'plannedStartDate', '2015-11-23', '2015-11-30', '2015-10-26 17:56:12', 1, 0),
(2177, 'ActivityPlanningElement', 11, 'update', 'plannedEndDate', '2015-11-25', '2015-12-02', '2015-10-26 17:56:12', 1, 0),
(2178, 'MilestonePlanningElement', 12, 'update', 'plannedStartDate', '2015-11-26', '2015-12-03', '2015-10-26 17:56:12', 1, 0),
(2179, 'MilestonePlanningElement', 12, 'update', 'plannedEndDate', '2015-11-26', '2015-12-03', '2015-10-26 17:56:12', 1, 0),
(2180, 'ActivityPlanningElement', 13, 'update', 'plannedStartDate', '2015-11-26', '2015-12-03', '2015-10-26 17:56:12', 1, 0),
(2181, 'ActivityPlanningElement', 13, 'update', 'plannedEndDate', '2015-12-02', '2015-12-09', '2015-10-26 17:56:12', 1, 0),
(2182, 'TestSessionPlanningElement', 15, 'update', 'plannedStartDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2183, 'TestSessionPlanningElement', 15, 'update', 'plannedEndDate', '2015-10-26', '2015-11-02', '2015-10-26 17:56:12', 1, 0),
(2184, 'ProjectPlanningElement', 4, 'update', 'plannedStartDate', '2016-01-04', '2016-01-11', '2015-10-26 17:56:12', 1, 0),
(2185, 'ProjectPlanningElement', 4, 'update', 'plannedEndDate', '2016-02-29', '2016-03-07', '2015-10-26 17:56:12', 1, 0),
(2186, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2016-01-04', '2016-01-11', '2015-10-26 17:56:12', 1, 0),
(2187, 'ActivityPlanningElement', 14, 'update', 'plannedEndDate', '2016-02-29', '2016-03-07', '2015-10-26 17:56:12', 1, 0),
(2188, 'ProjectPlanningElement', 1, 'update', 'validatedStartDate', '2011-09-05', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2189, 'ProjectPlanningElement', 1, 'update', 'validatedEndDate', '2015-08-19', '2016-01-08', '2015-10-26 17:56:21', 1, 0),
(2190, 'ProjectPlanningElement', 1, 'update', 'validatedDuration', '1027', '50', '2015-10-26 17:56:21', 1, 0),
(2191, 'ProjectPlanningElement', 2, 'update', 'validatedStartDate', '2012-03-05', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2192, 'ProjectPlanningElement', 2, 'update', 'validatedEndDate', '2015-08-19', '2016-01-08', '2015-10-26 17:56:21', 1, 0),
(2193, 'ProjectPlanningElement', 2, 'update', 'validatedDuration', '896', '50', '2015-10-26 17:56:21', 1, 0),
(2194, 'ActivityPlanningElement', 7, 'update', 'validatedStartDate', '2012-03-05', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2195, 'ActivityPlanningElement', 7, 'update', 'validatedEndDate', '2015-08-19', '2016-01-08', '2015-10-26 17:56:21', 1, 0),
(2196, 'ActivityPlanningElement', 7, 'update', 'validatedDuration', '896', '50', '2015-10-26 17:56:21', 1, 0),
(2197, 'ProjectPlanningElement', 3, 'update', 'validatedStartDate', '2011-09-05', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2198, 'ProjectPlanningElement', 3, 'update', 'validatedEndDate', '2015-07-24', '2015-12-09', '2015-10-26 17:56:21', 1, 0),
(2199, 'ProjectPlanningElement', 3, 'update', 'validatedDuration', '1009', '28', '2015-10-26 17:56:21', 1, 0),
(2200, 'ActivityPlanningElement', 8, 'update', 'validatedStartDate', '2011-09-05', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2201, 'ActivityPlanningElement', 8, 'update', 'validatedEndDate', '2015-07-20', '2015-12-03', '2015-10-26 17:56:21', 1, 0),
(2202, 'ActivityPlanningElement', 8, 'update', 'validatedDuration', '1005', '24', '2015-10-26 17:56:21', 1, 0),
(2203, 'ActivityPlanningElement', 9, 'update', 'validatedStartDate', '2011-09-05', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2204, 'ActivityPlanningElement', 9, 'update', 'validatedEndDate', '2015-07-08', '2015-11-23', '2015-10-26 17:56:21', 1, 0),
(2205, 'ActivityPlanningElement', 9, 'update', 'validatedDuration', '997', '16', '2015-10-26 17:56:21', 1, 0),
(2206, 'ActivityPlanningElement', 10, 'update', 'validatedStartDate', '2015-07-09', '2015-11-24', '2015-10-26 17:56:21', 1, 0),
(2207, 'ActivityPlanningElement', 10, 'update', 'validatedEndDate', '2015-07-14', '2015-11-27', '2015-10-26 17:56:21', 1, 0),
(2208, 'ActivityPlanningElement', 11, 'update', 'validatedStartDate', '2015-07-15', '2015-11-30', '2015-10-26 17:56:21', 1, 0),
(2209, 'ActivityPlanningElement', 11, 'update', 'validatedEndDate', '2015-07-17', '2015-12-02', '2015-10-26 17:56:21', 1, 0),
(2210, 'MilestonePlanningElement', 12, 'update', 'validatedStartDate', '2015-07-20', '2015-12-03', '2015-10-26 17:56:21', 1, 0),
(2211, 'MilestonePlanningElement', 12, 'update', 'validatedEndDate', '2015-07-20', '2015-12-03', '2015-10-26 17:56:21', 1, 0),
(2212, 'ActivityPlanningElement', 13, 'update', 'validatedStartDate', '2015-07-20', '2015-12-03', '2015-10-26 17:56:21', 1, 0),
(2213, 'ActivityPlanningElement', 13, 'update', 'validatedEndDate', '2015-07-24', '2015-12-09', '2015-10-26 17:56:21', 1, 0),
(2214, 'TestSessionPlanningElement', 15, 'update', 'validatedStartDate', '2015-06-25', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2215, 'TestSessionPlanningElement', 15, 'update', 'validatedEndDate', '2015-06-25', '2015-11-02', '2015-10-26 17:56:21', 1, 0),
(2216, 'ProjectPlanningElement', 4, 'update', 'validatedStartDate', '2012-03-12', '2016-01-11', '2015-10-26 17:56:21', 1, 0),
(2217, 'ProjectPlanningElement', 4, 'update', 'validatedEndDate', '2015-08-24', '2016-03-07', '2015-10-26 17:56:21', 1, 0),
(2218, 'ProjectPlanningElement', 4, 'update', 'validatedDuration', '894', '41', '2015-10-26 17:56:21', 1, 0),
(2219, 'ActivityPlanningElement', 14, 'update', 'validatedStartDate', '2012-03-12', '2016-01-11', '2015-10-26 17:56:21', 1, 0),
(2220, 'ActivityPlanningElement', 14, 'update', 'validatedEndDate', '2015-08-24', '2016-03-07', '2015-10-26 17:56:21', 1, 0),
(2221, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', '894', '41', '2015-10-26 17:56:21', 1, 0),
(2222, 'Dependency', 9, 'insert', NULL, NULL, NULL, '2015-10-26 17:56:35', 1, 0),
(2223, 'TestSessionPlanningElement', 15, 'update', 'plannedStartDate', '2015-11-02', '2015-12-03', '2015-10-26 17:56:35', 1, 0),
(2224, 'TestSessionPlanningElement', 15, 'update', 'plannedEndDate', '2015-11-02', NULL, '2015-10-26 17:56:35', 1, 0),
(2225, 'TestSessionPlanningElement', 15, 'update', 'plannedDuration', '1', NULL, '2015-10-26 17:56:35', 1, 0),
(2226, 'Dependency', 10, 'insert', NULL, NULL, NULL, '2015-10-26 17:56:41', 1, 0),
(2227, 'TestSessionPlanningElement', 15, 'update', 'plannedStartDate', '2015-12-03', '2015-11-30', '2015-10-26 17:56:41', 1, 0),
(2228, 'Dependency', 9, 'delete', NULL, NULL, NULL, '2015-10-26 17:56:52', 1, 0),
(2229, 'ExpenseDetailType', 5, 'delete', NULL, NULL, NULL, '2015-10-26 17:57:56', 1, 0),
(2230, 'ProjectPlanningElement', 1, 'update', 'plannedEndDate', '2016-01-08', '2016-02-05', '2015-10-26 17:58:20', 1, 0),
(2231, 'ProjectPlanningElement', 1, 'update', 'plannedDuration', '50', '70', '2015-10-26 17:58:20', 1, 0),
(2232, 'ProjectPlanningElement', 2, 'update', 'plannedEndDate', '2016-01-08', '2016-02-05', '2015-10-26 17:58:20', 1, 0),
(2233, 'ProjectPlanningElement', 2, 'update', 'plannedDuration', '50', '70', '2015-10-26 17:58:20', 1, 0),
(2234, 'ActivityPlanningElement', 7, 'update', 'plannedEndDate', '2016-01-08', '2016-02-05', '2015-10-26 17:58:20', 1, 0),
(2235, 'ActivityPlanningElement', 7, 'update', 'plannedEndFraction', '0.20000', '0.14', '2015-10-26 17:58:20', 1, 0),
(2236, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '50', '70', '2015-10-26 17:58:20', 1, 0),
(2237, 'ProjectPlanningElement', 3, 'update', 'plannedEndDate', '2015-12-09', '2015-12-08', '2015-10-26 17:58:20', 1, 0),
(2238, 'ProjectPlanningElement', 3, 'update', 'plannedDuration', '28', '27', '2015-10-26 17:58:20', 1, 0),
(2239, 'ActivityPlanningElement', 8, 'update', 'plannedEndDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:20', 1, 0),
(2240, 'ActivityPlanningElement', 8, 'update', 'plannedDuration', '24', '23', '2015-10-26 17:58:20', 1, 0),
(2241, 'ActivityPlanningElement', 10, 'update', 'plannedStartFraction', '0.50000', '0.1', '2015-10-26 17:58:20', 1, 0),
(2242, 'ActivityPlanningElement', 10, 'update', 'plannedEndDate', '2015-11-27', '2015-11-26', '2015-10-26 17:58:20', 1, 0),
(2243, 'ActivityPlanningElement', 10, 'update', 'plannedEndFraction', '1.00000', '0.3', '2015-10-26 17:58:20', 1, 0),
(2244, 'ActivityPlanningElement', 10, 'update', 'plannedDuration', '4', '3', '2015-10-26 17:58:20', 1, 0),
(2245, 'ActivityPlanningElement', 11, 'update', 'plannedStartDate', '2015-11-30', '2015-11-27', '2015-10-26 17:58:20', 1, 0),
(2246, 'ActivityPlanningElement', 11, 'update', 'plannedEndDate', '2015-12-02', '2015-12-01', '2015-10-26 17:58:20', 1, 0),
(2247, 'MilestonePlanningElement', 12, 'update', 'plannedStartDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:20', 1, 0),
(2248, 'MilestonePlanningElement', 12, 'update', 'plannedEndDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:20', 1, 0),
(2249, 'ActivityPlanningElement', 13, 'update', 'plannedStartDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:20', 1, 0),
(2250, 'ActivityPlanningElement', 13, 'update', 'plannedEndDate', '2015-12-09', '2015-12-08', '2015-10-26 17:58:20', 1, 0),
(2251, 'TestSessionPlanningElement', 15, 'update', 'plannedStartDate', '2015-11-30', '2015-11-27', '2015-10-26 17:58:20', 1, 0),
(2252, 'TestSessionPlanningElement', 15, 'update', 'plannedStartFraction', '0.50000', '0.1', '2015-10-26 17:58:20', 1, 0),
(2253, 'TestSessionPlanningElement', 15, 'update', 'plannedEndDate', NULL, '2015-11-27', '2015-10-26 17:58:20', 1, 0),
(2254, 'TestSessionPlanningElement', 15, 'update', 'plannedEndFraction', '0.90000', '0.5', '2015-10-26 17:58:20', 1, 0),
(2255, 'TestSessionPlanningElement', 15, 'update', 'plannedDuration', NULL, '1', '2015-10-26 17:58:20', 1, 0),
(2256, 'ProjectPlanningElement', 4, 'update', 'plannedStartDate', '2016-01-11', '2016-02-09', '2015-10-26 17:58:20', 1, 0),
(2257, 'ProjectPlanningElement', 4, 'update', 'plannedDuration', '41', '20', '2015-10-26 17:58:20', 1, 0),
(2258, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2016-01-11', '2016-02-09', '2015-10-26 17:58:21', 1, 0),
(2259, 'ActivityPlanningElement', 14, 'update', 'plannedEndFraction', '1.00000', '0.5', '2015-10-26 17:58:21', 1, 0),
(2260, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '41', '20', '2015-10-26 17:58:21', 1, 0),
(2261, 'TestSessionPlanningElement', 15, 'update', 'validatedEndDate', '2015-11-02', '2015-11-04', '2015-10-26 17:58:36', 1, 0),
(2262, 'TestSessionPlanningElement', 15, 'update', 'validatedDuration', '1', '3', '2015-10-26 17:58:36', 1, 0),
(2263, 'TestSessionPlanningElement', 15, 'update', 'idTestSessionPlanningMode', '9', '14', '2015-10-26 17:58:36', 1, 0),
(2264, 'TestSessionPlanningElement', 15, 'update', 'plannedEndDate', '2015-11-27', '2015-12-01', '2015-10-26 17:58:43', 1, 0),
(2265, 'TestSessionPlanningElement', 15, 'update', 'plannedDuration', '1', '3', '2015-10-26 17:58:43', 1, 0),
(2266, 'ProjectPlanningElement', 1, 'update', 'validatedEndDate', '2016-01-08', '2016-02-05', '2015-10-26 17:58:48', 1, 0),
(2267, 'ProjectPlanningElement', 1, 'update', 'validatedDuration', '50', '70', '2015-10-26 17:58:48', 1, 0),
(2268, 'ProjectPlanningElement', 2, 'update', 'validatedEndDate', '2016-01-08', '2016-02-05', '2015-10-26 17:58:48', 1, 0),
(2269, 'ProjectPlanningElement', 2, 'update', 'validatedDuration', '50', '70', '2015-10-26 17:58:48', 1, 0),
(2270, 'ActivityPlanningElement', 7, 'update', 'validatedEndDate', '2016-01-08', '2016-02-05', '2015-10-26 17:58:48', 1, 0),
(2271, 'ActivityPlanningElement', 7, 'update', 'validatedDuration', '50', '70', '2015-10-26 17:58:48', 1, 0),
(2272, 'ProjectPlanningElement', 3, 'update', 'validatedEndDate', '2015-12-09', '2015-12-08', '2015-10-26 17:58:48', 1, 0),
(2273, 'ProjectPlanningElement', 3, 'update', 'validatedDuration', '28', '27', '2015-10-26 17:58:48', 1, 0),
(2274, 'ActivityPlanningElement', 8, 'update', 'validatedEndDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:48', 1, 0),
(2275, 'ActivityPlanningElement', 8, 'update', 'validatedDuration', '24', '23', '2015-10-26 17:58:48', 1, 0),
(2276, 'ActivityPlanningElement', 10, 'update', 'validatedEndDate', '2015-11-27', '2015-11-26', '2015-10-26 17:58:48', 1, 0),
(2277, 'ActivityPlanningElement', 10, 'update', 'validatedDuration', '4', '3', '2015-10-26 17:58:48', 1, 0),
(2278, 'ActivityPlanningElement', 11, 'update', 'validatedStartDate', '2015-11-30', '2015-11-27', '2015-10-26 17:58:48', 1, 0),
(2279, 'ActivityPlanningElement', 11, 'update', 'validatedEndDate', '2015-12-02', '2015-12-01', '2015-10-26 17:58:48', 1, 0),
(2280, 'MilestonePlanningElement', 12, 'update', 'validatedStartDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:48', 1, 0),
(2281, 'MilestonePlanningElement', 12, 'update', 'validatedEndDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:48', 1, 0),
(2282, 'ActivityPlanningElement', 13, 'update', 'validatedStartDate', '2015-12-03', '2015-12-02', '2015-10-26 17:58:48', 1, 0),
(2283, 'ActivityPlanningElement', 13, 'update', 'validatedEndDate', '2015-12-09', '2015-12-08', '2015-10-26 17:58:48', 1, 0),
(2284, 'TestSessionPlanningElement', 15, 'update', 'validatedStartDate', '2015-11-02', '2015-11-27', '2015-10-26 17:58:48', 1, 0),
(2285, 'TestSessionPlanningElement', 15, 'update', 'validatedEndDate', '2015-11-04', '2015-12-01', '2015-10-26 17:58:48', 1, 0),
(2286, 'ProjectPlanningElement', 4, 'update', 'validatedStartDate', '2016-01-11', '2016-02-09', '2015-10-26 17:58:48', 1, 0),
(2287, 'ProjectPlanningElement', 4, 'update', 'validatedDuration', '41', '20', '2015-10-26 17:58:48', 1, 0),
(2288, 'ActivityPlanningElement', 14, 'update', 'validatedStartDate', '2016-01-11', '2016-02-09', '2015-10-26 17:58:48', 1, 0),
(2289, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', '41', '20', '2015-10-26 17:58:48', 1, 0),
(2290, 'Dependency', 5, 'delete', NULL, NULL, NULL, '2015-10-26 17:59:22', 1, 0),
(2291, 'ProjectPlanningElement', 1, 'update', 'plannedEndDate', '2016-02-05', '2016-02-29', '2015-10-26 17:59:25', 1, 0),
(2292, 'ProjectPlanningElement', 1, 'update', 'plannedDuration', '70', '86', '2015-10-26 17:59:25', 1, 0),
(2293, 'ProjectPlanningElement', 2, 'update', 'plannedEndDate', '2016-02-05', '2016-02-29', '2015-10-26 17:59:25', 1, 0),
(2294, 'ProjectPlanningElement', 2, 'update', 'plannedDuration', '70', '86', '2015-10-26 17:59:25', 1, 0),
(2295, 'ActivityPlanningElement', 7, 'update', 'plannedEndDate', '2016-02-05', '2016-02-29', '2015-10-26 17:59:25', 1, 0),
(2296, 'ActivityPlanningElement', 7, 'update', 'plannedDuration', '70', '86', '2015-10-26 17:59:25', 1, 0),
(2297, 'ProjectPlanningElement', 4, 'update', 'plannedStartDate', '2016-02-09', '2016-02-10', '2015-10-26 17:59:25', 1, 0),
(2298, 'ProjectPlanningElement', 4, 'update', 'plannedDuration', '20', '19', '2015-10-26 17:59:25', 1, 0),
(2299, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2016-02-09', '2016-02-10', '2015-10-26 17:59:25', 1, 0),
(2300, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '20', '19', '2015-10-26 17:59:25', 1, 0),
(2301, 'ActivityPlanningElement', 14, 'update', 'validatedStartDate', '2016-02-09', '2015-11-02', '2015-10-26 18:00:22', 1, 0),
(2302, 'ActivityPlanningElement', 14, 'update', 'validatedEndDate', '2016-03-07', '2016-01-29', '2015-10-26 18:00:22', 1, 0),
(2303, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', '20', '65', '2015-10-26 18:00:22', 1, 0),
(2304, 'ProjectPlanningElement', 4, 'update', 'plannedStartDate', '2016-02-10', '2015-11-05', '2015-10-26 18:00:27', 1, 0),
(2305, 'ProjectPlanningElement', 4, 'update', 'plannedEndDate', '2016-03-07', '2016-01-29', '2015-10-26 18:00:27', 1, 0),
(2306, 'ProjectPlanningElement', 4, 'update', 'plannedDuration', '19', '62', '2015-10-26 18:00:27', 1, 0),
(2307, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2016-02-10', '2015-11-05', '2015-10-26 18:00:27', 1, 0),
(2308, 'ActivityPlanningElement', 14, 'update', 'plannedStartFraction', '0.00000', '0.5', '2015-10-26 18:00:27', 1, 0),
(2309, 'ActivityPlanningElement', 14, 'update', 'plannedEndDate', '2016-03-07', '2016-01-29', '2015-10-26 18:00:27', 1, 0),
(2310, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '19', '62', '2015-10-26 18:00:27', 1, 0),
(2311, 'ActivityPlanningElement', 14, 'update', 'validatedEndDate', '2016-01-29', '2016-02-29', '2015-10-26 18:00:40', 1, 0),
(2312, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', '65', '86', '2015-10-26 18:00:40', 1, 0),
(2313, 'ProjectPlanningElement', 4, 'update', 'plannedStartDate', '2015-11-05', '2015-11-06', '2015-10-26 18:00:43', 1, 0),
(2314, 'ProjectPlanningElement', 4, 'update', 'plannedEndDate', '2016-01-29', '2016-02-29', '2015-10-26 18:00:43', 1, 0),
(2315, 'ProjectPlanningElement', 4, 'update', 'plannedDuration', '62', '82', '2015-10-26 18:00:43', 1, 0),
(2316, 'ActivityPlanningElement', 14, 'update', 'plannedStartDate', '2015-11-05', '2015-11-06', '2015-10-26 18:00:43', 1, 0),
(2317, 'ActivityPlanningElement', 14, 'update', 'plannedStartFraction', '0.50000', '0', '2015-10-26 18:00:43', 1, 0),
(2318, 'ActivityPlanningElement', 14, 'update', 'plannedEndDate', '2016-01-29', '2016-02-29', '2015-10-26 18:00:43', 1, 0),
(2319, 'ActivityPlanningElement', 14, 'update', 'plannedDuration', '62', '82', '2015-10-26 18:00:43', 1, 0),
(2320, 'ProjectPlanningElement', 1, 'update', 'validatedEndDate', '2016-02-05', '2016-02-29', '2015-10-26 18:00:47', 1, 0),
(2321, 'ProjectPlanningElement', 1, 'update', 'validatedDuration', '70', '86', '2015-10-26 18:00:47', 1, 0),
(2322, 'ProjectPlanningElement', 2, 'update', 'validatedEndDate', '2016-02-05', '2016-02-29', '2015-10-26 18:00:47', 1, 0),
(2323, 'ProjectPlanningElement', 2, 'update', 'validatedDuration', '70', '86', '2015-10-26 18:00:47', 1, 0),
(2324, 'ActivityPlanningElement', 7, 'update', 'validatedEndDate', '2016-02-05', '2016-02-29', '2015-10-26 18:00:47', 1, 0),
(2325, 'ActivityPlanningElement', 7, 'update', 'validatedDuration', '70', '86', '2015-10-26 18:00:47', 1, 0),
(2326, 'ProjectPlanningElement', 4, 'update', 'validatedStartDate', '2016-02-09', '2015-11-06', '2015-10-26 18:00:48', 1, 0),
(2327, 'ProjectPlanningElement', 4, 'update', 'validatedEndDate', '2016-03-07', '2016-02-29', '2015-10-26 18:00:48', 1, 0),
(2328, 'ProjectPlanningElement', 4, 'update', 'validatedDuration', '20', '82', '2015-10-26 18:00:48', 1, 0),
(2329, 'ActivityPlanningElement', 14, 'update', 'validatedStartDate', '2015-11-02', '2015-11-06', '2015-10-26 18:00:48', 1, 0),
(2330, 'ActivityPlanningElement', 14, 'update', 'validatedDuration', '86', '82', '2015-10-26 18:00:48', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `importable`
--

CREATE TABLE `importable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `importable`
--

INSERT INTO `importable` (`id`, `name`, `idle`) VALUES
(1, 'Ticket', 0),
(2, 'Activity', 0),
(3, 'Milestone', 0),
(4, 'Risk', 0),
(5, 'Action', 0),
(6, 'Issue', 0),
(7, 'Meeting', 0),
(8, 'Decision', 0),
(9, 'Question', 0),
(10, 'IndividualExpense', 0),
(11, 'ProjectExpense', 0),
(12, 'Client', 0),
(13, 'Contact', 0),
(14, 'Project', 0),
(15, 'Team', 0),
(16, 'Resource', 0),
(17, 'Affectation', 0),
(18, 'Assignment', 0),
(19, 'Product', 0),
(20, 'ProductVersion', 0),
(21, 'Document', 0),
(22, 'Requirement', 0),
(23, 'TestCase', 0),
(24, 'TestSession', 0),
(25, 'TestCaseRun', 0),
(26, 'Opportunity', 0),
(27, 'Command', 0),
(28, 'Quotation', 0),
(29, 'Work', 0),
(30, 'Component', 0),
(31, 'ComponentVersion', 0),
(32, 'ProductStructure', 0),
(33, 'Bill', 0),
(34, 'Payment', 0),
(35, 'ResourceCost', 0),
(42, 'DocumentDirectory', 0);

-- --------------------------------------------------------

--
-- Structure de la table `importlog`
--

CREATE TABLE `importlog` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `mode` varchar(10) DEFAULT 'manual',
  `importDateTime` datetime DEFAULT NULL,
  `importFile` varchar(1000) DEFAULT NULL,
  `importClass` varchar(100) DEFAULT NULL,
  `importStatus` varchar(10) DEFAULT NULL,
  `importTodo` int(6) DEFAULT NULL,
  `importDone` int(6) DEFAULT NULL,
  `importDoneCreated` int(6) DEFAULT NULL,
  `importDoneModified` int(6) DEFAULT NULL,
  `importDoneUnchanged` int(6) DEFAULT NULL,
  `importRejected` int(6) DEFAULT NULL,
  `importRejectedInvalid` int(6) DEFAULT NULL,
  `importRejectedError` int(6) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `indicator`
--

CREATE TABLE `indicator` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `targetDateColumnName` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `indicator`
--

INSERT INTO `indicator` (`id`, `name`, `code`, `type`, `sortOrder`, `idle`, `targetDateColumnName`) VALUES
(1, 'initialDueDateTime', 'IDDT', 'delay', 110, 0, NULL),
(2, 'actualDueDateTime', 'ADDT', 'delay', 120, 0, NULL),
(3, 'initialDueDate', 'IDD', 'delay', 130, 0, NULL),
(4, 'actualDueDate', 'ADD', 'delay', 140, 0, NULL),
(5, 'initialEndDate', 'IED', 'delay', 150, 0, NULL),
(6, 'validatedEndDate', 'VED', 'delay', 160, 0, NULL),
(7, 'plannedEndDate', 'PED', 'delay', 170, 0, NULL),
(8, 'initialStartDate', 'ISD', 'delay', 180, 0, NULL),
(9, 'validatedStartDate', 'VSD', 'delay', 190, 0, NULL),
(10, 'plannedStartDate', 'PSD', 'delay', 200, 0, NULL),
(11, 'PlannedCostOverValidatedCost', 'PCOVC', 'percent', 210, 0, NULL),
(12, 'PlannedCostOverAssignedCost', 'PCOAC', 'percent', 220, 0, NULL),
(13, 'PlannedWorkOverValidatedWork', 'PWOVW', 'percent', 230, 0, NULL),
(14, 'PlannedWorkOverAssignedWork', 'PWOAW', 'percent', 240, 0, NULL),
(15, 'RealWorkOverValidatedWork', 'RWOVW', 'percent', 250, 0, NULL),
(16, 'RealWorkOverAssignedWork', 'RWOAW', 'percent', 260, 0, NULL),
(17, 'expectedTenderDateTime', 'DELAY', 'delay', 310, 0, 'receptionDateTime'),
(18, 'expensePlannedDate', 'DELAY', 'delay', 320, 0, 'expenseRealDate'),
(19, 'deliveryDate', 'DELAY', 'delay', 330, 0, 'receptionDate'),
(20, 'validityEndDate', 'DELAY', 'delay', 340, 0, 'idleDate'),
(21, 'validatedDate', 'DELAY', 'delay', 350, 0, 'idBill'),
(22, 'plannedDate', 'DELAY', 'delay', 360, 0, 'idBill'),
(23, 'date', 'DELAY', 'delay', 370, 0, 'idBill'),
(24, 'paymentDueDate', 'DELAY', 'delay', 380, 0, 'paymentDate'),
(25, 'meetingDate', 'DELAY', 'delay', 390, 0, 'done'),
(26, 'date', 'DELAY', 'delay', 400, 0, 'sendDate');

-- --------------------------------------------------------

--
-- Structure de la table `indicatorable`
--

CREATE TABLE `indicatorable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `indicatorable`
--

INSERT INTO `indicatorable` (`id`, `name`, `idle`) VALUES
(1, 'Ticket', 0),
(2, 'Activity', 0),
(3, 'Milestone', 0),
(4, 'Risk', 0),
(5, 'Action', 0),
(6, 'Issue', 0),
(7, 'Question', 0),
(8, 'Project', 0),
(9, 'TestSession', 0),
(12, 'Requirement', 0),
(14, 'Tender', 0),
(15, 'IndividualExpense', 0),
(16, 'ProjectExpense', 0),
(17, 'Quotation', 0),
(18, 'Command', 0),
(19, 'Term', 0),
(20, 'Bill', 0),
(21, 'Meeting', 0);

-- --------------------------------------------------------

--
-- Structure de la table `indicatorableindicator`
--

CREATE TABLE `indicatorableindicator` (
  `id` int(12) UNSIGNED NOT NULL,
  `idIndicatorable` int(12) UNSIGNED DEFAULT NULL,
  `nameIndicatorable` varchar(100) DEFAULT NULL,
  `idIndicator` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `indicatorableindicator`
--

INSERT INTO `indicatorableindicator` (`id`, `idIndicatorable`, `nameIndicatorable`, `idIndicator`, `idle`) VALUES
(1, 1, 'Ticket', 1, 0),
(2, 1, 'Ticket', 2, 0),
(3, 4, 'Risk', 3, 0),
(4, 5, 'Action', 3, 0),
(5, 6, 'Issue', 3, 0),
(6, 7, 'Question', 3, 0),
(7, 4, 'Risk', 4, 0),
(8, 5, 'Action', 4, 0),
(9, 6, 'Issue', 4, 0),
(10, 7, 'Question', 4, 0),
(11, 2, 'Activity', 5, 0),
(12, 3, 'Milestone', 5, 0),
(13, 8, 'Project', 5, 0),
(14, 2, 'Activity', 6, 0),
(15, 3, 'Milestone', 6, 0),
(16, 8, 'Project', 6, 0),
(17, 2, 'Activity', 7, 0),
(18, 3, 'Milestone', 7, 0),
(19, 8, 'Project', 7, 0),
(20, 2, 'Activity', 8, 0),
(21, 8, 'Project', 8, 0),
(22, 2, 'Activity', 9, 0),
(23, 8, 'Project', 9, 0),
(24, 2, 'Activity', 10, 0),
(25, 8, 'Project', 10, 0),
(26, 2, 'Activity', 11, 0),
(27, 8, 'Project', 11, 0),
(28, 2, 'Activity', 12, 0),
(29, 8, 'Project', 12, 0),
(30, 2, 'Activity', 13, 0),
(31, 8, 'Project', 13, 0),
(32, 2, 'Activity', 14, 0),
(33, 8, 'Project', 14, 0),
(34, 2, 'Activity', 15, 0),
(35, 8, 'Project', 15, 0),
(36, 2, 'Activity', 16, 0),
(37, 8, 'Project', 16, 0),
(38, 9, 'TestSession', 6, 0),
(39, 9, 'TestSession', 7, 0),
(40, 9, 'TestSession', 8, 0),
(41, 9, 'TestSession', 9, 0),
(42, 9, 'TestSession', 10, 0),
(43, 9, 'TestSession', 11, 0),
(44, 9, 'TestSession', 12, 0),
(45, 9, 'TestSession', 13, 0),
(46, 9, 'TestSession', 14, 0),
(47, 9, 'TestSession', 15, 0),
(48, 9, 'TestSession', 16, 0),
(55, 12, 'Requirement', 3, 0),
(56, 12, 'Requirement', 4, 0),
(57, 14, 'Tender', 17, 0),
(58, 15, 'IndividualExpense', 18, 0),
(59, 16, 'ProjectExpense', 18, 0),
(60, 16, 'ProjectExpense', 19, 0),
(61, 17, 'Quotation', 20, 0),
(62, 18, 'Command', 5, 0),
(63, 18, 'Command', 6, 0),
(64, 19, 'Term', 21, 0),
(65, 19, 'Term', 22, 0),
(66, 19, 'Term', 23, 0),
(67, 20, 'Bill', 24, 0),
(68, 21, 'Meeting', 25, 0),
(69, 20, 'Bill', 26, 0);

-- --------------------------------------------------------

--
-- Structure de la table `indicatordefinition`
--

CREATE TABLE `indicatordefinition` (
  `id` int(12) UNSIGNED NOT NULL,
  `idIndicatorable` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `nameIndicatorable` varchar(100) DEFAULT NULL,
  `idIndicator` int(12) UNSIGNED DEFAULT NULL,
  `codeIndicator` varchar(10) DEFAULT NULL,
  `typeIndicator` varchar(10) DEFAULT NULL,
  `idType` int(12) UNSIGNED DEFAULT NULL,
  `warningValue` decimal(6,3) DEFAULT NULL,
  `idWarningDelayUnit` int(12) UNSIGNED DEFAULT NULL,
  `codeWarningDelayUnit` varchar(10) DEFAULT NULL,
  `alertValue` decimal(6,3) DEFAULT NULL,
  `idAlertDelayUnit` int(12) UNSIGNED DEFAULT NULL,
  `codeAlertDelayUnit` varchar(10) DEFAULT NULL,
  `mailToUser` int(1) UNSIGNED DEFAULT '0',
  `mailToResource` int(1) UNSIGNED DEFAULT '0',
  `mailToProject` int(1) UNSIGNED DEFAULT '0',
  `mailToContact` int(1) UNSIGNED DEFAULT '0',
  `mailToLeader` int(1) UNSIGNED DEFAULT '0',
  `mailToOther` int(1) UNSIGNED DEFAULT '0',
  `alertToUser` int(1) UNSIGNED DEFAULT '0',
  `alertToResource` int(1) UNSIGNED DEFAULT '0',
  `alertToProject` int(1) UNSIGNED DEFAULT '0',
  `alertToContact` int(1) UNSIGNED DEFAULT '0',
  `alertToLeader` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `mailToAssigned` int(1) UNSIGNED DEFAULT '0',
  `mailToManager` int(1) UNSIGNED DEFAULT '0',
  `otherMail` varchar(4000) DEFAULT NULL,
  `alertToAssigned` int(1) UNSIGNED DEFAULT '0',
  `alertToManager` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `indicatordefinition`
--

INSERT INTO `indicatordefinition` (`id`, `idIndicatorable`, `name`, `nameIndicatorable`, `idIndicator`, `codeIndicator`, `typeIndicator`, `idType`, `warningValue`, `idWarningDelayUnit`, `codeWarningDelayUnit`, `alertValue`, `idAlertDelayUnit`, `codeAlertDelayUnit`, `mailToUser`, `mailToResource`, `mailToProject`, `mailToContact`, `mailToLeader`, `mailToOther`, `alertToUser`, `alertToResource`, `alertToProject`, `alertToContact`, `alertToLeader`, `idle`, `mailToAssigned`, `mailToManager`, `otherMail`, `alertToAssigned`, `alertToManager`) VALUES
(1, 1, 'actualDueDateTime', 'Ticket', 2, 'ADDT', 'delay', NULL, '1.000', 1, 'HH', '0.000', 1, 'HH', 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, NULL, 0, 0),
(2, 1, 'initialDueDateTime', 'Ticket', 1, 'IDDT', 'delay', NULL, '0.000', 1, 'HH', NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0),
(3, 2, 'validatedEndDate', 'Activity', 6, 'VED', 'delay', NULL, '1.000', 4, 'OD', '0.000', 1, 'HH', 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, NULL, 0, 0),
(4, 2, 'PlannedWorkOverValidatedWork', 'Activity', 13, 'PWOVW', 'percent', NULL, '100.000', 5, 'PCT', '110.000', 5, 'PCT', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, NULL, 0, 0),
(5, 5, 'actualDueDate', 'Action', 4, 'ADD', 'delay', NULL, '1.000', 4, 'OD', '1.000', 2, 'OH', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, 0, 0),
(6, 3, 'validatedEndDate', 'Milestone', 6, 'VED', 'delay', 25, '1.000', 4, 'OD', NULL, NULL, NULL, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `indicatorvalue`
--

CREATE TABLE `indicatorvalue` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(10) UNSIGNED DEFAULT NULL,
  `idIndicatorDefinition` int(10) UNSIGNED DEFAULT NULL,
  `targetDateTime` datetime DEFAULT NULL,
  `targetValue` decimal(11,2) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `warningTargetDateTime` datetime DEFAULT NULL,
  `warningTargetValue` decimal(11,2) DEFAULT NULL,
  `warningSent` int(1) UNSIGNED DEFAULT '0',
  `alertTargetDateTime` datetime DEFAULT NULL,
  `alertTargetValue` decimal(11,2) DEFAULT NULL,
  `alertSent` int(1) UNSIGNED DEFAULT '0',
  `handled` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `status` varchar(2) DEFAULT NULL,
  `targetDateColumnName` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `indicatorvalue`
--

INSERT INTO `indicatorvalue` (`id`, `refType`, `refId`, `idIndicatorDefinition`, `targetDateTime`, `targetValue`, `code`, `type`, `warningTargetDateTime`, `warningTargetValue`, `warningSent`, `alertTargetDateTime`, `alertTargetValue`, `alertSent`, `handled`, `done`, `idle`, `status`, `targetDateColumnName`) VALUES
(3, 'Ticket', 1, 1, '2011-09-09 18:30:00', NULL, 'ADDT', 'delay', '2011-09-09 17:30:00', NULL, 1, '2011-09-09 17:30:00', NULL, 1, 0, 0, 0, NULL, NULL),
(4, 'Ticket', 1, 2, NULL, NULL, 'IDDT', 'delay', '2011-09-02 18:00:00', NULL, 1, '2011-09-02 18:00:00', NULL, 0, 0, 0, 0, NULL, NULL),
(5, 'Activity', 1, 3, '2015-08-19 00:00:00', NULL, 'VED', 'delay', '2015-08-18 00:00:00', NULL, 1, '2015-08-18 00:00:00', NULL, 1, 1, 0, 0, NULL, NULL),
(6, 'Activity', 1, 4, NULL, '100.00', 'PWOVW', 'percent', NULL, '100.00', 0, NULL, '110.00', 0, 1, 0, 0, NULL, NULL),
(7, 'Activity', 7, 4, NULL, '0.00', 'PWOVW', 'percent', NULL, '0.00', 0, NULL, '0.00', 0, 0, 0, 0, NULL, NULL),
(8, 'Activity', 3, 4, NULL, '10.00', 'PWOVW', 'percent', NULL, '10.00', 1, NULL, '11.00', 1, 0, 0, 0, NULL, NULL),
(9, 'Activity', 7, 3, '2016-02-29 00:00:00', NULL, 'VED', 'delay', '2016-02-26 00:00:00', NULL, 0, '2016-02-26 00:00:00', NULL, 0, 0, 0, 0, NULL, NULL),
(10, 'Activity', 3, 3, '2015-07-08 00:00:00', NULL, 'VED', 'delay', '2015-07-07 00:00:00', NULL, 1, '2015-07-07 00:00:00', NULL, 1, 0, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `issue`
--

CREATE TABLE `issue` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idIssueType` int(12) UNSIGNED DEFAULT NULL,
  `cause` mediumtext,
  `impact` mediumtext,
  `idPriority` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `initialEndDate` date DEFAULT NULL,
  `actualEndDate` date DEFAULT NULL,
  `idleDate` date DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `idCriticality` int(12) UNSIGNED DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `issue`
--

INSERT INTO `issue` (`id`, `idProject`, `name`, `description`, `idIssueType`, `cause`, `impact`, `idPriority`, `creationDate`, `idUser`, `idStatus`, `idResource`, `initialEndDate`, `actualEndDate`, `idleDate`, `result`, `comment`, `idle`, `done`, `doneDate`, `handled`, `handledDate`, `idCriticality`, `reference`, `externalReference`, `cancelled`) VALUES
(1, 1, 'No environment for performance testing', NULL, 4, 'Need to test performance on a correctly size environment, available for 2 week, with production data', 'Not able to test performance', 3, '2012-03-14', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, 3, '001-001-TEC-1', NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `likelihood`
--

CREATE TABLE `likelihood` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` int(3) UNSIGNED DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `valuePct` int(3) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `likelihood`
--

INSERT INTO `likelihood` (`id`, `name`, `value`, `color`, `sortOrder`, `idle`, `valuePct`) VALUES
(1, 'Low (10%)', 1, '#32cd32', 10, 0, 10),
(2, 'Medium (50%)', 2, '#ffd700', 20, 0, 50),
(3, 'High (90%)', 4, '#ff0000', 30, 0, 90);

-- --------------------------------------------------------

--
-- Structure de la table `link`
--

CREATE TABLE `link` (
  `id` int(12) UNSIGNED NOT NULL,
  `ref1Type` varchar(100) DEFAULT NULL,
  `ref1Id` int(12) UNSIGNED NOT NULL,
  `ref2Type` varchar(100) DEFAULT NULL,
  `ref2Id` int(12) UNSIGNED NOT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `link`
--

INSERT INTO `link` (`id`, `ref1Type`, `ref1Id`, `ref2Type`, `ref2Id`, `comment`, `creationDate`, `idUser`) VALUES
(1, 'Action', 1, 'Risk', 1, NULL, NULL, NULL),
(2, 'Action', 1, 'Issue', 1, NULL, NULL, NULL),
(3, 'Issue', 1, 'Risk', 1, NULL, NULL, NULL),
(4, 'Decision', 1, 'Meeting', 1, NULL, NULL, NULL),
(5, 'Meeting', 1, 'Question', 1, NULL, NULL, NULL),
(6, 'Activity', 1, 'Ticket', 1, NULL, '2012-05-05 22:46:00', 1),
(7, 'Meeting', 1, 'Ticket', 1, 'Last meeting', '2012-05-05 22:46:27', 1),
(8, 'Document', 1, 'Ticket', 1, NULL, '2012-05-05 22:53:27', 1),
(9, 'DocumentVersion', 3, 'Ticket', 1, NULL, '2012-05-05 22:54:42', 1),
(10, 'Requirement', 1, 'TestCase', 1, NULL, '2012-08-05 17:05:11', 1),
(11, 'Requirement', 1, 'TestCase', 2, NULL, '2012-08-05 17:06:45', 1),
(12, 'TestSession', 1, 'Ticket', 2, 'Test case #2', NULL, 1),
(13, 'Requirement', 1, 'Ticket', 2, 'Test case #2', NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `linkable`
--

CREATE TABLE `linkable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idDefaultLinkable` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `linkable`
--

INSERT INTO `linkable` (`id`, `name`, `idle`, `idDefaultLinkable`) VALUES
(1, 'Action', 0, 3),
(2, 'Issue', 0, 1),
(3, 'Risk', 0, 1),
(4, 'Meeting', 0, 5),
(5, 'Decision', 0, 4),
(6, 'Question', 0, 4),
(7, 'Ticket', 0, 7),
(8, 'Activity', 0, 8),
(9, 'Milestone', 0, 8),
(10, 'Document', 0, 10),
(11, 'Requirement', 0, 12),
(12, 'TestCase', 0, 11),
(13, 'TestSession', 0, 8),
(14, 'Project', 0, 14),
(15, 'IndividualExpense', 0, 4),
(16, 'ProjectExpense', 0, 8),
(17, 'Opportunity', 0, 1),
(18, 'Command', 0, 14),
(19, 'Quotation', 0, 18);

-- --------------------------------------------------------

--
-- Structure de la table `list`
--

CREATE TABLE `list` (
  `id` int(12) UNSIGNED NOT NULL,
  `list` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `list`
--

INSERT INTO `list` (`id`, `list`, `name`, `code`, `sortOrder`, `idle`) VALUES
(1, 'yesNo', 'displayYes', 'YES', 20, 0),
(2, 'yesNo', 'displayNo', 'NO', 10, 0),
(1000001, 'readWrite', 'displayWrite', 'WRITE', 10, 0),
(1000002, 'readWrite', 'displayReadOnly', 'READ', 20, 0);

-- --------------------------------------------------------

--
-- Structure de la table `mail`
--

CREATE TABLE `mail` (
  `id` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `refType` int(12) UNSIGNED DEFAULT NULL,
  `refId` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `mailDateTime` datetime DEFAULT NULL,
  `mailTo` varchar(4000) DEFAULT NULL,
  `mailTitle` varchar(4000) DEFAULT NULL,
  `mailBody` mediumtext,
  `mailStatus` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `mail`
--

INSERT INTO `mail` (`id`, `idUser`, `idProject`, `refType`, `refId`, `idStatus`, `mailDateTime`, `mailTo`, `mailTitle`, `mailBody`, `mailStatus`, `idle`) VALUES
(1, 1, 1, 1, 1, 1, '2011-09-02 01:45:00', 'project.manager@toolware.fr', '[Project\'Or RIA] Ticket #1 moved to status recorded', '<html>\n<head>\n<title>[Project\'Or RIA] Ticket #1 moved to status recorded</title>\n</head>\n<body>\nThe status of Ticket #1 [bug: it does not work] has changed to\nrecorded<br/>\n<br/>\n<div style="font-weight: bold;">Ticket #1</div><br/>\n<div style="text-decoration:underline;font-weight: bold;">project\n:</div>\nproject one<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">ticket type\n:</div>\nIncident<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">name\n:</div>\nbug: it does not work<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">description\n:</div>\n<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">issuer\n:</div>\nadmin<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">status\n:</div>\nrecorded<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">responsible\n:</div>\n <br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">result\n:</div>\n<br/><br/>\n\n<body>\n</html>', 'ERROR', 0),
(2, 1, 1, 1, 1, 3, '2011-09-02 01:54:00', 'project.manager@toolware.fr', '[Project\'Or RIA] Ticket #1 moved to status in progress', '<html>\n<head>\n<title>[Project\'Or RIA] Ticket #1 moved to status in progress</title>\n</head>\n<body>\nThe status of Ticket #1 [bug: it does not work] has changed to in\nprogress<br/>\n<br/>\n<div style="font-weight: bold;">Ticket #1</div><br/>\n<div style="text-decoration:underline;font-weight: bold;">project\n:</div>\nproject one<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">ticket type\n:</div>\nIncident<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">name\n:</div>\nbug: it does not work<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">description\n:</div>\n<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">issuer\n:</div>\nadmin<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">status\n:</div>\nin progress<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">responsible\n:</div>\nproject manager<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">result\n:</div>\n<br/><br/>\n\n<body>\n</html>', 'ERROR', 0),
(3, 1, 1, 9, 1, 1, '2012-03-15 21:30:00', 'project.manager@toolware.fr', '[Project\'Or RIA] Question #1 moved to status recorded', '<html>\n<head>\n<title>[Project\'Or RIA] Question #1 moved to status recorded</title>\n</head>\n<body>\nThe status of Question #1 [What will be first deployed users] has\nchanged to recorded<br/>\n<br/>\n<div style="font-weight: bold;">Question #1</div><br/>\n<div style="text-decoration:underline;font-weight: bold;">project\n:</div>\nproject one<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">question\ntype :</div>\nFunctional<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">name :</div>\nWhat will be first deployed users<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">description\n:</div>\n<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">issuer\n:</div>\nadmin<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">status\n:</div>\nrecorded<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">responsible\n:</div>\n <br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">response\n:</div>\n<br/><br/>\n\n<body>\n</html>', 'ERROR', 0),
(4, 1, 1, 7, 1, 1, '2012-05-06 16:22:00', 'support@toolware.fr,project.manager@toolware.fr,project.leader@external.com', 'Steering Committee 2012-03-15', 'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//CompanyName//ProductName//EN\r\nMETHOD:REQUEST\r\nBEGIN:VEVENT\r\nORGANIZER;CN=admin:MAILTO:\r\nATTENDEE;CN="admin";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:support@toolware.fr\r\nATTENDEE;CN="project manager";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:project.manager@toolware.fr\r\nATTENDEE;CN="external project leader one";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:project.leader@external.com\r\nUID:20120506T162242-28267-domain.com\r\nDTSTAMP:20120506T162242\r\nDTSTART:20120315T\r\nDTEND:20120315T\r\nSUMMARY:Steering Committee 2012-03-15\r\nDESCRIPTION:\r\nBEGIN:VALARM\r\nTRIGGER:-PT15M\r\nACTION:DISPLAY\r\nDESCRIPTION:Reminder\r\nEND:VALARM\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n', 'ERROR', 0),
(5, 1, 1, 7, 1, 1, '2012-05-06 16:30:00', 'support@toolware.fr,project.manager@toolware.fr,project.leader@external.com', 'Steering Committee 2012-03-15', 'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//CompanyName//ProductName//EN\r\nMETHOD:REQUEST\r\nBEGIN:VEVENT\r\nORGANIZER;CN=admin:MAILTO:\r\nATTENDEE;CN="admin";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:support@toolware.fr\r\nATTENDEE;CN="project manager";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:project.manager@toolware.fr\r\nATTENDEE;CN="external project leader one";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:project.leader@external.com\r\nUID:20120506T163023-19912-domain.com\r\nDTSTAMP:20120506T163023\r\nDTSTART:20120315T\r\nDTEND:20120315T\r\nSUMMARY:Steering Committee 2012-03-15\r\nDESCRIPTION:\r\nBEGIN:VALARM\r\nTRIGGER:-PT15M\r\nACTION:DISPLAY\r\nDESCRIPTION:Reminder\r\nEND:VALARM\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n', 'OK', 0),
(6, 1, 1, 7, 1, 1, '2012-05-06 16:33:00', 'support@toolware.fr,project.manager@toolware.fr,project.leader@external.com', 'Steering Committee 2012-03-15', 'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//CompanyName//ProductName//EN\r\nMETHOD:REQUEST\r\nBEGIN:VEVENT\r\nORGANIZER;CN=admin:MAILTO:\r\nATTENDEE;CN="admin";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:support@toolware.fr\r\nATTENDEE;CN="project manager";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:project.manager@toolware.fr\r\nATTENDEE;CN="external project leader one";ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:project.leader@external.com\r\nUID:20120506T163320-11933-domain.com\r\nDTSTAMP:20120506T163320\r\nDTSTART:20120315T160000\r\nDTEND:20120315T18:00:00\r\nSUMMARY:Steering Committee 2012-03-15\r\nDESCRIPTION:\r\nBEGIN:VALARM\r\nTRIGGER:-PT15M\r\nACTION:DISPLAY\r\nDESCRIPTION:Reminder\r\nEND:VALARM\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n', 'OK', 0),
(7, 1, NULL, 10, 1, 4, '2012-08-05 17:02:00', 'project.manager@toolware.fr', '[Project\'Or RIA DEV] Requirement #1 moved to status done', '<html>\n<head>\n<title>[Project\'Or RIA DEV] Requirement #1 moved to status\ndone</title>\n</head>\n<body>\nThe status of Requirement #1 [Filed "Name" is mandatory] has changed\nto done<br/>\nid=1<br/>\nname=Filed "Name" is mandatory<br/>\nstatus=done<br/>\nproject= <br/>\ntype=Functional<br/>\nreference=-FUNC-1<br/>\nexternalReference<br/>\nissuer=admin<br/>\nresponsible=project manager<br/><br/>\n<br/>\n<div style="font-weight: bold;">Requirement #1</div><br/>\n<div style="text-decoration:underline;font-weight: bold;">project\n:</div>\n <br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">requirement\ntype :</div>\nFunctional<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">name :</div>\nFiled &quot;Name&quot; is mandatory<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">description\n:</div>\nFiled name must be set<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">user :</div>\nadmin<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">status\n:</div>\ndone<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">responsible\n:</div>\nproject manager<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">result\n:</div>\n<br/><br/>\n\n<body>\n</html>', 'ERROR', 0),
(8, 1, 1, 1, 2, 1, '2012-08-05 17:09:00', 'admin@toolware.fr, project.manager@toolware.fr, project.leader@external.com', '[Project\'Or RIA DEV] Ticket #2 moved to status recorded', '<html>\n<head>\n<title>[Project\'Or RIA DEV] Ticket #2 moved to status recorded</title>\n</head>\n<body>\nThe status of Ticket #2 [Enter some quotes on filed names : error\nMessage] has changed to recorded<br/>\nid=2<br/>\nname=Enter some quotes on filed names : error Message<br/>\nstatus=recorded<br/>\nproject=project one<br/>\ntype=Incident<br/>\nreference=001-001-INC-2<br/>\nexternalReference<br/>\nissuer=admin<br/>\nresponsible= <br/><br/>\n<br/>\n<div style="font-weight: bold;">Ticket #2</div><br/>\n<div style="text-decoration:underline;font-weight: bold;">project\n:</div>\nproject one<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">ticket type\n:</div>\nIncident<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">name :</div>\nEnter some quotes on filed names : error Message<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">description\n:</div>\nGet a Sql Error message : invalid instruction.<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">issuer\n:</div>\nadmin<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">status\n:</div>\nrecorded<br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">responsible\n:</div>\n <br/><br/>\n<div style="text-decoration:underline;font-weight: bold;">result\n:</div>\n<br/><br/>\n\n<body>\n</html>', 'ERROR', 0),
(9, 1, 2, NULL, 1, 4, '2014-01-04 19:08:00', 'admin@toolware.fr, project.manager@toolware.fr', '[Project\'Or RIA Manual] Ticket #1 moved to status \'done\' : "bug: it does not work"', '<html><head><title>[Project\'Or RIA Manual] Ticket #1 moved to status\n\'done\' : "bug: it does not work"</title></head><body><table\nstyle="font-size:9pt; width: 95%"><tr><td colspan="3"\nstyle="font-size:18pt;color:#AAAAAA"><a\nhref="http://127.0.0.1/projeqtorV4.1/view/main.php?directAccess=true&objectClass=TicketSimple&objectId=1">Ticket\n#1</a></td></tr><tr><td colspan="3" style="background:#555555;color:\n#FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Description</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;id&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><span\nstyle="color:grey;">#</span>1&nbsp;&nbsp;&nbsp;001-001-INC-1</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;project&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">project one -\nmaintenance</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;name&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">bug: it does not\nwork</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;urgency&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">Urgent</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;creation\ndate/time&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">01/09/2011\n12:00</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;description&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"></td></tr><tr><td\ncolspan="3" style="background:#555555;color: #FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Treatment</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;status&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">done</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;responsible&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">project\nmanager</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;due\ndate&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">09/09/2011\n18:30</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;closed&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><input type="checkbox"\ndisabled="disabled"  /></td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;closed\ntime&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"> </td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;cancelled&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><input type="checkbox"\ndisabled="disabled"  /></td></tr>cancelled&nbsp;</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;target\nversion&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"> </td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;result&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"></td></tr><tr><td\ncolspan="3" style="background:#555555;color: #FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Notes</td></tr></table></body></html>', 'OK', 0),
(10, 1, 2, NULL, 1, 8, '2014-01-04 19:17:00', 'admin@toolware.fr, project.manager@toolware.fr', '[Project\'Or RIA Manual] Ticket #1 moved to status \'re-opened\' : "bug: it does not work"', '<html><head><title>[Project\'Or RIA Manual] Ticket #1 moved to status\n\'re-opened\' : "bug: it does not work"</title></head><body><table\nstyle="font-size:9pt; width: 95%"><tr><td colspan="3"\nstyle="font-size:18pt;color:#AAAAAA"><a\nhref="http://127.0.0.1/projeqtorV4.1/view/main.php?directAccess=true&objectClass=TicketSimple&objectId=1">Ticket\n#1</a></td></tr><tr><td colspan="3" style="background:#555555;color:\n#FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Description</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;id&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><span\nstyle="color:grey;">#</span>1&nbsp;&nbsp;&nbsp;001-001-INC-1</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;project&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">project one -\nmaintenance</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;name&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">bug: it does not\nwork</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;urgency&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">Urgent</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;creation\ndate/time&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">01/09/2011\n12:00</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;description&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"></td></tr><tr><td\ncolspan="3" style="background:#555555;color: #FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Treatment</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;status&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align:\nleft;">re-opened</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;responsible&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">project\nmanager</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;due\ndate&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">09/09/2011\n18:30</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;closed&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><input type="checkbox"\ndisabled="disabled"  />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<input\ntype="checkbox" disabled="disabled" \n/>cancelled&nbsp;</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;target\nversion&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"> </td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;result&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"></td></tr><tr><td\ncolspan="3" style="background:#555555;color: #FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Notes</td></tr></table></body></html>', 'OK', 0),
(11, 1, 2, NULL, 1, 9, '2014-01-04 19:38:00', 'admin@toolware.fr, project.manager@toolware.fr', '[Project\'Or RIA Manual] Ticket #1 moved to status \'cancelled\' : "bug: it does not work"', '<html><head><title>[Project\'Or RIA Manual] Ticket #1 moved to status\n\'cancelled\' : "bug: it does not work"</title></head><body><table\nstyle="font-size:9pt; width: 95%"><tr><td colspan="3"\nstyle="font-size:18pt;color:#AAAAAA"><a\nhref="http://127.0.0.1/projeqtorV4.1/view/main.php?directAccess=true&objectClass=TicketSimple&objectId=1">Ticket\n#1</a></td></tr><tr><td colspan="3" style="background:#555555;color:\n#FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Description</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;id&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><span\nstyle="color:grey;">#</span>1&nbsp;&nbsp;&nbsp;001-001-INC-1</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;project&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">project one -\nmaintenance</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;name&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">bug: it does not\nwork</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;urgency&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">Urgent</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;creation\ndate/time&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">01/09/2011\n12:00</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;description&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"></td></tr><tr><td\ncolspan="3" style="background:#555555;color: #FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Treatment</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;status&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align:\nleft;">cancelled</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;responsible&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">project\nmanager</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;due\ndate&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;">09/09/2011\n18:30</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;closed&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"><input type="checkbox"\ndisabled="disabled"  checked />&nbsp;&nbsp;&nbsp;04/01/2014\n19:18&nbsp;&nbsp;&nbsp;<input type="checkbox" disabled="disabled" \nchecked />cancelled&nbsp;</td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align: middle;">&nbsp;&nbsp;target\nversion&nbsp;</td><td style="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"> </td></tr><tr><td\nstyle="background:#DDDDDD;font-weight:bold;text-align:\nright;width:25%;vertical-align:\nmiddle;">&nbsp;&nbsp;result&nbsp;</td><td\nstyle="width:2px;">&nbsp;</td><td\nstyle="background:#FFFFFF;text-align: left;"></td></tr><tr><td\ncolspan="3" style="background:#555555;color: #FFFFFF; text-align:\ncenter;font-size:10pt;font-weight:bold;">Notes</td></tr></table></body></html>', 'OK', 0),
(12, 1, 2, 1, 1, 8, '2016-10-24 09:37:00', 'pascal.bernard.mure@gmail.com', '[ProjeQtOr] message from admin : Ticket #1', NULL, 'OK', 0);

-- --------------------------------------------------------

--
-- Structure de la table `mailable`
--

CREATE TABLE `mailable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `mailable`
--

INSERT INTO `mailable` (`id`, `name`, `idle`) VALUES
(1, 'Ticket', 0),
(2, 'Activity', 0),
(3, 'Milestone', 0),
(4, 'Risk', 0),
(5, 'Action', 0),
(6, 'Issue', 0),
(7, 'Meeting', 0),
(8, 'Decision', 0),
(9, 'Question', 0),
(10, 'Requirement', 0),
(11, 'TestSession', 0),
(12, 'TestCase', 0),
(13, 'Project', 0),
(14, 'Document', 0),
(15, 'IndividualExpense', 0),
(16, 'ProjectExpense', 0),
(17, 'Term', 0),
(18, 'Bill', 0),
(19, 'ActivityPrice', 0),
(20, 'Opportunity', 0),
(21, 'Command', 0),
(22, 'Quotation', 0),
(23, 'Product', 0),
(24, 'ProductVersion', 0),
(25, 'Component', 0),
(26, 'ComponentVersion', 0);

-- --------------------------------------------------------

--
-- Structure de la table `measureunit`
--

CREATE TABLE `measureunit` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `pluralName` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT '0',
  `idle` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `measureunit`
--

INSERT INTO `measureunit` (`id`, `name`, `pluralName`, `sortOrder`, `idle`) VALUES
(1, 'piece', 'pieces', 10, 0),
(2, 'lot', 'lots', 20, 0),
(3, 'day', 'days', 30, 0),
(4, 'month', 'months', 40, 0);

-- --------------------------------------------------------

--
-- Structure de la table `meeting`
--

CREATE TABLE `meeting` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idMeetingType` int(12) UNSIGNED DEFAULT NULL,
  `meetingDate` date DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `attendees` varchar(4000) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `sendTo` varchar(4000) DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `result` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `description` mediumtext,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `meetingStartTime` time DEFAULT NULL,
  `meetingEndTime` time DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `idPeriodicMeeting` int(12) UNSIGNED DEFAULT NULL,
  `isPeriodic` int(1) UNSIGNED DEFAULT '0',
  `periodicOccurence` int(3) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `meeting`
--

INSERT INTO `meeting` (`id`, `idProject`, `idMeetingType`, `meetingDate`, `name`, `attendees`, `idUser`, `sendTo`, `idStatus`, `idResource`, `result`, `idle`, `idleDate`, `handled`, `handledDate`, `done`, `doneDate`, `description`, `reference`, `externalReference`, `meetingStartTime`, `meetingEndTime`, `location`, `idActivity`, `idPeriodicMeeting`, `isPeriodic`, `periodicOccurence`, `cancelled`) VALUES
(1, 1, 30, '2012-03-15', 'Steering Committee 2012-03-15', '"admin" <support@toolware.fr>, "project manager" <project.manager@toolware.fr>, "external project leader one" <project.leader@external.com>', 1, NULL, 1, NULL, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, '001-001-STE-1', NULL, '16:00:00', '18:00:00', NULL, NULL, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `menu`
--

CREATE TABLE `menu` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idMenu` int(12) UNSIGNED DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `sortOrder` int(5) UNSIGNED DEFAULT NULL,
  `level` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `menuClass` varchar(400) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `menu`
--

INSERT INTO `menu` (`id`, `name`, `idMenu`, `type`, `sortOrder`, `level`, `idle`, `menuClass`) VALUES
(1, 'menuToday', 0, 'item', 10, NULL, 0, 'Work Risk RequirementTest Financial Meeting '),
(2, 'menuWork', 0, 'menu', 40, 'Project', 1, 'Work Risk Meeting '),
(3, 'menuRisk', 43, 'object', 300, 'Project', 0, 'Risk '),
(4, 'menuAction', 2, 'object', 90, 'Project', 0, 'Work Risk Meeting '),
(5, 'menuIssue', 43, 'object', 320, 'Project', 0, 'Risk '),
(6, 'menuReview', 0, 'menu', 330, NULL, 1, 'Work Meeting '),
(7, 'menuFollowup', 0, 'menu', 100, NULL, 1, 'Work Risk RequirementTest Financial '),
(8, 'menuImputation', 7, 'item', 110, NULL, 0, 'Work '),
(9, 'menuPlanning', 7, 'item', 120, NULL, 0, 'Work '),
(11, 'menuTool', 0, 'menu', 380, NULL, 1, 'Admin '),
(12, 'menuRequestor', 11, 'item', 390, NULL, 1, 'Admin '),
(13, 'menuParameter', 0, 'menu', 700, NULL, 1, 'Work Risk RequirementTest Financial Meeting Admin Automation EnvironmentalParameter ListOfValues Type HabilitationParameter '),
(14, 'menuEnvironmentalParameter', 0, 'menu', 440, NULL, 1, 'Work Financial EnvironmentalParameter '),
(15, 'menuClient', 14, 'object', 520, 'ReadWriteEnvironment', 0, 'Financial EnvironmentalParameter '),
(16, 'menuProject', 0, 'object', 20, 'Project', 0, 'Work Risk RequirementTest Financial Meeting '),
(17, 'menuUser', 14, 'object', 490, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter HabilitationParameter '),
(18, 'menuGlobalParameter', 13, 'item', 985, NULL, 0, 'Admin EnvironmentalParameter HabilitationParameter '),
(19, 'menuProjectParameter', 13, 'item', 990, NULL, 1, ''),
(20, 'menuUserParameter', 13, 'item', 995, '', 0, 'Work Risk RequirementTest Financial Meeting Admin Automation EnvironmentalParameter ListOfValues Type HabilitationParameter '),
(21, 'menuHabilitation', 37, 'item', 955, NULL, 0, 'HabilitationParameter '),
(22, 'menuTicket', 2, 'object', 50, 'Project', 0, 'Work '),
(25, 'menuActivity', 2, 'object', 70, 'Project', 0, 'Work '),
(26, 'menuMilestone', 2, 'object', 80, 'Project', 0, 'Work '),
(34, 'menuStatus', 36, 'object', 720, 'ReadWriteList', 0, 'ListOfValues '),
(36, 'menuListOfValues', 13, 'menu', 705, NULL, 1, 'ListOfValues '),
(37, 'menuHabilitationParameter', 13, 'menu', 940, NULL, 1, 'Type '),
(38, 'menuSeverity', 36, 'object', 755, 'ReadWriteList', 0, 'ListOfValues '),
(39, 'menuLikelihood', 36, 'object', 745, 'ReadWriteList', 0, 'ListOfValues '),
(40, 'menuCriticality', 36, 'object', 750, 'ReadWriteList', 0, 'ListOfValues '),
(41, 'menuPriority', 36, 'object', 765, 'ReadWriteList', 0, 'ListOfValues '),
(42, 'menuUrgency', 36, 'object', 760, 'ReadWriteList', 0, 'ListOfValues '),
(43, 'menuRiskManagementPlan', 0, 'menu', 290, NULL, 1, 'Risk '),
(44, 'menuResource', 14, 'object', 500, 'ReadWriteEnvironment', 0, 'Work EnvironmentalParameter '),
(45, 'menuRiskType', 79, 'object', 860, 'ReadWriteType', 0, 'Type '),
(46, 'menuIssueType', 79, 'object', 875, 'ReadWriteType', 0, 'Type '),
(47, 'menuAccessProfile', 37, 'object', 950, NULL, 0, 'HabilitationParameter '),
(48, 'menuAccessRight', 37, 'item', 965, NULL, 0, 'HabilitationParameter '),
(49, 'menuProfile', 37, 'object', 945, NULL, 0, 'HabilitationParameter '),
(50, 'menuAffectation', 14, 'object', 470, 'Project', 0, 'EnvironmentalParameter '),
(51, 'menuMessage', 11, 'object', 420, 'Project', 0, 'Admin '),
(52, 'menuMessageType', 79, 'object', 895, 'ReadWriteType', 0, 'Type '),
(53, 'menuTicketType', 79, 'object', 810, 'ReadWriteType', 0, 'Type '),
(55, 'menuActivityType', 79, 'object', 815, 'ReadWriteType', 0, 'Type '),
(56, 'menuMilestoneType', 79, 'object', 820, 'ReadWriteType', 0, 'Type '),
(57, 'menuTeam', 14, 'object', 540, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter '),
(58, 'menuImportData', 11, 'item', 430, NULL, 0, 'Admin '),
(59, 'menuWorkflow', 88, 'object', 580, 'ReadWriteEnvironment', 0, 'Automation '),
(60, 'menuActionType', 79, 'object', 870, 'ReadWriteType', 0, 'Type '),
(61, 'menuReports', 7, 'item', 150, NULL, 0, 'Work Risk RequirementTest Financial '),
(62, 'menuMeeting', 6, 'object', 340, 'Project', 0, 'Work Meeting '),
(63, 'menuDecision', 6, 'object', 360, 'Project', 0, 'Meeting '),
(64, 'menuQuestion', 6, 'object', 370, 'Project', 0, 'Meeting '),
(65, 'menuMeetingType', 79, 'object', 880, 'ReadWriteType', 0, 'Type '),
(66, 'menuDecisionType', 79, 'object', 885, 'ReadWriteType', 0, 'Type '),
(67, 'menuQuestionType', 79, 'object', 890, 'ReadWriteType', 0, 'Type '),
(68, 'menuStatusMail', 88, 'object', 590, 'ReadWriteEnvironment', 0, 'Automation '),
(69, 'menuMail', 11, 'object', 400, 'Project', 0, 'Admin '),
(70, 'menuHabilitationReport', 37, 'item', 960, NULL, 0, 'HabilitationParameter '),
(71, 'menuHabilitationOther', 37, 'item', 970, NULL, 0, 'HabilitationParameter '),
(72, 'menuContact', 14, 'object', 510, 'ReadWriteEnvironment', 0, 'Financial EnvironmentalParameter '),
(73, 'menuRole', 36, 'object', 715, 'ReadWriteList', 0, 'ListOfValues '),
(74, 'menuFinancial', 0, 'menu', 200, NULL, 1, 'Work Financial '),
(75, 'menuIndividualExpense', 151, 'object', 210, 'Project', 0, 'Work Financial '),
(76, 'menuProjectExpense', 151, 'object', 220, 'Project', 0, 'Financial '),
(78, 'menuPayment', 152, 'object', 270, 'Project', 0, 'Financial '),
(79, 'menuType', 13, 'menu', 800, NULL, 1, ''),
(80, 'menuIndividualExpenseType', 79, 'object', 833, 'ReadWriteType', 0, 'Type '),
(81, 'menuProjectExpenseType', 79, 'object', 837, 'ReadWriteType', 0, 'Type '),
(82, 'menuInvoiceType', 79, 'object', 860, 'ReadWriteType', 1, 'Type '),
(83, 'menuPaymentType', 79, 'object', 857, 'ReadWriteType', 0, 'Type '),
(84, 'menuExpenseDetailType', 79, 'object', 841, 'ReadWriteType', 0, 'Type '),
(85, 'menuCalendar', 14, 'item', 560, 'ReadWriteEnvironment', 0, 'Work EnvironmentalParameter '),
(86, 'menuProduct', 14, 'object', 450, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter '),
(87, 'menuProductVersion', 14, 'object', 460, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter '),
(88, 'menuAutomation', 0, 'menu', 570, NULL, 1, 'Automation '),
(89, 'menuTicketDelay', 88, 'object', 600, 'ReadWriteEnvironment', 0, 'Automation '),
(90, 'menuIndicatorDefinition', 88, 'object', 610, 'ReadWriteEnvironment', 0, 'Automation '),
(91, 'menuAlert', 11, 'object', 410, 'Project', 0, 'Admin '),
(92, 'menuAdmin', 13, 'item', 975, NULL, 0, 'Admin '),
(93, 'menuProjectType', 79, 'object', 805, 'ReadWriteType', 0, 'Type '),
(94, 'menuActivityPrice', 152, 'object', 280, 'Project', 0, 'Financial '),
(95, 'menuRecipient', 14, 'object', 530, 'ReadWriteEnvironment', 0, 'Financial EnvironmentalParameter '),
(96, 'menuTerm', 152, 'object', 250, 'Project', 0, 'Financial '),
(97, 'menuBill', 152, 'object', 260, 'Project', 0, 'Financial '),
(100, 'menuBillType', 79, 'object', 853, 'ReadWriteType', 0, 'Type '),
(101, 'menuDocumentType', 79, 'object', 900, 'ReadWriteType', 0, 'Type '),
(102, 'menuDocument', 0, 'object', 30, 'Project', 0, 'Work Risk RequirementTest Financial Meeting '),
(103, 'menuDocumentDirectory', 14, 'object', 550, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter '),
(104, 'menuContext', 14, 'object', 480, NULL, 0, 'EnvironmentalParameter '),
(105, 'menuContextType', 79, 'object', 905, 'ReadWriteType', 0, 'Type '),
(106, 'menuResourcePlanning', 7, 'item', 140, NULL, 0, 'Work '),
(107, 'menuRequirementType', 79, 'object', 910, 'ReadWriteType', 0, 'Type '),
(108, 'menuTestCaseType', 79, 'object', 915, 'ReadWriteType', 0, 'Type '),
(109, 'menuTestSessionType', 79, 'object', 920, 'ReadWriteType', 0, 'Type '),
(110, 'menuRequirementTest', 0, 'menu', 160, NULL, 1, 'Work RequirementTest '),
(111, 'menuRequirement', 110, 'object', 170, 'Project', 0, 'RequirementTest '),
(112, 'menuTestCase', 110, 'object', 180, 'Project', 0, 'RequirementTest '),
(113, 'menuTestSession', 110, 'object', 190, 'Project', 0, 'RequirementTest '),
(114, 'menuRiskLevel', 36, 'object', 770, 'ReadWriteList', 0, 'ListOfValues '),
(115, 'menuFeasibility', 36, 'object', 775, 'ReadWriteList', 0, 'ListOfValues '),
(116, 'menuPredefinedNote', 88, 'object', 620, 'ReadWriteEnvironment', 0, 'Automation '),
(117, 'menuEfficiency', 36, 'object', 780, 'ReadWriteList', 0, 'ListOfValues '),
(118, 'menuTicketSimple', 2, 'object', 60, 'Project', 0, 'Work '),
(119, 'menuOpportunity', 43, 'object', 310, 'Project', 0, 'Risk '),
(120, 'menuOpportunityType', 79, 'object', 865, 'ReadWriteType', 0, 'Type '),
(121, 'menuHealth', 36, 'object', 730, 'ReadWriteList', 0, 'ListOfValues '),
(122, 'menuAudit', 13, 'object', 980, NULL, 0, 'Admin '),
(123, 'menuPortfolioPlanning', 7, 'item', 130, NULL, 0, 'Work '),
(124, 'menuPeriodicMeeting', 6, 'object', 350, 'Project', 0, 'Meeting '),
(125, 'menuCommand', 152, 'object', 240, 'Project', 0, 'Financial '),
(126, 'menuCommandType', 79, 'object', 849, 'ReadWriteType', 0, 'Type '),
(127, 'menuOverallProgress', 36, 'object', 735, 'ReadWriteList', 0, 'ListOfValues '),
(128, 'menuQuality', 36, 'object', 725, 'ReadWriteList', 0, 'ListOfValues '),
(129, 'menuTrend', 36, 'object', 740, 'ReadWriteList', 0, 'ListOfValues '),
(130, 'menuChecklistDefinition', 88, 'object', 630, 'ReadWriteEnvironment', 0, 'Automation '),
(131, 'menuQuotation', 152, 'object', 230, 'Project', 0, 'Financial '),
(132, 'menuQuotationType', 79, 'object', 845, 'ReadWriteType', 0, 'Type '),
(133, 'menuDiary', 7, 'item', 145, NULL, 0, 'Work '),
(134, 'menuClientType', 79, 'object', 925, 'ReadWriteType', 0, 'Type '),
(135, 'menuAccessRightNoProject', 37, 'item', 968, NULL, 0, 'HabilitationParameter '),
(136, 'menuPluginManagement', 143, 'item', 9010, NULL, 0, 'Admin '),
(137, 'menuPaymentDelay', 36, 'object', 785, 'ReadWriteList', 0, 'ListOfValues '),
(138, 'menuPaymentMode', 36, 'object', 786, 'ReadWriteList', 0, 'ListOfValues '),
(139, 'menuDeliveryMode', 36, 'object', 787, 'ReadWriteList', 0, 'ListOfValues '),
(140, 'menuMeasureUnit', 36, 'object', 788, 'ReadWriteList', 0, 'ListOfValues '),
(141, 'menuComponent', 14, 'object', 464, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter'),
(142, 'menuComponentVersion', 14, 'object', 466, 'ReadWriteEnvironment', 0, 'EnvironmentalParameter'),
(143, 'menuPlugin', NULL, 'menu', 9000, NULL, 1, 'Admin'),
(144, 'menuProductType', 79, 'object', 930, 'ReadWriteType', 0, 'Type '),
(145, 'menuComponentType', 79, 'object', 932, 'ReadWriteType', 0, 'Type '),
(146, 'menuGallery', 152, 'item', 285, NULL, 0, 'Financial'),
(147, 'menuProviderType', 79, 'object', 927, 'ReadWriteType', 0, 'Type '),
(148, 'menuProvider', 14, 'object', 525, 'ReadWriteEnvironment', 0, 'Financial EnvironmentalParameter '),
(149, 'menuResolution', 36, 'object', 722, 'ReadWriteList', 0, 'ListOfValues '),
(150, 'menuDashboardTicket', 0, 'item', 15, NULL, 0, 'Work Risk RequirementTest Financial Meeting '),
(151, 'menuExpenses', 74, 'menu', 202, NULL, 1, ''),
(152, 'menuIncomings', 74, 'menu', 225, NULL, 1, ''),
(153, 'menuCallForTender', 151, 'object', 204, 'Project', 0, 'Financial '),
(154, 'menuTender', 151, 'object', 206, 'Project', 0, 'Financial '),
(155, 'menuCallForTenderType', 79, 'object', 825, 'Project', 0, 'Type '),
(156, 'menuTenderType', 79, 'object', 829, 'Project', 0, 'Type '),
(157, 'menuTenderStatus', 36, 'object', 790, NULL, 0, 'ListOfValues ');

-- --------------------------------------------------------

--
-- Structure de la table `menucustom`
--

CREATE TABLE `menucustom` (
  `id` int(12) UNSIGNED NOT NULL,
  `idMenu` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `menuselector`
--

CREATE TABLE `menuselector` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE `message` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idMessageType` int(12) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `idProfile` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `showOnLogin` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `message`
--

INSERT INTO `message` (`id`, `idProject`, `name`, `idMessageType`, `description`, `idProfile`, `idUser`, `idle`, `showOnLogin`) VALUES
(1, NULL, 'Welcome', 15, 'Welcome to ProjectOr web application', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `milestone`
--

CREATE TABLE `milestone` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idMilestoneType` int(12) UNSIGNED DEFAULT NULL,
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `idVersion` int(12) UNSIGNED DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `milestone`
--

INSERT INTO `milestone` (`id`, `idProject`, `name`, `description`, `creationDate`, `idUser`, `idStatus`, `idResource`, `result`, `comment`, `idle`, `idMilestoneType`, `idActivity`, `done`, `idleDate`, `doneDate`, `handled`, `handledDate`, `idVersion`, `reference`, `externalReference`, `cancelled`) VALUES
(1, 3, 'Delivery of Evolution X', NULL, '2011-09-02', 1, 1, NULL, NULL, NULL, 0, 25, 2, 0, NULL, NULL, 0, NULL, NULL, '001-001-2-KEY-1', NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `mutex`
--

CREATE TABLE `mutex` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `note`
--

CREATE TABLE `note` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) NOT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `updateDate` datetime DEFAULT NULL,
  `note` mediumtext,
  `idPrivacy` int(12) UNSIGNED DEFAULT '1',
  `idTeam` int(12) UNSIGNED DEFAULT '1',
  `fromEmail` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `note`
--

INSERT INTO `note` (`id`, `refType`, `refId`, `idUser`, `creationDate`, `updateDate`, `note`, `idPrivacy`, `idTeam`, `fromEmail`) VALUES
(1, 'Ticket', 1, 1, '2012-03-19 00:13:58', NULL, 'New comment.\nFor testing...', 1, NULL, 0),
(2, 'Ticket', 2, 1, '2014-01-05 16:32:53', NULL, 'New comment.\n... for testing.', 1, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `opportunity`
--

CREATE TABLE `opportunity` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idOpportunityType` int(12) UNSIGNED DEFAULT NULL,
  `cause` mediumtext,
  `impact` mediumtext,
  `idSeverity` int(12) UNSIGNED DEFAULT NULL,
  `idLikelihood` int(12) UNSIGNED DEFAULT NULL,
  `idCriticality` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `initialEndDate` date DEFAULT NULL,
  `actualEndDate` date DEFAULT NULL,
  `idleDate` date DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idPriority` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `impactCost` decimal(11,2) UNSIGNED DEFAULT '0.00',
  `projectReserveAmount` decimal(11,2) UNSIGNED DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `origin`
--

CREATE TABLE `origin` (
  `id` int(12) UNSIGNED NOT NULL,
  `originType` varchar(100) DEFAULT NULL,
  `originId` int(12) UNSIGNED DEFAULT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `originable`
--

CREATE TABLE `originable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `originable`
--

INSERT INTO `originable` (`id`, `name`, `idle`) VALUES
(1, 'Ticket', 0),
(2, 'Activity', 0),
(3, 'Milestone', 0),
(4, 'IndividualExpense', 0),
(5, 'ProjectExpense', 0),
(6, 'Risk', 0),
(7, 'Action', 0),
(8, 'Issue', 0),
(9, 'Meeting', 0),
(10, 'Decision', 0),
(11, 'Question', 0),
(12, 'Project', 0),
(13, 'Document', 0),
(14, 'Requirement', 0),
(15, 'TestSession', 0),
(16, 'TestCase', 0),
(17, 'Command', 0),
(18, 'Quotation', 0);

-- --------------------------------------------------------

--
-- Structure de la table `otherversion`
--

CREATE TABLE `otherversion` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `idVersion` int(12) UNSIGNED NOT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `overallprogress`
--

CREATE TABLE `overallprogress` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `overallprogress`
--

INSERT INTO `overallprogress` (`id`, `name`, `sortOrder`, `idle`) VALUES
(1, '0%', 100, 0),
(2, '10%', 200, 0),
(3, '25%', 300, 0),
(4, '50%', 400, 0),
(5, '75%', 500, 0),
(6, '90%', 600, 0),
(7, '100%', 700, 0);

-- --------------------------------------------------------

--
-- Structure de la table `parameter`
--

CREATE TABLE `parameter` (
  `id` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `parameterCode` varchar(100) DEFAULT NULL,
  `parameterValue` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `parameter`
--

INSERT INTO `parameter` (`id`, `idUser`, `idProject`, `parameterCode`, `parameterValue`) VALUES
(1, NULL, NULL, 'dbVersion', 'V5.5.4'),
(2, 1, NULL, 'destinationWidth', '847'),
(3, 1, NULL, 'theme', 'ProjeQtOr'),
(4, 1, NULL, 'lang', 'en'),
(5, 1, NULL, 'defaultProject', '*'),
(6, 1, NULL, 'displayAttachment', 'YES_OPENED'),
(7, 1, NULL, 'displayNote', 'YES_OPENED'),
(8, 1, NULL, 'displayHistory', 'NO'),
(9, 1, NULL, 'refreshUpdates', 'YES'),
(10, 3, NULL, 'destinationWidth', '719'),
(11, 3, NULL, 'theme', 'blue'),
(12, 3, NULL, 'lang', 'en'),
(13, 3, NULL, 'defaultProject', '3'),
(14, 3, NULL, 'displayAttachment', 'YES_CLOSED'),
(15, 3, NULL, 'displayNote', 'YES_CLOSED'),
(16, 3, NULL, 'displayHistory', 'YES_CLOSED'),
(17, 3, NULL, 'refreshUpdates', 'YES'),
(18, 1, NULL, 'hideMenu', 'NO'),
(19, 1, NULL, 'switchedMode', 'NO'),
(20, 1, NULL, 'printInNewWindow', 'NO'),
(21, 1, NULL, 'pdfInNewWindow', 'NO'),
(22, NULL, NULL, 'startAM', '08:00'),
(23, NULL, NULL, 'endAM', '12:00'),
(24, NULL, NULL, 'startPM', '14:00'),
(25, NULL, NULL, 'endPM', '18:00'),
(26, NULL, NULL, 'dayTime', '8'),
(27, NULL, NULL, 'alertCheckTime', '60'),
(28, NULL, NULL, 'cronSleepTime', '10'),
(29, NULL, NULL, 'cronCheckDates', '30'),
(30, NULL, NULL, 'ldapDefaultProfile', '5'),
(31, NULL, NULL, 'ldapMsgOnUserCreation', 'NO'),
(32, NULL, NULL, 'csvSeparator', ';'),
(33, NULL, NULL, 'referenceFormatPrefix', '{PROJ}-{TYPE}-'),
(34, NULL, NULL, 'changeReferenceOnTypeChange', 'NO'),
(35, NULL, NULL, 'draftSeparator', '_draft'),
(36, NULL, NULL, 'documentRoot', '../files/documents/'),
(37, NULL, NULL, 'billPrefix', 'BILL'),
(38, NULL, NULL, 'billSuffix', '_FR'),
(39, NULL, NULL, 'billNumSize', '5'),
(40, NULL, NULL, 'billNumStart', '10000'),
(41, NULL, NULL, 'displayResourcePlan', 'initials'),
(42, NULL, NULL, 'maxProjectsToDisplay', '25'),
(43, 1, NULL, 'planningShowProject', '1'),
(44, NULL, NULL, 'paramMailTitleStatus', '[${dbName}] ${item} #${id} moved to status \'${status}\' : "${name}"'),
(45, NULL, NULL, 'paramMailTitleResponsible', '[${dbName}] ${responsible} is now responsible of ${item} #${id} : "${name}"'),
(46, NULL, NULL, 'paramMailTitleNote', '[${dbName}] New note has been posted on ${item} #${id} : "${name}"'),
(47, NULL, NULL, 'paramMailTitleAttachment', '[${dbName}] New attachment has been posted on ${item} #${id} : "${name}"'),
(48, NULL, NULL, 'paramMailTitleNew', '[${dbName}] ${item} #${id} has been created : "${name}"'),
(49, NULL, NULL, 'cronCheckImport', '60'),
(50, NULL, NULL, 'cronImportDirectory', '../files/import'),
(51, NULL, NULL, 'cronImportLogDestination', 'file'),
(52, NULL, NULL, 'cronImportMailList', ''),
(53, NULL, NULL, 'cronDirectory', '../files/cron'),
(54, NULL, NULL, 'paramMailTitleDirect', '[${dbName}] message from ${sender} : ${item} #${id}'),
(55, NULL, NULL, 'maxItemsInTodayLists', '100'),
(56, NULL, NULL, 'paramDbDisplayName', 'ProjeQtOr'),
(57, NULL, NULL, 'paramMailTitle', '[Project\'Or RIA] ${item} #${id} moved to status ${status}'),
(58, NULL, NULL, 'paramMailMessage', 'The status of ${item} #${id} [${name}] has changed to ${status}'),
(59, NULL, NULL, 'paramMailSender', 'test@projeqtor.net'),
(60, NULL, NULL, 'paramMailReplyTo', 'test@projeqtor.net'),
(61, NULL, NULL, 'paramAdminMail', 'test@projeqtor.net'),
(62, NULL, NULL, 'paramMailSmtpServer', NULL),
(63, NULL, NULL, 'paramMailSmtpPort', '25'),
(64, NULL, NULL, 'paramMailSendmailPath', NULL),
(65, NULL, NULL, 'paramMailShowDetail', 'true'),
(66, NULL, NULL, 'paramLdap_allow_login', 'false'),
(67, NULL, NULL, 'paramLdap_base_dn', NULL),
(68, NULL, NULL, 'paramLdap_host', NULL),
(69, NULL, NULL, 'paramLdap_port', NULL),
(70, NULL, NULL, 'paramLdap_version', '2'),
(71, NULL, NULL, 'paramLdap_search_user', NULL),
(72, NULL, NULL, 'paramLdap_search_pass', NULL),
(73, NULL, NULL, 'paramLdap_user_filter', NULL),
(74, NULL, NULL, 'paramDefaultPassword', 'projeqtordemo'),
(75, NULL, NULL, 'paramPasswordMinLength', '5'),
(76, NULL, NULL, 'lockPassword', 'false'),
(77, NULL, NULL, 'paramDefaultLocale', 'fr-ca'),
(78, NULL, NULL, 'paramDefaultTimezone', 'Europe/Paris'),
(79, NULL, NULL, 'currency', '$'),
(80, NULL, NULL, 'currencyPosition', 'before'),
(81, NULL, NULL, 'paramFadeLoadingMode', 'true'),
(82, NULL, NULL, 'paramRowPerPage', '50'),
(83, NULL, NULL, 'paramIconSize', '16'),
(84, NULL, NULL, 'defaultTheme', 'ProjeQtOr'),
(85, NULL, NULL, 'paramPathSeparator', '\\'),
(86, NULL, NULL, 'paramAttachmentDirectory', '../files/attach/'),
(87, NULL, NULL, 'paramAttachmentMaxSize', '2097152'),
(88, NULL, NULL, 'paramReportTempDirectory', '../files/report/'),
(89, NULL, NULL, 'paramMemoryLimitForPDF', '512'),
(90, NULL, NULL, 'defaultBillCode', NULL),
(91, NULL, NULL, 'paramMailEol', 'CRLF'),
(92, NULL, NULL, 'msgClosedApplication', 'Application is closed. \nOnly admin user can connect. \nPlease come back later.'),
(93, NULL, NULL, 'paramMailBodyUser', 'You are welcome to ${dbName} at <a href="${url}">${url}</a>.<br>Your login is <b>${login}</b>.<br/>Your password is initialized to <b>${password}</b><br/>You will have to change it on first connection.<br/><br/>In case of an issue contact your administrator at <b>${adminMail}</b>.'),
(94, NULL, NULL, 'paramMailTitleUser', '[${dbName}] message from ${sender} : Your account information'),
(95, NULL, NULL, 'paramMailTitleNoteChange', '[${dbName}] A note has been modified on ${item} #${id} : "${name}"'),
(96, NULL, NULL, 'paramMailTitleDescription', '[${dbName}] Description has been modified on ${item} #${id} : "${name}"'),
(97, NULL, NULL, 'paramMailTitleResult', '[${dbName}] Result has been modified on ${item} #${id} : "${name}'),
(98, NULL, NULL, 'paramMailTitleAssignment', '[${dbName}] New assignment has been added on ${item} #${id} : "${name}"'),
(99, NULL, NULL, 'paramMailTitleAssignmentChange', '[${dbName}] An assignment has been modified on ${item} #${id} : "${name}"'),
(100, NULL, NULL, 'paramMailTitleAnyChange', '[${dbName}] ${item} #${id} has been modified : "${name}"'),
(101, NULL, NULL, 'documentReferenceFormat', '{PROJ}-{TYPE}-{NUM}-{NAME}'),
(102, NULL, NULL, 'versionReferenceSuffix', '-{VERS}'),
(103, NULL, NULL, 'realWorkOnlyForResponsible', 'NO'),
(104, NULL, NULL, 'maxDaysToBookWork', '7'),
(105, NULL, NULL, 'cronCheckEmails', '-1'),
(106, 1, NULL, 'planningLeftSize', '325px'),
(107, NULL, NULL, 'imputationUnit', 'days'),
(108, NULL, NULL, 'workUnit', 'days'),
(109, NULL, NULL, 'ganttPlanningPrintOldStyle', 'NO'),
(110, NULL, NULL, 'displayOnlyHandled', 'NO'),
(111, NULL, NULL, 'setHandledOnRealWork', 'NO'),
(112, NULL, NULL, 'setResponsibleIfSingle', 'YES'),
(113, NULL, NULL, 'setResponsibleIfNeeded', 'YES'),
(114, NULL, NULL, 'defaultProfile', '5'),
(115, NULL, NULL, 'paramLockAfterWrongTries', NULL),
(116, NULL, NULL, 'initializePassword', 'NO'),
(117, NULL, NULL, 'referenceFormatNumber', NULL),
(118, NULL, NULL, 'preserveUploadedFileName', 'YES'),
(119, NULL, NULL, 'getVersion', 'YES'),
(120, NULL, NULL, 'cronCheckEmailsHost', NULL),
(121, NULL, NULL, 'cronCheckEmailsUser', NULL),
(122, NULL, NULL, 'cronCheckEmailsPassword', NULL),
(123, NULL, NULL, 'paramMailReplyToName', 'PROJEQTOR TEST FOR DEV'),
(124, NULL, NULL, 'paramMailSmtpUsername', 'test@projeqtor.net'),
(125, NULL, NULL, 'paramMailSmtpPassword', 'testProjeQtOr'),
(126, 1, NULL, 'printHistory', 'NO'),
(127, 1, NULL, 'projectIndentChar', '_'),
(128, NULL, NULL, 'paramTopIconSize', '16'),
(129, NULL, NULL, 'paramMailTitleApprover', '[${dbName}] message from ${sender} : You need to approve a document'),
(130, NULL, NULL, 'paramMailBodyApprover', '[${dbName}] You are approver of <a href="${url}" > Document #${id}</a> : "${name}".<br/>Please access <a href="${url}" >this document</a> and follow approval process.'),
(131, NULL, NULL, 'consolidateValidated', 'NO'),
(132, NULL, NULL, 'dependencyStrictMode', 'YES'),
(133, NULL, NULL, 'passwordValidityDays', NULL),
(134, NULL, NULL, 'rememberMe', 'YES'),
(135, NULL, NULL, 'filenameCharset', NULL),
(136, NULL, NULL, 'startPage', 'today.php'),
(137, NULL, NULL, 'setDoneOnNoLeftWork', 'YES'),
(138, NULL, NULL, 'billReferenceFormat', 'BILL{NUME}_FR'),
(139, 1, NULL, 'imputationShowPlannedWork', '0'),
(140, 1, NULL, 'imputationHideDone', '0'),
(141, 1, NULL, 'imputationHideNotHandled', '0'),
(142, 1, NULL, 'imputationDisplayOnlyCurrentWeekMeetings', '0'),
(143, 1, NULL, 'planningScale', 'month'),
(144, NULL, NULL, 'messageAlertImputationResource', 'Your real work allocation is not complete up to ${DAY}'),
(145, NULL, NULL, 'messageAlertImputationProjectLeader', 'Some of your resources did not enter real work up to ${DAY}'),
(146, NULL, NULL, 'imputationAlertGenerationDay', '5'),
(147, NULL, NULL, 'imputationAlertGenerationHour', '17:00'),
(148, NULL, NULL, 'imputationAlertControlDay', 'current'),
(149, NULL, NULL, 'imputationAlertControlNumberOfDays', '7'),
(150, NULL, NULL, 'imputationAlertSendToResource', 'MAIL'),
(151, NULL, NULL, 'imputationAlertSendToProjectLeader', 'MAIL'),
(152, NULL, NULL, 'imputationAlertSendToTeamManager', 'MAIL'),
(153, 1, NULL, 'accordionPaneBottom', 'projectLinkDiv'),
(154, 1, NULL, 'contentPaneLeftBottomDivHeight', '300'),
(155, 1, NULL, 'accordionPaneTop', 'messageDiv'),
(156, 1, NULL, 'contentPaneLeftDivWidth', '325'),
(157, NULL, NULL, 'maxDaysToBookWorkBlocking', NULL),
(158, NULL, NULL, 'imputationAlertInputByOther', 'NO'),
(159, NULL, NULL, 'responsibleFromProduct', 'always'),
(160, NULL, NULL, 'ldapCreationAction', 'createNothing'),
(161, NULL, NULL, 'versionNameAutoformat', 'NO'),
(162, NULL, NULL, 'versionNameAutoformatSeparator', NULL),
(163, NULL, NULL, 'csvExportUTF8', 'NO'),
(164, NULL, NULL, 'fontForPDF', 'freesans'),
(165, NULL, NULL, 'editor', 'CK'),
(166, NULL, NULL, 'allowTypeRestrictionOnProject', 'NO'),
(167, NULL, NULL, 'showTendersOnVersions', 'NO'),
(168, 1, NULL, 'contentPaneTopDetailDivHeightTicket', '346');

-- --------------------------------------------------------

--
-- Structure de la table `payment`
--

CREATE TABLE `payment` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idBill` int(12) UNSIGNED DEFAULT NULL,
  `paymentDate` date DEFAULT NULL,
  `idPaymentMode` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) DEFAULT '0',
  `idPaymentType` int(12) UNSIGNED DEFAULT NULL,
  `paymentAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `paymentFeeAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `paymentCreditAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `referenceBill` varchar(100) DEFAULT NULL,
  `idClient` int(12) UNSIGNED DEFAULT NULL,
  `idRecipient` int(12) UNSIGNED DEFAULT NULL,
  `billAmount` decimal(11,2) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `paymentdelay`
--

CREATE TABLE `paymentdelay` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `days` int(3) UNSIGNED DEFAULT NULL,
  `endOfMonth` int(1) DEFAULT '0',
  `sortOrder` int(3) DEFAULT '0',
  `idle` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `paymentdelay`
--

INSERT INTO `paymentdelay` (`id`, `name`, `days`, `endOfMonth`, `sortOrder`, `idle`) VALUES
(1, '15 days', 15, 0, 10, 0),
(2, '15 days end of month', 15, 1, 20, 0),
(3, '30 days', 30, 0, 30, 0),
(4, '30 days end of month', 30, 1, 40, 0),
(5, '45 days', 45, 0, 50, 0),
(6, '45 days end of month', 45, 1, 60, 0),
(7, '60 days', 60, 0, 70, 0),
(8, 'on order', 0, 0, 80, 0);

-- --------------------------------------------------------

--
-- Structure de la table `paymentmode`
--

CREATE TABLE `paymentmode` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT '0',
  `idle` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `paymentmode`
--

INSERT INTO `paymentmode` (`id`, `name`, `sortOrder`, `idle`) VALUES
(1, 'bank transfer', 10, 0),
(2, 'cheque', 20, 0),
(3, 'credit card', 30, 0),
(4, 'virtual payment terminal', 40, 0),
(5, 'paypal', 50, 0);

-- --------------------------------------------------------

--
-- Structure de la table `periodicity`
--

CREATE TABLE `periodicity` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `periodicityCode` varchar(10) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `periodicity`
--

INSERT INTO `periodicity` (`id`, `name`, `periodicityCode`, `sortOrder`, `idle`) VALUES
(1, 'periodicityDaily', 'DAY', 100, 0),
(2, 'periodicityWeekly', 'WEEK', 200, 0),
(3, 'periodicityMonthlyDay', 'MONTHDAY', 300, 0),
(4, 'periodicityMonthlyWeek', 'MONTHWEEK', 400, 0),
(5, 'periodicityYearly', 'YEAR', 500, 1);

-- --------------------------------------------------------

--
-- Structure de la table `periodicmeeting`
--

CREATE TABLE `periodicmeeting` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idMeetingType` int(12) UNSIGNED DEFAULT NULL,
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `periodicityStartDate` date DEFAULT NULL,
  `periodicityEndDate` date DEFAULT NULL,
  `meetingStartTime` time DEFAULT NULL,
  `meetingEndTime` time DEFAULT NULL,
  `periodicityTimes` int(3) DEFAULT NULL,
  `idPeriodicity` int(12) UNSIGNED DEFAULT NULL,
  `periodicityDailyFrequency` int(2) DEFAULT NULL,
  `periodicityWeeklyFrequency` int(2) DEFAULT NULL,
  `periodicityWeeklyDay` int(1) DEFAULT NULL,
  `periodicityMonthlyDayFrequency` int(2) DEFAULT NULL,
  `periodicityMonthlyDayDay` int(2) DEFAULT NULL,
  `periodicityMonthlyWeekFrequency` int(2) DEFAULT NULL,
  `periodicityMonthlyWeekNumber` int(1) DEFAULT NULL,
  `periodicityMonthlyWeekDay` int(2) DEFAULT NULL,
  `periodicityYearlyDay` int(2) DEFAULT NULL,
  `periodicityYearlyMonth` int(2) DEFAULT NULL,
  `periodicityOpenDays` int(1) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `attendees` varchar(4000) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `plannedwork`
--

CREATE TABLE `plannedwork` (
  `id` int(12) UNSIGNED NOT NULL,
  `idResource` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `idAssignment` int(12) UNSIGNED DEFAULT NULL,
  `work` decimal(8,5) UNSIGNED DEFAULT NULL,
  `workDate` date DEFAULT NULL,
  `day` varchar(8) DEFAULT NULL,
  `week` varchar(6) DEFAULT NULL,
  `month` varchar(6) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  `dailyCost` decimal(7,2) DEFAULT NULL,
  `cost` decimal(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `plannedwork`
--

INSERT INTO `plannedwork` (`id`, `idResource`, `idProject`, `refType`, `refId`, `idAssignment`, `work`, `workDate`, `day`, `week`, `month`, `year`, `dailyCost`, `cost`) VALUES
(3573, 3, 2, 'Activity', 1, 1, '0.50000', '2015-11-05', '20151105', '201545', '201511', '2015', NULL, NULL),
(3574, 3, 2, 'Activity', 1, 1, '0.50000', '2015-11-10', '20151110', '201546', '201511', '2015', NULL, NULL),
(3575, 3, 2, 'Activity', 1, 1, '0.50000', '2015-11-16', '20151116', '201547', '201511', '2015', NULL, NULL),
(3576, 3, 2, 'Activity', 1, 1, '0.50000', '2015-11-19', '20151119', '201547', '201511', '2015', NULL, NULL),
(3577, 3, 2, 'Activity', 1, 1, '0.50000', '2015-11-25', '20151125', '201548', '201511', '2015', NULL, NULL),
(3578, 3, 2, 'Activity', 1, 1, '0.50000', '2015-11-30', '20151130', '201549', '201511', '2015', NULL, NULL),
(3579, 3, 2, 'Activity', 1, 1, '0.50000', '2015-12-04', '20151204', '201549', '201512', '2015', NULL, NULL),
(3580, 3, 2, 'Activity', 1, 1, '0.50000', '2015-12-09', '20151209', '201550', '201512', '2015', NULL, NULL),
(3581, 3, 2, 'Activity', 1, 1, '0.50000', '2015-12-15', '20151215', '201551', '201512', '2015', NULL, NULL),
(3582, 3, 2, 'Activity', 1, 1, '0.50000', '2015-12-18', '20151218', '201551', '201512', '2015', NULL, NULL),
(3583, 3, 2, 'Activity', 1, 1, '0.50000', '2015-12-24', '20151224', '201552', '201512', '2015', NULL, NULL),
(3584, 3, 2, 'Activity', 1, 1, '0.50000', '2015-12-29', '20151229', '201553', '201512', '2015', NULL, NULL),
(3585, 3, 2, 'Activity', 1, 1, '0.50000', '2016-01-04', '20160104', '201601', '201601', '2016', NULL, NULL),
(3586, 3, 2, 'Activity', 1, 1, '0.50000', '2016-01-07', '20160107', '201601', '201601', '2016', NULL, NULL),
(3587, 3, 2, 'Activity', 1, 1, '0.50000', '2016-01-13', '20160113', '201602', '201601', '2016', NULL, NULL),
(3588, 3, 2, 'Activity', 1, 1, '0.50000', '2016-01-18', '20160118', '201603', '201601', '2016', NULL, NULL),
(3589, 3, 2, 'Activity', 1, 1, '0.50000', '2016-01-22', '20160122', '201603', '201601', '2016', NULL, NULL),
(3590, 3, 2, 'Activity', 1, 1, '0.50000', '2016-01-27', '20160127', '201604', '201601', '2016', NULL, NULL),
(3591, 3, 2, 'Activity', 1, 1, '0.50000', '2016-02-02', '20160202', '201605', '201602', '2016', NULL, NULL),
(3592, 3, 2, 'Activity', 1, 1, '0.20000', '2016-02-05', '20160205', '201605', '201602', '2016', NULL, NULL),
(3593, 3, 2, 'Activity', 1, 1, '0.20000', '2016-02-08', '20160208', '201606', '201602', '2016', NULL, NULL),
(3594, 3, 2, 'Activity', 1, 1, '0.10000', '2016-02-09', '20160209', '201606', '201602', '2016', NULL, NULL),
(3595, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-02', '20151102', '201545', '201511', '2015', NULL, NULL),
(3596, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-03', '20151103', '201545', '201511', '2015', NULL, NULL),
(3597, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-04', '20151104', '201545', '201511', '2015', NULL, NULL),
(3598, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-05', '20151105', '201545', '201511', '2015', NULL, NULL),
(3599, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-06', '20151106', '201545', '201511', '2015', NULL, NULL),
(3600, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-09', '20151109', '201546', '201511', '2015', NULL, NULL),
(3601, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-10', '20151110', '201546', '201511', '2015', NULL, NULL),
(3602, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-11', '20151111', '201546', '201511', '2015', NULL, NULL),
(3603, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-12', '20151112', '201546', '201511', '2015', NULL, NULL),
(3604, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-13', '20151113', '201546', '201511', '2015', NULL, NULL),
(3605, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-16', '20151116', '201547', '201511', '2015', NULL, NULL),
(3606, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-17', '20151117', '201547', '201511', '2015', NULL, NULL),
(3607, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-18', '20151118', '201547', '201511', '2015', NULL, NULL),
(3608, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-19', '20151119', '201547', '201511', '2015', NULL, NULL),
(3609, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-20', '20151120', '201547', '201511', '2015', NULL, NULL),
(3610, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-23', '20151123', '201548', '201511', '2015', NULL, NULL),
(3611, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-24', '20151124', '201548', '201511', '2015', NULL, NULL),
(3612, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-25', '20151125', '201548', '201511', '2015', NULL, NULL),
(3613, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-26', '20151126', '201548', '201511', '2015', NULL, NULL),
(3614, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-27', '20151127', '201548', '201511', '2015', NULL, NULL),
(3615, 10, 2, 'Activity', 1, 2, '0.50000', '2015-11-30', '20151130', '201549', '201511', '2015', NULL, NULL),
(3616, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-01', '20151201', '201549', '201512', '2015', NULL, NULL),
(3617, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-02', '20151202', '201549', '201512', '2015', NULL, NULL),
(3618, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-03', '20151203', '201549', '201512', '2015', NULL, NULL),
(3619, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-04', '20151204', '201549', '201512', '2015', NULL, NULL),
(3620, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-07', '20151207', '201550', '201512', '2015', NULL, NULL),
(3621, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-08', '20151208', '201550', '201512', '2015', NULL, NULL),
(3622, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-09', '20151209', '201550', '201512', '2015', NULL, NULL),
(3623, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-10', '20151210', '201550', '201512', '2015', NULL, NULL),
(3624, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-11', '20151211', '201550', '201512', '2015', NULL, NULL),
(3625, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-14', '20151214', '201551', '201512', '2015', NULL, NULL),
(3626, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-15', '20151215', '201551', '201512', '2015', NULL, NULL),
(3627, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-16', '20151216', '201551', '201512', '2015', NULL, NULL),
(3628, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-17', '20151217', '201551', '201512', '2015', NULL, NULL),
(3629, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-18', '20151218', '201551', '201512', '2015', NULL, NULL),
(3630, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-21', '20151221', '201552', '201512', '2015', NULL, NULL),
(3631, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-22', '20151222', '201552', '201512', '2015', NULL, NULL),
(3632, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-23', '20151223', '201552', '201512', '2015', NULL, NULL),
(3633, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-24', '20151224', '201552', '201512', '2015', NULL, NULL),
(3634, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-25', '20151225', '201552', '201512', '2015', NULL, NULL),
(3635, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-28', '20151228', '201553', '201512', '2015', NULL, NULL),
(3636, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-29', '20151229', '201553', '201512', '2015', NULL, NULL),
(3637, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-30', '20151230', '201553', '201512', '2015', NULL, NULL),
(3638, 10, 2, 'Activity', 1, 2, '0.50000', '2015-12-31', '20151231', '201553', '201512', '2015', NULL, NULL),
(3639, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-01', '20160101', '201653', '201601', '2016', NULL, NULL),
(3640, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-04', '20160104', '201601', '201601', '2016', NULL, NULL),
(3641, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-05', '20160105', '201601', '201601', '2016', NULL, NULL),
(3642, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-06', '20160106', '201601', '201601', '2016', NULL, NULL),
(3643, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-07', '20160107', '201601', '201601', '2016', NULL, NULL),
(3644, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-08', '20160108', '201601', '201601', '2016', NULL, NULL),
(3645, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-11', '20160111', '201602', '201601', '2016', NULL, NULL),
(3646, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-12', '20160112', '201602', '201601', '2016', NULL, NULL),
(3647, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-13', '20160113', '201602', '201601', '2016', NULL, NULL),
(3648, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-14', '20160114', '201602', '201601', '2016', NULL, NULL),
(3649, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-15', '20160115', '201602', '201601', '2016', NULL, NULL),
(3650, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-18', '20160118', '201603', '201601', '2016', NULL, NULL),
(3651, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-19', '20160119', '201603', '201601', '2016', NULL, NULL),
(3652, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-20', '20160120', '201603', '201601', '2016', NULL, NULL),
(3653, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-21', '20160121', '201603', '201601', '2016', NULL, NULL),
(3654, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-22', '20160122', '201603', '201601', '2016', NULL, NULL),
(3655, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-25', '20160125', '201604', '201601', '2016', NULL, NULL),
(3656, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-26', '20160126', '201604', '201601', '2016', NULL, NULL),
(3657, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-27', '20160127', '201604', '201601', '2016', NULL, NULL),
(3658, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-28', '20160128', '201604', '201601', '2016', NULL, NULL),
(3659, 10, 2, 'Activity', 1, 2, '0.50000', '2016-01-29', '20160129', '201604', '201601', '2016', NULL, NULL),
(3660, 10, 2, 'Activity', 1, 2, '0.50000', '2016-02-01', '20160201', '201605', '201602', '2016', NULL, NULL),
(3661, 10, 2, 'Activity', 1, 2, '0.50000', '2016-02-02', '20160202', '201605', '201602', '2016', NULL, NULL),
(3662, 10, 2, 'Activity', 1, 2, '0.50000', '2016-02-03', '20160203', '201605', '201602', '2016', NULL, NULL),
(3663, 10, 2, 'Activity', 1, 2, '0.50000', '2016-02-04', '20160204', '201605', '201602', '2016', NULL, NULL),
(3664, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-05', '20160205', '201605', '201602', '2016', NULL, NULL),
(3665, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-08', '20160208', '201606', '201602', '2016', NULL, NULL),
(3666, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-09', '20160209', '201606', '201602', '2016', NULL, NULL),
(3667, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-10', '20160210', '201606', '201602', '2016', NULL, NULL),
(3668, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-11', '20160211', '201606', '201602', '2016', NULL, NULL),
(3669, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-12', '20160212', '201606', '201602', '2016', NULL, NULL),
(3670, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-15', '20160215', '201607', '201602', '2016', NULL, NULL),
(3671, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-16', '20160216', '201607', '201602', '2016', NULL, NULL),
(3672, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-17', '20160217', '201607', '201602', '2016', NULL, NULL),
(3673, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-18', '20160218', '201607', '201602', '2016', NULL, NULL),
(3674, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-19', '20160219', '201607', '201602', '2016', NULL, NULL),
(3675, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-22', '20160222', '201608', '201602', '2016', NULL, NULL),
(3676, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-23', '20160223', '201608', '201602', '2016', NULL, NULL),
(3677, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-24', '20160224', '201608', '201602', '2016', NULL, NULL),
(3678, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-25', '20160225', '201608', '201602', '2016', NULL, NULL),
(3679, 10, 2, 'Activity', 1, 2, '2.50000', '2016-02-26', '20160226', '201608', '201602', '2016', NULL, NULL),
(3680, 10, 2, 'Activity', 1, 2, '0.70000', '2016-02-29', '20160229', '201609', '201602', '2016', NULL, NULL),
(3681, 3, 4, 'Activity', 7, 6, '0.50000', '2015-11-06', '20151106', '201545', '201511', '2015', NULL, NULL),
(3682, 3, 4, 'Activity', 7, 6, '0.50000', '2015-11-13', '20151113', '201546', '201511', '2015', NULL, NULL),
(3683, 3, 4, 'Activity', 7, 6, '0.50000', '2015-11-20', '20151120', '201547', '201511', '2015', NULL, NULL),
(3684, 3, 4, 'Activity', 7, 6, '0.50000', '2015-11-27', '20151127', '201548', '201511', '2015', NULL, NULL),
(3685, 3, 4, 'Activity', 7, 6, '0.50000', '2015-12-03', '20151203', '201549', '201512', '2015', NULL, NULL),
(3686, 3, 4, 'Activity', 7, 6, '0.50000', '2015-12-10', '20151210', '201550', '201512', '2015', NULL, NULL),
(3687, 3, 4, 'Activity', 7, 6, '0.50000', '2015-12-17', '20151217', '201551', '201512', '2015', NULL, NULL),
(3688, 3, 4, 'Activity', 7, 6, '0.50000', '2015-12-24', '20151224', '201552', '201512', '2015', NULL, NULL),
(3689, 3, 4, 'Activity', 7, 6, '0.50000', '2015-12-30', '20151230', '201553', '201512', '2015', NULL, NULL),
(3690, 3, 4, 'Activity', 7, 6, '0.50000', '2016-01-06', '20160106', '201601', '201601', '2016', NULL, NULL),
(3691, 3, 4, 'Activity', 7, 6, '0.50000', '2016-01-13', '20160113', '201602', '201601', '2016', NULL, NULL),
(3692, 3, 4, 'Activity', 7, 6, '0.50000', '2016-01-20', '20160120', '201603', '201601', '2016', NULL, NULL),
(3693, 3, 4, 'Activity', 7, 6, '0.50000', '2016-01-27', '20160127', '201604', '201601', '2016', NULL, NULL),
(3694, 3, 4, 'Activity', 7, 6, '0.50000', '2016-02-02', '20160202', '201605', '201602', '2016', NULL, NULL),
(3695, 3, 4, 'Activity', 7, 6, '0.50000', '2016-02-09', '20160209', '201606', '201602', '2016', NULL, NULL),
(3696, 3, 4, 'Activity', 7, 6, '0.50000', '2016-02-16', '20160216', '201607', '201602', '2016', NULL, NULL),
(3697, 3, 4, 'Activity', 7, 6, '0.50000', '2016-02-23', '20160223', '201608', '201602', '2016', NULL, NULL),
(3698, 3, 4, 'Activity', 7, 6, '0.50000', '2016-02-29', '20160229', '201609', '201602', '2016', NULL, NULL),
(3699, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-02', '20151102', '201545', '201511', '2015', NULL, NULL),
(3700, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-03', '20151103', '201545', '201511', '2015', NULL, NULL),
(3701, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-04', '20151104', '201545', '201511', '2015', NULL, NULL),
(3702, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-05', '20151105', '201545', '201511', '2015', NULL, NULL),
(3703, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-06', '20151106', '201545', '201511', '2015', NULL, NULL),
(3704, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-09', '20151109', '201546', '201511', '2015', NULL, NULL),
(3705, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-10', '20151110', '201546', '201511', '2015', NULL, NULL),
(3706, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-11', '20151111', '201546', '201511', '2015', NULL, NULL),
(3707, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-12', '20151112', '201546', '201511', '2015', NULL, NULL),
(3708, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-13', '20151113', '201546', '201511', '2015', NULL, NULL),
(3709, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-16', '20151116', '201547', '201511', '2015', NULL, NULL),
(3710, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-17', '20151117', '201547', '201511', '2015', NULL, NULL),
(3711, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-18', '20151118', '201547', '201511', '2015', NULL, NULL),
(3712, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-19', '20151119', '201547', '201511', '2015', NULL, NULL),
(3713, 8, 3, 'Activity', 3, 3, '1.00000', '2015-11-20', '20151120', '201547', '201511', '2015', NULL, NULL),
(3714, 8, 3, 'Activity', 3, 3, '0.70000', '2015-11-23', '20151123', '201548', '201511', '2015', NULL, NULL),
(3715, 10, 3, 'Activity', 4, 4, '4.50000', '2015-11-24', '20151124', '201548', '201511', '2015', NULL, NULL),
(3716, 10, 3, 'Activity', 4, 4, '4.50000', '2015-11-25', '20151125', '201548', '201511', '2015', NULL, NULL),
(3717, 10, 3, 'Activity', 4, 4, '1.00000', '2015-11-26', '20151126', '201548', '201511', '2015', NULL, NULL),
(3718, 10, 1, 'TestSession', 1, 7, '0.70000', '2015-11-27', '20151127', '201548', '201511', '2015', NULL, NULL),
(3719, 10, 1, 'TestSession', 1, 7, '0.60000', '2015-11-30', '20151130', '201549', '201511', '2015', NULL, NULL),
(3720, 10, 1, 'TestSession', 1, 7, '0.70000', '2015-12-01', '20151201', '201549', '201512', '2015', NULL, NULL),
(3721, 8, 3, 'Activity', 5, 5, '1.00000', '2015-11-27', '20151127', '201548', '201511', '2015', NULL, NULL),
(3722, 8, 3, 'Activity', 5, 5, '1.00000', '2015-11-30', '20151130', '201549', '201511', '2015', NULL, NULL),
(3723, 8, 3, 'Activity', 5, 5, '1.00000', '2015-12-01', '20151201', '201549', '201512', '2015', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `planningelement`
--

CREATE TABLE `planningelement` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `refType` varchar(100) NOT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `refName` varchar(100) DEFAULT NULL,
  `initialStartDate` date DEFAULT NULL,
  `validatedStartDate` date DEFAULT NULL,
  `plannedStartDate` date DEFAULT NULL,
  `realStartDate` date DEFAULT NULL,
  `initialEndDate` date DEFAULT NULL,
  `validatedEndDate` date DEFAULT NULL,
  `plannedEndDate` date DEFAULT NULL,
  `realEndDate` date DEFAULT NULL,
  `initialDuration` int(5) DEFAULT NULL,
  `validatedDuration` int(5) UNSIGNED DEFAULT NULL,
  `plannedDuration` int(5) DEFAULT NULL,
  `realDuration` int(5) DEFAULT NULL,
  `initialWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `validatedWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `plannedWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `realWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `wbs` varchar(100) DEFAULT NULL,
  `wbsSortable` varchar(400) DEFAULT NULL,
  `topId` int(12) UNSIGNED DEFAULT NULL,
  `topRefType` varchar(100) DEFAULT NULL,
  `topRefId` int(12) UNSIGNED DEFAULT NULL,
  `priority` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT NULL,
  `elementary` int(1) UNSIGNED DEFAULT NULL,
  `leftWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `assignedWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `dependencyLevel` decimal(3,0) UNSIGNED DEFAULT NULL,
  `idPlanningMode` int(12) DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `initialCost` decimal(11,2) DEFAULT NULL,
  `validatedCost` decimal(11,2) DEFAULT NULL,
  `assignedCost` decimal(11,2) DEFAULT NULL,
  `realCost` decimal(11,2) DEFAULT NULL,
  `leftCost` decimal(11,2) DEFAULT NULL,
  `plannedCost` decimal(11,2) DEFAULT NULL,
  `idBill` int(12) UNSIGNED DEFAULT NULL,
  `progress` int(3) UNSIGNED DEFAULT '0',
  `expectedProgress` int(6) UNSIGNED DEFAULT '0',
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `validatedCalculated` int(1) UNSIGNED DEFAULT '0',
  `workElementEstimatedWork` decimal(9,5) UNSIGNED DEFAULT NULL,
  `workElementRealWork` decimal(9,5) UNSIGNED DEFAULT NULL,
  `workElementLeftWork` decimal(9,5) UNSIGNED DEFAULT NULL,
  `workElementCount` decimal(5,0) UNSIGNED DEFAULT NULL,
  `expenseAssignedAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `expensePlannedAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `expenseRealAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `expenseLeftAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `expenseValidatedAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalAssignedCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalPlannedCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalRealCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalLeftCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalValidatedCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `notPlannedWork` decimal(12,5) UNSIGNED DEFAULT '0.00000',
  `marginWork` decimal(14,5) DEFAULT NULL,
  `marginCost` decimal(14,5) DEFAULT NULL,
  `marginWorkPct` int(6) DEFAULT NULL,
  `marginCostPct` int(6) DEFAULT NULL,
  `plannedStartFraction` decimal(6,5) DEFAULT '0.00000',
  `plannedEndFraction` decimal(6,5) DEFAULT '1.00000',
  `validatedStartFraction` decimal(6,5) DEFAULT '0.00000',
  `validatedEndFraction` decimal(6,5) DEFAULT '1.00000',
  `reserveAmount` decimal(11,2) UNSIGNED DEFAULT '0.00',
  `validatedExpenseCalculated` int(1) UNSIGNED DEFAULT '0',
  `needReplan` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `planningelement`
--

INSERT INTO `planningelement` (`id`, `idProject`, `refType`, `refId`, `refName`, `initialStartDate`, `validatedStartDate`, `plannedStartDate`, `realStartDate`, `initialEndDate`, `validatedEndDate`, `plannedEndDate`, `realEndDate`, `initialDuration`, `validatedDuration`, `plannedDuration`, `realDuration`, `initialWork`, `validatedWork`, `plannedWork`, `realWork`, `wbs`, `wbsSortable`, `topId`, `topRefType`, `topRefId`, `priority`, `idle`, `elementary`, `leftWork`, `assignedWork`, `dependencyLevel`, `idPlanningMode`, `done`, `initialCost`, `validatedCost`, `assignedCost`, `realCost`, `leftCost`, `plannedCost`, `idBill`, `progress`, `expectedProgress`, `cancelled`, `validatedCalculated`, `workElementEstimatedWork`, `workElementRealWork`, `workElementLeftWork`, `workElementCount`, `expenseAssignedAmount`, `expensePlannedAmount`, `expenseRealAmount`, `expenseLeftAmount`, `expenseValidatedAmount`, `totalAssignedCost`, `totalPlannedCost`, `totalRealCost`, `totalLeftCost`, `totalValidatedCost`, `notPlannedWork`, `marginWork`, `marginCost`, `marginWorkPct`, `marginCostPct`, `plannedStartFraction`, `plannedEndFraction`, `validatedStartFraction`, `validatedEndFraction`, `reserveAmount`, `validatedExpenseCalculated`, `needReplan`) VALUES
(1, 1, 'Project', 1, 'project one', '2011-09-05', '2015-11-02', '2015-11-02', NULL, '2015-08-19', '2016-02-29', '2016-02-29', NULL, 1027, 86, 86, NULL, '0.00000', '110.00000', '115.90000', '0.00000', '1', '001', NULL, NULL, NULL, 500, 0, 0, '115.90000', '105.20000', NULL, NULL, 0, NULL, NULL, '26584.00', '0.00', '29794.00', '29794.00', NULL, 0, 0, 0, 1, NULL, NULL, NULL, NULL, '6500.00', '6297.68', '6297.68', '0.00', NULL, '33084.00', '36091.68', '6297.68', '29794.00', '0.00', '0.00000', '-5.90000', NULL, -5, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(2, 2, 'Project', 2, 'project one - maintenance', '2012-03-05', '2015-11-02', '2015-11-02', NULL, '2015-08-19', '2016-02-29', '2016-02-29', NULL, 896, 86, 86, NULL, '0.00000', '100.00000', '85.20000', '0.00000', '1.1', '001.001', 1, 'Project', 1, 500, 0, 0, '85.20000', '85.20000', NULL, NULL, 0, NULL, NULL, '21544.00', '0.00', '21544.00', '21544.00', NULL, 0, 0, 0, 1, NULL, NULL, NULL, NULL, '0.00', '0.00', '0.00', '0.00', NULL, '21544.00', '21544.00', '0.00', '21544.00', '0.00', '0.00000', '14.80000', NULL, 15, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(3, 3, 'Project', 3, 'project one - developement', '2011-09-05', '2015-11-02', '2015-11-02', NULL, '2015-07-24', '2015-12-08', '2015-12-08', NULL, 1009, 27, 27, NULL, '0.00000', '10.00000', '28.70000', '0.00000', '1.2', '001.002', 1, 'Project', 1, 500, 0, 0, '28.70000', '18.00000', NULL, NULL, 0, NULL, NULL, '4600.00', '0.00', '7810.00', '7810.00', NULL, 0, 0, 0, 1, NULL, NULL, NULL, NULL, '0.00', '0.00', '0.00', '0.00', NULL, '4600.00', '7810.00', '0.00', '7810.00', '0.00', '0.00000', '-18.70000', NULL, -187, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(4, 4, 'Project', 4, 'project two', '2012-03-12', '2015-11-06', '2015-11-06', NULL, '2015-08-24', '2016-02-29', '2016-02-29', NULL, 894, 82, 82, NULL, '0.00000', '0.00000', '9.00000', '0.00000', '2', '002', NULL, NULL, NULL, 500, 0, 0, '9.00000', '0.00000', NULL, NULL, 0, NULL, NULL, '0.00', '0.00', '4500.00', '4500.00', NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, '0.00', '0.00', '0.00', '0.00', NULL, '0.00', '4500.00', '0.00', '4500.00', '0.00', '0.00000', NULL, NULL, NULL, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(5, 5, 'Project', 5, 'internal project', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', '0.00000', '0.00000', '0.00000', '3', '003', NULL, NULL, NULL, 500, 0, 0, '0.00000', '0.00000', NULL, NULL, 0, NULL, NULL, '0.00', '0.00', '0.00', '0.00', NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(6, 6, 'Project', 6, 'holidays', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', '0.00000', '0.00000', '0.00000', '3.1', '003.001', 5, 'Project', 5, 500, 0, 1, '0.00000', '0.00000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(7, 2, 'Activity', 1, 'bug fixing', '2012-03-05', '2015-11-02', '2015-11-02', NULL, '2015-08-19', '2016-02-29', '2016-02-29', NULL, 896, 86, 86, NULL, '0.00000', '100.00000', '85.20000', '0.00000', '1.1.1', '001.001.001', 2, 'Project', 2, 500, 0, 1, '85.20000', '85.20000', NULL, 7, 0, NULL, NULL, '21544.00', '0.00', '21544.00', '21544.00', NULL, 0, 0, 0, 0, '0.00000', '0.00000', '0.00000', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '0.14000', '0.00000', '1.00000', '0.00', 0, 0),
(8, 3, 'Activity', 2, 'Evolution X', '2011-09-05', '2015-11-02', '2015-11-02', NULL, '2015-07-20', '2015-12-02', '2015-12-02', NULL, 1005, 23, 23, NULL, NULL, '10.00000', '28.70000', '0.00000', '1.2.1', '001.002.001', 3, 'Project', 3, 500, 0, 0, '28.70000', '18.00000', NULL, 1, 0, NULL, NULL, '4600.00', '0.00', '7810.00', '7810.00', 1, 0, 0, 0, 1, '0.00000', '0.00000', '0.00000', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(9, 3, 'Activity', 3, 'Evolutoin X - Analysis', '2011-09-05', '2015-11-02', '2015-11-02', NULL, '2015-07-08', '2015-11-23', '2015-11-23', NULL, 997, 16, 16, NULL, '0.00000', '10.00000', '15.70000', '0.00000', '1.2.1.1', '001.002.001.001', 8, 'Activity', 2, 500, 0, 1, '15.70000', '5.00000', NULL, 1, 0, NULL, NULL, '1500.00', '0.00', '4710.00', '4710.00', NULL, 0, 0, 0, 0, '0.00000', '0.00000', '0.00000', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '0.70000', '0.00000', '1.00000', '0.00', 0, 0),
(10, 3, 'Activity', 4, 'Evolution X - Development', '2015-07-09', '2015-11-24', '2015-11-24', NULL, '2015-07-14', '2015-11-26', '2015-11-26', NULL, 4, 3, 3, NULL, NULL, NULL, '10.00000', '0.00000', '1.2.1.2', '001.002.001.002', 8, 'Activity', 2, 500, 0, 1, '10.00000', '10.00000', NULL, 1, 0, NULL, NULL, '2200.00', '0.00', '2200.00', '2200.00', NULL, 0, 0, 0, 0, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.10000', '0.30000', '0.00000', '1.00000', '0.00', 0, 0),
(11, 3, 'Activity', 5, 'Evolution X - Tests', '2015-07-15', '2015-11-27', '2015-11-27', NULL, '2015-07-17', '2015-12-01', '2015-12-01', NULL, 3, 3, 3, NULL, NULL, NULL, '3.00000', '0.00000', '1.2.1.3', '001.002.001.003', 8, 'Activity', 2, 500, 0, 1, '3.00000', '3.00000', NULL, 1, 0, NULL, NULL, '900.00', '0.00', '900.00', '900.00', NULL, 0, 0, 0, 0, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(12, 3, 'Milestone', 1, 'Delivery of Evolution X', '2015-07-20', '2015-12-02', '2015-12-02', NULL, '2015-07-20', '2015-12-02', '2015-12-02', NULL, 1, 1, 1, NULL, '0.00000', '0.00000', '0.00000', '0.00000', '1.2.1.4', '001.002.001.004', 8, 'Activity', 2, 500, 0, 1, '0.00000', NULL, NULL, 5, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '0.00000', '0.00000', '1.00000', '0.00', 0, 0),
(13, 3, 'Activity', 6, 'Evolution Y', '2015-07-20', '2015-12-02', '2015-12-02', NULL, '2015-07-24', '2015-12-08', '2015-12-08', NULL, 5, 5, 5, NULL, NULL, NULL, '0.00000', '0.00000', '1.2.2', '001.002.002', 3, 'Project', 3, 500, 0, 1, '0.00000', NULL, NULL, 8, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '1.00000', '0.00000', '1.00000', '0.00', 0, 0),
(14, 4, 'Activity', 7, 'Management', '2012-03-12', '2015-11-06', '2015-11-06', NULL, '2015-08-24', '2016-02-29', '2016-02-29', NULL, 894, 82, 82, NULL, '0.00000', '0.00000', '9.00000', '0.00000', '2.1', '002.001', 4, 'Project', 4, 500, 0, 1, '9.00000', '0.00000', NULL, 7, 0, NULL, NULL, '0.00', '0.00', '4500.00', '4500.00', NULL, 0, 0, 0, 0, '0.00000', '0.00000', '0.00000', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.00000', '0.50000', '0.00000', '1.00000', '0.00', 0, 0),
(15, 1, 'TestSession', 1, 'Web Application V1 - Main test session', '2015-06-25', '2015-11-27', '2015-11-27', NULL, '2015-06-25', '2015-12-01', '2015-12-01', NULL, 1, 3, 3, NULL, '0.00000', '0.00000', '2.00000', '0.00000', '1.3', '001.003', 1, 'Project', 1, 500, 0, 1, '2.00000', '2.00000', NULL, 14, 0, NULL, NULL, '440.00', '0.00', '440.00', '440.00', NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, '0.10000', '0.50000', '0.00000', '1.00000', '0.00', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `planningmode`
--

CREATE TABLE `planningmode` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(5) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `mandatoryStartDate` int(1) UNSIGNED DEFAULT '0',
  `mandatoryEndDate` int(1) UNSIGNED DEFAULT '0',
  `applyTo` varchar(20) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `mandatoryDuration` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `planningmode`
--

INSERT INTO `planningmode` (`id`, `name`, `code`, `sortOrder`, `mandatoryStartDate`, `mandatoryEndDate`, `applyTo`, `idle`, `mandatoryDuration`) VALUES
(1, 'PlanningModeASAP', 'ASAP', 100, 0, 0, 'Activity', 0, 0),
(2, 'PlanningModeREGUL', 'REGUL', 200, 1, 1, 'Activity', 0, 0),
(3, 'PlanningModeFULL', 'FULL', 300, 1, 1, 'Activity', 0, 0),
(4, 'PlanningModeALAP', 'ALAP', 400, 0, 1, 'Activity', 0, 0),
(5, 'PlanningModeFLOAT', 'FLOAT', 100, 0, 0, 'Milestone', 0, 0),
(6, 'PlanningModeFIXED', 'FIXED', 200, 0, 1, 'Milestone', 0, 0),
(7, 'PlanningModeHALF', 'HALF', 320, 1, 1, 'Activity', 0, 0),
(8, 'PlanningModeFDUR', 'FDUR', 450, 0, 0, 'Activity', 0, 1),
(9, 'PlanningModeASAP', 'ASAP', 100, 0, 0, 'TestSession', 0, 0),
(10, 'PlanningModeREGUL', 'REGUL', 200, 1, 1, 'TestSession', 0, 0),
(11, 'PlanningModeFULL', 'FULL', 300, 1, 1, 'TestSession', 0, 0),
(12, 'PlanningModeALAP', 'ALAP', 400, 0, 1, 'TestSession', 0, 0),
(13, 'PlanningModeHALF', 'HALF', 320, 1, 1, 'TestSession', 0, 0),
(14, 'PlanningModeFDUR', 'FDUR', 450, 0, 0, 'TestSession', 0, 1),
(16, 'PlanningModeFIXED', 'FIXED', 100, 1, 0, 'Meeting', 0, 0),
(17, 'PlanningModeGROUP', 'GROUP', 150, 0, 0, 'Activity', 0, 0),
(18, 'PlanningModeGROUP', 'GROUP', 150, 0, 0, 'TestSession', 0, 0),
(19, 'PlanningModeSTART', 'START', 130, 1, 0, 'Activity', 0, 0),
(20, 'PlanningModeQUART', 'QUART', 340, 1, 1, 'Activity', 0, 0),
(21, 'PlanningModeSTART', 'START', 130, 1, 0, 'TestSession', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `plugin`
--

CREATE TABLE `plugin` (
  `id` int(12) UNSIGNED NOT NULL,
  `description` mediumtext,
  `name` varchar(100) DEFAULT NULL,
  `zipFile` varchar(4000) DEFAULT NULL,
  `deploymentDate` date DEFAULT NULL,
  `isDeployed` int(1) UNSIGNED DEFAULT '0',
  `deploymentVersion` varchar(100) DEFAULT NULL,
  `compatibilityVersion` varchar(100) DEFAULT NULL,
  `pluginVersion` varchar(100) DEFAULT NULL,
  `idle` int(1) DEFAULT '0',
  `comment` varchar(4000) DEFAULT NULL,
  `uniqueCode` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `plugintriggeredevent`
--

CREATE TABLE `plugintriggeredevent` (
  `id` int(12) UNSIGNED NOT NULL,
  `idPlugin` int(12) UNSIGNED DEFAULT NULL,
  `event` varchar(100) DEFAULT NULL,
  `className` varchar(100) DEFAULT NULL,
  `script` varchar(255) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `predefinedtext`
--

CREATE TABLE `predefinedtext` (
  `id` int(12) UNSIGNED NOT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `idTextable` int(12) UNSIGNED DEFAULT NULL,
  `idType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `text` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `predefinedtext`
--

INSERT INTO `predefinedtext` (`id`, `scope`, `idTextable`, `idType`, `name`, `text`, `idle`) VALUES
(1, 'Note', 18, NULL, 'Reason for cancelling ticket', 'I decide to cancell ticket.\nMy name is _____\nReason for cancelling is : \n____', 0);

-- --------------------------------------------------------

--
-- Structure de la table `priority`
--

CREATE TABLE `priority` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` int(3) UNSIGNED DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `priority`
--

INSERT INTO `priority` (`id`, `name`, `value`, `color`, `sortOrder`, `idle`) VALUES
(1, 'Low priority', 1, '#32cd32', 40, 0),
(2, 'Medium priority', 2, '#ffd700', 30, 0),
(3, 'High priority', 4, '#ff0000', 20, 0),
(4, 'Critical priority', 8, '#000000', 10, 0);

-- --------------------------------------------------------

--
-- Structure de la table `privacy`
--

CREATE TABLE `privacy` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `privacy`
--

INSERT INTO `privacy` (`id`, `name`, `color`, `sortOrder`, `idle`) VALUES
(1, 'public', '#003399', 100, 0),
(2, 'team', '#99FF99', 200, 0),
(3, 'private', '#FF9966', 300, 0);

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idClient` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `idProductType` int(12) UNSIGNED DEFAULT NULL,
  `idComponentType` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `product`
--

INSERT INTO `product` (`id`, `name`, `idClient`, `idContact`, `description`, `creationDate`, `idle`, `idProduct`, `designation`, `scope`, `idProductType`, `idComponentType`, `idResource`) VALUES
(1, 'web application', 1, 5, NULL, '2011-09-01', 0, NULL, NULL, 'Product', NULL, NULL, NULL),
(2, 'swing application', 2, 6, NULL, '2011-09-01', 0, NULL, NULL, 'Product', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `productproject`
--

CREATE TABLE `productproject` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `productstructure`
--

CREATE TABLE `productstructure` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idComponent` int(12) UNSIGNED DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `productversionstructure`
--

CREATE TABLE `productversionstructure` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProductVersion` int(12) UNSIGNED DEFAULT NULL,
  `idComponentVersion` int(12) UNSIGNED DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `profile`
--

CREATE TABLE `profile` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `profileCode` varchar(3) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `profile`
--

INSERT INTO `profile` (`id`, `name`, `description`, `profileCode`, `sortOrder`, `idle`) VALUES
(1, 'profileAdministrator', 'Has a visibility over all the projects', 'ADM', 100, 0),
(2, 'profileSupervisor', 'Has a visibility over all the projects', 'SUP', 200, 0),
(3, 'profileProjectLeader', 'Leads his owns project', 'PL', 310, 0),
(4, 'profileTeamMember', 'Works for a project', 'TM', 320, 0),
(5, 'profileGuest', 'Has limited visibility to a project', 'G', 500, 0),
(6, 'profileExternalProjectLeader', NULL, 'EPL', 410, 0),
(7, 'profileExternalTeamMember', NULL, 'ETM', 420, 0);

-- --------------------------------------------------------

--
-- Structure de la table `project`
--

CREATE TABLE `project` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` mediumtext,
  `idClient` int(12) DEFAULT NULL,
  `idRecipient` int(12) UNSIGNED DEFAULT NULL,
  `projectCode` varchar(25) DEFAULT NULL,
  `contractCode` varchar(25) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `paymentDelay` int(3) DEFAULT NULL,
  `longitude` float(15,12) DEFAULT NULL,
  `latitude` float(15,12) DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `sortOrder` varchar(400) DEFAULT NULL,
  `idProjectType` int(12) UNSIGNED DEFAULT NULL,
  `codeType` varchar(10) DEFAULT 'OPE',
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idHealth` int(12) UNSIGNED DEFAULT NULL,
  `fixPlanning` int(1) UNSIGNED DEFAULT '0',
  `clientCode` varchar(25) DEFAULT NULL,
  `idOverallProgress` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idQuality` int(12) UNSIGNED DEFAULT NULL,
  `idTrend` int(12) UNSIGNED DEFAULT NULL,
  `idSponsor` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `objectives` mediumtext,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `isUnderConstruction` int(1) UNSIGNED DEFAULT '0',
  `lastUpdateDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `project`
--

INSERT INTO `project` (`id`, `name`, `description`, `idClient`, `idRecipient`, `projectCode`, `contractCode`, `color`, `idProject`, `idle`, `idUser`, `done`, `idleDate`, `doneDate`, `paymentDelay`, `longitude`, `latitude`, `idContact`, `sortOrder`, `idProjectType`, `codeType`, `idStatus`, `idHealth`, `fixPlanning`, `clientCode`, `idOverallProgress`, `cancelled`, `idQuality`, `idTrend`, `idSponsor`, `creationDate`, `objectives`, `idResource`, `isUnderConstruction`, `lastUpdateDateTime`) VALUES
(1, 'project one', '1st project\nThis project has 2 sub-projects', 1, NULL, '001-001', 'X23-472-722', '#6a5acd', NULL, 0, 5, 0, NULL, NULL, NULL, NULL, NULL, NULL, '001', 48, 'OPE', 1, 2, 0, NULL, 2, 0, 1, 2, NULL, NULL, NULL, 5, 0, NULL),
(2, 'project one - maintenance', 'This project is dedicated to maintenance of \'\'web application\'\' V1.0\nIt is sub-project of project one.', 1, NULL, '001-001-1', 'X23-472-722', '#6495ed', 1, 0, 5, 0, NULL, NULL, NULL, NULL, NULL, NULL, '001.001', 75, 'OPE', 1, 1, 0, NULL, 2, 0, 1, 1, NULL, NULL, NULL, 5, 0, NULL),
(3, 'project one - developement', 'This project is dedicated to developement of \'\'web application\'\' V2.0\nIt is sub-project of project one.', 1, NULL, '001-001-2', 'X23-472-722', '#87ceeb', 1, 0, 5, 0, NULL, NULL, NULL, NULL, NULL, NULL, '001.002', 75, 'OPE', 1, 3, 0, NULL, 4, 0, 3, 3, NULL, NULL, NULL, 5, 0, NULL),
(4, 'project two', '1st project\nThis project has 2 sub-projects', 2, NULL, '002-002', 'X24-001-007', '#b22222', NULL, 0, 6, 0, NULL, NULL, NULL, NULL, NULL, NULL, '002', 49, 'OPE', 1, 1, 0, NULL, 7, 0, 1, 2, NULL, NULL, NULL, 6, 0, NULL),
(5, 'internal project', 'internal project\nout of project work', 3, NULL, NULL, NULL, '#008b8b', NULL, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '003', 52, 'ADM', 1, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL),
(6, 'holidays', 'holidays', 3, NULL, NULL, NULL, '#20b2aa', 5, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '003.001', 52, 'ADM', 1, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `projecthistory`
--

CREATE TABLE `projecthistory` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `day` varchar(10) DEFAULT NULL,
  `realWork` decimal(14,5) UNSIGNED DEFAULT NULL,
  `leftWork` decimal(14,5) UNSIGNED DEFAULT NULL,
  `realCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `leftCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalRealCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `totalLeftCost` decimal(11,2) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `projecthistory`
--

INSERT INTO `projecthistory` (`id`, `idProject`, `day`, `realWork`, `leftWork`, `realCost`, `leftCost`, `totalRealCost`, `totalLeftCost`) VALUES
(1, 1, '20151026', '2.00000', '113.90000', '1000.00', '28794.00', '7297.68', '28794.00'),
(2, 3, '20151026', '3.20000', '25.50000', '960.00', '6850.00', '960.00', '6850.00'),
(3, 2, '20151026', '2.00000', '83.20000', '1000.00', '20544.00', '1000.00', '20544.00'),
(4, 4, '20151026', '2.00000', '7.00000', '1000.00', '3500.00', '1000.00', '3500.00');

-- --------------------------------------------------------

--
-- Structure de la table `provider`
--

CREATE TABLE `provider` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `idProviderType` int(12) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `providerCode` varchar(25) DEFAULT NULL,
  `idPaymentDelay` int(12) UNSIGNED DEFAULT NULL,
  `numTax` varchar(100) DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `complement` varchar(100) DEFAULT NULL,
  `zip` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `quality`
--

CREATE TABLE `quality` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `quality`
--

INSERT INTO `quality` (`id`, `name`, `color`, `sortOrder`, `icon`, `idle`) VALUES
(1, 'conform', '#32CD32', 100, 'smileyGreen.png', 0),
(2, 'some remarks', '#ffd700', 200, 'smileyYellow.png', 0),
(3, 'not conform', '#FF0000', 300, 'smileyRed.png', 0);

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idQuestionType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `sendMail` varchar(100) DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `replier` varchar(100) DEFAULT NULL,
  `initialDueDate` date DEFAULT NULL,
  `actualDueDate` date DEFAULT NULL,
  `result` mediumtext,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `question`
--

INSERT INTO `question` (`id`, `idProject`, `idQuestionType`, `name`, `description`, `creationDate`, `idUser`, `sendMail`, `idStatus`, `idResource`, `replier`, `initialDueDate`, `actualDueDate`, `result`, `done`, `doneDate`, `idle`, `idleDate`, `handled`, `handledDate`, `reference`, `externalReference`, `cancelled`) VALUES
(1, 1, 37, 'Who will be first deployed users ?', NULL, '2012-03-15', 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, NULL, '001-001-FUN-1', NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `quotation`
--

CREATE TABLE `quotation` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idQuotationType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idClient` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `additionalInfo` mediumtext,
  `initialEndDate` date DEFAULT NULL,
  `untaxedAmount` decimal(12,2) DEFAULT NULL,
  `initialPricePerDayAmount` decimal(12,2) DEFAULT '0.00',
  `initialAmount` decimal(12,2) DEFAULT '0.00',
  `comment` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `sendDate` date DEFAULT NULL,
  `validityEndDate` date DEFAULT NULL,
  `idActivityType` int(12) UNSIGNED DEFAULT NULL,
  `result` mediumtext,
  `idPaymentDelay` int(12) UNSIGNED DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT NULL,
  `fullAmount` decimal(12,2) DEFAULT NULL,
  `idDeliveryMode` int(12) UNSIGNED DEFAULT NULL,
  `idLikelihood` int(12) UNSIGNED DEFAULT NULL,
  `plannedWork` decimal(12,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `recipient`
--

CREATE TABLE `recipient` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `companyNumber` varchar(100) DEFAULT NULL,
  `numTax` varchar(100) DEFAULT NULL,
  `bankName` varchar(100) DEFAULT NULL,
  `ibanCountry` varchar(2) DEFAULT NULL,
  `ibanKey` varchar(2) DEFAULT NULL,
  `ibanBban` varchar(34) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `complement` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `taxFree` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `legalNotice` varchar(1000) DEFAULT NULL,
  `contactName` varchar(100) DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `contactPhone` varchar(100) DEFAULT NULL,
  `contactMobile` varchar(100) DEFAULT NULL,
  `bankNationalAccountNumber` varchar(100) DEFAULT NULL,
  `bankInternationalAccountNumber` varchar(100) DEFAULT NULL,
  `bankIdentificationCode` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `recipient`
--

INSERT INTO `recipient` (`id`, `name`, `companyNumber`, `numTax`, `bankName`, `ibanCountry`, `ibanKey`, `ibanBban`, `designation`, `street`, `complement`, `zip`, `city`, `state`, `country`, `taxFree`, `idle`, `legalNotice`, `contactName`, `contactEmail`, `contactPhone`, `contactMobile`, `bankNationalAccountNumber`, `bankInternationalAccountNumber`, `bankIdentificationCode`) VALUES
(1, 'Client 1 Recipient', '123 456 789', 'TAX 01 01 01', 'BARCLAYS BANK', '21', '17', '1234567890', 'M. CLIENT', 'rue blanche', NULL, '75001', 'PARIS', NULL, 'FRANCE', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2117 1234567890', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `referencable`
--

CREATE TABLE `referencable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `referencable`
--

INSERT INTO `referencable` (`id`, `name`, `idle`) VALUES
(1, 'Ticket', 0),
(2, 'Activity', 0),
(3, 'Milestone', 0),
(4, 'IndividualExpense', 0),
(5, 'ProjectExpense', 0),
(6, 'Risk', 0),
(7, 'Action', 0),
(8, 'Issue', 0),
(9, 'Meeting', 0),
(10, 'Decision', 0),
(11, 'Question', 0),
(12, 'Document', 0),
(13, 'Requirement', 0),
(14, 'TestCase', 0),
(15, 'TestSession', 0),
(16, 'Command', 0),
(17, 'Opportunity', 0),
(18, 'Quotation', 0),
(19, 'Bill', 0);

-- --------------------------------------------------------

--
-- Structure de la table `report`
--

CREATE TABLE `report` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idReportCategory` int(12) UNSIGNED NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  `sortOrder` int(5) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `orientation` varchar(1) DEFAULT 'L'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `report`
--

INSERT INTO `report` (`id`, `name`, `idReportCategory`, `file`, `sortOrder`, `idle`, `orientation`) VALUES
(1, 'reportWorkWeekly', 1, 'work.php', 110, 0, 'L'),
(2, 'reportWorkMonthly', 1, 'work.php', 120, 0, 'L'),
(3, 'reportWorkYearly', 1, 'work.php', 130, 0, 'L'),
(4, 'reportPlanColoredMonthly', 2, 'colorPlan.php', 230, 0, 'L'),
(5, 'reportPlanResourceMonthly', 2, 'resourcePlan.php', 240, 0, 'L'),
(6, 'reportPlanProjectMonthly', 2, 'projectPlan.php', 250, 0, 'L'),
(7, 'reportPlanGantt', 2, '../tool/jsonPlanning.php?print=true', 210, 0, 'L'),
(8, 'reportWorkPlan', 2, 'workPlan.php', 220, 0, 'L'),
(9, 'reportTicketYearly', 3, 'ticketYearlyReport.php', 310, 0, 'L'),
(10, 'reportTicketYearlyByType', 3, 'ticketYearlyReportByType.php', 320, 0, 'L'),
(11, 'reportTicketWeeklyCrossReport', 3, 'ticketReport.php', 330, 0, 'L'),
(12, 'reportTicketMonthlyCrossReport', 3, 'ticketReport.php', 340, 0, 'L'),
(13, 'reportTicketYearlyCrossReport', 3, 'ticketReport.php', 350, 0, 'L'),
(14, 'reportTicketWeeklySynthesis', 3, 'ticketSynthesis.php', 360, 0, 'L'),
(15, 'reportTicketMonthlySynthesis', 3, 'ticketSynthesis.php', 370, 0, 'L'),
(16, 'reportTicketYearlySynthesis', 3, 'ticketSynthesis.php', 380, 0, 'L'),
(17, 'reportTicketGlobalCrossReport', 3, 'ticketReport.php', 355, 0, 'L'),
(18, 'reportTicketGlobalSynthesis', 3, 'ticketSynthesis.php', 390, 0, 'L'),
(19, 'reportGlobalWorkPlanningWeekly', 2, 'globalWorkPlanning.php?scale=week', 260, 0, 'L'),
(20, 'reportGlobalWorkPlanningMonthly', 2, 'globalWorkPlanning.php?scale=month', 270, 0, 'L'),
(21, 'reportStatusOngoing', 4, 'status.php', 410, 0, 'L'),
(22, 'reportStatusAll', 4, 'status.php?showIdle=true', 420, 0, 'L'),
(23, 'reportRiskManagementPlan', 4, 'riskManagementPlan.php', 430, 0, 'L'),
(24, 'reportHistoryDeteled', 5, 'history.php?scope=deleted', 520, 0, 'L'),
(25, 'reportHistoryDetail', 5, 'history.php?scope=item', 510, 0, 'L'),
(26, 'reportCostDetail', 6, 'costPlan.php', 610, 0, 'L'),
(27, 'reportCostMonthly', 6, 'globalCostPlanning.php?scale=month', 620, 0, 'L'),
(28, 'reportWorkDetailWeekly', 1, 'workDetail.php?scale=week', 140, 0, 'L'),
(29, 'reportWorkDetailMonthly', 1, 'workDetail.php?scale=month', 150, 0, 'L'),
(30, 'reportWorkDetailYearly', 1, 'workDetail.php?scale=year', 160, 0, 'L'),
(31, 'reportPlanDetail', 2, 'detailPlan.php', 255, 0, 'L'),
(32, 'reportAvailabilityPlan', 2, 'availabilityPlan.php', 280, 0, 'L'),
(33, 'reportExpenseProject', 6, 'expensePlan.php?scale=month&scope=Project', 660, 0, 'L'),
(34, 'reportExpenseResource', 6, 'expensePlan.php?scale=month&scope=Individual', 670, 0, 'L'),
(35, 'reportExpenseTotal', 6, 'expensePlan.php?scale=month', 680, 0, 'L'),
(36, 'reportExpenseCostTotal', 6, 'expenseCostTotalPlan.php?scale=month', 690, 0, 'L'),
(37, 'reportBill', 7, 'bill.php', 710, 0, 'L'),
(39, 'reportVersionDetail', 4, 'versionDetail.php', 450, 0, 'L'),
(41, 'reportProductTest', 8, 'productTest.php', 820, 0, 'L'),
(42, 'reportPlanActivityMonthly', 2, 'activityPlan.php', 252, 0, 'L'),
(43, 'reportTestSession', 8, 'testSession.php', 830, 0, 'L'),
(44, 'reportRequirementTest', 8, 'requirementTest.php', 810, 0, 'L'),
(45, 'reportTermMonthly', 7, 'term.php', 720, 0, 'L'),
(46, 'reportTermWeekly', 7, 'term.php', 730, 0, 'L'),
(47, 'reportOpportunityPlan', 4, 'opportunityPlan.php', 440, 0, 'L'),
(48, 'reportAudit', 9, 'audit.php', 910, 0, 'L'),
(49, 'reportPortfolioGantt', 2, '../tool/jsonPlanning.php?print=true&portfolio=true', 215, 0, 'L'),
(50, 'reportProject', 9, 'projectDashboard.php', 920, 0, 'L'),
(51, 'flashReport', 9, 'projectFlashReport.php', 930, 0, 'L'),
(52, 'reportAvailabilitySynthesis', 2, 'availabilitySynthesis.php', 282, 0, 'L'),
(53, 'reportProductTestDetail', 8, 'productTestDetail.php', 825, 0, 'L'),
(54, 'reportWorkWeeklyResource', 1, 'work.php', 170, 0, 'L'),
(55, 'reportWorkMonthlyResource', 1, 'work.php', 180, 0, 'L'),
(56, 'reportWorkYearlyResource', 1, 'work.php', 190, 0, 'L'),
(57, 'reportPlanDetailPerResource', 2, 'detailPlan.php', 256, 0, 'L'),
(58, 'reportPlanProjectDetailPerResource', 2, 'activityPlan.php', 257, 0, 'L');

-- --------------------------------------------------------

--
-- Structure de la table `reportcategory`
--

CREATE TABLE `reportcategory` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(5) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `reportcategory`
--

INSERT INTO `reportcategory` (`id`, `name`, `sortOrder`, `idle`) VALUES
(1, 'reportCategoryWork', 10, 0),
(2, 'reportCategoryPlan', 20, 0),
(3, 'reportCategoryTicket', 30, 0),
(4, 'reportCategoryStatus', 40, 0),
(5, 'reportCategoryHistory', 90, 0),
(6, 'reportCategoryCost', 50, 0),
(7, 'reportCategoryBill', 60, 0),
(8, 'reportCategoryRequirementTest', 70, 0),
(9, 'reportCategoryMisc', 80, 0);

-- --------------------------------------------------------

--
-- Structure de la table `reportparameter`
--

CREATE TABLE `reportparameter` (
  `id` int(12) UNSIGNED NOT NULL,
  `idReport` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `paramType` varchar(100) DEFAULT NULL,
  `sortOrder` int(5) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `defaultValue` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `reportparameter`
--

INSERT INTO `reportparameter` (`id`, `idReport`, `name`, `paramType`, `sortOrder`, `idle`, `defaultValue`) VALUES
(1, 1, 'week', 'week', 10, 0, 'currentWeek'),
(2, 2, 'month', 'month', 10, 0, 'currentMonth'),
(3, 3, 'year', 'year', 10, 0, 'currentYear'),
(4, 4, 'month', 'month', 10, 0, 'currentMonth'),
(5, 5, 'month', 'month', 10, 0, 'currentMonth'),
(6, 6, 'month', 'month', 10, 0, 'currentMonth'),
(7, 7, 'startDate', 'date', 20, 0, 'today'),
(8, 7, 'endDate', 'date', 40, 0, NULL),
(9, 7, 'format', 'periodScale', 40, 0, 'day'),
(10, 7, 'idProject', 'projectList', 10, 0, 'currentProject'),
(11, 8, 'idProject', 'projectList', 10, 0, 'currentProject'),
(12, 9, 'idProject', 'projectList', 10, 0, 'currentProject'),
(13, 9, 'year', 'year', 20, 0, 'currentYear'),
(14, 9, 'idTicketType', 'ticketType', 30, 0, NULL),
(15, 9, 'issuer', 'userList', 40, 0, NULL),
(16, 9, 'responsible', 'resourceList', 50, 0, NULL),
(17, 10, 'idProject', 'projectList', 10, 0, 'currentProject'),
(18, 10, 'year', 'year', 20, 0, 'currentYear'),
(19, 10, 'issuer', 'userList', 40, 0, NULL),
(20, 10, 'responsible', 'resourceList', 50, 0, NULL),
(21, 11, 'idProject', 'projectList', 10, 0, 'currentProject'),
(22, 11, 'week', 'week', 20, 0, 'currentWeek'),
(23, 11, 'issuer', 'userList', 30, 0, NULL),
(24, 11, 'responsible', 'resourceList', 40, 0, NULL),
(25, 12, 'idProject', 'projectList', 10, 0, 'currentProject'),
(26, 12, 'month', 'month', 20, 0, 'currentMonth'),
(27, 12, 'issuer', 'userList', 30, 0, NULL),
(28, 12, 'responsible', 'resourceList', 40, 0, NULL),
(29, 13, 'idProject', 'projectList', 10, 0, 'currentProject'),
(30, 13, 'year', 'year', 20, 0, 'currentYear'),
(31, 13, 'issuer', 'userList', 30, 0, NULL),
(32, 13, 'responsible', 'resourceList', 40, 0, NULL),
(33, 14, 'idProject', 'projectList', 10, 0, 'currentProject'),
(34, 14, 'week', 'week', 20, 0, 'currentWeek'),
(35, 14, 'issuer', 'userList', 30, 0, NULL),
(36, 14, 'responsible', 'resourceList', 40, 0, NULL),
(37, 15, 'idProject', 'projectList', 10, 0, 'currentProject'),
(38, 15, 'month', 'month', 20, 0, 'currentMonth'),
(39, 15, 'issuer', 'userList', 30, 0, NULL),
(40, 15, 'responsible', 'resourceList', 40, 0, NULL),
(41, 16, 'idProject', 'projectList', 10, 0, 'currentProject'),
(42, 16, 'year', 'year', 20, 0, 'currentYear'),
(43, 16, 'issuer', 'userList', 30, 0, NULL),
(44, 16, 'responsible', 'resourceList', 40, 0, NULL),
(45, 17, 'idProject', 'projectList', 10, 0, 'currentProject'),
(46, 17, 'issuer', 'userList', 20, 0, NULL),
(47, 17, 'responsible', 'resourceList', 30, 0, NULL),
(48, 18, 'idProject', 'projectList', 10, 0, 'currentProject'),
(49, 18, 'issuer', 'userList', 20, 0, NULL),
(50, 18, 'responsible', 'resourceList', 30, 0, NULL),
(51, 19, 'idProject', 'projectList', 10, 0, 'currentProject'),
(52, 20, 'idProject', 'projectList', 10, 0, 'currentProject'),
(53, 21, 'idProject', 'projectList', 10, 0, 'currentProject'),
(54, 21, 'issuer', 'userList', 20, 0, NULL),
(55, 21, 'responsible', 'resourceList', 30, 0, NULL),
(56, 22, 'idProject', 'projectList', 10, 0, 'currentProject'),
(57, 22, 'issuer', 'userList', 20, 0, NULL),
(58, 22, 'responsible', 'resourceList', 30, 0, NULL),
(59, 23, 'idProject', 'projectList', 10, 0, 'currentProject'),
(61, 25, 'refType', 'objectList', 10, 0, NULL),
(62, 25, 'refId', 'id', 20, 0, NULL),
(63, 26, 'idProject', 'projectList', 10, 0, 'currentProject'),
(64, 27, 'idProject', 'projectList', 10, 0, 'currentProject'),
(65, 28, 'week', 'week', 10, 0, 'currentWeek'),
(66, 29, 'month', 'month', 10, 0, 'currentMonth'),
(67, 30, 'year', 'year', 10, 0, 'currentYear'),
(68, 31, 'idProject', 'projectList', 10, 0, 'currentProject'),
(69, 31, 'month', 'month', 20, 0, 'currentMonth'),
(70, 32, 'month', 'month', 10, 0, 'currentMonth'),
(71, 33, 'idProject', 'projectList', 10, 0, 'currentProject'),
(72, 34, 'idProject', 'projectList', 10, 0, 'currentProject'),
(73, 35, 'idProject', 'projectList', 10, 0, 'currentProject'),
(74, 36, 'idProject', 'projectList', 10, 0, 'currentProject'),
(75, 34, 'idResource', 'resourceList', 20, 0, NULL),
(76, 9, 'requestor', 'requestorList', 35, 0, NULL),
(77, 10, 'requestor', 'requestorList', 35, 0, NULL),
(78, 11, 'requestor', 'requestorList', 25, 0, NULL),
(79, 12, 'requestor', 'requestorList', 25, 0, NULL),
(80, 13, 'requestor', 'requestorList', 25, 0, NULL),
(81, 14, 'requestor', 'requestorList', 25, 0, NULL),
(82, 15, 'requestor', 'requestorList', 25, 0, NULL),
(83, 16, 'requestor', 'requestorList', 25, 0, NULL),
(84, 17, 'requestor', 'requestorList', 15, 0, NULL),
(85, 18, 'requestor', 'requestorList', 15, 0, NULL),
(86, 37, 'idBill', 'billList', 10, 0, NULL),
(87, 37, 'idProject', 'projectList', 20, 0, 'currentProject'),
(88, 37, 'idClient', 'clientList', 30, 0, NULL),
(89, 1, 'idProject', 'projectList', 1, 0, 'currentProject'),
(90, 2, 'idProject', 'projectList', 1, 0, 'currentProject'),
(91, 3, 'idProject', 'projectList', 1, 0, 'currentProject'),
(92, 28, 'idProject', 'projectList', 1, 0, 'currentProject'),
(93, 29, 'idProject', 'projectList', 1, 0, 'currentProject'),
(94, 30, 'idProject', 'projectList', 1, 0, 'currentProject'),
(95, 4, 'idProject', 'projectList', 1, 0, 'currentProject'),
(96, 5, 'idProject', 'projectList', 1, 0, 'currentProject'),
(97, 6, 'idProject', 'projectList', 1, 0, 'currentProject'),
(101, 39, 'idProject', 'projectList', 10, 0, 'currentProject'),
(102, 39, 'idVersion', 'versionList', 20, 0, NULL),
(103, 39, 'responsible', 'resourceList', 30, 0, NULL),
(105, 44, 'idProduct', 'productList', 20, 0, NULL),
(106, 44, 'idVersion', 'versionList', 30, 0, NULL),
(107, 44, 'showDetail', 'showDetail', 40, 0, NULL),
(108, 41, 'idProject', 'projectList', 10, 0, NULL),
(109, 41, 'idProduct', 'productList', 20, 0, NULL),
(110, 41, 'idVersion', 'versionList', 30, 0, NULL),
(111, 41, 'showDetail', 'showDetail', 40, 0, NULL),
(112, 42, 'idProject', 'projectList', 10, 0, 'currentProject'),
(113, 42, 'month', 'month', 20, 0, 'currentMonth'),
(114, 43, 'idProject', 'projectList', 10, 0, NULL),
(115, 43, 'idProduct', 'productList', 20, 0, NULL),
(116, 43, 'idVersion', 'versionList', 30, 0, NULL),
(117, 43, 'idTestSession', 'testSessionList', 40, 0, NULL),
(118, 43, 'showDetail', 'showDetail', 50, 0, NULL),
(119, 44, 'idProject', 'projectList', 10, 0, NULL),
(120, 1, 'idTeam', 'teamList', 5, 0, NULL),
(121, 2, 'idTeam', 'teamList', 5, 0, NULL),
(122, 3, 'idTeam', 'teamList', 5, 0, NULL),
(123, 28, 'idTeam', 'teamList', 5, 0, NULL),
(124, 29, 'idTeam', 'teamList', 5, 0, NULL),
(125, 30, 'idTeam', 'teamList', 5, 0, NULL),
(126, 4, 'idTeam', 'teamList', 5, 0, NULL),
(127, 5, 'idTeam', 'teamList', 5, 0, NULL),
(128, 6, 'idTeam', 'teamList', 5, 0, NULL),
(129, 42, 'idTeam', 'teamList', 15, 0, NULL),
(130, 31, 'idTeam', 'teamList', 15, 0, NULL),
(131, 32, 'idTeam', 'teamList', 20, 0, NULL),
(132, 38, 'otherVersions', 'boolean', 900, 0, NULL),
(133, 39, 'otherVersions', 'boolean', 900, 0, NULL),
(134, 45, 'idProject', 'projectList', 10, 0, 'currentProject'),
(135, 45, 'month', 'month', 20, 0, 'currentMonth'),
(136, 46, 'idProject', 'projectList', 10, 0, 'currentProject'),
(137, 46, 'week', 'week', 20, 0, 'currentWeek'),
(138, 19, 'idTeam', 'teamList', 20, 0, NULL),
(139, 19, 'week', 'week', 30, 0, 'currentYear'),
(140, 20, 'idTeam', 'teamList', 20, 0, NULL),
(141, 20, 'month', 'month', 30, 0, 'currentYear'),
(142, 27, 'idTeam', 'teamList', 20, 0, NULL),
(143, 27, 'month', 'month', 30, 0, 'currentYear'),
(144, 47, 'idProject', 'projectList', 10, 0, 'currentProject'),
(145, 48, 'month', 'month', 10, 0, 'currentMonth'),
(146, 49, 'idProject', 'projectList', 10, 0, 'currentProject'),
(147, 49, 'startDate', 'date', 20, 0, 'today'),
(148, 49, 'endDate', 'date', 30, 0, NULL),
(149, 49, 'format', 'periodScale', 40, 0, 'week'),
(150, 49, 'listShowMilestone', 'milestoneTypeList', 50, 0, ''),
(151, 50, 'idProject', 'projectList', 10, 0, 'currentProject'),
(152, 51, 'idProject', 'projectList', 10, 0, 'currentProject'),
(153, 52, 'period', 'nextPeriod', 10, 0, '10/month'),
(154, 52, 'idTeam', 'teamList', 20, 0, NULL),
(155, 53, 'idProject', 'projectList', 10, 0, NULL),
(156, 53, 'idProduct', 'productList', 20, 0, NULL),
(157, 53, 'idVersion', 'versionList', 30, 0, NULL),
(158, 54, 'week', 'week', 30, 0, 'currentWeek'),
(159, 55, 'month', 'month', 30, 0, 'currentMonth'),
(160, 56, 'year', 'year', 30, 0, 'currentYear'),
(161, 54, 'idProject', 'projectList', 10, 0, 'currentProject'),
(162, 55, 'idProject', 'projectList', 10, 0, 'currentProject'),
(163, 56, 'idProject', 'projectList', 10, 0, 'currentProject'),
(164, 54, 'idResource', 'resourceList', 20, 0, 'currentResource'),
(165, 55, 'idResource', 'resourceList', 20, 0, 'currentResource'),
(166, 56, 'idResource', 'resourceList', 20, 0, 'currentResource'),
(167, 38, 'showDoneVersions', 'boolean', 850, 0, NULL),
(168, 39, 'showDoneVersions', 'boolean', 850, 0, NULL),
(169, 57, 'month', 'month', 20, 0, 'currentMonth'),
(171, 57, 'idResource', 'resourceList', 10, 0, 'currentResource'),
(172, 31, 'idResource', 'resourceList', 17, 0, NULL),
(173, 42, 'idResource', 'resourceList', 17, 0, NULL),
(174, 58, 'month', 'month', 20, 0, 'currentMonth'),
(175, 58, 'idResource', 'resourceList', 10, 0, 'currentResource'),
(176, 31, 'includeNextMonth', 'boolean', 50, 0, NULL),
(177, 57, 'includeNextMonth', 'boolean', 50, 0, NULL),
(178, 4, 'includeNextMonth', 'boolean', 50, 0, NULL),
(179, 5, 'includeNextMonth', 'boolean', 50, 0, NULL),
(180, 6, 'includeNextMonth', 'boolean', 50, 0, NULL),
(181, 42, 'includeNextMonth', 'boolean', 50, 0, NULL),
(182, 58, 'includeNextMonth', 'boolean', 50, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `requirement`
--

CREATE TABLE `requirement` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idVersion` int(12) UNSIGNED DEFAULT NULL,
  `idRequirementType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDateTime` datetime DEFAULT NULL,
  `description` mediumtext,
  `idRequirement` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `idTargetVersion` int(12) UNSIGNED DEFAULT NULL,
  `plannedWork` decimal(14,5) UNSIGNED DEFAULT '0.00000',
  `idUrgency` int(12) UNSIGNED DEFAULT NULL,
  `idCriticality` int(12) UNSIGNED DEFAULT NULL,
  `idFeasibility` int(12) UNSIGNED DEFAULT NULL,
  `idRiskLevel` int(12) UNSIGNED DEFAULT NULL,
  `result` mediumtext,
  `countPassed` int(5) DEFAULT '0',
  `countFailed` int(5) DEFAULT '0',
  `countBlocked` int(5) DEFAULT '0',
  `countPlanned` int(5) DEFAULT '0',
  `countLinked` int(5) DEFAULT '0',
  `countIssues` int(5) DEFAULT '0',
  `countTotal` int(5) DEFAULT '0',
  `idRunStatus` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `locked` int(1) UNSIGNED DEFAULT '0',
  `idLocker` int(12) UNSIGNED DEFAULT NULL,
  `lockedDate` datetime DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `initialDueDate` date DEFAULT NULL,
  `actualDueDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `requirement`
--

INSERT INTO `requirement` (`id`, `reference`, `idProject`, `idProduct`, `idVersion`, `idRequirementType`, `name`, `externalReference`, `idUser`, `creationDateTime`, `description`, `idRequirement`, `idStatus`, `idResource`, `handled`, `handledDate`, `done`, `doneDate`, `idle`, `idleDate`, `idTargetVersion`, `plannedWork`, `idUrgency`, `idCriticality`, `idFeasibility`, `idRiskLevel`, `result`, `countPassed`, `countFailed`, `countBlocked`, `countPlanned`, `countLinked`, `countIssues`, `countTotal`, `idRunStatus`, `idContact`, `locked`, `idLocker`, `lockedDate`, `cancelled`, `initialDueDate`, `actualDueDate`) VALUES
(1, '-FUNC-1', NULL, 1, NULL, 76, 'Filed "Name" is mandatory', NULL, 1, '2012-08-05 17:01:00', 'Filed name must be set', NULL, 4, 3, 1, '2012-08-05', 1, '2012-08-05', 0, NULL, NULL, '0.00000', NULL, 1, 1, 2, NULL, 1, 1, 0, 0, 2, 0, 2, 3, 6, 0, NULL, NULL, 0, NULL, NULL),
(2, '-FUNC-2', NULL, 1, NULL, 76, 'field "2" must be numeric', NULL, 1, '2012-08-05 19:38:00', 'qsd', NULL, 1, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, '0.00000', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 5, NULL, 0, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `resolution`
--

CREATE TABLE `resolution` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `solved` int(1) UNSIGNED DEFAULT '0',
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `resolution`
--

INSERT INTO `resolution` (`id`, `name`, `solved`, `color`, `sortOrder`, `idle`) VALUES
(1, 'not resolved', 1, '#eeeeee', 10, 0),
(2, 'fixed', 1, '#00ff00', 20, 0),
(3, 'already fixed', 1, '#00ff00', 30, 0),
(4, 'duplicate', 0, '#ff0000', 40, 0),
(5, 'rejected', 0, '#ff0000', 50, 0),
(6, 'support provided', 1, '#00ff00', 60, 0),
(7, 'workaround provided', 1, '#00ff00', 70, 0),
(8, 'evolution done', 1, '#00ff00', 80, 0);

-- --------------------------------------------------------

--
-- Structure de la table `resource`
--

CREATE TABLE `resource` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `password` varchar(100) DEFAULT NULL,
  `idProfile` int(12) DEFAULT NULL,
  `isResource` int(1) UNSIGNED DEFAULT '0',
  `isUser` int(1) UNSIGNED DEFAULT '0',
  `locked` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `phone` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `idTeam` int(12) UNSIGNED DEFAULT NULL,
  `capacity` decimal(5,2) UNSIGNED DEFAULT '1.00',
  `address` varchar(4000) DEFAULT NULL,
  `isContact` int(1) UNSIGNED DEFAULT '0',
  `designation` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `complement` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `idClient` int(12) UNSIGNED DEFAULT NULL,
  `idRole` int(12) UNSIGNED DEFAULT NULL,
  `idRecipient` int(12) UNSIGNED DEFAULT NULL,
  `isLdap` int(1) UNSIGNED DEFAULT '0',
  `initials` varchar(10) DEFAULT NULL,
  `loginTry` int(5) UNSIGNED DEFAULT '0',
  `salt` varchar(100) DEFAULT NULL,
  `crypto` varchar(100) DEFAULT 'md5',
  `idCalendarDefinition` int(12) UNSIGNED DEFAULT '1',
  `cookieHash` varchar(400) DEFAULT NULL,
  `passwordChangeDate` date DEFAULT NULL,
  `apiKey` varchar(400) DEFAULT NULL,
  `dontReceiveTeamMails` int(1) UNSIGNED DEFAULT '0',
  `function` varchar(100) DEFAULT NULL,
  `idProvider` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `resource`
--

INSERT INTO `resource` (`id`, `name`, `fullName`, `email`, `description`, `password`, `idProfile`, `isResource`, `isUser`, `locked`, `idle`, `phone`, `mobile`, `fax`, `idTeam`, `capacity`, `address`, `isContact`, `designation`, `street`, `complement`, `zip`, `city`, `state`, `country`, `idClient`, `idRole`, `idRecipient`, `isLdap`, `initials`, `loginTry`, `salt`, `crypto`, `idCalendarDefinition`, `cookieHash`, `passwordChangeDate`, `apiKey`, `dontReceiveTeamMails`, `function`, `idProvider`) VALUES
(1, 'admin', 'admin', 'admin@toolware.fr', NULL, '21232f297a57a5a743894a0e4a801fc3', 1, 1, 1, 0, 0, NULL, NULL, NULL, NULL, '1.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', 'e6e4941e966def9ca59890c08181fa30', 0, NULL, NULL),
(2, 'guest', NULL, NULL, NULL, '084e0343a0486ff05530df6c705c8bb4', 5, 0, 1, 0, 0, NULL, NULL, NULL, NULL, '1.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', '5d742be3c93871efc7bab039ef08bfa6', 0, NULL, NULL),
(3, 'manager', 'project manager', 'project.manager@toolware.fr', NULL, '6d361b76b20af1a3ebbf75a00b501766', 3, 1, 1, 0, 0, NULL, NULL, NULL, 1, '1.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', '35adac1dd9888f4940a83440691284ac', 0, NULL, NULL),
(4, 'member1', 'analyst A', NULL, NULL, NULL, 4, 1, 1, 0, 0, NULL, NULL, NULL, 1, '1.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', '154413d8c292ad77497f084efecf1da3', 0, NULL, NULL),
(5, 'external1', 'external project leader one', 'project.leader@external.com', NULL, NULL, 6, 0, 1, 0, 0, NULL, NULL, NULL, NULL, '1.00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 0, 'EPL', 0, NULL, 'md5', 1, NULL, '2015-06-25', 'f5d8e7a228d7ab2ffb4ac2d5254dcfba', 0, NULL, NULL),
(6, 'external2', 'external project leader two', NULL, NULL, NULL, 6, 0, 1, 0, 0, NULL, NULL, NULL, NULL, '1.00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', '04b6870607489958284551cf605b5c59', 0, NULL, NULL),
(7, NULL, 'external business leader one', NULL, NULL, NULL, 5, 0, 0, 0, 0, NULL, NULL, NULL, NULL, '1.00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, NULL, NULL, 0, NULL, NULL),
(8, 'member2', 'analyst B', NULL, NULL, NULL, 4, 1, 1, 0, 0, NULL, NULL, NULL, 1, '1.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', 'f2a3a9c843208ce20dd2ebb1599155c9', 0, NULL, NULL),
(9, 'member3', 'analyst C', NULL, NULL, NULL, 4, 1, 1, 0, 0, NULL, NULL, NULL, 2, '1.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, '2015-06-25', '15c97db66fe436b3f727a8a99bae2b44', 0, NULL, NULL),
(10, NULL, 'web developer', NULL, NULL, NULL, 4, 1, 0, 0, 0, NULL, NULL, NULL, 1, '5.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, NULL, NULL, 0, NULL, NULL),
(11, NULL, 'swing developer', NULL, NULL, NULL, 4, 1, 0, 0, 0, NULL, NULL, NULL, 2, '5.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, NULL, NULL, 0, NULL, NULL),
(12, NULL, 'multi developer', NULL, NULL, NULL, 4, 1, 0, 0, 0, NULL, NULL, NULL, NULL, '5.00', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, 0, NULL, 0, NULL, 'md5', 1, NULL, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `resourcecost`
--

CREATE TABLE `resourcecost` (
  `id` int(12) UNSIGNED NOT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idRole` int(12) UNSIGNED DEFAULT NULL,
  `cost` decimal(11,2) DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `resourcecost`
--

INSERT INTO `resourcecost` (`id`, `idResource`, `idRole`, `cost`, `startDate`, `endDate`, `idle`) VALUES
(1, 3, 1, '500.00', NULL, NULL, 0),
(2, 4, 2, '300.00', NULL, NULL, 0),
(3, 8, 2, '300.00', NULL, NULL, 0),
(4, 9, 2, '300.00', NULL, NULL, 0),
(5, 10, 3, '220.00', NULL, NULL, 0),
(6, 11, 3, '230.00', NULL, NULL, 0),
(7, 12, 3, '250.00', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `restricttype`
--

CREATE TABLE `restricttype` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProjectType` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `className` varchar(100) DEFAULT NULL,
  `idType` int(12) UNSIGNED DEFAULT NULL,
  `idProfile` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `risk`
--

CREATE TABLE `risk` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idRiskType` int(12) UNSIGNED DEFAULT NULL,
  `cause` mediumtext,
  `impact` mediumtext,
  `idSeverity` int(12) UNSIGNED DEFAULT NULL,
  `idLikelihood` int(12) UNSIGNED DEFAULT NULL,
  `idCriticality` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `initialEndDate` date DEFAULT NULL,
  `actualEndDate` date DEFAULT NULL,
  `idleDate` date DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idPriority` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `impactCost` decimal(11,2) UNSIGNED DEFAULT '0.00',
  `projectReserveAmount` decimal(11,2) UNSIGNED DEFAULT '0.00',
  `mitigationPlan` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `risk`
--

INSERT INTO `risk` (`id`, `idProject`, `name`, `description`, `idRiskType`, `cause`, `impact`, `idSeverity`, `idLikelihood`, `idCriticality`, `creationDate`, `idUser`, `idStatus`, `idResource`, `initialEndDate`, `actualEndDate`, `idleDate`, `result`, `comment`, `idle`, `done`, `doneDate`, `handled`, `handledDate`, `reference`, `externalReference`, `idPriority`, `cancelled`, `impactCost`, `projectReserveAmount`, `mitigationPlan`) VALUES
(1, 1, 'Performance', NULL, 1, 'Hardware not sized corresponding to expected load', 'Anable to deliver the service', 3, 2, 3, '2012-03-14', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, '001-001-CON-1', NULL, NULL, 0, '0.00', '0.00', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `risklevel`
--

CREATE TABLE `risklevel` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `risklevel`
--

INSERT INTO `risklevel` (`id`, `name`, `color`, `sortOrder`, `idle`) VALUES
(1, 'Very Low', '#00FF00', 100, 0),
(2, 'Low', '#00AAAA', 200, 0),
(3, 'Average', '#AAAAAA', 300, 0),
(4, 'High', '#AAAA00', 400, 0),
(5, 'Very High', '#FF0000', 500, 0);

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `sortOrder` int(3) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `role`
--

INSERT INTO `role` (`id`, `name`, `description`, `sortOrder`, `idle`) VALUES
(1, 'Manager', 'Leader/Manager of the project', 10, 0),
(2, 'Analyst', 'Responsible of specifications', 20, 0),
(3, 'Developer', 'Sowftware developer', 30, 0),
(4, 'Expert', 'Technical expert', 40, 0),
(5, 'Machine', 'Non human resource', 50, 0);

-- --------------------------------------------------------

--
-- Structure de la table `runstatus`
--

CREATE TABLE `runstatus` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `runstatus`
--

INSERT INTO `runstatus` (`id`, `name`, `color`, `sortOrder`, `idle`) VALUES
(1, 'planned', '#FFFFFF', 200, 0),
(2, 'passed', '#32CD32', 300, 0),
(3, 'failed', '#FF0000', 500, 0),
(4, 'blocked', '#FFA500', 400, 0),
(5, 'notPlanned', '#BB64BB', 100, 1);

-- --------------------------------------------------------

--
-- Structure de la table `severity`
--

CREATE TABLE `severity` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` int(3) UNSIGNED DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `severity`
--

INSERT INTO `severity` (`id`, `name`, `value`, `color`, `sortOrder`, `idle`) VALUES
(1, 'Low', 1, '#32cd32', 10, 0),
(2, 'Medium', 2, '#ffd700', 20, 0),
(3, 'High', 4, '#ff0000', 30, 0);

-- --------------------------------------------------------

--
-- Structure de la table `sla`
--

CREATE TABLE `sla` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idTicketType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `durationSla` double DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `status`
--

CREATE TABLE `status` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `setDoneStatus` int(1) UNSIGNED DEFAULT '0',
  `setIdleStatus` int(1) UNSIGNED DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `setHandledStatus` int(1) UNSIGNED DEFAULT '0',
  `isCopyStatus` int(1) UNSIGNED DEFAULT '0',
  `setCancelledStatus` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `status`
--

INSERT INTO `status` (`id`, `name`, `setDoneStatus`, `setIdleStatus`, `color`, `sortOrder`, `idle`, `setHandledStatus`, `isCopyStatus`, `setCancelledStatus`) VALUES
(1, 'recorded', 0, 0, '#ffa500', 100, 0, 0, 0, 0),
(2, 'qualified', 0, 0, '#87ceeb', 200, 0, 0, 0, 0),
(3, 'in progress', 0, 0, '#d2691e', 300, 0, 1, 0, 0),
(4, 'done', 1, 0, '#afeeee', 400, 0, 1, 0, 0),
(5, 'verified', 1, 0, '#32cd32', 500, 0, 1, 0, 0),
(6, 'delivered', 1, 0, '#4169e1', 600, 0, 1, 0, 0),
(7, 'closed', 1, 1, '#c0c0c0', 700, 0, 1, 0, 0),
(8, 're-opened', 0, 0, '#ff0000', 250, 0, 0, 0, 0),
(9, 'cancelled', 1, 1, '#c0c0c0', 999, 0, 1, 0, 1),
(10, 'assigned', 0, 0, '#8b4513', 275, 0, 1, 0, 0),
(11, 'accepted', 0, 0, '#a52a2a', 220, 0, 0, 0, 0),
(12, 'validated', 1, 0, '#98fb98', 650, 0, 1, 0, 0),
(13, 'prepared', 0, 0, '#d2691e', 290, 0, 1, 0, 0),
(14, 'copied', 0, 0, '#ffffff', 999, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `statusmail`
--

CREATE TABLE `statusmail` (
  `id` int(12) UNSIGNED NOT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idMailable` int(12) UNSIGNED DEFAULT NULL,
  `mailToUser` int(1) UNSIGNED DEFAULT '0',
  `mailToResource` int(1) UNSIGNED DEFAULT '0',
  `mailToProject` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `mailToContact` int(1) UNSIGNED DEFAULT '0',
  `mailToLeader` int(1) UNSIGNED DEFAULT '0',
  `mailToOther` int(1) UNSIGNED DEFAULT '0',
  `otherMail` varchar(4000) DEFAULT NULL,
  `idEvent` int(12) UNSIGNED DEFAULT NULL,
  `mailToManager` int(1) UNSIGNED DEFAULT '0',
  `mailToAssigned` int(1) UNSIGNED DEFAULT '0',
  `idType` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `statusmail`
--

INSERT INTO `statusmail` (`id`, `idStatus`, `idMailable`, `mailToUser`, `mailToResource`, `mailToProject`, `idle`, `mailToContact`, `mailToLeader`, `mailToOther`, `otherMail`, `idEvent`, `mailToManager`, `mailToAssigned`, `idType`) VALUES
(1, 1, 1, 1, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(2, 2, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(3, 11, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(4, 8, 1, 1, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(5, 10, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(6, 3, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(7, 4, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(8, 5, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(9, 6, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(10, 12, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(11, 7, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(12, 9, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(13, 8, 2, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(14, 10, 2, 0, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(15, 3, 2, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(16, 4, 2, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(17, 12, 2, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(18, 7, 2, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(19, 9, 2, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(20, 8, 3, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(21, 10, 3, 0, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(22, 3, 3, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(23, 4, 3, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(24, 12, 3, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(25, 7, 3, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(26, 9, 3, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(27, 8, 4, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(28, 10, 4, 0, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(29, 3, 4, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(30, 4, 4, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(31, 12, 4, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(32, 7, 4, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(33, 9, 4, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(34, 8, 5, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(35, 10, 5, 0, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(36, 3, 5, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(37, 4, 5, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(38, 12, 5, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(39, 7, 5, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(40, 9, 5, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(41, 8, 6, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(42, 10, 6, 0, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(43, 3, 6, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(44, 4, 6, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(45, 12, 6, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(46, 7, 6, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(47, 9, 6, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(48, 13, 7, 0, 0, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(49, 6, 7, 0, 0, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(50, 12, 8, 0, 0, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(51, 9, 8, 0, 0, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(52, 1, 9, 1, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(53, 2, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(54, 11, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(55, 8, 9, 1, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(56, 10, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(57, 3, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(58, 4, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(59, 5, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(60, 6, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(61, 12, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(62, 7, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(63, 9, 9, 1, 1, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(64, 4, 10, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(65, 12, 10, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(66, 3, 11, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL),
(67, 4, 11, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `team`
--

CREATE TABLE `team` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idResource` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `team`
--

INSERT INTO `team` (`id`, `name`, `description`, `idle`, `idResource`) VALUES
(1, 'web team', NULL, 0, NULL),
(2, 'swing team', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `tempupdate`
--

CREATE TABLE `tempupdate` (
  `id` int(12) DEFAULT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) DEFAULT NULL,
  `idOther` int(12) UNSIGNED DEFAULT NULL,
  `workValue` decimal(8,5) UNSIGNED DEFAULT NULL,
  `costValue` decimal(12,2) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tender`
--

CREATE TABLE `tender` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `idTenderType` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idCallForTender` int(12) UNSIGNED DEFAULT NULL,
  `idTenderStatus` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `idProvider` int(12) UNSIGNED DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `requestDateTime` datetime DEFAULT NULL,
  `expectedTenderDateTime` datetime DEFAULT NULL,
  `receptionDateTime` datetime DEFAULT NULL,
  `evaluationValue` decimal(7,2) DEFAULT NULL,
  `evaluationRank` int(3) DEFAULT NULL,
  `offerValidityEndDate` date DEFAULT NULL,
  `plannedAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `taxPct` decimal(5,2) DEFAULT NULL,
  `plannedTaxAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `plannedFullAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `initialAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `initialTaxAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `initialFullAmount` decimal(11,2) UNSIGNED DEFAULT NULL,
  `deliveryDelay` varchar(100) DEFAULT NULL,
  `deliveryDate` date DEFAULT NULL,
  `paymentCondition` varchar(100) DEFAULT NULL,
  `evaluation` decimal(7,2) DEFAULT NULL,
  `result` mediumtext,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `done` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `doneDate` date DEFAULT NULL,
  `idleDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tenderevaluation`
--

CREATE TABLE `tenderevaluation` (
  `id` int(12) UNSIGNED NOT NULL,
  `idTenderEvaluationCriteria` int(12) UNSIGNED DEFAULT NULL,
  `idTender` int(12) UNSIGNED DEFAULT NULL,
  `evaluationValue` decimal(5,2) DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tenderevaluationcriteria`
--

CREATE TABLE `tenderevaluationcriteria` (
  `id` int(12) UNSIGNED NOT NULL,
  `idCallForTender` int(12) UNSIGNED DEFAULT NULL,
  `criteriaName` varchar(100) DEFAULT NULL,
  `criteriaMaxValue` int(3) UNSIGNED DEFAULT '10',
  `criteriaCoef` int(3) UNSIGNED DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tenderstatus`
--

CREATE TABLE `tenderstatus` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `isWaiting` int(1) UNSIGNED DEFAULT '0',
  `isReceived` int(1) UNSIGNED DEFAULT '0',
  `isNotSelect` int(1) UNSIGNED DEFAULT '0',
  `isSelected` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tenderstatus`
--

INSERT INTO `tenderstatus` (`id`, `name`, `color`, `sortOrder`, `isWaiting`, `isReceived`, `isNotSelect`, `isSelected`, `idle`) VALUES
(1, 'request to send', '#ffa500', 10, 0, 0, 0, 0, 0),
(2, 'waiting for reply', '#f08080', 20, 1, 0, 0, 0, 0),
(3, 'out of date answer', '#c0c0c0', 30, 0, 1, 1, 0, 0),
(4, 'incomplete file', '#c0c0c0', 40, 0, 1, 1, 0, 0),
(5, 'admissible', '#87ceeb', 50, 0, 1, 0, 0, 0),
(6, 'short list', '#4169e1', 60, 0, 1, 0, 0, 0),
(7, 'not selected', '#c0c0c0', 70, 0, 1, 1, 0, 0),
(8, 'selected', '#98fb98', 80, 0, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `term`
--

CREATE TABLE `term` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `validatedAmount` decimal(10,2) DEFAULT NULL,
  `plannedAmount` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `validatedDate` date DEFAULT NULL,
  `plannedDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT NULL,
  `idBill` int(12) UNSIGNED DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `term`
--

INSERT INTO `term` (`id`, `name`, `idProject`, `amount`, `validatedAmount`, `plannedAmount`, `date`, `validatedDate`, `plannedDate`, `idle`, `idBill`, `idUser`, `creationDate`) VALUES
(1, 'March 2012 - 50%', 1, '2400.00', NULL, NULL, '2012-03-15', NULL, NULL, 0, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `testcase`
--

CREATE TABLE `testcase` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idVersion` int(12) UNSIGNED DEFAULT NULL,
  `idTestCaseType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDateTime` datetime DEFAULT NULL,
  `idContext1` int(12) UNSIGNED DEFAULT NULL,
  `idContext2` int(12) UNSIGNED DEFAULT NULL,
  `idContext3` int(12) UNSIGNED DEFAULT NULL,
  `description` mediumtext,
  `idTestCase` int(12) UNSIGNED DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `idPriority` int(12) UNSIGNED DEFAULT NULL,
  `prerequisite` mediumtext,
  `result` mediumtext,
  `sessionCount` int(5) DEFAULT '0',
  `runCount` int(5) DEFAULT '0',
  `lastRunDate` date DEFAULT NULL,
  `idRunStatus` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `testcase`
--

INSERT INTO `testcase` (`id`, `reference`, `idProject`, `idProduct`, `idVersion`, `idTestCaseType`, `name`, `externalReference`, `idUser`, `creationDateTime`, `idContext1`, `idContext2`, `idContext3`, `description`, `idTestCase`, `idStatus`, `idResource`, `handled`, `handledDate`, `done`, `doneDate`, `idle`, `idleDate`, `idPriority`, `prerequisite`, `result`, `sessionCount`, `runCount`, `lastRunDate`, `idRunStatus`, `cancelled`) VALUES
(1, '-REQU-1', NULL, 1, NULL, 80, 'Filed name not set : error', NULL, 1, '2012-08-05 17:03:00', NULL, NULL, NULL, 'Set fleld "name" empty.\nSave.', NULL, 1, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Error message : "Mandatory field"', 0, 0, NULL, 2, 0),
(2, '-REQU-2', NULL, 1, NULL, 80, 'Filed name set : no blocking message', NULL, 1, '2012-08-05 17:05:00', NULL, NULL, NULL, 'Enter a value for field "Name".\nTry to enter 120 caracters, including some quotes and non ascii cars.\nSave.', NULL, 1, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Save without error.', 0, 0, NULL, 3, 0);

-- --------------------------------------------------------

--
-- Structure de la table `testcaserun`
--

CREATE TABLE `testcaserun` (
  `id` int(12) UNSIGNED NOT NULL,
  `idTestCase` int(12) UNSIGNED DEFAULT NULL,
  `idTestSession` int(12) UNSIGNED DEFAULT NULL,
  `idRunStatus` int(12) UNSIGNED DEFAULT NULL,
  `idTicket` int(12) UNSIGNED DEFAULT NULL,
  `statusDateTime` datetime DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `testcaserun`
--

INSERT INTO `testcaserun` (`id`, `idTestCase`, `idTestSession`, `idRunStatus`, `idTicket`, `statusDateTime`, `comment`, `idle`) VALUES
(1, 2, 1, 3, 2, '2012-08-05 17:09:10', NULL, 0),
(2, 1, 1, 2, NULL, '2012-08-05 17:08:17', NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `testsession`
--

CREATE TABLE `testsession` (
  `id` int(12) UNSIGNED NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idVersion` int(12) UNSIGNED DEFAULT NULL,
  `idTestSessionType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `creationDateTime` datetime DEFAULT NULL,
  `description` mediumtext,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDate` date DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idleDate` date DEFAULT NULL,
  `result` mediumtext,
  `countPassed` int(5) DEFAULT '0',
  `countFailed` int(5) DEFAULT '0',
  `countBlocked` int(5) DEFAULT '0',
  `countTotal` int(5) DEFAULT '0',
  `countIssues` int(5) DEFAULT '0',
  `countPlanned` int(5) DEFAULT '0',
  `idRunStatus` int(12) UNSIGNED DEFAULT NULL,
  `idTestSession` int(12) UNSIGNED DEFAULT NULL,
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `testsession`
--

INSERT INTO `testsession` (`id`, `reference`, `idProject`, `idProduct`, `idVersion`, `idTestSessionType`, `name`, `externalReference`, `idUser`, `creationDateTime`, `description`, `idStatus`, `idResource`, `startDate`, `endDate`, `handled`, `handledDate`, `done`, `doneDate`, `idle`, `idleDate`, `result`, `countPassed`, `countFailed`, `countBlocked`, `countTotal`, `countIssues`, `countPlanned`, `idRunStatus`, `idTestSession`, `idActivity`, `cancelled`) VALUES
(1, '-EVO-1', 1, 1, 1, 83, 'Web Application V1 - Main test session', NULL, 1, '2012-08-05 17:06:00', 'Main session for V1.0, including all elementary tests', 1, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 1, 1, 0, 2, 1, 0, 3, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `textable`
--

CREATE TABLE `textable` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `textable`
--

INSERT INTO `textable` (`id`, `name`, `idle`) VALUES
(1, 'Action', 0),
(2, 'Activity', 0),
(3, 'Bill', 0),
(4, 'Decision', 0),
(5, 'IndividualExpense', 0),
(6, 'Issue', 0),
(7, 'Meeting', 0),
(8, 'Milestone', 0),
(9, 'Product', 0),
(10, 'Project', 0),
(11, 'ProjectExpense', 0),
(12, 'Question', 0),
(13, 'Requirement', 0),
(14, 'Risk', 0),
(15, 'Term', 0),
(16, 'TestCase', 0),
(17, 'TestSession', 0),
(18, 'Ticket', 0),
(19, 'Version', 0),
(20, 'Quotation', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ticket`
--

CREATE TABLE `ticket` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idTicketType` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDateTime` datetime DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `initialDueDateTime` datetime DEFAULT NULL,
  `idStatus` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `actualDueDateTime` datetime DEFAULT NULL,
  `idleDateTime` datetime DEFAULT NULL,
  `result` mediumtext,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `idCriticality` int(12) UNSIGNED DEFAULT NULL,
  `idUrgency` int(12) UNSIGNED DEFAULT NULL,
  `idPriority` int(12) UNSIGNED DEFAULT NULL,
  `done` int(1) UNSIGNED DEFAULT '0',
  `doneDateTime` datetime DEFAULT NULL,
  `handled` int(1) UNSIGNED DEFAULT '0',
  `handledDateTime` datetime DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `idTargetProductVersion` int(12) UNSIGNED DEFAULT NULL,
  `idOriginalProductVersion` int(12) UNSIGNED DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `externalReference` varchar(100) DEFAULT NULL,
  `idTicket` int(12) UNSIGNED DEFAULT NULL,
  `idContext1` int(12) UNSIGNED DEFAULT NULL,
  `idContext2` int(12) UNSIGNED DEFAULT NULL,
  `idContext3` int(12) UNSIGNED DEFAULT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `cancelled` int(1) UNSIGNED DEFAULT '0',
  `idComponent` int(12) UNSIGNED DEFAULT NULL,
  `idOriginalComponentVersion` int(12) UNSIGNED DEFAULT NULL,
  `idTargetComponentVersion` int(12) UNSIGNED DEFAULT NULL,
  `idResolution` int(12) UNSIGNED DEFAULT NULL,
  `solved` int(1) UNSIGNED DEFAULT '0',
  `lastUpdateDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ticket`
--

INSERT INTO `ticket` (`id`, `idProject`, `idTicketType`, `name`, `description`, `creationDateTime`, `idUser`, `initialDueDateTime`, `idStatus`, `idResource`, `actualDueDateTime`, `idleDateTime`, `result`, `comment`, `idle`, `idActivity`, `idCriticality`, `idUrgency`, `idPriority`, `done`, `doneDateTime`, `handled`, `handledDateTime`, `idContact`, `idTargetProductVersion`, `idOriginalProductVersion`, `reference`, `externalReference`, `idTicket`, `idContext1`, `idContext2`, `idContext3`, `idProduct`, `cancelled`, `idComponent`, `idOriginalComponentVersion`, `idTargetComponentVersion`, `idResolution`, `solved`, `lastUpdateDateTime`) VALUES
(1, 2, 16, 'bug: it does not work', NULL, '2011-09-01 12:00:00', 1, '2011-09-02 18:00:00', 8, 3, '2011-09-09 18:30:00', NULL, NULL, NULL, 0, NULL, 1, 2, 1, 0, NULL, 0, NULL, NULL, NULL, 1, '001-001-INC-1', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, '2015-10-26 18:54:25'),
(2, 1, 16, 'Enter some quotes on filed names : error Message', 'Get a Sql Error message : invalid instruction.', '2012-08-05 17:08:00', 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, '001-001-INC-2', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, '2015-06-25 22:42:37');

-- --------------------------------------------------------

--
-- Structure de la table `today`
--

CREATE TABLE `today` (
  `id` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `staticSection` varchar(100) DEFAULT NULL,
  `idReport` int(12) UNSIGNED DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `today`
--

INSERT INTO `today` (`id`, `idUser`, `scope`, `staticSection`, `idReport`, `sortOrder`, `idle`) VALUES
(1, 1, 'static', 'Projects', NULL, 1, 0),
(2, 2, 'static', 'Projects', NULL, 1, 0),
(3, 3, 'static', 'Projects', NULL, 1, 0),
(4, 4, 'static', 'Projects', NULL, 1, 0),
(5, 5, 'static', 'Projects', NULL, 1, 0),
(6, 6, 'static', 'Projects', NULL, 1, 0),
(7, 8, 'static', 'Projects', NULL, 1, 0),
(8, 9, 'static', 'Projects', NULL, 1, 0),
(16, 1, 'static', 'AssignedTasks', NULL, 2, 0),
(17, 2, 'static', 'AssignedTasks', NULL, 2, 0),
(18, 3, 'static', 'AssignedTasks', NULL, 2, 0),
(19, 4, 'static', 'AssignedTasks', NULL, 2, 0),
(20, 5, 'static', 'AssignedTasks', NULL, 2, 0),
(21, 6, 'static', 'AssignedTasks', NULL, 2, 0),
(22, 8, 'static', 'AssignedTasks', NULL, 2, 0),
(23, 9, 'static', 'AssignedTasks', NULL, 2, 0),
(31, 1, 'static', 'ResponsibleTasks', NULL, 3, 0),
(32, 2, 'static', 'ResponsibleTasks', NULL, 3, 0),
(33, 3, 'static', 'ResponsibleTasks', NULL, 3, 0),
(34, 4, 'static', 'ResponsibleTasks', NULL, 3, 0),
(35, 5, 'static', 'ResponsibleTasks', NULL, 3, 0),
(36, 6, 'static', 'ResponsibleTasks', NULL, 3, 0),
(37, 8, 'static', 'ResponsibleTasks', NULL, 3, 0),
(38, 9, 'static', 'ResponsibleTasks', NULL, 3, 0),
(46, 1, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(47, 2, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(48, 3, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(49, 4, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(50, 5, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(51, 6, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(52, 8, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(53, 9, 'static', 'IssuerRequestorTasks', NULL, 4, 0),
(61, 1, 'static', 'ProjectsTasks', NULL, 5, 0),
(62, 2, 'static', 'ProjectsTasks', NULL, 5, 0),
(63, 3, 'static', 'ProjectsTasks', NULL, 5, 0),
(64, 4, 'static', 'ProjectsTasks', NULL, 5, 0),
(65, 5, 'static', 'ProjectsTasks', NULL, 5, 0),
(66, 6, 'static', 'ProjectsTasks', NULL, 5, 0),
(67, 8, 'static', 'ProjectsTasks', NULL, 5, 0),
(68, 9, 'static', 'ProjectsTasks', NULL, 5, 0);

-- --------------------------------------------------------

--
-- Structure de la table `todayparameter`
--

CREATE TABLE `todayparameter` (
  `id` int(12) UNSIGNED NOT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idReport` int(12) UNSIGNED DEFAULT NULL,
  `idToday` int(12) UNSIGNED DEFAULT NULL,
  `parameterName` varchar(100) DEFAULT NULL,
  `parameterValue` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `trend`
--

CREATE TABLE `trend` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `trend`
--

INSERT INTO `trend` (`id`, `name`, `color`, `sortOrder`, `icon`, `idle`) VALUES
(1, 'increasing', '#32CD32', 100, 'arrowUpGreen.png', 0),
(2, 'even', '#ffd700', 200, 'arrowRightGrey.png', 0),
(3, 'decreasing', '#FF0000', 300, 'arrowDownRed.png', 0);

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE `type` (
  `id` int(12) UNSIGNED NOT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `color` varchar(7) DEFAULT NULL,
  `idWorkflow` int(12) UNSIGNED DEFAULT NULL,
  `mandatoryDescription` int(1) UNSIGNED DEFAULT '0',
  `mandatoryResultOnDone` int(1) UNSIGNED DEFAULT '0',
  `mandatoryResourceOnHandled` int(1) UNSIGNED DEFAULT '0',
  `lockHandled` int(1) UNSIGNED DEFAULT '0',
  `lockDone` int(1) UNSIGNED DEFAULT '0',
  `lockIdle` int(1) UNSIGNED DEFAULT '0',
  `internalData` varchar(1) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `description` mediumtext,
  `lockCancelled` int(1) UNSIGNED DEFAULT '0',
  `showInFlash` int(1) UNSIGNED DEFAULT '0',
  `idPlanningMode` int(12) UNSIGNED DEFAULT NULL,
  `mandatoryResolutionOnDone` int(1) UNSIGNED DEFAULT '0',
  `lockSolved` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `type`
--

INSERT INTO `type` (`id`, `scope`, `name`, `sortOrder`, `idle`, `color`, `idWorkflow`, `mandatoryDescription`, `mandatoryResultOnDone`, `mandatoryResourceOnHandled`, `lockHandled`, `lockDone`, `lockIdle`, `internalData`, `code`, `description`, `lockCancelled`, `showInFlash`, `idPlanningMode`, `mandatoryResolutionOnDone`, `lockSolved`) VALUES
(1, 'Risk', 'Contractual', 10, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'CON', NULL, 1, 0, NULL, 0, 0),
(2, 'Risk', 'Operational', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'OPE', NULL, 1, 0, NULL, 0, 0),
(3, 'Risk', 'Technical', 30, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'TEC', NULL, 1, 0, NULL, 0, 0),
(4, 'Issue', 'Technical issue', 10, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'TEC', NULL, 1, 0, NULL, 0, 0),
(5, 'Issue', 'Process non conformity', 30, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'PRO', NULL, 1, 0, NULL, 0, 0),
(6, 'Issue', 'Quality non conformity', 40, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'QUA', NULL, 1, 0, NULL, 0, 0),
(7, 'Issue', 'Process non appliability', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'PRO', NULL, 1, 0, NULL, 0, 0),
(8, 'Issue', 'Customer complaint', 90, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'CUS', NULL, 1, 0, NULL, 0, 0),
(9, 'Issue', 'Delay non respect', 50, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'DEL', NULL, 1, 0, NULL, 0, 0),
(10, 'Issue', 'Resource management issue', 70, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'RES', NULL, 1, 0, NULL, 0, 0),
(12, 'Issue', 'Financial loss', 80, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'FIN', NULL, 1, 0, NULL, 0, 0),
(13, 'Message', 'ALERT', 10, 0, '#ff0000', 1, 0, 1, 1, 1, 1, 1, NULL, 'ALE', NULL, 1, 0, NULL, 0, 0),
(14, 'Message', 'WARNING', 10, 0, '#ffa500', 1, 0, 1, 1, 1, 1, 1, NULL, 'WAR', NULL, 1, 0, NULL, 0, 0),
(15, 'Message', 'INFO', 30, 0, '#0000ff', 1, 0, 1, 1, 1, 1, 1, NULL, 'INF', NULL, 1, 0, NULL, 0, 0),
(16, 'Ticket', 'Incident', 10, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'INC', NULL, 1, 0, NULL, 0, 0),
(17, 'Ticket', 'Support / Assistance', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'SUP', NULL, 1, 0, NULL, 0, 0),
(18, 'Ticket', 'Anomaly / Bug', 30, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'ANO', NULL, 1, 0, NULL, 0, 0),
(19, 'Activity', 'Development', 10, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'DEV', NULL, 1, 0, 1, 0, 0),
(20, 'Activity', 'Evolution', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'EVO', NULL, 1, 0, 1, 0, 0),
(21, 'Activity', 'Management', 30, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'MAN', NULL, 1, 0, 1, 0, 0),
(22, 'Activity', 'Phase', 40, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'PHA', NULL, 1, 0, 1, 0, 0),
(23, 'Milestone', 'Deliverable', 10, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'DEL', NULL, 1, 0, 5, 0, 0),
(24, 'Milestone', 'Incoming', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'INC', NULL, 1, 0, 5, 0, 0),
(25, 'Milestone', 'Key date', 30, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'KEY', NULL, 1, 0, 5, 0, 0),
(26, 'Activity', 'Task', 1, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'TAS', NULL, 1, 0, 1, 0, 0),
(27, 'Action', 'Project', 10, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'PRO', NULL, 1, 0, NULL, 0, 0),
(28, 'Action', 'Internal', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'INT', NULL, 1, 0, NULL, 0, 0),
(29, 'Action', 'Customer', 20, 0, NULL, 1, 0, 1, 1, 1, 1, 1, NULL, 'CUS', NULL, 1, 0, NULL, 0, 0),
(30, 'Meeting', 'Steering Committee', 10, 0, NULL, 7, 0, 1, 1, 1, 1, 1, NULL, 'STE', NULL, 1, 0, 16, 0, 0),
(31, 'Meeting', 'Progress Metting', 20, 0, NULL, 7, 0, 1, 1, 1, 1, 1, NULL, 'PRO', NULL, 1, 0, 16, 0, 0),
(32, 'Meeting', 'Team meeting', 30, 0, NULL, 7, 0, 1, 1, 1, 1, 1, NULL, 'TEA', NULL, 1, 0, 16, 0, 0),
(33, 'Decision', 'Functional', 10, 0, NULL, 6, 0, 1, 1, 1, 1, 1, NULL, 'FUN', NULL, 1, 0, NULL, 0, 0),
(34, 'Decision', 'Operational', 20, 0, NULL, 6, 0, 1, 1, 1, 1, 1, NULL, 'OPE', NULL, 1, 0, NULL, 0, 0),
(35, 'Decision', 'Contractual', 30, 0, NULL, 6, 0, 1, 1, 1, 1, 1, NULL, 'CON', NULL, 1, 0, NULL, 0, 0),
(36, 'Decision', 'Strategic', 40, 0, NULL, 6, 0, 1, 1, 1, 1, 1, NULL, 'STR', NULL, 1, 0, NULL, 0, 0),
(37, 'Question', 'Functional', 10, 0, NULL, 5, 0, 1, 1, 1, 1, 1, NULL, 'FUN', NULL, 1, 0, NULL, 0, 0),
(38, 'Question', 'Technical', 20, 0, NULL, 5, 0, 1, 1, 1, 1, 1, NULL, 'TEC', NULL, 1, 0, NULL, 0, 0),
(39, 'IndividualExpense', 'Expense report', 10, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'EXP', NULL, 0, 0, NULL, 0, 0),
(40, 'ProjectExpense', 'Machine expense', 10, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'MAC', NULL, 0, 0, NULL, 0, 0),
(41, 'ProjectExpense', 'Office expense', 20, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'OFF', NULL, 0, 0, NULL, 0, 0),
(42, 'Invoice', 'event invoice', 10, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'EVE', NULL, 0, 0, NULL, 0, 0),
(43, 'Invoice', 'partial invoice', 20, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'PAR', NULL, 0, 0, NULL, 0, 0),
(44, 'Invoice', 'final invoice', 30, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'FIN', NULL, 0, 0, NULL, 0, 0),
(46, 'Payment', 'partial payment', 20, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'PAR', NULL, 0, 0, NULL, 0, 0),
(47, 'Payment', 'final payment', 10, 0, NULL, 8, 0, 0, 0, 0, 0, 0, NULL, 'FIN', NULL, 0, 0, NULL, 0, 0),
(48, 'Project', 'Fixed Price', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'E', 'OPE', NULL, 0, 0, NULL, 0, 0),
(49, 'Project', 'Time & Materials', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'R', 'OPE', NULL, 0, 0, NULL, 0, 0),
(50, 'Project', 'Capped Time & Materials', 30, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'P', 'OPE', NULL, 0, 0, NULL, 0, 0),
(51, 'Project', 'Internal', 40, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'N', 'OPE', NULL, 0, 0, NULL, 0, 0),
(52, 'Project', 'Administrative', 80, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'N', 'ADM', NULL, 0, 0, NULL, 0, 0),
(53, 'Project', 'Template', 90, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'N', 'TMP', NULL, 0, 0, NULL, 0, 0),
(54, 'Document', 'Need expression', 210, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'NEEDEXP', NULL, 0, 0, NULL, 0, 0),
(55, 'Document', 'General Specification', 220, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'GENSPEC', NULL, 0, 0, NULL, 0, 0),
(56, 'Document', 'Detailed Specification', 230, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'DETSPEC', NULL, 0, 0, NULL, 0, 0),
(57, 'Document', 'General Conception', 240, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'GENCON', NULL, 0, 0, NULL, 0, 0),
(58, 'Document', 'Detail Conception', 250, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'DETCON', NULL, 0, 0, NULL, 0, 0),
(59, 'Document', 'Test Plan', 260, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'TEST', NULL, 0, 0, NULL, 0, 0),
(60, 'Document', 'Installaton manual', 270, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'INST', NULL, 0, 0, NULL, 0, 0),
(61, 'Document', 'Exploitation manual', 280, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'EXPL', NULL, 0, 0, NULL, 0, 0),
(62, 'Document', 'User manual', 290, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'MANUAL', NULL, 0, 0, NULL, 0, 0),
(63, 'Document', 'Contract', 110, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'CTRCT', NULL, 0, 0, NULL, 0, 0),
(64, 'Document', 'Management', 120, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'MGT', NULL, 0, 0, NULL, 0, 0),
(65, 'Document', 'Meeting Review', 130, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'MEETREV', NULL, 0, 0, NULL, 0, 0),
(66, 'Document', 'Follow-up', 140, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'F-UP', NULL, 0, 0, NULL, 0, 0),
(67, 'Document', 'Financial', 150, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'FIN', NULL, 0, 0, NULL, 0, 0),
(68, 'Versioning', 'evolutive', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'EVO', NULL, 0, 0, NULL, 0, 0),
(69, 'Versioning', 'chronological', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'EVT', NULL, 0, 0, NULL, 0, 0),
(70, 'Versioning', 'sequential', 30, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'SEQ', NULL, 0, 0, NULL, 0, 0),
(71, 'Versioning', 'external', 40, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, 'EXT', NULL, 0, 0, NULL, 0, 0),
(72, 'Bill', 'Partial bill', 100, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, 'PARTIAL', NULL, 1, 0, NULL, 0, 0),
(73, 'Bill', 'Final bill', 200, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, 'FINAL', NULL, 1, 0, NULL, 0, 0),
(74, 'Bill', 'Complete bill', 300, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, 'COMPLETE', NULL, 1, 0, NULL, 0, 0),
(75, 'Project', 'Manual billed', 0, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 'M', 'OPE', NULL, 0, 0, NULL, 0, 0),
(76, 'Requirement', 'Functional', 10, 0, NULL, 1, 1, 0, 1, 1, 1, 1, NULL, 'FUNC', NULL, 1, 0, NULL, 0, 0),
(77, 'Requirement', 'Technical', 20, 0, NULL, 1, 1, 0, 1, 1, 1, 1, NULL, 'TECH', NULL, 1, 0, NULL, 0, 0),
(78, 'Requirement', 'Security', 30, 0, NULL, 1, 1, 0, 1, 1, 1, 1, NULL, 'SECU', NULL, 1, 0, NULL, 0, 0),
(79, 'Requirement', 'Regulatory', 40, 0, NULL, 1, 1, 0, 1, 1, 1, 1, NULL, 'REGL', NULL, 1, 0, NULL, 0, 0),
(80, 'TestCase', 'Requirement test', 10, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'REQU', NULL, 1, 0, NULL, 0, 0),
(81, 'TestCase', 'Non regression', 30, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'NR', NULL, 1, 0, NULL, 0, 0),
(82, 'TestCase', 'Unit test', 20, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'UT', NULL, 1, 0, NULL, 0, 0),
(83, 'TestSession', 'Evolution test session', 10, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'EVO', NULL, 1, 0, 9, 0, 0),
(84, 'TestSession', 'Development test session', 20, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'DEV', NULL, 1, 0, 9, 0, 0),
(85, 'TestSession', 'Non regression test session', 30, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'NR', NULL, 1, 0, 9, 0, 0),
(86, 'TestSession', 'Unitary case test session', 40, 0, NULL, 1, 1, 1, 1, 1, 1, 1, NULL, 'UT', NULL, 1, 0, 9, 0, 0),
(87, 'Opportunity', 'Contractual', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, 0, 0),
(88, 'Opportunity', 'Operational', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, 0, 0),
(89, 'Opportunity', 'Technical', 30, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, 0, 0),
(90, 'Command', 'Fixe Price', 10, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 1, 0, NULL, 0, 0),
(91, 'Command', 'Per day', 20, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 1, 0, NULL, 0, 0),
(92, 'Quotation', 'Fixe Price', 10, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(93, 'Quotation', 'Per day', 20, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(94, 'Quotation', 'Per month', 30, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(95, 'Quotation', 'Per year', 40, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(96, 'Command', 'Per month', 30, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(97, 'Command', 'Per year', 40, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(98, 'Client', 'business prospect', 10, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(99, 'Client', 'customer', 10, 0, NULL, 1, 0, 0, 0, 0, 1, 1, NULL, '', NULL, 0, 0, NULL, 0, 0),
(100, 'Product', 'software', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(101, 'Product', 'service', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(102, 'Component', 'specific', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(103, 'Component', 'on the shelf', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(104, 'Provider', 'wholesaler', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(105, 'Provider', 'retailer', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(106, 'Provider', 'service provider', 30, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(107, 'Provider', 'subcontractor', 40, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(108, 'Provider', 'central purchasing', 50, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(109, 'CallForTender', 'by mutual agreement', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(110, 'CallForTender', 'adapted procedure', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(111, 'CallForTender', 'open call for tender', 30, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(112, 'CallForTender', 'restricted call for tender', 40, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(113, 'Tender', 'by mutual agreement', 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(114, 'Tender', 'adapted procedure', 20, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(115, 'Tender', 'open call for tender', 30, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0),
(116, 'Tender', 'restricted call for tender', 40, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `urgency`
--

CREATE TABLE `urgency` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` int(3) UNSIGNED DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `urgency`
--

INSERT INTO `urgency` (`id`, `name`, `value`, `color`, `sortOrder`, `idle`) VALUES
(1, 'Blocking', 4, '#ff0000', 30, 0),
(2, 'Urgent', 2, '#ffd700', 20, 0),
(3, 'Not urgent', 1, '#32cd32', 10, 0);

-- --------------------------------------------------------

--
-- Structure de la table `version`
--

CREATE TABLE `version` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProduct` int(12) UNSIGNED DEFAULT NULL,
  `idContact` int(12) UNSIGNED DEFAULT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `creationDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `initialEisDate` date DEFAULT NULL,
  `plannedEisDate` date DEFAULT NULL,
  `realEisDate` date DEFAULT NULL,
  `initialEndDate` date DEFAULT NULL,
  `plannedEndDate` date DEFAULT NULL,
  `realEndDate` date DEFAULT NULL,
  `isEis` int(1) UNSIGNED DEFAULT '0',
  `scope` varchar(100) DEFAULT NULL,
  `versionNumber` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `version`
--

INSERT INTO `version` (`id`, `idProduct`, `idContact`, `idResource`, `name`, `description`, `creationDate`, `idle`, `initialEisDate`, `plannedEisDate`, `realEisDate`, `initialEndDate`, `plannedEndDate`, `realEndDate`, `isEis`, `scope`, `versionNumber`) VALUES
(1, 1, 5, 3, 'wa V1.0', NULL, '2011-09-01', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'Product', NULL),
(2, 1, 5, 3, 'wa V2.0', NULL, '2011-09-01', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'Product', NULL),
(3, 2, 6, 3, 'sa V1.0', NULL, '2011-09-01', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'Product', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `versionproject`
--

CREATE TABLE `versionproject` (
  `id` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `idVersion` int(12) UNSIGNED DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `versionproject`
--

INSERT INTO `versionproject` (`id`, `idProject`, `idVersion`, `startDate`, `endDate`, `idle`) VALUES
(2, 2, 1, NULL, NULL, 0),
(3, 1, 2, NULL, NULL, 0),
(4, 3, 2, NULL, NULL, 0),
(5, 4, 3, '2011-09-01', '2011-12-31', 0);

-- --------------------------------------------------------

--
-- Structure de la table `visibilityscope`
--

CREATE TABLE `visibilityscope` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `accessCode` varchar(3) DEFAULT NULL,
  `sortOrder` int(3) UNSIGNED DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `visibilityscope`
--

INSERT INTO `visibilityscope` (`id`, `name`, `accessCode`, `sortOrder`, `idle`) VALUES
(1, 'visibilityScopeNo', 'NO', 100, 0),
(2, 'visibilityScopeValid', 'VAL', 200, 0),
(4, 'visibilityScopeAll', 'ALL', 400, 0);

-- --------------------------------------------------------

--
-- Structure de la table `work`
--

CREATE TABLE `work` (
  `id` int(12) UNSIGNED NOT NULL,
  `idResource` int(12) UNSIGNED NOT NULL,
  `idProject` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED NOT NULL,
  `idAssignment` int(12) UNSIGNED DEFAULT NULL,
  `work` decimal(8,5) UNSIGNED DEFAULT NULL,
  `workDate` date DEFAULT NULL,
  `day` varchar(8) DEFAULT NULL,
  `week` varchar(6) DEFAULT NULL,
  `month` varchar(6) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  `dailyCost` decimal(11,2) UNSIGNED DEFAULT NULL,
  `cost` decimal(11,2) DEFAULT NULL,
  `idBill` int(12) UNSIGNED DEFAULT NULL,
  `idWorkElement` int(12) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `workelement`
--

CREATE TABLE `workelement` (
  `id` int(12) UNSIGNED NOT NULL,
  `refType` varchar(100) DEFAULT NULL,
  `refId` int(12) UNSIGNED DEFAULT NULL,
  `refName` varchar(100) DEFAULT NULL,
  `plannedWork` decimal(9,5) UNSIGNED DEFAULT '0.00000',
  `realWork` decimal(9,5) UNSIGNED DEFAULT '0.00000',
  `leftWork` decimal(9,5) UNSIGNED DEFAULT '0.00000',
  `done` int(1) UNSIGNED DEFAULT '0',
  `idle` int(1) UNSIGNED DEFAULT '0',
  `ongoing` int(1) UNSIGNED DEFAULT '0',
  `ongoingStartDateTime` datetime DEFAULT NULL,
  `idUser` int(12) UNSIGNED DEFAULT NULL,
  `idActivity` int(12) UNSIGNED DEFAULT NULL,
  `idProject` int(12) UNSIGNED DEFAULT NULL,
  `realCost` decimal(11,2) DEFAULT NULL,
  `leftCost` decimal(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `workelement`
--

INSERT INTO `workelement` (`id`, `refType`, `refId`, `refName`, `plannedWork`, `realWork`, `leftWork`, `done`, `idle`, `ongoing`, `ongoingStartDateTime`, `idUser`, `idActivity`, `idProject`, `realCost`, `leftCost`) VALUES
(1, 'Ticket', 1, 'bug: it does not work', '0.00000', '0.00000', '0.00000', 0, 0, 0, NULL, NULL, NULL, 2, NULL, NULL),
(2, 'Ticket', 2, 'Enter some quotes on filed names : error Message', NULL, NULL, NULL, 0, 0, 0, NULL, 1, NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `workflow`
--

CREATE TABLE `workflow` (
  `id` int(12) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` mediumtext,
  `idle` int(1) UNSIGNED DEFAULT '0',
  `workflowUpdate` varchar(100) DEFAULT NULL,
  `sortOrder` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `workflow`
--

INSERT INTO `workflow` (`id`, `name`, `description`, `idle`, `workflowUpdate`, `sortOrder`) VALUES
(1, 'Default', 'Default workflow with just logic constraints.\nAnyone can change status.', 0, '[     ]', NULL),
(2, 'Simple', 'Simple workflow with limited status.\nAnyone can change status.', 0, '[     ]', NULL),
(3, 'External validation', 'Elaborated workflow with internal team treatment and external validation.', 0, '[      ]', NULL),
(4, 'External acceptation & validation', 'Elaborated workflow with external acceptation, internal team treatment and external validation.', 0, '[     ]', NULL),
(5, 'Simple with validation', 'Simple workflow with limited status, including validation.\nAnyone can change status.', 0, '[     ]', NULL),
(6, 'Validation', 'Short workflow with only validation or cancel possibility.\nRestricted validation rights.', 0, '[      ]', NULL),
(7, 'Simple with preparation', 'Simple workflow with limited status, including preparation.\nAnyone can change status.', 0, '[     ]', NULL),
(8, 'Simple with Project Leader validation', 'Simple workflow with limited status, including Project Leader validation.\nAnyone can change status, except validation : only Project Leader.', 0, '[     ]', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `workflowstatus`
--

CREATE TABLE `workflowstatus` (
  `id` int(12) UNSIGNED NOT NULL,
  `idWorkflow` int(12) UNSIGNED NOT NULL,
  `idStatusFrom` int(12) UNSIGNED NOT NULL,
  `idStatusTo` int(12) UNSIGNED NOT NULL,
  `idProfile` int(12) UNSIGNED NOT NULL,
  `allowed` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `workflowstatus`
--

INSERT INTO `workflowstatus` (`id`, `idWorkflow`, `idStatusFrom`, `idStatusTo`, `idProfile`, `allowed`) VALUES
(1, 0, 1, 8, 1, 1),
(2, 0, 1, 8, 2, 1),
(3, 0, 1, 8, 3, 1),
(4, 3, 1, 2, 4, 1),
(5, 1, 1, 11, 3, 1),
(6, 1, 1, 11, 4, 1),
(7, 1, 1, 11, 6, 1),
(8, 1, 1, 11, 7, 1),
(9, 1, 1, 11, 5, 1),
(10, 1, 1, 10, 1, 1),
(11, 1, 1, 10, 2, 1),
(12, 1, 1, 10, 3, 1),
(13, 1, 1, 10, 4, 1),
(14, 1, 1, 10, 6, 1),
(15, 1, 1, 10, 7, 1),
(16, 1, 1, 10, 5, 1),
(17, 1, 1, 11, 1, 1),
(18, 1, 1, 11, 2, 1),
(19, 1, 2, 10, 1, 1),
(20, 1, 2, 3, 1, 1),
(21, 1, 2, 3, 2, 1),
(22, 1, 2, 3, 3, 1),
(23, 1, 2, 3, 4, 1),
(24, 1, 2, 3, 6, 1),
(25, 1, 2, 3, 7, 1),
(26, 1, 2, 3, 5, 1),
(27, 2, 1, 10, 1, 1),
(28, 2, 1, 10, 2, 1),
(29, 2, 1, 10, 3, 1),
(30, 2, 1, 10, 4, 1),
(31, 2, 1, 10, 6, 1),
(32, 2, 1, 10, 7, 1),
(33, 2, 1, 10, 5, 1),
(34, 1, 1, 3, 1, 1),
(35, 1, 1, 3, 4, 1),
(36, 1, 1, 4, 3, 1),
(37, 1, 1, 2, 3, 1),
(38, 1, 1, 2, 7, 1),
(39, 1, 1, 4, 2, 1),
(40, 1, 1, 3, 2, 1),
(41, 1, 1, 3, 7, 1),
(42, 1, 1, 3, 3, 1),
(43, 1, 1, 4, 4, 1),
(44, 1, 1, 4, 1, 1),
(45, 1, 1, 4, 7, 1),
(46, 3, 1, 10, 3, 1),
(47, 3, 1, 10, 4, 1),
(48, 3, 1, 3, 3, 1),
(49, 3, 1, 3, 4, 1),
(71, 1, 4, 5, 2, 1),
(72, 1, 4, 5, 3, 1),
(73, 1, 4, 5, 4, 1),
(74, 1, 4, 5, 6, 1),
(75, 1, 4, 5, 7, 1),
(76, 1, 4, 5, 5, 1),
(77, 1, 1, 2, 1, 1),
(78, 1, 1, 2, 2, 1),
(79, 1, 1, 2, 4, 1),
(80, 1, 1, 2, 6, 1),
(81, 1, 1, 2, 5, 1),
(82, 1, 1, 3, 6, 1),
(83, 1, 1, 3, 5, 1),
(84, 1, 1, 4, 6, 1),
(85, 1, 1, 4, 5, 1),
(86, 1, 1, 9, 1, 1),
(87, 1, 1, 9, 2, 1),
(88, 1, 1, 9, 3, 1),
(89, 1, 1, 9, 4, 1),
(90, 1, 1, 9, 6, 1),
(91, 1, 1, 9, 7, 1),
(92, 1, 1, 9, 5, 1),
(93, 1, 2, 11, 1, 1),
(94, 1, 2, 11, 2, 1),
(95, 1, 2, 11, 3, 1),
(96, 1, 2, 11, 4, 1),
(97, 1, 2, 11, 6, 1),
(98, 1, 2, 11, 7, 1),
(99, 1, 2, 11, 5, 1),
(100, 1, 2, 10, 2, 1),
(101, 1, 2, 10, 3, 1),
(102, 1, 2, 10, 4, 1),
(103, 1, 2, 10, 6, 1),
(104, 1, 2, 10, 7, 1),
(105, 1, 2, 10, 5, 1),
(106, 1, 2, 4, 1, 1),
(107, 1, 2, 4, 2, 1),
(108, 1, 2, 4, 3, 1),
(109, 1, 2, 4, 4, 1),
(110, 1, 2, 4, 6, 1),
(111, 1, 2, 4, 7, 1),
(112, 1, 2, 4, 5, 1),
(113, 1, 2, 9, 1, 1),
(114, 1, 2, 9, 2, 1),
(115, 1, 2, 9, 3, 1),
(116, 1, 2, 9, 4, 1),
(117, 1, 2, 9, 6, 1),
(118, 1, 2, 9, 7, 1),
(119, 1, 2, 9, 5, 1),
(120, 1, 11, 10, 1, 1),
(121, 1, 11, 10, 2, 1),
(122, 1, 11, 10, 3, 1),
(123, 1, 11, 10, 4, 1),
(124, 1, 11, 10, 6, 1),
(125, 1, 11, 10, 7, 1),
(126, 1, 11, 10, 5, 1),
(127, 1, 11, 3, 1, 1),
(128, 1, 11, 3, 2, 1),
(129, 1, 11, 3, 3, 1),
(130, 1, 11, 3, 4, 1),
(131, 1, 11, 3, 6, 1),
(132, 1, 11, 3, 7, 1),
(133, 1, 11, 3, 5, 1),
(134, 1, 11, 4, 1, 1),
(135, 1, 11, 4, 2, 1),
(136, 1, 11, 4, 3, 1),
(137, 1, 11, 4, 4, 1),
(138, 1, 11, 4, 6, 1),
(139, 1, 11, 4, 7, 1),
(140, 1, 11, 4, 5, 1),
(141, 1, 11, 9, 1, 1),
(142, 1, 11, 9, 2, 1),
(143, 1, 11, 9, 3, 1),
(144, 1, 11, 9, 4, 1),
(145, 1, 11, 9, 6, 1),
(146, 1, 11, 9, 7, 1),
(147, 1, 11, 9, 5, 1),
(148, 1, 8, 10, 1, 1),
(149, 1, 8, 10, 2, 1),
(150, 1, 8, 10, 3, 1),
(151, 1, 8, 10, 4, 1),
(152, 1, 8, 10, 6, 1),
(153, 1, 8, 10, 7, 1),
(154, 1, 8, 10, 5, 1),
(155, 1, 8, 3, 1, 1),
(156, 1, 8, 3, 2, 1),
(157, 1, 8, 3, 3, 1),
(158, 1, 8, 3, 4, 1),
(159, 1, 8, 3, 6, 1),
(160, 1, 8, 3, 7, 1),
(161, 1, 8, 3, 5, 1),
(162, 1, 8, 4, 1, 1),
(163, 1, 8, 4, 2, 1),
(164, 1, 8, 4, 3, 1),
(165, 1, 8, 4, 4, 1),
(166, 1, 8, 4, 6, 1),
(167, 1, 8, 4, 7, 1),
(168, 1, 8, 4, 5, 1),
(169, 1, 8, 5, 1, 1),
(170, 1, 8, 5, 2, 1),
(171, 1, 8, 5, 3, 1),
(172, 1, 8, 5, 4, 1),
(173, 1, 8, 5, 6, 1),
(174, 1, 8, 5, 7, 1),
(175, 1, 8, 5, 5, 1),
(176, 1, 8, 6, 1, 1),
(177, 1, 8, 6, 2, 1),
(178, 1, 8, 6, 3, 1),
(179, 1, 8, 6, 4, 1),
(180, 1, 8, 6, 6, 1),
(181, 1, 8, 6, 7, 1),
(182, 1, 8, 6, 5, 1),
(183, 1, 8, 12, 1, 1),
(184, 1, 8, 12, 2, 1),
(185, 1, 8, 12, 3, 1),
(186, 1, 8, 12, 4, 1),
(187, 1, 8, 12, 6, 1),
(188, 1, 8, 12, 7, 1),
(189, 1, 8, 12, 5, 1),
(190, 1, 8, 7, 1, 1),
(191, 1, 8, 7, 2, 1),
(192, 1, 8, 7, 3, 1),
(193, 1, 8, 7, 4, 1),
(194, 1, 8, 7, 6, 1),
(195, 1, 8, 7, 7, 1),
(196, 1, 8, 7, 5, 1),
(197, 1, 8, 9, 1, 1),
(198, 1, 8, 9, 2, 1),
(199, 1, 8, 9, 3, 1),
(200, 1, 8, 9, 4, 1),
(201, 1, 8, 9, 6, 1),
(202, 1, 8, 9, 7, 1),
(203, 1, 8, 9, 5, 1),
(204, 1, 10, 3, 1, 1),
(205, 1, 10, 3, 2, 1),
(206, 1, 10, 3, 3, 1),
(207, 1, 10, 3, 4, 1),
(208, 1, 10, 3, 6, 1),
(209, 1, 10, 3, 7, 1),
(210, 1, 10, 3, 5, 1),
(211, 1, 10, 4, 1, 1),
(212, 1, 10, 4, 2, 1),
(213, 1, 10, 4, 3, 1),
(214, 1, 10, 4, 4, 1),
(215, 1, 10, 4, 6, 1),
(216, 1, 10, 4, 7, 1),
(217, 1, 10, 4, 5, 1),
(218, 1, 10, 9, 1, 1),
(219, 1, 10, 9, 2, 1),
(220, 1, 10, 9, 3, 1),
(221, 1, 10, 9, 4, 1),
(222, 1, 10, 9, 6, 1),
(223, 1, 10, 9, 7, 1),
(224, 1, 10, 9, 5, 1),
(225, 1, 3, 4, 1, 1),
(226, 1, 3, 4, 2, 1),
(227, 1, 3, 4, 3, 1),
(228, 1, 3, 4, 4, 1),
(229, 1, 3, 4, 6, 1),
(230, 1, 3, 4, 7, 1),
(231, 1, 3, 4, 5, 1),
(232, 1, 3, 9, 1, 1),
(233, 1, 3, 9, 2, 1),
(234, 1, 3, 9, 3, 1),
(235, 1, 3, 9, 4, 1),
(236, 1, 3, 9, 6, 1),
(237, 1, 3, 9, 7, 1),
(238, 1, 3, 9, 5, 1),
(239, 1, 4, 8, 1, 1),
(240, 1, 4, 8, 2, 1),
(241, 1, 4, 8, 3, 1),
(242, 1, 4, 8, 4, 1),
(243, 1, 4, 8, 6, 1),
(244, 1, 4, 8, 7, 1),
(245, 1, 4, 8, 5, 1),
(246, 1, 4, 5, 1, 1),
(247, 1, 4, 6, 1, 1),
(248, 1, 4, 6, 2, 1),
(249, 1, 4, 6, 3, 1),
(250, 1, 4, 6, 4, 1),
(251, 1, 4, 6, 6, 1),
(252, 1, 4, 6, 7, 1),
(253, 1, 4, 6, 5, 1),
(254, 1, 4, 12, 1, 1),
(255, 1, 4, 12, 2, 1),
(256, 1, 4, 12, 3, 1),
(257, 1, 4, 12, 4, 1),
(258, 1, 4, 12, 6, 1),
(259, 1, 4, 12, 7, 1),
(260, 1, 4, 12, 5, 1),
(261, 1, 4, 7, 1, 1),
(262, 1, 4, 7, 2, 1),
(263, 1, 4, 7, 3, 1),
(264, 1, 4, 7, 4, 1),
(265, 1, 4, 7, 6, 1),
(266, 1, 4, 7, 7, 1),
(267, 1, 4, 7, 5, 1),
(268, 1, 5, 8, 1, 1),
(269, 1, 5, 8, 2, 1),
(270, 1, 5, 8, 3, 1),
(271, 1, 5, 8, 4, 1),
(272, 1, 5, 8, 6, 1),
(273, 1, 5, 8, 7, 1),
(274, 1, 5, 8, 5, 1),
(275, 1, 5, 6, 1, 1),
(276, 1, 5, 6, 2, 1),
(277, 1, 5, 6, 3, 1),
(278, 1, 5, 6, 4, 1),
(279, 1, 5, 6, 6, 1),
(280, 1, 5, 6, 7, 1),
(281, 1, 5, 6, 5, 1),
(282, 1, 5, 12, 1, 1),
(283, 1, 5, 12, 2, 1),
(284, 1, 5, 12, 3, 1),
(285, 1, 5, 12, 4, 1),
(286, 1, 5, 12, 6, 1),
(287, 1, 5, 12, 7, 1),
(288, 1, 5, 12, 5, 1),
(289, 1, 5, 7, 1, 1),
(290, 1, 5, 7, 2, 1),
(291, 1, 5, 7, 3, 1),
(292, 1, 5, 7, 4, 1),
(293, 1, 5, 7, 6, 1),
(294, 1, 5, 7, 7, 1),
(295, 1, 5, 7, 5, 1),
(296, 1, 6, 8, 1, 1),
(297, 1, 6, 8, 2, 1),
(298, 1, 6, 8, 3, 1),
(299, 1, 6, 8, 4, 1),
(300, 1, 6, 8, 6, 1),
(301, 1, 6, 8, 7, 1),
(302, 1, 6, 8, 5, 1),
(303, 1, 6, 12, 1, 1),
(304, 1, 6, 12, 2, 1),
(305, 1, 6, 12, 3, 1),
(306, 1, 6, 12, 4, 1),
(307, 1, 6, 12, 6, 1),
(308, 1, 6, 12, 7, 1),
(309, 1, 6, 12, 5, 1),
(310, 1, 6, 7, 1, 1),
(311, 1, 6, 7, 2, 1),
(312, 1, 6, 7, 3, 1),
(313, 1, 6, 7, 4, 1),
(314, 1, 6, 7, 6, 1),
(315, 1, 6, 7, 7, 1),
(316, 1, 6, 7, 5, 1),
(317, 1, 12, 8, 1, 1),
(318, 1, 12, 8, 2, 1),
(319, 1, 12, 8, 3, 1),
(320, 1, 12, 8, 4, 1),
(321, 1, 12, 8, 6, 1),
(322, 1, 12, 8, 7, 1),
(323, 1, 12, 8, 5, 1),
(324, 1, 12, 7, 1, 1),
(325, 1, 12, 7, 2, 1),
(326, 1, 12, 7, 3, 1),
(327, 1, 12, 7, 4, 1),
(328, 1, 12, 7, 6, 1),
(329, 1, 12, 7, 7, 1),
(330, 1, 12, 7, 5, 1),
(331, 1, 7, 8, 1, 1),
(332, 1, 7, 8, 2, 1),
(333, 1, 7, 8, 3, 1),
(334, 1, 7, 8, 4, 1),
(335, 1, 7, 8, 6, 1),
(336, 1, 7, 8, 7, 1),
(337, 1, 7, 8, 5, 1),
(338, 1, 9, 8, 1, 1),
(339, 1, 9, 8, 2, 1),
(340, 1, 9, 8, 3, 1),
(341, 1, 9, 8, 4, 1),
(342, 1, 9, 8, 6, 1),
(343, 1, 9, 8, 7, 1),
(344, 1, 9, 8, 5, 1),
(345, 2, 1, 9, 1, 1),
(346, 2, 1, 9, 2, 1),
(347, 2, 1, 9, 3, 1),
(348, 2, 1, 9, 4, 1),
(349, 2, 1, 9, 6, 1),
(350, 2, 1, 9, 7, 1),
(351, 2, 1, 9, 5, 1),
(352, 2, 8, 10, 1, 1),
(353, 2, 8, 10, 2, 1),
(354, 2, 8, 10, 3, 1),
(355, 2, 8, 10, 4, 1),
(356, 2, 8, 10, 6, 1),
(357, 2, 8, 10, 7, 1),
(358, 2, 8, 10, 5, 1),
(359, 2, 8, 9, 1, 1),
(360, 2, 8, 9, 2, 1),
(361, 2, 8, 9, 3, 1),
(362, 2, 8, 9, 4, 1),
(363, 2, 8, 9, 6, 1),
(364, 2, 8, 9, 7, 1),
(365, 2, 8, 9, 5, 1),
(366, 2, 10, 3, 1, 1),
(367, 2, 10, 3, 2, 1),
(368, 2, 10, 3, 3, 1),
(369, 2, 10, 3, 4, 1),
(370, 2, 10, 3, 6, 1),
(371, 2, 10, 3, 7, 1),
(372, 2, 10, 3, 5, 1),
(373, 2, 10, 9, 1, 1),
(374, 2, 10, 9, 2, 1),
(375, 2, 10, 9, 3, 1),
(376, 2, 10, 9, 4, 1),
(377, 2, 10, 9, 6, 1),
(378, 2, 10, 9, 7, 1),
(379, 2, 10, 9, 5, 1),
(380, 2, 3, 4, 1, 1),
(381, 2, 3, 4, 2, 1),
(382, 2, 3, 4, 3, 1),
(383, 2, 3, 4, 4, 1),
(384, 2, 3, 4, 6, 1),
(385, 2, 3, 4, 7, 1),
(386, 2, 3, 4, 5, 1),
(387, 2, 3, 9, 1, 1),
(388, 2, 3, 9, 2, 1),
(389, 2, 3, 9, 3, 1),
(390, 2, 3, 9, 4, 1),
(391, 2, 3, 9, 6, 1),
(392, 2, 3, 9, 7, 1),
(393, 2, 3, 9, 5, 1),
(394, 2, 4, 8, 1, 1),
(395, 2, 4, 8, 2, 1),
(396, 2, 4, 8, 3, 1),
(397, 2, 4, 8, 4, 1),
(398, 2, 4, 8, 6, 1),
(399, 2, 4, 8, 7, 1),
(400, 2, 4, 8, 5, 1),
(401, 2, 4, 7, 1, 1),
(402, 2, 4, 7, 2, 1),
(403, 2, 4, 7, 3, 1),
(404, 2, 4, 7, 4, 1),
(405, 2, 4, 7, 6, 1),
(406, 2, 4, 7, 7, 1),
(407, 2, 4, 7, 5, 1),
(408, 2, 7, 8, 1, 1),
(409, 2, 7, 8, 2, 1),
(410, 2, 7, 8, 3, 1),
(411, 2, 7, 8, 4, 1),
(412, 2, 7, 8, 6, 1),
(413, 2, 7, 8, 7, 1),
(414, 2, 7, 8, 5, 1),
(415, 2, 9, 8, 1, 1),
(416, 2, 9, 8, 2, 1),
(417, 2, 9, 8, 3, 1),
(418, 2, 9, 8, 4, 1),
(419, 2, 9, 8, 6, 1),
(420, 2, 9, 8, 7, 1),
(421, 2, 9, 8, 5, 1),
(422, 3, 1, 2, 3, 1),
(423, 3, 1, 9, 3, 1),
(424, 3, 1, 9, 4, 1),
(425, 3, 2, 10, 3, 1),
(426, 3, 2, 10, 4, 1),
(427, 3, 2, 3, 3, 1),
(428, 3, 2, 3, 4, 1),
(429, 3, 2, 9, 3, 1),
(430, 3, 2, 9, 4, 1),
(431, 3, 8, 10, 3, 1),
(432, 3, 8, 10, 4, 1),
(433, 3, 8, 3, 3, 1),
(434, 3, 8, 3, 4, 1),
(435, 3, 8, 9, 3, 1),
(436, 3, 8, 9, 4, 1),
(437, 3, 10, 3, 3, 1),
(438, 3, 10, 3, 4, 1),
(439, 3, 10, 9, 3, 1),
(440, 3, 10, 9, 4, 1),
(441, 3, 3, 4, 3, 1),
(442, 3, 3, 4, 4, 1),
(443, 3, 3, 9, 3, 1),
(444, 3, 3, 9, 4, 1),
(445, 3, 4, 3, 3, 1),
(446, 3, 4, 3, 4, 1),
(447, 3, 4, 5, 3, 1),
(448, 3, 4, 5, 4, 1),
(449, 3, 4, 6, 3, 1),
(450, 3, 5, 6, 3, 1),
(451, 3, 6, 8, 6, 1),
(452, 3, 6, 8, 7, 1),
(453, 3, 6, 12, 6, 1),
(454, 3, 6, 12, 7, 1),
(455, 3, 12, 7, 3, 1),
(456, 3, 12, 7, 4, 1),
(457, 3, 12, 7, 6, 1),
(458, 3, 12, 7, 7, 1),
(459, 3, 7, 8, 3, 1),
(460, 3, 7, 8, 4, 1),
(461, 3, 7, 8, 6, 1),
(462, 3, 7, 8, 7, 1),
(463, 3, 9, 8, 3, 1),
(464, 3, 9, 8, 4, 1),
(465, 3, 9, 8, 6, 1),
(466, 3, 9, 8, 7, 1),
(467, 4, 1, 2, 3, 1),
(468, 4, 1, 2, 4, 1),
(469, 4, 2, 11, 6, 1),
(470, 4, 2, 11, 7, 1),
(471, 4, 2, 9, 6, 1),
(472, 4, 2, 9, 7, 1),
(473, 4, 11, 10, 3, 1),
(474, 4, 11, 10, 4, 1),
(475, 4, 11, 3, 3, 1),
(476, 4, 11, 3, 4, 1),
(477, 4, 8, 10, 3, 1),
(478, 4, 8, 10, 4, 1),
(479, 4, 8, 3, 3, 1),
(480, 4, 8, 3, 4, 1),
(481, 4, 10, 3, 3, 1),
(482, 4, 10, 3, 4, 1),
(483, 4, 3, 4, 3, 1),
(484, 4, 3, 4, 4, 1),
(485, 4, 11, 2, 3, 1),
(486, 4, 4, 5, 3, 1),
(487, 4, 4, 5, 4, 1),
(488, 4, 5, 6, 3, 1),
(489, 4, 4, 10, 3, 1),
(490, 4, 4, 10, 4, 1),
(491, 4, 4, 3, 3, 1),
(492, 4, 4, 3, 4, 1),
(493, 4, 6, 8, 6, 1),
(494, 4, 6, 8, 7, 1),
(495, 4, 6, 12, 6, 1),
(496, 4, 6, 12, 7, 1),
(497, 4, 12, 7, 3, 1),
(498, 4, 12, 7, 4, 1),
(499, 4, 12, 7, 6, 1),
(500, 4, 12, 7, 7, 1),
(501, 4, 7, 8, 3, 1),
(502, 4, 7, 8, 6, 1),
(503, 4, 9, 8, 6, 1),
(504, 5, 1, 10, 1, 1),
(505, 5, 1, 10, 2, 1),
(506, 5, 1, 10, 3, 1),
(507, 5, 1, 10, 4, 1),
(508, 5, 1, 10, 6, 1),
(509, 5, 1, 10, 7, 1),
(510, 5, 1, 10, 5, 1),
(511, 5, 1, 9, 1, 1),
(512, 5, 1, 9, 2, 1),
(513, 5, 1, 9, 3, 1),
(514, 5, 1, 9, 4, 1),
(515, 5, 1, 9, 6, 1),
(516, 5, 1, 9, 7, 1),
(517, 5, 1, 9, 5, 1),
(518, 5, 8, 10, 1, 1),
(519, 5, 8, 10, 2, 1),
(520, 5, 8, 10, 3, 1),
(521, 5, 8, 10, 4, 1),
(522, 5, 8, 10, 6, 1),
(523, 5, 8, 10, 7, 1),
(524, 5, 8, 10, 5, 1),
(525, 5, 8, 9, 1, 1),
(526, 5, 8, 9, 2, 1),
(527, 5, 8, 9, 3, 1),
(528, 5, 8, 9, 4, 1),
(529, 5, 8, 9, 6, 1),
(530, 5, 8, 9, 7, 1),
(531, 5, 8, 9, 5, 1),
(532, 5, 10, 3, 1, 1),
(533, 5, 10, 3, 2, 1),
(534, 5, 10, 3, 3, 1),
(535, 5, 10, 3, 4, 1),
(536, 5, 10, 3, 6, 1),
(537, 5, 10, 3, 7, 1),
(538, 5, 10, 3, 5, 1),
(539, 5, 10, 9, 1, 1),
(540, 5, 10, 9, 2, 1),
(541, 5, 10, 9, 3, 1),
(542, 5, 10, 9, 4, 1),
(543, 5, 10, 9, 6, 1),
(544, 5, 10, 9, 7, 1),
(545, 5, 10, 9, 5, 1),
(546, 5, 3, 4, 1, 1),
(547, 5, 3, 4, 2, 1),
(548, 5, 3, 4, 3, 1),
(549, 5, 3, 4, 4, 1),
(550, 5, 3, 4, 6, 1),
(551, 5, 3, 4, 7, 1),
(552, 5, 3, 4, 5, 1),
(553, 5, 3, 9, 1, 1),
(554, 5, 3, 9, 2, 1),
(555, 5, 3, 9, 3, 1),
(556, 5, 3, 9, 4, 1),
(557, 5, 3, 9, 6, 1),
(558, 5, 3, 9, 7, 1),
(559, 5, 3, 9, 5, 1),
(560, 5, 4, 8, 1, 1),
(561, 5, 4, 8, 2, 1),
(562, 5, 4, 8, 3, 1),
(563, 5, 4, 8, 4, 1),
(564, 5, 4, 8, 6, 1),
(565, 5, 4, 8, 7, 1),
(566, 5, 4, 8, 5, 1),
(567, 5, 4, 12, 1, 1),
(568, 5, 4, 12, 2, 1),
(569, 5, 4, 12, 3, 1),
(570, 5, 4, 12, 4, 1),
(571, 5, 4, 12, 6, 1),
(572, 5, 4, 12, 7, 1),
(573, 5, 4, 12, 5, 1),
(574, 5, 12, 8, 1, 1),
(575, 5, 12, 8, 2, 1),
(576, 5, 12, 8, 3, 1),
(577, 5, 12, 8, 4, 1),
(578, 5, 12, 8, 6, 1),
(579, 5, 12, 8, 7, 1),
(580, 5, 12, 8, 5, 1),
(581, 5, 12, 7, 1, 1),
(582, 5, 12, 7, 2, 1),
(583, 5, 12, 7, 3, 1),
(584, 5, 12, 7, 4, 1),
(585, 5, 12, 7, 6, 1),
(586, 5, 12, 7, 7, 1),
(587, 5, 12, 7, 5, 1),
(588, 5, 7, 8, 1, 1),
(589, 5, 7, 8, 2, 1),
(590, 5, 7, 8, 3, 1),
(591, 5, 7, 8, 4, 1),
(592, 5, 7, 8, 6, 1),
(593, 5, 7, 8, 7, 1),
(594, 5, 7, 8, 5, 1),
(595, 5, 9, 8, 1, 1),
(596, 5, 9, 8, 2, 1),
(597, 5, 9, 8, 3, 1),
(598, 5, 9, 8, 4, 1),
(599, 5, 9, 8, 6, 1),
(600, 5, 9, 8, 7, 1),
(601, 5, 9, 8, 5, 1),
(602, 7, 1, 13, 1, 1),
(603, 7, 1, 13, 2, 1),
(604, 7, 1, 13, 3, 1),
(605, 7, 1, 13, 4, 1),
(606, 7, 1, 13, 6, 1),
(607, 7, 1, 13, 7, 1),
(608, 7, 1, 13, 5, 1),
(609, 7, 1, 9, 1, 1),
(610, 7, 1, 9, 2, 1),
(611, 7, 1, 9, 3, 1),
(612, 7, 1, 9, 4, 1),
(613, 7, 1, 9, 6, 1),
(614, 7, 1, 9, 7, 1),
(615, 7, 1, 9, 5, 1),
(616, 7, 13, 9, 1, 1),
(617, 7, 13, 9, 2, 1),
(618, 7, 13, 9, 3, 1),
(619, 7, 13, 9, 4, 1),
(620, 7, 13, 9, 6, 1),
(621, 7, 13, 9, 7, 1),
(622, 7, 13, 9, 5, 1),
(623, 7, 13, 4, 1, 1),
(624, 7, 13, 4, 2, 1),
(625, 7, 13, 4, 3, 1),
(626, 7, 13, 4, 4, 1),
(627, 7, 13, 4, 6, 1),
(628, 7, 13, 4, 7, 1),
(629, 7, 13, 4, 5, 1),
(630, 7, 4, 6, 1, 1),
(631, 7, 4, 6, 2, 1),
(632, 7, 4, 6, 3, 1),
(633, 7, 4, 6, 4, 1),
(634, 7, 4, 6, 6, 1),
(635, 7, 4, 6, 7, 1),
(636, 7, 4, 6, 5, 1),
(637, 7, 6, 12, 1, 1),
(638, 7, 6, 12, 2, 1),
(639, 7, 6, 12, 3, 1),
(640, 7, 6, 12, 6, 1),
(641, 7, 6, 12, 6, 1),
(642, 7, 6, 12, 7, 1),
(643, 7, 6, 12, 5, 1),
(644, 6, 1, 12, 1, 1),
(645, 6, 1, 12, 3, 1),
(646, 6, 1, 9, 1, 1),
(647, 6, 1, 9, 3, 1),
(648, 8, 1, 3, 1, 1),
(649, 8, 1, 3, 2, 1),
(650, 8, 1, 3, 3, 1),
(651, 8, 1, 3, 4, 1),
(652, 8, 1, 3, 6, 1),
(653, 8, 1, 3, 7, 1),
(654, 8, 1, 3, 5, 1),
(655, 8, 3, 4, 1, 1),
(656, 8, 3, 4, 2, 1),
(657, 8, 3, 4, 3, 1),
(658, 8, 3, 4, 4, 1),
(659, 8, 3, 4, 6, 1),
(660, 8, 3, 4, 7, 1),
(661, 8, 3, 4, 5, 1),
(662, 8, 4, 3, 3, 1),
(663, 8, 4, 12, 3, 1),
(664, 8, 12, 7, 3, 1),
(665, 2, 1, 4, 1, 1),
(666, 2, 1, 4, 2, 1),
(667, 2, 1, 4, 3, 1),
(668, 2, 1, 4, 4, 1),
(669, 2, 1, 4, 6, 1),
(670, 2, 1, 4, 7, 1),
(671, 2, 1, 4, 5, 1);

-- --------------------------------------------------------

--
-- Structure de la table `workperiod`
--

CREATE TABLE `workperiod` (
  `id` int(12) UNSIGNED NOT NULL,
  `idResource` int(12) UNSIGNED DEFAULT NULL,
  `periodRange` varchar(10) DEFAULT NULL,
  `periodValue` varchar(10) DEFAULT NULL,
  `submitted` int(1) UNSIGNED DEFAULT '0',
  `submittedDate` datetime DEFAULT NULL,
  `validated` int(1) UNSIGNED DEFAULT '0',
  `validatedDate` datetime DEFAULT NULL,
  `idLocker` int(12) UNSIGNED DEFAULT NULL,
  `comment` varchar(4000) DEFAULT NULL,
  `idle` int(1) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `workperiod`
--

INSERT INTO `workperiod` (`id`, `idResource`, `periodRange`, `periodValue`, `submitted`, `submittedDate`, `validated`, `validatedDate`, `idLocker`, `comment`, `idle`) VALUES
(1, 3, 'week', '201401', 0, NULL, 0, NULL, NULL, NULL, 0),
(2, 8, 'week', '201136', 0, NULL, 0, NULL, NULL, NULL, 0),
(3, 8, 'week', '201141', 0, NULL, 0, NULL, NULL, NULL, 0),
(4, 10, 'week', '201210', 0, NULL, 0, NULL, NULL, NULL, 0),
(5, 10, 'week', '201211', 0, NULL, 0, NULL, NULL, NULL, 0),
(6, 3, 'week', '201211', 0, NULL, 0, NULL, NULL, NULL, 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `accessprofile`
--
ALTER TABLE `accessprofile`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `accessright`
--
ALTER TABLE `accessright`
  ADD PRIMARY KEY (`id`),
  ADD KEY `accessrightProfile` (`idProfile`),
  ADD KEY `accessrightMenu` (`idMenu`);

--
-- Index pour la table `accessscope`
--
ALTER TABLE `accessscope`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `action`
--
ALTER TABLE `action`
  ADD PRIMARY KEY (`id`),
  ADD KEY `actionProject` (`idProject`),
  ADD KEY `actionUser` (`idUser`),
  ADD KEY `actionResource` (`idResource`),
  ADD KEY `actionStatus` (`idStatus`),
  ADD KEY `actionType` (`idActionType`);

--
-- Index pour la table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activityProject` (`idProject`),
  ADD KEY `activityUser` (`idUser`),
  ADD KEY `activityResource` (`idResource`),
  ADD KEY `activityStatus` (`idStatus`),
  ADD KEY `activityType` (`idActivityType`),
  ADD KEY `activityActivity` (`idActivity`);

--
-- Index pour la table `activityprice`
--
ALTER TABLE `activityprice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activitypriceProject` (`idProject`),
  ADD KEY `activitypriceActivityType` (`idActivityType`),
  ADD KEY `activitypriceTeam` (`idTeam`);

--
-- Index pour la table `affectation`
--
ALTER TABLE `affectation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `affectationProject` (`idProject`),
  ADD KEY `affectationResource` (`idResource`);

--
-- Index pour la table `alert`
--
ALTER TABLE `alert`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `approver`
--
ALTER TABLE `approver`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approverRef` (`refType`,`refId`),
  ADD KEY `approverAffectable` (`idAffectable`);

--
-- Index pour la table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignmentProject` (`idProject`),
  ADD KEY `assignmentResource` (`idResource`),
  ADD KEY `assignmentRef` (`refType`,`refId`);

--
-- Index pour la table `attachment`
--
ALTER TABLE `attachment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attachementUser` (`idUser`),
  ADD KEY `attachementRef` (`refType`,`refId`);

--
-- Index pour la table `audit`
--
ALTER TABLE `audit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auditUser` (`idUser`),
  ADD KEY `auditSessionId` (`sessionId`);

--
-- Index pour la table `auditsummary`
--
ALTER TABLE `auditsummary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auditsummaryAuditDay` (`auditDay`);

--
-- Index pour la table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`),
  ADD KEY `billBillType` (`idBillType`),
  ADD KEY `billProject` (`idProject`),
  ADD KEY `billClient` (`idClient`),
  ADD KEY `billRecipient` (`idRecipient`),
  ADD KEY `billStatus` (`idStatus`);

--
-- Index pour la table `billline`
--
ALTER TABLE `billline`
  ADD PRIMARY KEY (`id`),
  ADD KEY `billlineReference` (`refType`,`refId`),
  ADD KEY `billlineTerm` (`idTerm`),
  ADD KEY `billlineResource` (`idResource`),
  ADD KEY `billlineActivityPrice` (`idActivityPrice`);

--
-- Index pour la table `calendar`
--
ALTER TABLE `calendar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `calendarDay` (`day`),
  ADD KEY `calendarWeek` (`week`),
  ADD KEY `calendarMonth` (`month`),
  ADD KEY `calendarYear` (`year`);

--
-- Index pour la table `calendardefinition`
--
ALTER TABLE `calendardefinition`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `callfortender`
--
ALTER TABLE `callfortender`
  ADD PRIMARY KEY (`id`),
  ADD KEY `callfortenderProject` (`idProject`),
  ADD KEY `callfortenderType` (`idCallForTenderType`),
  ADD KEY `callfortenderStatus` (`idStatus`),
  ADD KEY `callfortenderResource` (`idResource`);

--
-- Index pour la table `checklist`
--
ALTER TABLE `checklist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `checklistReference` (`refType`,`refId`),
  ADD KEY `checklistChecklistDefinition` (`idChecklistDefinition`);

--
-- Index pour la table `checklistable`
--
ALTER TABLE `checklistable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `checklistdefinition`
--
ALTER TABLE `checklistdefinition`
  ADD PRIMARY KEY (`id`),
  ADD KEY `checklistdefinitionChecklistable` (`idChecklistable`),
  ADD KEY `checklistdefinitionNameChecklistable` (`nameChecklistable`),
  ADD KEY `checklistdefinitionType` (`idType`);

--
-- Index pour la table `checklistdefinitionline`
--
ALTER TABLE `checklistdefinitionline`
  ADD PRIMARY KEY (`id`),
  ADD KEY `checklistdefinitionlineChecklistDefinition` (`idChecklistDefinition`);

--
-- Index pour la table `checklistline`
--
ALTER TABLE `checklistline`
  ADD PRIMARY KEY (`id`),
  ADD KEY `checklistlineChecklist` (`idChecklist`),
  ADD KEY `checklistlineChecklistDefinitionLine` (`idChecklistDefinitionLine`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clientClientType` (`idClientType`);

--
-- Index pour la table `collapsed`
--
ALTER TABLE `collapsed`
  ADD PRIMARY KEY (`id`),
  ADD KEY `collapsedUser` (`idUser`);

--
-- Index pour la table `columnselector`
--
ALTER TABLE `columnselector`
  ADD PRIMARY KEY (`id`),
  ADD KEY `scopeColumnSelector` (`scope`,`objectClass`,`idUser`);

--
-- Index pour la table `command`
--
ALTER TABLE `command`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commandProject` (`idProject`),
  ADD KEY `commandUser` (`idUser`),
  ADD KEY `commandResource` (`idResource`),
  ADD KEY `commandStatus` (`idStatus`),
  ADD KEY `commandType` (`idCommandType`);

--
-- Index pour la table `context`
--
ALTER TABLE `context`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contextContextType` (`idContextType`);

--
-- Index pour la table `contexttype`
--
ALTER TABLE `contexttype`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `copyable`
--
ALTER TABLE `copyable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `criticality`
--
ALTER TABLE `criticality`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `cronexecution`
--
ALTER TABLE `cronexecution`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `decision`
--
ALTER TABLE `decision`
  ADD PRIMARY KEY (`id`),
  ADD KEY `decisionProject` (`idProject`),
  ADD KEY `decisionType` (`idDecisionType`),
  ADD KEY `decisionUser` (`idUser`),
  ADD KEY `decisionResource` (`idResource`),
  ADD KEY `decisionStatus` (`idStatus`);

--
-- Index pour la table `delay`
--
ALTER TABLE `delay`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `delayunit`
--
ALTER TABLE `delayunit`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `deliverymode`
--
ALTER TABLE `deliverymode`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `dependable`
--
ALTER TABLE `dependable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `dependency`
--
ALTER TABLE `dependency`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dependencyPredecessorRef` (`predecessorRefType`,`predecessorRefId`),
  ADD KEY `dependencyPredecessorId` (`predecessorId`),
  ADD KEY `dependencySuccessorRef` (`successorRefType`,`successorRefId`),
  ADD KEY `dependencySuccessorId` (`successorId`);

--
-- Index pour la table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documentProject` (`idProject`),
  ADD KEY `documentProduct` (`idProduct`),
  ADD KEY `documentDocumentType` (`idDocumentType`),
  ADD KEY `documentDocumentDirectory` (`idDocumentDirectory`),
  ADD KEY `documentVersionType` (`idVersioningType`),
  ADD KEY `documentStatus` (`idStatus`),
  ADD KEY `documentDocumentVersion` (`idDocumentVersion`),
  ADD KEY `documentDocumentVersionRef` (`idDocumentVersionRef`),
  ADD KEY `documentAuthor` (`idAuthor`),
  ADD KEY `documentLocker` (`idLocker`);

--
-- Index pour la table `documentdirectory`
--
ALTER TABLE `documentdirectory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documentdirectoryProject` (`idProject`),
  ADD KEY `documentdirectoryProduct` (`idProduct`),
  ADD KEY `documentdirectoryDocumentDirectory` (`idDocumentDirectory`),
  ADD KEY `documentdirectoryDocumentType` (`idDocumentType`);

--
-- Index pour la table `documentversion`
--
ALTER TABLE `documentversion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documentversionDocument` (`idDocument`),
  ADD KEY `documentversionAuthor` (`idAuthor`),
  ADD KEY `documentversionStatus` (`idStatus`);

--
-- Index pour la table `efficiency`
--
ALTER TABLE `efficiency`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expenseProject` (`idProject`),
  ADD KEY `expenseType` (`idExpenseType`),
  ADD KEY `expenseUser` (`idUser`),
  ADD KEY `expenseResource` (`idResource`),
  ADD KEY `expenseStatus` (`idStatus`),
  ADD KEY `expenseDay` (`day`),
  ADD KEY `expenseWeek` (`week`),
  ADD KEY `expenseMonth` (`month`),
  ADD KEY `expenseYear` (`year`),
  ADD KEY `expenseProvider` (`idProvider`),
  ADD KEY `expenseResponsible` (`idResponsible`);

--
-- Index pour la table `expensedetail`
--
ALTER TABLE `expensedetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expensedetailProject` (`idProject`),
  ADD KEY `expensedetailType` (`idExpenseDetailType`),
  ADD KEY `expensedetailExpense` (`idExpense`);

--
-- Index pour la table `expensedetailtype`
--
ALTER TABLE `expensedetailtype`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `extrahiddenfield`
--
ALTER TABLE `extrahiddenfield`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `favorite`
--
ALTER TABLE `favorite`
  ADD PRIMARY KEY (`id`),
  ADD KEY `favoriteUser` (`idUser`);

--
-- Index pour la table `favoriteparameter`
--
ALTER TABLE `favoriteparameter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `favoriteParameterUser` (`idUser`),
  ADD KEY `favoriteParameterReport` (`idReport`),
  ADD KEY `favoriteParameterToday` (`idFavorite`);

--
-- Index pour la table `feasibility`
--
ALTER TABLE `feasibility`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `filter`
--
ALTER TABLE `filter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `filterUser` (`idUser`);

--
-- Index pour la table `filtercriteria`
--
ALTER TABLE `filtercriteria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `filtercriteriaFilter` (`idFilter`);

--
-- Index pour la table `habilitation`
--
ALTER TABLE `habilitation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `habilitationProfile` (`idProfile`),
  ADD KEY `habilitationMenu` (`idMenu`);

--
-- Index pour la table `habilitationother`
--
ALTER TABLE `habilitationother`
  ADD PRIMARY KEY (`id`),
  ADD KEY `habilitationotherProfile` (`idProfile`);

--
-- Index pour la table `habilitationreport`
--
ALTER TABLE `habilitationreport`
  ADD PRIMARY KEY (`id`),
  ADD KEY `habilitationReportProfile` (`idProfile`),
  ADD KEY `habilitationReportReport` (`idReport`);

--
-- Index pour la table `health`
--
ALTER TABLE `health`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `historyUser` (`idUser`),
  ADD KEY `historyRef` (`refType`,`refId`);

--
-- Index pour la table `importable`
--
ALTER TABLE `importable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `importlog`
--
ALTER TABLE `importlog`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `indicator`
--
ALTER TABLE `indicator`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `indicatorable`
--
ALTER TABLE `indicatorable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `indicatorableindicator`
--
ALTER TABLE `indicatorableindicator`
  ADD PRIMARY KEY (`id`),
  ADD KEY `indicatorableindicatorIndicatorable` (`idIndicatorable`),
  ADD KEY `indicatorableindicatorIndicator` (`idIndicator`);

--
-- Index pour la table `indicatordefinition`
--
ALTER TABLE `indicatordefinition`
  ADD PRIMARY KEY (`id`),
  ADD KEY `indicatordefinitionIndicatorable` (`idIndicatorable`),
  ADD KEY `indicatordefinitionIndicator` (`idIndicator`),
  ADD KEY `indicatordefinitionType` (`idType`);

--
-- Index pour la table `indicatorvalue`
--
ALTER TABLE `indicatorvalue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `indicatorvalueIndicatordefinition` (`idIndicatorDefinition`),
  ADD KEY `indicatorvalueReference` (`refType`,`refId`);

--
-- Index pour la table `issue`
--
ALTER TABLE `issue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `issueProject` (`idProject`),
  ADD KEY `issueUser` (`idUser`),
  ADD KEY `issueResource` (`idResource`),
  ADD KEY `issueStatus` (`idStatus`),
  ADD KEY `issueType` (`idIssueType`),
  ADD KEY `issuePriority` (`idPriority`);

--
-- Index pour la table `likelihood`
--
ALTER TABLE `likelihood`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `link`
--
ALTER TABLE `link`
  ADD PRIMARY KEY (`id`),
  ADD KEY `linkRef1` (`ref1Type`,`ref1Id`),
  ADD KEY `linkRef2` (`ref2Type`,`ref2Id`);

--
-- Index pour la table `linkable`
--
ALTER TABLE `linkable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `list`
--
ALTER TABLE `list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `listList` (`list`);

--
-- Index pour la table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mailProject` (`idProject`),
  ADD KEY `mailUser` (`idUser`),
  ADD KEY `mailRef` (`refType`,`refId`),
  ADD KEY `mailStatus` (`idStatus`);

--
-- Index pour la table `mailable`
--
ALTER TABLE `mailable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `measureunit`
--
ALTER TABLE `measureunit`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `meeting`
--
ALTER TABLE `meeting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meetingProject` (`idProject`),
  ADD KEY `meetingType` (`idMeetingType`),
  ADD KEY `meetingUser` (`idUser`),
  ADD KEY `meetingResource` (`idResource`),
  ADD KEY `meetingStatus` (`idStatus`),
  ADD KEY `meetingPeriodicMeeting` (`idPeriodicMeeting`);

--
-- Index pour la table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menuMenu` (`idMenu`);

--
-- Index pour la table `menucustom`
--
ALTER TABLE `menucustom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menucustomUser` (`idUser`);

--
-- Index pour la table `menuselector`
--
ALTER TABLE `menuselector`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `messageProject` (`idProject`),
  ADD KEY `messageUser` (`idUser`),
  ADD KEY `messageType` (`idMessageType`),
  ADD KEY `messageProfile` (`idProfile`);

--
-- Index pour la table `milestone`
--
ALTER TABLE `milestone`
  ADD PRIMARY KEY (`id`),
  ADD KEY `milestoneProject` (`idProject`),
  ADD KEY `milestoneUser` (`idUser`),
  ADD KEY `milestoneResource` (`idResource`),
  ADD KEY `milestoneStatus` (`idStatus`),
  ADD KEY `milestoneType` (`idMilestoneType`),
  ADD KEY `milestoneActivity` (`idActivity`);

--
-- Index pour la table `mutex`
--
ALTER TABLE `mutex`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`),
  ADD KEY `noteUser` (`idUser`),
  ADD KEY `noteRef` (`refType`,`refId`);

--
-- Index pour la table `opportunity`
--
ALTER TABLE `opportunity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opportunityProject` (`idProject`),
  ADD KEY `opportunityUser` (`idUser`),
  ADD KEY `opportunityResource` (`idResource`),
  ADD KEY `opportunityStatus` (`idStatus`),
  ADD KEY `opportunityType` (`idOpportunityType`),
  ADD KEY `opportunitySeverity` (`idSeverity`),
  ADD KEY `opportunityLikelihood` (`idLikelihood`),
  ADD KEY `opportunityCriticality` (`idCriticality`);

--
-- Index pour la table `origin`
--
ALTER TABLE `origin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `originOrigin` (`originType`,`originId`),
  ADD KEY `originRef` (`refType`,`refId`);

--
-- Index pour la table `originable`
--
ALTER TABLE `originable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `otherversion`
--
ALTER TABLE `otherversion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otherversionRef` (`refType`,`refId`),
  ADD KEY `otherversionVersion` (`idVersion`),
  ADD KEY `otherversionUser` (`idUser`);

--
-- Index pour la table `overallprogress`
--
ALTER TABLE `overallprogress`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `parameter`
--
ALTER TABLE `parameter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parameterProject` (`idProject`),
  ADD KEY `parameterUser` (`idUser`);

--
-- Index pour la table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paymentBill` (`idBill`);

--
-- Index pour la table `paymentdelay`
--
ALTER TABLE `paymentdelay`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paymentmode`
--
ALTER TABLE `paymentmode`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `periodicity`
--
ALTER TABLE `periodicity`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `periodicmeeting`
--
ALTER TABLE `periodicmeeting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `periodicmeetingProject` (`idProject`),
  ADD KEY `periodicmeetingType` (`idMeetingType`),
  ADD KEY `periodicmeetingUser` (`idUser`),
  ADD KEY `periodicmeetingResource` (`idResource`);

--
-- Index pour la table `plannedwork`
--
ALTER TABLE `plannedwork`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workDay` (`day`),
  ADD KEY `plannedworkWeek` (`week`),
  ADD KEY `plannedworkMonth` (`month`),
  ADD KEY `plannedworkYear` (`year`),
  ADD KEY `plannedworkRef` (`refType`,`refId`),
  ADD KEY `plannedworkResource` (`idResource`),
  ADD KEY `plannedworkAssignment` (`idAssignment`);

--
-- Index pour la table `planningelement`
--
ALTER TABLE `planningelement`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `planningelementReference` (`refType`,`refId`),
  ADD KEY `planningelementTopId` (`topId`),
  ADD KEY `planningelementTopRef` (`topRefType`,`topRefId`),
  ADD KEY `planningelementProject` (`idProject`),
  ADD KEY `planningelementWbsSortable` (`wbsSortable`(255)),
  ADD KEY `planningElementDependencyLevel` (`dependencyLevel`),
  ADD KEY `planningelementPlanningMode` (`idPlanningMode`),
  ADD KEY `planningelementBill` (`idBill`);

--
-- Index pour la table `planningmode`
--
ALTER TABLE `planningmode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `planningmodeApplyTo` (`applyTo`);

--
-- Index pour la table `plugin`
--
ALTER TABLE `plugin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pluginName` (`name`);

--
-- Index pour la table `plugintriggeredevent`
--
ALTER TABLE `plugintriggeredevent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugintriggeredeventPlugin` (`idPlugin`);

--
-- Index pour la table `predefinedtext`
--
ALTER TABLE `predefinedtext`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `priority`
--
ALTER TABLE `priority`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `privacy`
--
ALTER TABLE `privacy`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `productClient` (`idClient`),
  ADD KEY `pruductContact` (`idContact`);

--
-- Index pour la table `productproject`
--
ALTER TABLE `productproject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `productprojectProject` (`idProject`),
  ADD KEY `productprojectProduct` (`idProduct`);

--
-- Index pour la table `productstructure`
--
ALTER TABLE `productstructure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ProductStructureProduct` (`idProduct`),
  ADD KEY `ProductStructureComponent` (`idComponent`);

--
-- Index pour la table `productversionstructure`
--
ALTER TABLE `productversionstructure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ProductVersionStructureProduct` (`idProductVersion`),
  ADD KEY `ProductVersionStructureComponent` (`idComponentVersion`);

--
-- Index pour la table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`),
  ADD KEY `projectProject` (`idProject`),
  ADD KEY `projectClient` (`idClient`),
  ADD KEY `projectUser` (`idUser`),
  ADD KEY `projectContact` (`idContact`),
  ADD KEY `projectRecipient` (`idRecipient`),
  ADD KEY `projectStatus` (`idStatus`);

--
-- Index pour la table `projecthistory`
--
ALTER TABLE `projecthistory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `projecthistoryProjectDay` (`idProject`,`day`);

--
-- Index pour la table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id`),
  ADD KEY `providerProviderType` (`idProviderType`);

--
-- Index pour la table `quality`
--
ALTER TABLE `quality`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questionProject` (`idProject`),
  ADD KEY `questionType` (`idQuestionType`),
  ADD KEY `questionUser` (`idUser`),
  ADD KEY `questionResource` (`idResource`),
  ADD KEY `questionStatus` (`idStatus`);

--
-- Index pour la table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quotationProject` (`idProject`),
  ADD KEY `quotationUser` (`idUser`),
  ADD KEY `quotationResource` (`idResource`),
  ADD KEY `quotationStatus` (`idStatus`),
  ADD KEY `quotationType` (`idQuotationType`),
  ADD KEY `quotationClient` (`idClient`),
  ADD KEY `quotationContact` (`idContact`);

--
-- Index pour la table `recipient`
--
ALTER TABLE `recipient`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `referencable`
--
ALTER TABLE `referencable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reportCategory` (`idReportCategory`);

--
-- Index pour la table `reportcategory`
--
ALTER TABLE `reportcategory`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `reportparameter`
--
ALTER TABLE `reportparameter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reportparameterReport` (`idReport`);

--
-- Index pour la table `requirement`
--
ALTER TABLE `requirement`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requirementProject` (`idProject`),
  ADD KEY `requirementProduct` (`idProduct`),
  ADD KEY `requirementVersion` (`idVersion`),
  ADD KEY `requirementType` (`idRequirementType`),
  ADD KEY `requirementUser` (`idUser`),
  ADD KEY `requirementRequirement` (`idRequirement`),
  ADD KEY `requirementStatus` (`idStatus`),
  ADD KEY `requirementResource` (`idResource`),
  ADD KEY `requirementTargetVersion` (`idTargetVersion`),
  ADD KEY `requirementUrgency` (`idUrgency`),
  ADD KEY `requirementCriticality` (`idCriticality`),
  ADD KEY `requirementFeasibility` (`idFeasibility`),
  ADD KEY `requiremenRiskLevel` (`idRiskLevel`);

--
-- Index pour la table `resolution`
--
ALTER TABLE `resolution`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `resource`
--
ALTER TABLE `resource`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userProfile` (`idProfile`),
  ADD KEY `userTeam` (`idTeam`),
  ADD KEY `userIsResource` (`isResource`),
  ADD KEY `userIsUser` (`isUser`),
  ADD KEY `userIsContact` (`isContact`),
  ADD KEY `userRecipient` (`idRecipient`);

--
-- Index pour la table `resourcecost`
--
ALTER TABLE `resourcecost`
  ADD PRIMARY KEY (`id`),
  ADD KEY `resourcecostResource` (`idResource`);

--
-- Index pour la table `restricttype`
--
ALTER TABLE `restricttype`
  ADD PRIMARY KEY (`id`),
  ADD KEY `restricttypeProjectType` (`idProjectType`,`className`,`idType`),
  ADD KEY `restricttypeProject` (`idProject`,`className`,`idType`),
  ADD KEY `restricttypeProfile` (`idProfile`,`className`,`idType`);

--
-- Index pour la table `risk`
--
ALTER TABLE `risk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `riskProject` (`idProject`),
  ADD KEY `riskUser` (`idUser`),
  ADD KEY `riskResource` (`idResource`),
  ADD KEY `riskStatus` (`idStatus`),
  ADD KEY `riskType` (`idRiskType`),
  ADD KEY `riskSeverity` (`idSeverity`),
  ADD KEY `riskLikelihood` (`idLikelihood`),
  ADD KEY `riskCriticality` (`idCriticality`);

--
-- Index pour la table `risklevel`
--
ALTER TABLE `risklevel`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `runstatus`
--
ALTER TABLE `runstatus`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `severity`
--
ALTER TABLE `severity`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sla`
--
ALTER TABLE `sla`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `statusmail`
--
ALTER TABLE `statusmail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `statusmailStatus` (`idStatus`),
  ADD KEY `statusmailMailable` (`idMailable`);

--
-- Index pour la table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tender`
--
ALTER TABLE `tender`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenderProject` (`idProject`),
  ADD KEY `tenderType` (`idTenderType`),
  ADD KEY `tenderProvider` (`idProvider`),
  ADD KEY `tenderStatusIndex` (`idStatus`),
  ADD KEY `tenderTenderStatus` (`idTenderStatus`),
  ADD KEY `tenderCallForTender` (`idCallForTender`);

--
-- Index pour la table `tenderevaluation`
--
ALTER TABLE `tenderevaluation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenderevaluationTenderEvaluationCriteria` (`idTenderEvaluationCriteria`),
  ADD KEY `tenderevaluationTender` (`idTender`);

--
-- Index pour la table `tenderevaluationcriteria`
--
ALTER TABLE `tenderevaluationcriteria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenderevaluationcriteriaCallForTender` (`idCallForTender`);

--
-- Index pour la table `tenderstatus`
--
ALTER TABLE `tenderstatus`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `term`
--
ALTER TABLE `term`
  ADD PRIMARY KEY (`id`),
  ADD KEY `termProject` (`idProject`),
  ADD KEY `termBill` (`idBill`);

--
-- Index pour la table `testcase`
--
ALTER TABLE `testcase`
  ADD PRIMARY KEY (`id`),
  ADD KEY `testcaseProject` (`idProject`),
  ADD KEY `testcaseProduct` (`idProduct`),
  ADD KEY `testcaseVersion` (`idVersion`),
  ADD KEY `testcaseType` (`idTestCaseType`),
  ADD KEY `testcaseUser` (`idUser`),
  ADD KEY `testcaseTestCase` (`idTestCase`),
  ADD KEY `testcaseStatus` (`idStatus`),
  ADD KEY `testcaseResource` (`idResource`),
  ADD KEY `testcasePriority` (`idPriority`),
  ADD KEY `testcaseRunStatus` (`idRunStatus`);

--
-- Index pour la table `testcaserun`
--
ALTER TABLE `testcaserun`
  ADD PRIMARY KEY (`id`),
  ADD KEY `testcaserunTestCase` (`idTestCase`),
  ADD KEY `testcaserunTestSession` (`idTestSession`),
  ADD KEY `testcaserunRunStatus` (`idRunStatus`),
  ADD KEY `testcaserunTicket` (`idTicket`);

--
-- Index pour la table `testsession`
--
ALTER TABLE `testsession`
  ADD PRIMARY KEY (`id`),
  ADD KEY `testsessionProject` (`idProject`),
  ADD KEY `testsessionProduct` (`idProduct`),
  ADD KEY `testsessionVersion` (`idVersion`),
  ADD KEY `testsessionType` (`idTestSessionType`),
  ADD KEY `testsessionUser` (`idUser`),
  ADD KEY `testsessionStatus` (`idStatus`),
  ADD KEY `testsessionResource` (`idResource`);

--
-- Index pour la table `textable`
--
ALTER TABLE `textable`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticketProject` (`idProject`),
  ADD KEY `ticketUser` (`idUser`),
  ADD KEY `ticketResource` (`idResource`),
  ADD KEY `ticketStatus` (`idStatus`),
  ADD KEY `ticketType` (`idTicketType`),
  ADD KEY `ticketActivity` (`idActivity`),
  ADD KEY `ticketUrgency` (`idUrgency`),
  ADD KEY `ticketPriority` (`idPriority`),
  ADD KEY `ticketCriticality` (`idCriticality`);

--
-- Index pour la table `today`
--
ALTER TABLE `today`
  ADD PRIMARY KEY (`id`),
  ADD KEY `todayUser` (`idUser`);

--
-- Index pour la table `todayparameter`
--
ALTER TABLE `todayparameter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `todayParameterUser` (`idUser`),
  ADD KEY `todayParameterReport` (`idReport`),
  ADD KEY `todayParameterToiday` (`idToday`);

--
-- Index pour la table `trend`
--
ALTER TABLE `trend`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typeScope` (`scope`);

--
-- Index pour la table `urgency`
--
ALTER TABLE `urgency`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `version`
--
ALTER TABLE `version`
  ADD PRIMARY KEY (`id`),
  ADD KEY `versionProduct` (`idProduct`),
  ADD KEY `versionContact` (`idContact`),
  ADD KEY `versionResource` (`idResource`);

--
-- Index pour la table `versionproject`
--
ALTER TABLE `versionproject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `versionprojectProject` (`idProject`),
  ADD KEY `versionprojectVersion` (`idVersion`);

--
-- Index pour la table `visibilityscope`
--
ALTER TABLE `visibilityscope`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `work`
--
ALTER TABLE `work`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `workReference` (`idAssignment`,`workDate`,`idWorkElement`),
  ADD KEY `workDay` (`day`),
  ADD KEY `workWeek` (`week`),
  ADD KEY `workMonth` (`month`),
  ADD KEY `workYear` (`year`),
  ADD KEY `workRef` (`refType`,`refId`),
  ADD KEY `workResource` (`idResource`),
  ADD KEY `workAssignment` (`idAssignment`),
  ADD KEY `workBill` (`idBill`),
  ADD KEY `workWorkelement` (`idWorkElement`);

--
-- Index pour la table `workelement`
--
ALTER TABLE `workelement`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `workelementReference` (`refType`,`refId`),
  ADD KEY `workelementUser` (`idUser`),
  ADD KEY `workelementActivity` (`idActivity`);

--
-- Index pour la table `workflow`
--
ALTER TABLE `workflow`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `workflowstatus`
--
ALTER TABLE `workflowstatus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workflowstatusProfile` (`idProfile`),
  ADD KEY `workflowstatusWorkflow` (`idWorkflow`),
  ADD KEY `workflowstatusStatusFrom` (`idStatusFrom`),
  ADD KEY `workflowstatusStatusTo` (`idStatusTo`);

--
-- Index pour la table `workperiod`
--
ALTER TABLE `workperiod`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workPeriodResource` (`idResource`),
  ADD KEY `workPeriodPeriod` (`periodRange`,`periodValue`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `accessprofile`
--
ALTER TABLE `accessprofile`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `accessright`
--
ALTER TABLE `accessright`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;
--
-- AUTO_INCREMENT pour la table `accessscope`
--
ALTER TABLE `accessscope`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `action`
--
ALTER TABLE `action`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `activity`
--
ALTER TABLE `activity`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `activityprice`
--
ALTER TABLE `activityprice`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `affectation`
--
ALTER TABLE `affectation`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT pour la table `alert`
--
ALTER TABLE `alert`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT pour la table `approver`
--
ALTER TABLE `approver`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `attachment`
--
ALTER TABLE `attachment`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `audit`
--
ALTER TABLE `audit`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `auditsummary`
--
ALTER TABLE `auditsummary`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `billline`
--
ALTER TABLE `billline`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `calendar`
--
ALTER TABLE `calendar`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT pour la table `calendardefinition`
--
ALTER TABLE `calendardefinition`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `callfortender`
--
ALTER TABLE `callfortender`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `checklist`
--
ALTER TABLE `checklist`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `checklistable`
--
ALTER TABLE `checklistable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `checklistdefinition`
--
ALTER TABLE `checklistdefinition`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `checklistdefinitionline`
--
ALTER TABLE `checklistdefinitionline`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `checklistline`
--
ALTER TABLE `checklistline`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `collapsed`
--
ALTER TABLE `collapsed`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT pour la table `columnselector`
--
ALTER TABLE `columnselector`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=850;
--
-- AUTO_INCREMENT pour la table `command`
--
ALTER TABLE `command`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `context`
--
ALTER TABLE `context`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `contexttype`
--
ALTER TABLE `contexttype`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `copyable`
--
ALTER TABLE `copyable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `criticality`
--
ALTER TABLE `criticality`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `cronexecution`
--
ALTER TABLE `cronexecution`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `decision`
--
ALTER TABLE `decision`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `delay`
--
ALTER TABLE `delay`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `delayunit`
--
ALTER TABLE `delayunit`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `deliverymode`
--
ALTER TABLE `deliverymode`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `dependable`
--
ALTER TABLE `dependable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `dependency`
--
ALTER TABLE `dependency`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `document`
--
ALTER TABLE `document`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `documentdirectory`
--
ALTER TABLE `documentdirectory`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `documentversion`
--
ALTER TABLE `documentversion`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `efficiency`
--
ALTER TABLE `efficiency`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `expensedetail`
--
ALTER TABLE `expensedetail`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `expensedetailtype`
--
ALTER TABLE `expensedetailtype`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `extrahiddenfield`
--
ALTER TABLE `extrahiddenfield`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `favorite`
--
ALTER TABLE `favorite`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `favoriteparameter`
--
ALTER TABLE `favoriteparameter`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `feasibility`
--
ALTER TABLE `feasibility`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `filter`
--
ALTER TABLE `filter`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `filtercriteria`
--
ALTER TABLE `filtercriteria`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `habilitation`
--
ALTER TABLE `habilitation`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1056;
--
-- AUTO_INCREMENT pour la table `habilitationother`
--
ALTER TABLE `habilitationother`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT pour la table `habilitationreport`
--
ALTER TABLE `habilitationreport`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;
--
-- AUTO_INCREMENT pour la table `health`
--
ALTER TABLE `health`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2331;
--
-- AUTO_INCREMENT pour la table `importable`
--
ALTER TABLE `importable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT pour la table `importlog`
--
ALTER TABLE `importlog`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `indicator`
--
ALTER TABLE `indicator`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT pour la table `indicatorable`
--
ALTER TABLE `indicatorable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT pour la table `indicatorableindicator`
--
ALTER TABLE `indicatorableindicator`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT pour la table `indicatordefinition`
--
ALTER TABLE `indicatordefinition`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `indicatorvalue`
--
ALTER TABLE `indicatorvalue`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `issue`
--
ALTER TABLE `issue`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `likelihood`
--
ALTER TABLE `likelihood`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `link`
--
ALTER TABLE `link`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `linkable`
--
ALTER TABLE `linkable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `list`
--
ALTER TABLE `list`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000003;
--
-- AUTO_INCREMENT pour la table `mail`
--
ALTER TABLE `mail`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `mailable`
--
ALTER TABLE `mailable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT pour la table `measureunit`
--
ALTER TABLE `measureunit`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `meeting`
--
ALTER TABLE `meeting`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT pour la table `menucustom`
--
ALTER TABLE `menucustom`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `menuselector`
--
ALTER TABLE `menuselector`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `milestone`
--
ALTER TABLE `milestone`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `mutex`
--
ALTER TABLE `mutex`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `opportunity`
--
ALTER TABLE `opportunity`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `origin`
--
ALTER TABLE `origin`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `originable`
--
ALTER TABLE `originable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `otherversion`
--
ALTER TABLE `otherversion`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `overallprogress`
--
ALTER TABLE `overallprogress`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `parameter`
--
ALTER TABLE `parameter`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;
--
-- AUTO_INCREMENT pour la table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `paymentdelay`
--
ALTER TABLE `paymentdelay`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `paymentmode`
--
ALTER TABLE `paymentmode`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `periodicity`
--
ALTER TABLE `periodicity`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `periodicmeeting`
--
ALTER TABLE `periodicmeeting`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `plannedwork`
--
ALTER TABLE `plannedwork`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3724;
--
-- AUTO_INCREMENT pour la table `planningelement`
--
ALTER TABLE `planningelement`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT pour la table `planningmode`
--
ALTER TABLE `planningmode`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT pour la table `plugin`
--
ALTER TABLE `plugin`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `plugintriggeredevent`
--
ALTER TABLE `plugintriggeredevent`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `predefinedtext`
--
ALTER TABLE `predefinedtext`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `priority`
--
ALTER TABLE `priority`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `privacy`
--
ALTER TABLE `privacy`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `productproject`
--
ALTER TABLE `productproject`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `productstructure`
--
ALTER TABLE `productstructure`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `productversionstructure`
--
ALTER TABLE `productversionstructure`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `projecthistory`
--
ALTER TABLE `projecthistory`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `provider`
--
ALTER TABLE `provider`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `quality`
--
ALTER TABLE `quality`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `quotation`
--
ALTER TABLE `quotation`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `recipient`
--
ALTER TABLE `recipient`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `referencable`
--
ALTER TABLE `referencable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT pour la table `reportcategory`
--
ALTER TABLE `reportcategory`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `reportparameter`
--
ALTER TABLE `reportparameter`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT pour la table `requirement`
--
ALTER TABLE `requirement`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `resolution`
--
ALTER TABLE `resolution`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `resource`
--
ALTER TABLE `resource`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `resourcecost`
--
ALTER TABLE `resourcecost`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `restricttype`
--
ALTER TABLE `restricttype`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `risk`
--
ALTER TABLE `risk`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `risklevel`
--
ALTER TABLE `risklevel`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `runstatus`
--
ALTER TABLE `runstatus`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `severity`
--
ALTER TABLE `severity`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `sla`
--
ALTER TABLE `sla`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `statusmail`
--
ALTER TABLE `statusmail`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT pour la table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `tender`
--
ALTER TABLE `tender`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `tenderevaluation`
--
ALTER TABLE `tenderevaluation`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `tenderevaluationcriteria`
--
ALTER TABLE `tenderevaluationcriteria`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `tenderstatus`
--
ALTER TABLE `tenderstatus`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `term`
--
ALTER TABLE `term`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `testcase`
--
ALTER TABLE `testcase`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `testcaserun`
--
ALTER TABLE `testcaserun`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `testsession`
--
ALTER TABLE `testsession`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `textable`
--
ALTER TABLE `textable`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT pour la table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `today`
--
ALTER TABLE `today`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT pour la table `todayparameter`
--
ALTER TABLE `todayparameter`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `trend`
--
ALTER TABLE `trend`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT pour la table `urgency`
--
ALTER TABLE `urgency`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `version`
--
ALTER TABLE `version`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `versionproject`
--
ALTER TABLE `versionproject`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `visibilityscope`
--
ALTER TABLE `visibilityscope`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `work`
--
ALTER TABLE `work`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT pour la table `workelement`
--
ALTER TABLE `workelement`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `workflow`
--
ALTER TABLE `workflow`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `workflowstatus`
--
ALTER TABLE `workflowstatus`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=672;
--
-- AUTO_INCREMENT pour la table `workperiod`
--
ALTER TABLE `workperiod`
  MODIFY `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
